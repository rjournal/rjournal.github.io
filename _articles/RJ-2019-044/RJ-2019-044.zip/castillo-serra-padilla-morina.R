###################################
##  The ercv package
###################################
## Packages and options

library("ercv") 
#library("evir") 
#library("poweRlaw") 
options(digits = 3)
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## S3:Examples
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
data(iFFT)
data(FFT)
data(BIFP)
data(MA)
data("moby", package = "poweRlaw")
data("danish",package = "evir")
data("nidd.thresh",package = "evir")
data(bilbao)
data("EURUSD")
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Transformed variables

prices<-ts(EURUSD$EUR.USD,frequency=365,start=1999) 
#plot(prices,col="blue",main="euro/dollar daily 	prices(1999-2016)") 
return <- 100*diff(log(prices)); 
pos.return <- subset(return, return >0); 
neg.return <- -subset(return, return <0);
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Exploratory data analysis
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Figure 1

pdf("Exploratory.pdf")
par(mfrow=c(3,3))   # 3 figures arranged in 3 rows and 3 columns

cvplot(iFFT,median(iFFT),main="iFFT")
cvplot(FFT,median(FFT),main="FFT")
cvplot(BIFP,median(BIFP),main="BIFP")

cvplot(MA,median(MA),main="MA")
cvplot(moby)
cvplot(danish,main="Danish")

cvplot(nidd.thresh,main="Nidd")
cvplot(bilbao,evi=c(0,-1),main="Bilbao")
cvplot(pos.return,main="EUR/USD")

dev.off()
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## S4:Estimation and Model diagnostics
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

set.seed(1)

Tm(nidd.thresh,evi=0, nextremes = 75)
Tm(nidd.thresh)
Tm(bilbao,evi=-1,nsim=1000)
Tm(bilbao,nsim=1000)
cievi(nextremes=length(bilbao),evi=-0.685)
Tm(pos.return,m=50,evi=0,thr=0.1,nsim=1000)
Tm(neg.return,m=50,evi=0,thr=0.1,nsim=1000)

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## S5: Threshold selection algorithm
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

DF <- thrselect(nidd.thresh,m=10, nsim=1000)
print(DF$options,digits=4)
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## S6: Transformation from heavy to light tails
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Transformed variables

tdanish <- tdata(danish)
tmoby<- tdata(moby)
# cvplot(tdanish, main="(a) Transformed Danish")
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Figure 2

pdf("Transformed.pdf",width=7, height=3.5)
par(mfrow=c(1,2))   # 2 figures arranged in 1 rows and 2 columns

cvplot(tdanish, main="(a) Transformed Danish")
cvplot(tmoby,main="(b) Transformed MobyDick")

dev.off()

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

t4moby<-tdata(moby,thr=4)
Tm(t4moby,m=50,nsim=1000) 
Tm(tdanish,m=20,nextremes = 951,omit = 8, nsim = 1000)

DF<-thrselect(tdanish,m=30, nsim = 1000) 

cievi(116,evi=-0.596)
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## S7: Fitting PoT parameters and tail plots 
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# Fitting and ccdfplot (Section 7)

fit1<-fitpot(danish,nextremes=116);fit1               #MLE 
fit2<-fitpot(danish,evi=0.598,nextremes=116);fit2     #CV

#ccdfplot(danish,pars=list(fit1),main="Danish (log scale) by MLE",ci=TRUE)
#ccdfplot(danish,pars=list(fit2),log="xy",main="Danish (log-log scale) by CV",ci=TRUE)

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Figure 3

pdf("ccdf_Danish.pdf",width=7, height=3.5)
par(mfrow=c(1,2))   # 2 figures arranged in 1 rows and 2 columns

ccdfplot(danish,pars=list(fit1,fit2),main="(a) Danish (log scale)")
ccdfplot(danish,pars=list(fit1,fit2),log="xy",main="(b) Danish (log-log scale)")

dev.off()
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# Power law approach

# Sigma parameters
fit1<-as.numeric(fit1$coeff);sg1<- fit1[2]/fit1[1];sg1
fit2<-as.numeric(fit2$coeff);sg2<- fit2[2]/fit2[1];sg2

# Subsets of the 116 upper extremes to the new origins
exDanish<-danish[danish>fit1[3]]-fit1[3]  #set the origin to zero
exDanish1<- exDanish+sg1              #set the origin to extrems a sg1
exDanish2<- exDanish+sg2              #set the origin to extrems a sg2

# Parameters for the 116 upper extremes
exfit1<-c(fit1[1],fit1[2],sg1,1)
exfit2<-c(fit2[1],fit2[2],sg2,1)
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Figure 4

pdf("linear_Danish.pdf",width=7, height=3.5)
par(mfrow=c(1,2))   # 2 figures arranged in 1 rows and 2 columns

ccdfplot(exDanish1, pars=list(exfit1),log="xy",main="(a) Danish extremes by MLE")
ccdfplot(exDanish2, pars=list(exfit2),log="xy",main="(b) Danish extremes by CV")

dev.off()
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
## Maximum correlation with threshold th
## cor(x,y), x=dat+th,  y=log(1-Fn)

corth<- function(dat,th=0) {n<- length(dat);x<- th+dat;x<- sort(x)
Fn<-seq(1:n)/(n+1);y<-1-Fn;cor(log(y),log(x))}

c(sg1,corth(exDanish,sg1))    #MLE cor = - 0.981
c(sg2,corth(exDanish,sg2))    #CV m?s correlacionat cor = - -0.990

# Optimization
mcor<-function(th){corth(exDanish,th)}
optimize(mcor,lower=0.6,upper=20,maximum=F)

# citation(package = "ismev", lib.loc = NULL, auto = NULL)