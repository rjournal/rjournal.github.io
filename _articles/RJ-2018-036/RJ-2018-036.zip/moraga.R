####################################################################
# Small Area Disease Risk Estimation and Visualization using R
# by Paula Moraga
####################################################################

# The R package is not on CRAN because it uses some external C libraries that make difficult to build the binaries.
# Therefore, we need to install it adding the URL of the INLA repository:
  
install.packages("INLA", repos = "https://inla.r-inla-download.org/R/stable", dep = TRUE)

# Data
library(SpatialEpi)
data(pennLC)

# Observed cases
d <- aggregate(x = pennLC$data$cases, by = list(county = pennLC$data$county), FUN = sum)
names(d) <- c("id", "Y")

# Expected cases
pennLC$data <- pennLC$data[order(pennLC$data$county, pennLC$data$race,
                                 pennLC$data$gender, pennLC$data$age), ]
population <- pennLC$data$population
cases <- pennLC$data$cases
n.strata <- 16
E <- expected(population, cases, n.strata)
d$E <- E[match(d$id, unique(pennLC$data$county))]

# Smokers proportions
d <- merge(d, pennLC$smoking, by.x = "id", by.y = "county")

# SIRs
d$SIR <- d$Y/d$E

# Add data to map
library(sp)
rownames(d) <- d$id
map <- SpatialPolygonsDataFrame(pennLC$spatial.polygon, d, match.ID = TRUE)
head(map@data)

# Mapping variables
library(leaflet)
l <- leaflet(map) %>% addTiles()
pal <- colorNumeric(palette = "YlOrRd", domain = map$SIR)
l %>% addPolygons(color = "grey", weight = 1, fillColor = ~pal(SIR), fillOpacity = 0.5) %>%
  addLegend(pal = pal, values = ~SIR, opacity = 0.5, title = "SIR", position = "bottomright")

labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
Smokers proportion: %s <br/> SIR: %s",
                  map$id, map$Y, round(map$E, 2), map$smoking, round(map$SIR, 2)) %>%
  lapply(htmltools::HTML)
l %>% addPolygons(color = "grey", weight = 1, fillColor = ~pal(SIR), fillOpacity = 0.5,
                  highlightOptions = highlightOptions(weight = 4), label = labels,
                  labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                           padding = "3px 8px"),
                                              textsize = "15px", direction = "auto")) %>%
  addLegend(pal = pal, values = ~SIR, opacity = 0.5, title = "SIR", position = "bottomright")

# Neighbourhood matrix
library(spdep)
library(INLA)
nb <- poly2nb(map)
head(nb)
nb2INLA("map.adj", nb)
g <- inla.read.graph(filename = "map.adj")

# Inference using INLA
map$re_u <- 1:nrow(map@data)
map$re_v <- 1:nrow(map@data)

formula <- Y ~ smoking + f(re_u, model = "besag", graph = g) + f(re_v, model = "iid")

res <- inla(formula, family = "poisson", data = map@data, E = E,
            control.predictor = list(compute = TRUE))

# Results
summary(res)

library(ggplot2)
marginal <- inla.smarginal(res$marginals.fixed$smoking)
marginal <- data.frame(marginal)
ggplot(marginal, aes(x = x, y = y)) + geom_line() +
  labs(x = expression(beta[1]), y = "Density") +
  geom_vline(xintercept = 0, col = "blue") + theme_bw()

head(res$summary.fitted.values)

map$RR <- res$summary.fitted.values[, "mean"]
map$LL <- res$summary.fitted.values[, "0.025quant"]
map$UL <- res$summary.fitted.values[, "0.975quant"]

# Mapping disease risk
pal <- colorNumeric(palette = "YlOrRd", domain = map$RR)
labels <- sprintf("<strong> %s </strong> <br/> Observed: %s <br/> Expected: %s <br/>
                  Smokers proportion: %s <br/> SIR: %s <br/> RR: %s (%s, %s)",
                  map$id, map$Y, round(map$E, 2), map$smoking, round(map$SIR, 2),
                  round(map$RR, 2), round(map$LL, 2), round(map$UL, 2)) %>%
  lapply(htmltools::HTML)
leaflet(map) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px", direction = "auto")) %>%
  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR", position = "bottomright")

# Map disease risk with the same scale as map of SIR

pal <- colorNumeric(palette = "YlOrRd", domain = map$SIR)

leaflet(map) %>% addTiles() %>%
  addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5,
              highlightOptions = highlightOptions(weight = 4), label = labels,
              labelOptions = labelOptions(style = list("font-weight" = "normal",
                                                       padding = "3px 8px"),
                                          textsize = "15px", direction = "auto")) %>%
  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR", position = "bottomright")

# Range of values of SIRs and RRs

range(map@data$SIR)
range(map@data$RR)