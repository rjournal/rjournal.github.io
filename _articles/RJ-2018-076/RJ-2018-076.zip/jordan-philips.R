# Replication script for the manuscript ``Dynamic Simulation and Testing for Single-Equation Cointegrating and Stationary Autoregressive Distributed Lag Models''
# Jordan and Philips
# Illustrating the package dynamac 0.1.4 for the R Journal

# Get the package from https://andyphilips.github.io/dynamac/ or CRAN
library(dynamac) # Loads inequality data (ineq)
library(urca) # Suggested for time series testing

data(ineq)
data(supreme.sup)

# Test for stationarity in Concern
summary(ur.df(ineq$concern, type = c("none"), lags = 1))
summary(ur.pp(ineq$concern, type = c("Z-tau"), model = c("constant"), use.lag = 1))
summary(ur.ers(ineq$concern, type = c("DF-GLS"), model = c("constant"), lag.max = 1)) 
summary(ur.kpss(ineq$concern, type = c("mu"), use.lag = 1))

# Test for stationarity in difference of Concern
summary(ur.df(diff(ineq$concern), type = c("none"), lags = 1))
summary(ur.pp(diff(ineq$concern), type = c("Z-tau"), model = c("constant"), use.lag = 1))
summary(ur.ers(diff(ineq$concern), type = c("DF-GLS"), model = c("constant"), lag.max = 1)) 
summary(ur.kpss(diff(ineq$concern), type = c("mu"), use.lag = 1))

# Test for stationarity in Unemployment Rate
summary(ur.df(ineq$urate, type = c("none"), lags = 1))
summary(ur.pp(ineq$urate, type = c("Z-tau"), model = c("constant"), use.lag = 1))
summary(ur.ers(ineq$urate, type = c("DF-GLS"), model = c("constant"), lag.max = 1)) 
summary(ur.kpss(ineq$urate, type = c("mu"), use.lag = 1))

# Test for stationarity in difference of Unemployment Rate
summary(ur.df(diff(ineq$urate), type = c("none"), lags = 1))
summary(ur.pp(diff(ineq$urate), type = c("Z-tau"), model = c("constant"), use.lag = 1))
summary(ur.ers(diff(ineq$urate), type = c("DF-GLS"), model = c("constant"), lag.max = 1)) 
summary(ur.kpss(diff(ineq$urate), type = c("mu"), use.lag = 1))

# Test for stationarity in Income Share of the Top 10
summary(ur.df(ineq$incshare10, type = c("none"), lags = 1))
summary(ur.pp(ineq$incshare10, type = c("Z-tau"), model = c("constant"), use.lag = 1))
summary(ur.ers(ineq$incshare10, type = c("DF-GLS"), model = c("constant"), lag.max = 1)) 
summary(ur.kpss(ineq$incshare10, type = c("mu"), use.lag = 1))

# Test for stationarity in difference of Income Share of the Top 10
summary(ur.df(diff(ineq$incshare10), type = c("none"), lags = 1))
summary(ur.pp(diff(ineq$incshare10), type = c("Z-tau"), model = c("constant"), use.lag = 1))
summary(ur.ers(diff(ineq$incshare10), type = c("DF-GLS"), model = c("constant"), lag.max = 1)) 
summary(ur.kpss(diff(ineq$incshare10), type = c("mu"), use.lag = 1))

# Model 1
res1 <- dynardl(concern ~ incshare10 + urate, data = ineq,
	lags = list("concern" = 1, "incshare10" = 1),
	diffs = c("incshare10", "urate"),
	ec = TRUE, simulate = FALSE )

summary(res1$model)

dynardl.auto.correlated(res1)

res2 <- dynardl(concern ~ incshare10 + urate, data = ineq,
	lags = list("concern" = 1, "incshare10" = 1),
	diffs = c("incshare10", "urate"),
	lagdiffs = list("concern" = 1),
	ec = TRUE, simulate = FALSE)

dynardl.auto.correlated(res2) # No more autocorrelation

pssbounds(res2)

set.seed(2059120)
res3 <- dynardl(concern ~ incshare10 + urate, data = ineq,
	lags = list("concern" = 1, "incshare10" = 1),
	diffs = c("incshare10", "urate"),
	lagdiffs = list("concern" = 1),
	ec = TRUE, simulate = TRUE,
	shockvar = c("incshare10"), shockval = .07)

area.simulation.graph(res3)
spike.simulation.graph(res3)


## Supreme Court approval analysis

load("/.../supreme.rda")

res4 <- dynardl(dcalc ~ iddiv + congapp, data = supreme.sup,
	lags = list("dcalc" = 1),
	levels = list("iddiv", "congapp"),
	ec = FALSE, simulate = FALSE)

summary(res4$model)

res4 <- dynardl(dcalc ~ iddiv + congapp, data = supreme.sup,
	lags = list("dcalc" = 1),
	levels = list("iddiv", "congapp"),
	ec = FALSE, simulate = TRUE,
	shockval = -15, shockvar = c("congapp"))

res5 <- dynardl(dcalc ~ iddiv + congapp, data = supreme.sup,
	lags = list("dcalc" = 1),
	levels = list("iddiv", "congapp"),
	ec = FALSE, simulate = TRUE,
	shockval = -15, shockvar = c("congapp"),
	sims = 15000)

par(mfrow = c(2, 1))
area.simulation.graph(res4)
area.simulation.graph(res5)

res6 <- dynardl(dcalc ~ iddiv + congapp, data = supreme.sup,
	lags = list("dcalc" = 1),
	levels = c("iddiv", "congapp"),
	ec = FALSE, simulate = TRUE,
	shockval = -15, shockvar = c("congapp"),
	sims = 15000, time = 20, range = 50,
	forceset = list("iddiv" = 0.22, "congapp" = 72))

spike.simulation.graph(res6)


head(ineq$incshare10)
head(lshift(ineq$incshare10, 2))
head(dshift(ineq$incshare10))
head(ldshift(ineq$incshare10, 2))

