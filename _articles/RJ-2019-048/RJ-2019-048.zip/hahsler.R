#' ---
#' title: "Replication Code for Associative Classification in R: arc, arulesCBA, and rCBA"
#' author: "Michael Hahsler"
#' output:
#'  html_document:
#'    toc: true
#' ---

options(digits = 2)
set.seed(1234)

library("arules")

#' # Prepare data
#'
#' Load data
data("iris")

#' Shuffle and split into training and test set (80/20 split)
iris <- iris[sample(seq(nrow(iris))),]

iris_train <- iris[1:(nrow(iris)*.8), ]
iris_test <- iris[-(1:(nrow(iris)*.8)),]

head(iris_train)


#' Discretization, conversion to transactions and mining CARs
library("arules")
library("arulesCBA")
iris_train_disc <- discretizeDF.supervised(Species ~ .,
	data = iris_train, method = "mdlp")
head(iris_train_disc)

#' Breaks
sapply(iris_train_disc, attr, "discretized:breaks")

#' # Mine class rules (CARs)
trans_train <- as(iris_train_disc, "transactions")
trans_train

inspect(head(trans_train))

rules <- apriori(trans_train, parameter = list(support = 0.01, confidence = 0.8),
  appearance = list(rhs = grep("Species=",  itemLabels(trans_train), value = TRUE),
  default = "lhs"))
rules

inspect(head(rules, n = 3))

#' Discretize new data consistently with the training data
iris_test_disc <- discretizeDF(iris_test, iris_train_disc)
trans_test <- as(iris_test_disc, "transactions")
inspect(head(trans_test))

#' # arc
library("arc")
classifier <- arc::cba(iris_train, "Species")

inspect(classifier@rules)

predict(classifier, head(iris_test))

classifier <- arc::cba(iris_train, "Species",
  rulelearning_options = list(minsupp = 0.05, minconf = 0.9,
    minlen=1, maxlen=5, maxtime=1000, target_rule_count=50000, trim=TRUE,
    find_conf_supp_thresholds = FALSE))
classifier@rules

inspect(classifier@rules)

#' # arulesCBA
library("arulesCBA")

classifier <- arulesCBA::CBA(Species ~ ., data = iris_train,
  supp = 0.05, confidence = 0.9)
classifier

predict(classifier, head(iris_test))

inspect(rules(classifier))

#' ## Create a custom classifier
rules <- mineCARs(Species ~ ., trans_train,
  parameter = list(support = 0.01, confidence = 0.8))

classifier <- arulesCBA::CBA_ruleset(Species ~ ., rules, method = "majority")
classifier

#' # rCBA
library("rCBA")

classifier <- rCBA::build(iris_train)
classifier$model

rCBA::classification(head(iris_test), classifier$model)

#' ## Example with FP-Growth
rulebase <- rCBA::fpgrowth(trans_train, support = 0.05, confidence = 0.9,
    consequent = "Species")

#' Apply M2 pruning
rulebase <- rCBA::pruning(trans_train, rulebase, method = "m2cba")

#' Make preditions
rCBA::classification(head(trans_test), rulebase)
