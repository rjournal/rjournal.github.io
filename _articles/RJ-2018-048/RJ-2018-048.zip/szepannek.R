### example

library(clustMixType)
set.seed(42)

n   <- 100
prb <- 0.9
muk <- qnorm(0.9) 
clusid <- rep(1:4, each = n)

x1 <- sample(c("A","B"), 2*n, replace = TRUE, prob = c(prb, 1-prb))
x1 <- c(x1, sample(c("A","B"), 2*n, replace = TRUE, prob = c(1-prb, prb)))
x1 <- as.factor(x1)

x2 <- sample(c("A","B"), 2*n, replace = TRUE, prob = c(prb, 1-prb))
x2 <- c(x2, sample(c("A","B"), 2*n, replace = TRUE, prob = c(1-prb, prb)))
x2 <- as.factor(x2)

x3 <- c(rnorm(n, mean = -muk), rnorm(n, mean = muk), rnorm(n, mean = -muk), rnorm(n, mean = muk))
x4 <- c(rnorm(n, mean = -muk), rnorm(n, mean = muk), rnorm(n, mean = -muk), rnorm(n, mean = muk))

x <- data.frame(x1,x2,x3,x4)

kpres <- kproto(x, 4)
kpres
summary(kpres)

#png("C:/clprofiles.png",width = 960)
library(wesanderson)

#par(mfrow=c(2,2))
par(mfrow=c(1,2), lwd=1, cex = 1.4)
clprofiles(kpres, x[,c(1,3)], col = wes_palette("Royal1", 4, type = "continuous"))
par(ask=F)
#dev.off()


### comparison with kmeans and kmodes

library(klaR)
library(clusteval)

kmres  <- kmeans(x[,3:4], 4)
kmores <- kmodes(x[,1:2], 4)

cluster_similarity(kpres$cluster, clusid, similarity = "rand")
cluster_similarity(kmres$cluster, clusid, similarity = "rand")
cluster_similarity(kmores$cluster, clusid, similarity = "rand")


### screeplot

Es <- numeric(10)
for(i in 1:10){
  kpres <- kproto(x, k = i, nstart = 5)
  Es[i] <- kpres$tot.withinss
}


### small simulation of #variables vs. runtime

vs   <- c(2,4,8,16,32,64,128)
reps <- 50
tms <- matrix(NA, nrow=reps, ncol = length(vs))
colnames(tms) <- vs

for(j in seq(along=vs)){
  for(i in 1:reps){
    n <- 100
    v <- vs[j]/2
    
    prb <- 0.9
    muk <- qnorm(0.9) 
    clusid <- rep(1:4, each = n)
    
    x <- sample(c("A","B"), 2*n, replace = TRUE, prob = c(prb, 1-prb))
    x <- c(x, sample(c("A","B"), 2*n, replace = TRUE, prob = c(1-prb, prb)))
    x <- as.factor(x)
    y <- c(rnorm(n, mean = -muk), rnorm(n, mean = muk), rnorm(n, mean = -muk), rnorm(n, mean = muk))
    df <- data.frame(x, y)
    
    if(v > 1) {for(k in 2:v){
      x <- sample(c("A","B"), 2*n, replace = TRUE, prob = c(prb, 1-prb))
      x <- c(x, sample(c("A","B"), 2*n, replace = TRUE, prob = c(1-prb, prb)))
      x <- as.factor(x)
      y <- c(rnorm(n, mean = -muk), rnorm(n, mean = muk), rnorm(n, mean = -muk), rnorm(n, mean = muk))
      df <- data.frame(df, x, y)
    }}
    
    a <- proc.time()[3] 
    kpres <- kproto(df, 4)
    tms[i,j] <- proc.time()[3] - a
  }
}


#par(ask=F)
#png("C:/scree_and_runtime.png", width = 720, height = 360) 
par(lwd=2, cex=1, mfrow= c(1,2))
boxplot(tms, xlab = "# Variables", ylab = "Runtime [s]", col = "lightgrey")
plot(1:10, Es, type = "b", ylab = "Objective Function", xlab = "# Clusters", main = "Scree Plot")
#dev.off()


