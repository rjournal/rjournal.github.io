rm(list = ls())
gc()

library(rcss)
rate <- 0.06 ## Interest rate
step <- 0.02 ## Time step between decision epochs
vol <- 0.2 ## Volatility of stock price process
n_dec <- 51 ## Number of decision epochs
## Grid of evenly spaced points
n_grid <- 90 * 3 + 1 
grid <- as.matrix(cbind(rep(1, n_grid), seq(10, 100, length = n_grid)))
## Disturbance samples
n_disturb <- 10000 ## Number of disturbances
weight <- rep(1/n_disturb, n_disturb)
disturb <- array(0, dim = c(2, 2, n_disturb))
disturb[1, 1,] <- 1
quantile <- qnorm(seq(0, 1, length = (n_disturb + 2))[c(-1, -(n_disturb + 2))])
disturb[2, 2,] <- exp((rate - 0.5 * vol^2) * step + vol * sqrt(step) * quantile)
## Transition
control <- matrix(c(c(1, 1), c(2, 1)), nrow = 2, byrow = TRUE)
## Subgradient representation of reward
strike <- 40
in_money <- grid[,2] <= strike
reward <- array(0, dim = c(n_grid, 2, 2, 2, n_dec))       
reward[in_money, 1, 2, 2,] <- strike
reward[in_money, 2, 2, 2,] <- -1
for (i in 1:n_dec){
  reward[,,,,i] <- exp(-rate * step * (i - 1)) * reward[,,,,i] 
}
## Perform Bellman recursion
r_index <- matrix(c(2, 2), ncol = 2)
bellman <- FastBellman(grid, reward, control, disturb, weight, r_index)

## Plot the value function
setEPS()
postscript("bermuda_value.eps")
plot(grid[,2], rowSums(bellman$value[,,2,1] * grid), type = "l",
     xlab = "Stock Price", ylab = "Option Value")
dev.off()

## Generate paths
set.seed(12345)
start <- c(1, 36) ## starting state
n_path <- 1000
path_disturb <- array(0, dim = c(2, 2, n_dec - 1, n_path))
path_disturb[1,1,,] <- 1
rand1 <- rnorm(((n_dec - 1) * n_path) / 2)
rand1 <- c(rand1, -rand1)
path_disturb[2,2,,] <- exp((rate - 0.5 * vol^2) * step + vol * sqrt(step) * rand1)
path <- Path(start, path_disturb)
path_nn <- Neighbour(matrix(path, ncol = 2), grid, 1, "kdtree", 0, 1)$indices

## Reward function
RewardFunc <- function(state, time) {
    output <- array(data = 0, dim = c(nrow(state), 4))
    output[,4] <- exp(-0.06 * 0.02 * (time - 1)) * pmax(40 - state[,2], 0)
    return(output)
}

## Bact testing
path_policy <- PathPolicy(path, path_nn, control, RewardFunc, bellman$expected, grid)
test <- TestPolicy2(2, path, control, RewardFunc, path_policy)
## Histogram of cumulated rewards
setEPS()
postscript("bermuda_histogram.eps")
hist(test$value, xlab = "Cumulated Rewards", main = "")
dev.off()
## Average to exercise
ex <- rep(50, n_path)
for (i in 1:n_path) {
    if (!all(test$position[i,] - 1)) {
        ex[i] <- min(which(test$position[i,] == 1)) - 1
    }
}
setEPS()
postscript("bermuda_exercise.eps")
hist(ex, xlab = "Exercise Times", main = "")
dev.off()


rm(list = ls())
gc()

library(rcss)
## Set Parameters
rho <- 0
kappa <- 0.9
mu <- 0
sigma <- 0.5
K <- 0 
n_dec <- 101  ## number of time epochs
N <- 5  ## number of rights
n_pos <- N + 1 ## number of positions
## Grid
n_grid <- 1001
grid <- cbind(rep(1, n_grid), seq(-2, 2, length = n_grid))
## Control matrix
control <- cbind(c(1, 1:N), 1:(N + 1))
## Reward subgradient representation
reward <- array(0, dim = c(n_grid, 2,nrow(control), 2, n_dec))
slope <- exp(grid[, 2])
for (t in 1:n_dec) {
    discount <- exp(-rho * (t - 1))
    for (p in 2:n_pos) {
        intercept <- (exp(grid[,2]) - K * discount) - slope * grid[, 2]
        reward[, 1, p, 1, t] <- intercept
        reward[, 2, p, 1, t] <- slope
    }
}
## Disturbance matrices
n_disturb <- 10000
disturb <- array(0, dim = c(2, 2, n_disturb))
disturb[1, 1,] <- 1
disturb[2, 2,] <- 1 - kappa
quantile <- qnorm(seq(0, 1, length = (n_disturb + 2))[c(-1, -(n_disturb + 2))])
disturb[2,1,] <- kappa * mu + sigma * quantile
disturb_weight <- rep(1/n_disturb, n_disturb)
## Bellman recursion
r_index <- matrix(c(2, 1), ncol = 2)
bellman <- FastBellman(grid, reward, control, disturb, disturb_weight, r_index)

## Generate paths
set.seed(12345)
n_path <- 1000
path_disturb <- array(0, dim = c(2, 2,n_dec - 1, n_path))
path_disturb[1, 1,,] <- 1
path_disturb[2, 2,,] <- 1 - kappa
path_disturb[2, 1,,] <- kappa * mu + sigma * rnorm((n_dec - 1) * n_path)
start <- c(1, 0)
path <- Path(start, path_disturb)
path_nn <- Neighbour(matrix(path, ncol = 2), grid, 1, "kdtree", 0, 1)$indices
## Exact reward function
RewardFunc <- function(state, time) {
    output <- array(0, dim = c(nrow(state), nrow(control) * 2))
    discount <- exp(-rho * (time - 1))
    for (i in 2:nrow(control)) {
        output[, 2 * i - 1] <-
            pmax(exp(state[, 2]) - K * discount, 0)
    }
    return(output)
}
# Path policy
policy <- PathPolicy(path, path_nn, control, RewardFunc, bellman$expected, grid)


test <- TestPolicy2(2, path, control, RewardFunc, policy)
## Histogram of cumulated rewards
setEPS()
postscript("swing_histogram.eps")
hist(test$value, xlab = "Cumulated Rewards", main = "")
dev.off()

## Exercise times
ex <- rep(0, n_dec)
for (i in 1:n_path) {
    for (t in 1:n_dec) {
        if ((test$position[i, t] != 1) && (test$action[i, t] == 1)) {
            ex[t] <- ex[t] + 1
        }
    }
}
setEPS()
postscript("swing_exercise.eps")
plot(0:(n_dec - 1), ex, xlab = "Time", ylab = "Number of Exercises",
     type = "b", main = "")
dev.off()
