#### THIS IS THE CODE FROM THE REAL EXAMPLE SECTION:

library(HCmodelSets) 
data(LymphomaData)
x <- t(patient.data$x)
y <- patient.data$time
status <- patient.data$status

# Data Splitting
X.in = x[1:168,]
Y.in = y[1:168]
status.in = status[1:168]
  
X.out = x[169:240,]
Y.out = y[169:240]
status.out = status[169:240]

####################################
## HCmodelSets
####################################
Y = cbind(Y.in,status.in)

#Reduction Phase
out.1 =  Reduction.Phase(X=X.in,Y=Y,Cox.Hazard = TRUE, vector.signif = c(2,0.0025,0.001),
                                           seed.HC = 2)

v1 = out.1$List.Selection$`Hypercube with dim 2`$numSelected1
sort(v1)


out.2 =  Reduction.Phase(X=X.in,Y=Y,Cox.Hazard = TRUE,vector.signif = c(2,0.0025,0.001),
                         seed.HC = 11)

v2 = out.2$List.Selection$`Hypercube with dim 2`$numSelected1
sort(v2)

####################################
## LASSO
####################################
library(glmnet)
library(survival)
lasso.fit <- glmnet(X.in, Surv(Y.in,status.in), family = "cox", alpha = 1)

# tunned to pick the number of variables in the reduction phase
n.coefs = apply(coef(lasso.fit), 2, function(x) length(which(x!=0)))
idx.coefs = which(n.coefs == length(v1))
if(length(idx.coefs)==0){idx.coefs = min(which(n.coefs >= v1))}
lasso.var = which(coef(lasso.fit)[,idx.coefs[1]]!=0)
lasso.var


outcome.exp.phase =  Exploratory.Phase(X=X.in,Y=Y,
                                               list.reduction = v1, silent = FALSE,
                                               Cox.Hazard = TRUE, signif=0.01)

sq.terms = outcome.exp.phase$mat.select.SQ
in.terms = outcome.exp.phase$mat.select.INTER

out.MS = ModelSelection.Phase(X=X.out,Y=cbind(Y.out,status.out),
                              list.reduction = v1, Cox.Hazard = TRUE, sq.terms = sq.terms,
                              in.terms = in.terms, signif=0.05, modelSize=7)

## CODE TO PRODUCE TABLE 3
idxs = c(sort(v1),"3814 ^2" ,"6134 * 3824", "3814 * 6706")
big.table = NULL

for(kk in 1:length(out.MS$goodModels)){
  table = matrix(0,nrow(out.MS$goodModels[[kk]]),length(idxs))
  colnames(table) = idxs
  for (jj in 1:nrow(table)) {
    table[jj,which(is.element(idxs,out.MS$goodModels[[kk]][jj,]))]=1  
    
    if(table[jj,19]==1){
      table[jj,c(12,14)]=1
    } else if(table[jj,20]==1){
      table[jj,c(10,15)]=1
    }
    
  }
  big.table = rbind(big.table,table)
}

vec <- 1:20
big.table.coded = sweep(big.table,MARGIN=2,vec,`*`)

## sort
idx.sorts = sort(colSums(big.table),decreasing = TRUE)
big.table.sort = big.table[,names(idx.sorts)]

mat.probs = matrix(NA,length(idxs),length(idxs))
for(j in 1:ncol(mat.probs)){
  idxs.MnotB = which(big.table.sort[,j]==0)
  mat.probs[,j] = colSums(big.table.sort[idxs.MnotB,])/length(idxs.MnotB)
}
    
colnames(mat.probs) = rownames(mat.probs) = match(names(idx.sorts), idxs)

library(xtable)
xtable(mat.probs)








