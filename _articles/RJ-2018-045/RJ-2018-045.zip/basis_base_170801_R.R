#######################################################################################
## initial analysis of evaporate data in Section 2
#######################################################################################
## loading data
evaporat <- read.table("evaporat.txt", header=T); attach(evaporat)
Rat <- Maxat-Minat; Rvh <- Maxh-Minh; Rst <- Maxst-Minst
w <- c(scale(evaporat$Evap,center=TRUE,scale=TRUE)); detach(evaporat)
evaporat <- data.frame(evaporat, Rat, Rvh, Rst)
w2 <- cbind(w, w^2); w3 <- cbind(w2, w^3); w4 <- cbind(w3, w^4)

## dr-package fitting
sir5 <- dr(Evap~Avat+Rat+Avst+Rst, data=evaporat, method="sir", nslice=5)
save5 <- update(sir5, method="save"); phdres <- update(sir5, method="phdres")
cov2 <- dr(w2~Avat+Rat+Avst+Rst,data=evaporat, method="ols")
cov3 <- dr(w3~Avat+Rat+Avst+Rst,data=evaporat, method="ols")
cov4 <- dr(w4~Avat+Rat+Avst+Rst,data=evaporat, method="ols")

## dimension test
round(dr.test(sir5),3)
round(dr.test(save5),3)
round(dr.test(phdres, numdir=4),3)
set.seed(100);round(dr.permutation.test(cov2,npermute=1000)$summary,3)
set.seed(100);round(dr.permutation.test(cov3,npermute=1000)$summary,3)
set.seed(100);round(dr.permutation.test(cov4,npermute=1000)$summary,3)


 
#######################################################################################
## numerical example to initiate BAS in Section 2
#######################################################################################
sir.cov <- sir.save <- sir.phd <- save.cov <- save.phd <- phd.cov <- NULL
sir.eta <- save.eta <- phd.eta <- cov.eta <- NULL; set.seed(1)

## starting loop
for (i in 1:500){

## model construction
  X <- matrix(rnorm(100*10), c(100,10)); y <- X[,1] + rnorm(100)
  w <- c(scale(y,center=TRUE,scale=TRUE)); w2 <- cbind(w, w^2)

## obtaining basis estimates from the SDR methods
  library(dr)
  dir.sir5<-dr.direction(dr(y~X, method="sir", nslice=5))[,1]
  dir.cov2<-dr.direction(dr(w2~X, method="ols"))[,1]
  dir.save5<-dr.direction(dr(y~X, method="save", nslice=5))[,1]
  dir.phd <-dr.direction(dr(y~X, method="phdres"))[,1]

## computing the absolute correlation between the estimates by each pair of the methods
  sir.cov[i]<-abs(cor(dir.sir5, dir.cov2)); sir.save[i]<-abs(cor(dir.sir5, dir.save5))
  sir.phd[i]<-abs(cor(dir.sir5, dir.phd)); save.cov[i]<-abs(cor(dir.save5, dir.cov2))
  save.phd[i]<-abs(cor(dir.save5, dir.phd)); phd.cov[i]<-abs(cor(dir.phd, dir.cov2))

## computing the absolute correlation between the estimate by each method and x1
  sir.eta[i]<-abs(cor(dir.sir5, X[,1])); cov.eta[i]<-abs(cor(dir.cov2, X[,1]))
  save.eta[i]<-abs(cor(dir.save5, X[,1])); phd.eta[i]<-abs(cor(dir.phd, X[,1]))
 }

## the averages of the absolute correlations by each pair of the methods
round(apply(cbind(sir.cov, sir.save, sir.phd, save.cov, save.phd, phd.cov), 2,mean),3)

## the averages of the absolute correlations by each method and x1
round(apply(cbind(sir.eta, cov.eta, save.eta, phd.eta), 2, mean), 3)



#######################################################################################
## numerical example to confirm the consideration of various d in Section 2
#######################################################################################
sir.cov <- sir.save <- sir.phd <- save.cov <- save.phd <- phd.cov <- NULL
sir.cov2 <- sir.save2 <- sir.phd2 <- save.cov2 <- save.phd2 <- phd.cov2 <- NULL
sir.cov3 <- sir.save3 <- sir.phd3 <- save.cov3 <- save.phd3 <- phd.cov3 <- NULL
sir.eta2 <- save.eta2 <- phd.eta2 <- cov.eta2 <- NULL; set.seed(1)

## true basis matrix of the central subspace
eta <- cbind( c(1,rep(0,9)), c(0,1,rep(0,8)) )

## starting loop
for (i in 1:500){

## model construction
  X <- matrix(rnorm(100*10), c(100,10)); y <- X[,1] + X[,1]*X[,2]+ rnorm(100)
  w <- c(scale(y,center=TRUE,scale=TRUE)); w2 <- cbind(w, w^2); w3<- cbind(w2, w^3)

## obtaining basis estimates from the four methods
  sir5b <- dr(y~X, method="sir", nslice=5)$raw.evectors
  cov2b<-dr(w2~X,method="ols")$raw.evectors; cov3b<-dr(w3~X,method="ols")$raw.evectors
  save5b <- dr(y~X, method="save", nslice=5)$raw.evectors
  phdb <- dr(y~X, method="phdres")$raw.evectors

## computing trace correlations under d=1 for the six pairs
  sir.cov[i] <- tr.cor(sir5b[,1], cov2b[,1], 1)
  sir.save[i] <- tr.cor(sir5b[,1], save5b[,1], 1)
  sir.phd[i] <- tr.cor(sir5b[,1], phdb[,1], 1)
  save.cov[i] <- tr.cor(save5b[,1], cov2b[,1], 1)
  save.phd[i] <- tr.cor(save5b[,1], phdb[,1], 1)
  phd.cov[i] <- tr.cor(phdb[,1], cov2b[,1], 1)

## computing trace correlations under d=2 for the six pairs
  sir.cov2[i] <- tr.cor(sir5b[,1:2], cov2b[,1:2], 2)
  sir.save2[i] <- tr.cor(sir5b[,1:2], save5b[,1:2], 2)
  sir.phd2[i] <- tr.cor(sir5b[,1:2], phdb[,1:2], 2)
  save.cov2[i] <- tr.cor(save5b[,1:2], cov2b[,1:2], 2)
  save.phd2[i] <- tr.cor(save5b[,1:2], phdb[,1:2], 2)
  phd.cov2[i] <- tr.cor(phdb[,1:2], cov2b[,1:2], 2)
  sir.cov3[i] <- tr.cor(sir5b[,1:3], cov3b[,1:3], 3)

## computing trace correlations under d=3 for the six pairs
  sir.save3[i] <- tr.cor(sir5b[,1:3], save5b[,1:3], 3)
  sir.phd3[i] <- tr.cor(sir5b[,1:3], phdb[,1:3], 3)
  save.cov3[i] <- tr.cor(save5b[,1:3], cov3b[,1:3], 3)
  save.phd3[i] <- tr.cor(save5b[,1:3], phdb[,1:3], 3)
  phd.cov3[i] <- tr.cor(phdb[,1:3], cov3b[,1:3], 3)
 }

## averages of the trace correlations for each pair under d=1,2,3
round(apply(cbind(sir.cov, sir.save, sir.phd, save.cov, save.phd, phd.cov), 2,mean),3)
round(apply(cbind(sir.cov2,sir.save2,sir.phd2,save.cov2,save.phd2,phd.cov2),2,mean),3)
round(apply(cbind(sir.cov3,sir.save3,sir.phd3,save.cov3,save.phd3,phd.cov3),2,mean),3)



#######################################################################################
## Intensive analysis of evaporate data using BAS in Section 3
#######################################################################################
## BAS application
BAS342<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=3, nsave=4, k=2, plot=FALSE)
BAS343<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=3, nsave=4, k=3, plot=FALSE)
BAS352<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=3, nsave=5, k=2, plot=FALSE)
BAS353<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=3, nsave=5, k=3, plot=FALSE)

BAS443<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=4, nsave=4, k=3, plot=FALSE)
BAS444<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=4, nsave=4, k=4, plot=FALSE)
BAS453<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=4, nsave=5, k=3, plot=FALSE)
BAS454<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=4, nsave=5, k=4, plot=FALSE)

BAS544<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=5, nsave=4, k=4, plot=FALSE)
BAS545<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=5, nsave=4, k=5, plot=FALSE)
BAS554<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=5, nsave=5, k=4, plot=FALSE)
BAS555<- bas1(Evap~Avat+Rat+Avst+Rst, data=evaporat, nsir=5, nsave=5, k=5, plot=FALSE)

## Selection results
BAS342$selection; BAS343$selection; BAS352$selection; BAS353$selection
BAS443$selection; BAS444$selection; BAS453$selection; BAS454$selection
BAS544$selection; BAS545$selection; BAS554$selection; BAS555$selection

## dimension test
set.seed(100);round(dr.permutation.test(BAS342$covk$cov2,npermute=1000)$summary,3)
set.seed(100);round(dr.permutation.test(BAS343$covk$cov3,npermute=1000)$summary,3)
round(dr.test(BAS443$phd, numdir=4),3)
round(dr.test(BAS544$sir),3)



#######################################################################################
## Some numerical studies in Section 4
#######################################################################################
set.seed(5); sel1 <- sel2 <- sel3 <- sel4 <- sel12 <- sel22 <- sel32 <- sel42 <- NULL

## starting loop
for (i in 1:500){

## model construction for n=100
  X<-matrix(rnorm(100*10), c(100,10))
  y1 <- X[,1] +rnorm(100); y2 <- X[,1]^2 +rnorm(100)
  y3 <- X[,1] +X[,1]*X[,2] +rnorm(100);  y4 <- 1 +X[,1] +exp(X[,2])*rnorm(100)

## model construction for n=200
  X2<-matrix(rnorm(200*10), c(200,10))
  y12 <- X2[,1] +rnorm(200);  y22 <- X2[,1]^2 +rnorm(200)
  y32 <- X2[,1] +X2[,1]*X2[,2] +rnorm(200);  y42 <- 1 +X2[,1] +exp(X2[,2])*rnorm(200)

## selection by BAS
 sel1[i]<-bas1(y1~X,plot=FALSE)$selection; sel2[i]<-bas1(y2~X,plot=FALSE)$selection
 sel3[i]<-bas1(y3~X,plot=FALSE)$selection; sel4[i]<-bas1(y4~X,plot=FALSE)$selection
 sel12[i]<-bas1(y12~X2,plot=FALSE)$selection;sel22[i]<-bas1(y22~X2,plot=FALSE)$selection
 sel32[i]<-bas1(y32~X2,plot=FALSE)$selection;sel42[i]<-bas1(y42~X2,plot=FALSE)$selection
}
## computing the selection percentages for model 1
# n=100
c(length(which(sel1=="sir")),length(which(sel1=="save")),
length(which(sel1=="phd")),length(which(sel1=="covk")))/500
# n=200
c(length(which(sel12=="sir")),length(which(sel12=="save")),
length(which(sel12=="phd")),length(which(sel12=="covk")))/500

## computing the selection percentages for model 2
#n=100
c(length(which(sel2=="sir")),length(which(sel2=="save")),
length(which(sel2=="phd")),length(which(sel2=="covk")))/500
#n=200
c(length(which(sel22=="sir")),length(which(sel22=="save")),
length(which(sel22=="phd")),length(which(sel22=="covk")))/500

## computing the selection percentages for model 3
#n=100
c(length(which(sel3=="sir")),length(which(sel3=="save")),
length(which(sel3=="phd")),length(which(sel3=="covk")))/500
#n=200
c(length(which(sel32=="sir")),length(which(sel32=="save")),
length(which(sel32=="phd")),length(which(sel32=="covk")))/500

## computing the selection percentages for model 4
#n=100
c(length(which(sel4=="sir")),length(which(sel4=="save")),
length(which(sel4=="phd")),length(which(sel4=="covk")))/500
#n=200
c(length(which(sel42=="sir")),length(which(sel42=="save")),
length(which(sel42=="phd")),length(which(sel42=="covk")))/500
