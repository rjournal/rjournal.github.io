#######################
# Replication script  #
# RJournal submission #
#######################

#######################################################
# Authors: A. Devaux, R. Genuer and C. Proust-Lima    #
# Inserm U1219, Bordeaux Population Health            #
# Université de Bordeaux                              #
# France                                              #
#                                                     #  
# The George Institute for Global health, UNSW Sydney #
# School of Population Health - UNSW Sydney           #
# Australia                                           #
#######################################################

# load packages
library("DynForest")
library("ggplot2")
library("cowplot")

####################
# Section 4        #
# Survival outcome #
####################

head(pbc2) # head of pbc2 data

# Split data for training and test steps
set.seed(1234)
id <- unique(pbc2$id)
id_sample <- sample(id, length(id)*2/3)
id_row <- which(pbc2$id %in% id_sample)
pbc2_train <- pbc2[id_row,]
pbc2_pred <- pbc2[-id_row,]

# Build the dataframe with longitudinal predictors
timeData_train <- pbc2_train[,c("id","time",
                                "serBilir","SGOT",
                                "albumin","alkaline")]

# Build the dataframe with time-fixed predictors
fixedData_train <- unique(pbc2_train[,c("id","age","drug","sex")])

# Specification of the models for time-dependent predictors
timeVarModel <- list(serBilir = list(fixed = serBilir ~ time,
                                     random = ~ time),
                     SGOT = list(fixed = SGOT ~ time + I(time^2),
                                 random = ~ time + I(time^2)),
                     albumin = list(fixed = albumin ~ time,
                                    random = ~ time),
                     alkaline = list(fixed = alkaline ~ time,
                                     random = ~ time))

# Build the outcome object
Y <- list(type = "surv",
          Y = unique(pbc2_train[,c("id","years","event")]))

# Build the random forest
res_dyn <- dynforest(timeData = timeData_train, 
                     fixedData = fixedData_train,
                     timeVar = "time", idVar = "id", 
                     timeVarModel = timeVarModel, Y = Y,
                     ntree = 200, mtry = 3, nodesize = 2, minsplit = 3,
                     cause = 2, ncores = 7, seed = 1234)

# Summary of the results
summary(res_dyn)

# Head and tail to investigate the tree structure
head(get_tree(dynforest_obj = res_dyn, tree = 1))
tail(get_tree(dynforest_obj = res_dyn, tree = 1))

# Plot the cumulative incidence function (CIF) of the cause of interest for leaf 251 in tree 1
plot(res_dyn, tree = 1, nodes = 251)

# Plot the CIF for subject 104 in the 9 first trees
plot(res_dyn, id = 104, max_tree = 9)

# Compute OOB error
res_dyn_OOB <- compute_ooberror(dynforest_obj = res_dyn)

# Get the overall OOB error
res_dyn_OOB

# Build objects for prediction step
id_pred <- unique(pbc2_pred$id[which(pbc2_pred$years>4)])
pbc2_pred_tLM <- pbc2_pred[which(pbc2_pred$id %in% id_pred),]
timeData_pred <- pbc2_pred_tLM[,c("id","time",
                                  "serBilir","SGOT",
                                  "albumin","alkaline")]
fixedData_pred <- unique(pbc2_pred_tLM[,c("id","age","drug","sex")])

# Predict the CIF fot the new subject at landmark time at 4 years
pred_dyn <- predict(object = res_dyn, 
                    timeData = timeData_pred, 
                    fixedData = fixedData_pred,
                    idVar = "id", timeVar = "time",
                    t0 = 4)

# Plot the CIF for subjects 102 and 260
plot(pred_dyn, id = c(102, 260))


# Compute the variable importance (VIMP) statistic
res_dyn_VIMP <- compute_vimp(dynforest_obj = res_dyn, seed = 123)

# Plot the VIMP in percentage
p1 <- plot(res_dyn_VIMP, PCT = TRUE)

# Define groups in order to compute the grouped-variable importance (gVIMP) statistic
group <- list(group1 = c("serBilir","SGOT"),
              group2 = c("albumin","alkaline"))

# Compute the gVIMP
res_dyn_gVIMP <- compute_gvimp(dynforest_obj = res_dyn,
                               group = group, seed = 123)

# Plot the gVIMP in percentage
p2 <- plot(res_dyn_gVIMP, PCT = TRUE)

plot_grid(p1, p2, labels = c("A", "B"))

# Build the random forest with mtry chosen at its maximum (i.e., mtry = 7)
res_dyn_max <- dynforest(timeData = timeData_train, 
                         fixedData = fixedData_train,
                         timeVar = "time", idVar = "id", 
                         timeVarModel = timeVarModel, Y = Y,
                         ntree = 200, mtry = 7, nodesize = 2, minsplit = 3, 
                         cause = 2, ncores = 7, seed = 1234)


# Compte the minimal depth statistic
depth_dyn <- compute_vardepth(dynforest_obj = res_dyn_max)

# Plot the minimal depth statistic by predictor or feature
p1 <- plot(depth_dyn, plot_level = "predictor")
p2 <- plot(depth_dyn, plot_level = "feature")

plot_grid(p1, p2, labels = c("A", "B"))


# mtry tuning
err.OOB <- comput_time <- vector("numeric", 7)

for (i in 1:7){
  
  res_dyn_mtry <- dynforest(timeData = timeData_train, fixedData = fixedData_train,
                            timeVar = "time", idVar = "id", 
                            timeVarModel = timeVarModel, Y = Y,
                            ntree = 200, mtry = i, nodesize = 2, minsplit = 3,
                            cause = 2, ncores = 7, seed = 1234)
  
  res_dyn_mtry_OOB <- compute_ooberror(dynforest_obj = res_dyn_mtry)
  
  err.OOB[i] <- mean(res_dyn_mtry_OOB$oob.err, na.rm = T)
  comput_time[i] <- as.numeric(res_dyn_mtry$comput.time)
  
}


ggplot(data.frame(mtry = seq(7), OOB.error = err.OOB), aes(x = mtry, y = OOB.error)) +
  geom_line(color = "red") +
  geom_point(color = "red", size = 1) +
  ylab("OOB error") +
  theme_bw() +
  theme(axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold"))

# Saving objects
save(res_dyn, res_dyn_OOB, pred_dyn, res_dyn_VIMP, res_dyn_gVIMP, res_dyn_max, err.OOB,
     file = "data/DynForest_fit_surv_all.RData")

#######################
# Section 5           #
# Categorical outcome #
#######################

rm(list = ls())

# Recode event variable
pbc2 <- pbc2[which(pbc2$years>4&pbc2$time<=4),]
pbc2$event <- ifelse(pbc2$event==2, 1, 0)
pbc2$event[which(pbc2$years>10)] <- 0

# Split the data for training and prediction steps
set.seed(1234)
id <- unique(pbc2$id)
id_sample <- sample(id, length(id)*2/3)
id_row <- which(pbc2$id %in% id_sample)
pbc2_train <- pbc2[id_row,]
pbc2_pred <- pbc2[-id_row,]

# Build the dataframe with longitudinal predictors
timeData_train <- pbc2_train[,c("id","time",
                                "serBilir","SGOT",
                                "albumin","alkaline")]

# Specification of the models for time-dependent predictors
timeVarModel <- list(serBilir = list(fixed = serBilir ~ time,
                                     random = ~ time),
                     SGOT = list(fixed = SGOT ~ time + I(time^2),
                                 random = ~ time + I(time^2)),
                     albumin = list(fixed = albumin ~ time,
                                    random = ~ time),
                     alkaline = list(fixed = alkaline ~ time,
                                     random = ~ time))

# Build the dataframe with time-fixed predictors
fixedData_train <- unique(pbc2_train[,c("id","age","drug","sex")])

# Build the outcome object
Y <- list(type = "factor",
          Y = unique(pbc2_train[,c("id","event")]))

# Build the random forest
res_dyn <- dynforest(timeData = timeData_train, fixedData = fixedData_train,
                     timeVar = "time", idVar = "id", timeVarModel = timeVarModel,
                     mtry = 7, nodesize = 2, 
                     Y = Y, ncores = 7, seed = 1234)


# Compute the OOB error
res_dyn_OOB <- compute_ooberror(dynforest_obj = res_dyn)

# Summary of the results
summary(res_dyn_OOB)


# Build objects for prediction step
id_pred <- unique(pbc2_pred$id[which(pbc2_pred$years>4)])
pbc2_pred <- pbc2_pred[which(pbc2_pred$id %in% id_pred),]
timeData_pred <- pbc2_pred[,c("id", "time", "serBilir", "SGOT", "albumin", "alkaline")]
fixedData_pred <- unique(pbc2_pred[,c("id","age","drug","sex")])
Y_pred <- list(type = "factor",
               Y = unique(pbc2_pred[which(pbc2_pred$years>4),c("id","event")]))

# Predict the event fot the new subject at landmark time at 4 years
pred_dyn <- predict(object = res_dyn,
                    timeData = timeData_pred, fixedData = fixedData_pred,
                    idVar = "id", timeVar = "time",
                    t0 = 4)

# Display the predicted event and the highest probability of the category
head(data.frame(pred = pred_dyn$pred_indiv, 
                proba = pred_dyn$pred_indiv_proba))

# Compute the variable importance (VIMP) statistic
res_dyn_VIMP <- compute_vimp(dynforest_obj = res_dyn, seed = 123)

# Plot the VIMP in percentage
plot(res_dyn_VIMP, PCT = TRUE)

# Compte the minimal depth statistic
depth_dyn <- compute_vardepth(dynforest_obj = res_dyn)

# Plot the minimal depth statistic by predictor or feature
p1 <- plot(depth_dyn, plot_level = "predictor")
p2 <- plot(depth_dyn, plot_level = "feature")

plot_grid(p1, p2, labels = c("A", "B"))

# Saving objects
save(res_dyn, res_dyn_OOB, pred_dyn, res_dyn_VIMP,
     file = "data/DynForest_fit_factor_all.RData")

###############
# sessionInfo #
###############

sessionInfo()