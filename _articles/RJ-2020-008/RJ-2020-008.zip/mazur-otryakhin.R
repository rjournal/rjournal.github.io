#####################################################
# Estimate deterioration experiment

#### Set of global parameters ####
library(rlfsm)

m<-45; M<-60; N<-200
p<-.4; p_prime<-.2
t1<-1; t2<-2; k<-2

NmonteC<-3e2
sigma<-0.3

### Grid for alphas and Hs continuous case

by_hs<-0.05; by_als<-0.1
hs<-seq(0.5+by_hs,1-by_hs,by=by_hs)
als<-seq(1+by_als,2-by_als,by=by_als)
####

test<-list()
dimns <-list(hs,als)

mtrx_contin_l<-matrix(data = NA, nrow = length(hs), ncol = length(als), dimnames=dimns)
mtrx_contin_h<-matrix(data = NA, nrow = length(hs), ncol = length(als), dimnames=dimns)
mtrx_gen_l<-matrix(data = NA, nrow = length(hs), ncol = length(als), dimnames=dimns)
mtrx_gen_h<-matrix(data = NA, nrow = length(hs), ncol = length(als), dimnames=dimns)


##### A function for NA/ NaN / error filtering
# returns 1 if everything is OK
Errfilter<-function(res){
  b1<-ifelse(is.character(res), 0, 1)
  b2<-ifelse(length(grep('NA',res))>0, 0, 1)
  b3<-ifelse(length(grep('NAN',res))>0, 0, 1)
  b1*b2*b3
}
####


#### The experiment #######

for(ind_hs in (1:length(hs))) {
  
  for(ind_als in (1:length(als))) {
    res<-data.frame()
    
    res<-foreach (j_ind = 1:NmonteC, .combine = rbind, .packages='stabledist', .inorder=FALSE) %dopar% {
      
      pathL <- path(N=N, m=m, M=M, alpha=als[ind_als], H=hs[ind_hs], sigma=sigma, freq='L')
      pathH <- path(N=N, m=m, M=M, alpha=als[ind_als], H=hs[ind_hs], sigma=sigma, freq='H')
      
      ConEstLow<-ContinEstim(t1=t1, t2=t2, p=p, k=2, path=pathL$lfsm, freq='L')
      GenEstLow<-GenLowEstim(t1=t1, t2=t2, p=p, path=pathL$lfsm, freq='L')
      
      ConEstHigh<-ContinEstim(t1=t1, t2=t2, p=p, k=2, path=pathH$lfsm, freq='H')
      GenEstHigh<-GenHighEstim(p=p, p_prime=p_prime, path=pathH$lfsm, freq='H', low_bound=0.01, up_bound=2)
      
      rcol<-cbind(CEL=Errfilter(ConEstLow),
                  GEL=Errfilter(GenEstLow),
                  CEH=Errfilter(ConEstHigh),
                  GEH=Errfilter(GenEstHigh))
      rcol
    }
    
    suc_rate<-colSums(res)/NmonteC
    
    mtrx_contin_l[ind_hs,ind_als]<-suc_rate['CEL']
    mtrx_gen_l[ind_hs,ind_als]<-suc_rate['GEL']
    mtrx_contin_h[ind_hs,ind_als]<-suc_rate['CEH']
    mtrx_gen_h[ind_hs,ind_als]<-suc_rate['GEH']
  }
  
}
#####################################################




#####################################################
# Zones with different convergence

#### Set of global parameters ####
library(rlfsm)
library(doParallel)
library(foreach)
library(gridExtra)
library(ggplot2)

registerDoParallel()


m<-45; M<-90; N<-1e3
p<-.4; p_prime<-.2
t<-1; t1<-1; t2<-2
fr<-'L'; NmonteC<-5e2

sigma<-0.3


## %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ##

# Grid for (alpha, H)
hs<-c(0.3,0.5,0.7,0.9)
by_als<-0.4
als<-seq(0.2,1.8,by=by_als)


# Sample path creation

path_set<-list()

for(ind_hs in (1:length(hs))) {
  
  path_set_als<-list()
  for(ind_als in (1:length(als))) {
    
    S_Path<-paths(N_var=NmonteC,N=N,m=m,M=M,alpha=als[ind_als],
                  H=hs[ind_hs],sigma=sigma,freq=fr,disable_X=FALSE,
                  levy_increments=NULL,parallel = TRUE)
    
    ll<-list(H=hs[ind_hs], alpha=als[ind_als], S_Path=S_Path)
    path_set_als[[ind_als]]<-ll
  }
  path_set[[ind_hs]]<-path_set_als
}


# Phi stats vs exp
phis_on_k<-function(p_data){
  
  S_paths<-p_data$S_Path
  alpha<-p_data$alpha
  H<-p_data$H
  
  data<-foreach(SP_ind = (1:NmonteC), .combine = rbind) %dopar% {
    
    S_Path<-S_paths[,SP_ind]
    d<-foreach(k_ind = seq(1,8,by=1), .combine = rbind) %do% {
      
      phi_vect<-phi(t=t1,k=k_ind,path=S_Path,H=H,freq='L')
      exp_vect<-tryCatch(
        exp(-(abs(sigma*Norm_alpha(h_kr,alpha=alpha,
                                   k=k_ind,r=1,H=H,l=0)$result)^alpha)),
        error=function(c) NA)
      al_vect<-alpha_hat(t1=1,t2=2,k=k_ind,path=S_Path,H=H,freq='L')
      
      c(sample_num=SP_ind, k=k_ind,
        phi_exper=phi_vect, phi_theor=exp_vect,
        alpha=alpha, H=H, alpha_est=al_vect)
    }
    d
  }
  
  data
  
}


# k_new estimates
Monte_k<-function(p_data){
  
  S_paths<-p_data$S_Path
  alpha<-p_data$alpha
  H<-p_data$H
  
  data<-foreach(SP_ind = (1:NmonteC), .combine = rbind) %dopar% {
    
    alpha_0<-alpha_hat(t1=t1,t2=t2,k=1,path=S_paths[,SP_ind],H=NULL,freq='L')
    if(alpha_0<=0) k_new<-NA else k_new<-2+floor(alpha_0^(-1))
    c(k_new=k_new, alpha=alpha, H=H)
  }
  data
}


# Computing on the sample paths
pl<-data.frame()
pk<-data.frame()

for(ind_hs in (1:length(hs))) {
  for(ind_als in (1:length(als))) {
    
    pl<-rbind(pl,phis_on_k(path_set[[ind_hs]][[ind_als]]))
    pk<-rbind(pk,Monte_k(path_set[[ind_hs]][[ind_als]]))
  }
}


# Plotting Phi on k

pl_log<-pl
pl_log$phi_theor<-log(pl_log$phi_theor)
pl_log$phi_exper<-log(pl_log$phi_exper)

pl_log$k<-factor(pl_log$k)
ggp <- ggplot(pl_log) +
  geom_boxplot(aes(x = k, y = phi_exper), color='blue') +
  geom_point(aes(x = k, y = phi_theor), inherit.aes = FALSE,
             size = 2, shape = 4, color='green3') +
  scale_y_continuous(limits = c(-200,0)) +
  facet_grid(alpha~H, scales = "free") +
  ggplot2::theme_bw() + labs(x = "k", y=NULL) #labs(x = "k", y = "phi")
ggp
ggsave(filename='phi_on_k.pdf', plot = ggp)


# Plotting alpha_hat on k

pl$k<-factor(pl$k)
ggp <- ggplot(pl) +
  geom_boxplot(aes(x = k, y = alpha_est), color='blue') +
  geom_hline(aes(yintercept = alpha), colour = "chocolate4") +
  facet_grid(alpha~H, scales = "free") +
  ggplot2::theme_bw() + labs(x = "k", y=NULL)
ggp
ggsave(filename='alpha_est_on_k.pdf', plot = ggp)


# Plotting histograms of k_new

ggk<-ggplot(data=pk, aes(k_new)) +
  geom_histogram(binwidth = 1, fill = 'darkgreen', center=0) +
  facet_grid(alpha~H) + coord_cartesian(xlim = c(0, 13)) +
  scale_x_continuous(breaks=c(1:9,13)) +
  theme_bw()
ggk
ggsave(filename='hist_of_k.pdf', plot = ggk)
#####################################################



#####################################################
# S4 classes examples

#### Set of global parameters ####
library(rlfsm)


#### Class definitions ####

# Make a class of parameters
setClass("AlpaHSigma",slots = list(alpha="numeric", H="numeric", sigma="numeric"))

#
V_params <- function(object) {
  if(is.numeric(object@alpha) & is.numeric(object@H) & is.numeric(object@sigma)) TRUE
  else paste("Wrong parameter (sigma,alpha,H)")
}
setValidity("AlpaHSigma", V_params)



# Make an S4 class of general low-frequency process
setClass("StochProcLow",slots = list(Process = "numeric", coordinates = "numeric"))

# Set a validator function for lengths of the process and its coordinates
VO_StochProc_lengths <- function(object) {
  if(length(object@Process) == length(object@coordinates)) TRUE
  else paste("Unequal process and coordinate lengths.")
}
setValidity("StochProcLow", VO_StochProc_lengths)


# Make an S4 class of general low-frequency lfsm
setClass("LfsmLow", contains = "StochProcLow")


# Make an S4 class of simulated low-frequency lfsm
#' @export
setClass("SimulatedLfsmLow",slots = list(pars = "AlpaHSigma",
                                         levy_motion = "numeric"),
         contains = "LfsmLow")

# Set a validator function for lengths of the process and the Levy motion
VO_SimulatedLfsm_lengths <- function(object) {
  if(length(object@Process) == length(object@levy_motion)) TRUE
  else paste("Unequal process and coordinate lengths.")
}
setValidity("SimulatedLfsmLow", VO_SimulatedLfsm_lengths)


#### Generic/Method definitions ####

setGeneric(name='ContinInfer', function(x,...){
  standardGeneric('ContinInfer')
}
)


# Plot method for SimulatedLfsm Low/High
#' @export
setMethod("plot", signature(x="SimulatedLfsmLow"),
          
          function(x) {
            
            
            d<-data.frame(coordinates = X_sim@coordinates, levy_motion = X_sim@levy_motion, lfsm = X_sim@Process)
            text<-paste("H = ", H, "alpha = ", alpha, "sigma =", sigma)
            # Draws a transparent line over jumps
            d$beta_ind<-ifelse(X_sim@pars@H-
                                 1/X_sim@pars@alpha>0,1,0.25)
            
            # Draw lfsm
            p <- ggplot2::ggplot(d, ggplot2::aes(x=coordinates, y=lfsm)) + ggplot2::geom_point(size = 0.25, colour = "brown")
            # Draws a transparent line over jumps
            p <- p + ggplot2::geom_line(ggplot2::aes(alpha=beta_ind), colour ="brown", size = 0.8)
            p <- p + ggplot2::theme_bw()
            p <- p + ggplot2::theme(axis.title.x=ggplot2::element_blank(), legend.position = "none")
            p <- p + ggplot2::labs(title=text)
            
            # Draw levi motion
            pl <- ggplot2::ggplot(d, ggplot2::aes(x=coordinates, y=levy_motion)) + ggplot2::geom_point(size = 0.25, colour = "darkgreen")
            pl<-pl + ggplot2::geom_line(size = 0.8, colour = "darkgreen", alpha=0.25)
            pl<-pl + ggplot2::theme_bw()
            
            # stack 2 charts
            
            ggp <- ggplot2::ggplotGrob(p)
            ggpl <- ggplot2::ggplotGrob(pl)
            
            Width <- grid::unit.pmax(ggp$widths[2:3], ggpl$widths[2:3])
            #Inference_3_1
            ggp$widths[2:3] <- Width
            ggpl$widths[2:3] <- Width
            
            g<-gridExtra::grid.arrange(ggp,ggpl,nrow=2)
            
            
          }
)


#### Inference_3_1 for StochProcLow ####
#' @export
setMethod("ContinInfer", signature(x="StochProcLow"),
          function(x,...) ContinEstim(path=x@Process,freq='L',...)
)

######################################################################





