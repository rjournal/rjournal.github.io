 library(testforDEP)
 lsat = testforDEP::LSAT$LSAT
 gpa = testforDEP::LSAT$GPA
 result = testforDEP::AUK(lsat, gpa, plot = TRUE, set.seed = TRUE)
 result$AUK

 tests = c("PEARSON", "KENDALL", "VEXLER", "TS2", "V", "MIC", "HOEFFD", "EL")
 testNames = list("Pearson", "Kendall", "log(VT_n)","$TS_2$", "$V$", "MIC", "Hoeffding","$T_{el}$")
 result = list()
 for(i in 1:length(tests)) result[[i]] = testforDEP(lsat, gpa, test = tests[i], p.opt = "MC", set.seed = T)
 #write results into table
  table = matrix(0, nrow = length(tests), ncol = 3)
  for(i in 1:length(tests)){
     table[i,1] = testNames[[i]]
     table[i,2] = round(result[[i]]@TS, digits = 3)
     p.val = result[[i]]@p_value
     table[i,3] = ifelse(p.val == 0, "< .0001", p.val)
   }
  colnames(table) = c("test", "statistic", "p-value")
  table
  
#############################################################################
#### SUBSET ANALYSIS ########################################################
#############################################################################

set.seed(100)
lsat = testforDEP::LSAT$LSAT
gpa = testforDEP::LSAT$GPA
lsat = lsat[c(45, 69, 23, 20, 6, 67, 24, 17, 4, 54, 76, 73, 9, 58, 81)]
gpa = gpa[c(45, 69, 23, 20, 6, 67, 24, 17, 4, 54, 76, 73, 9, 58, 81)]

result = testforDEP::AUK(lsat, gpa, plot = TRUE, set.seed = TRUE)
 result$AUK

 tests = c("PEARSON", "KENDALL", "VEXLER", "TS2", "V", "MIC", "HOEFFD", "EL")
 testNames = list("Pearson", "Kendall", "$log(VT_n)$","$TS_2$", "$V$", "MIC", "Hoeffding","$T_{el}$")
 result = list()
 for(i in 1:length(tests)) result[[i]] = testforDEP(lsat, gpa, test = tests[i], p.opt = "MC", set.seed = T)
 #write results into table
  table = matrix(0, nrow = length(tests), ncol = 3)
  for(i in 1:length(tests)){
     table[i,1] = testNames[[i]]
     table[i,2] = round(result[[i]]@TS, digits = 3)
     p.val = result[[i]]@p_value
     table[i,3] = ifelse(p.val == 0, "< .0001", p.val)
   }
  colnames(table) = c("test", "statistic", "p-value")
  table


