#########################################################################
#########################################################################
##### (1) Following are the simulation codes in the bivariate Normal case
#####

source("../../Clikcorr1.3.R")

# The true correlation coefficients.
Rtrue = c(0.00, 0.50, 0.95)

# Sample sizes.
N = c(50, 200, 500)

# The actual data are standard normal, the limit of detection is LDS*rnorm
# (lower detection limit if the limit is negative, upper detection
# limit if the limit is positive).
LDS = c(0.01)

# Number of simulation replications.
nrep = 500

# Proportion of missing values.
pmiss <- 0

fisher = function(V) {
    # Use the classical Pearson correlation coefficient and the Fisher
    # transformation method to determine a confidence interval for the
    # population correlation coefficient.  This function should only
    # be used with complete data.
    #
    # Arguments:
    #  V: A list containing elements named xobs and yobs, both of
    #     which are numeric vectors of the same length.
    #
    # Returns:
    #  A list containing elements named r (the Pearson correlation
    #  coefficient), f (the Fisher-transformed correlation
    #  coefficient), lb (the lower bound of the 95% confidence
    #  interval) and ub (the upper bound of the 95% confidence
    #  interval.
    
    r = cor(V$xobs[,1], V$yobs[,1])
    f = 0.5*log((1+r)/(1-r))
    n = length(V$xobs[,1])
    lb = f - 2/sqrt(n-3)
    ub = f + 2/sqrt(n-3)
    lb = (exp(2*lb)-1) / (exp(2*lb)+1)
    ub = (exp(2*ub)-1) / (exp(2*ub)+1)
    return(list(r=r, f=f, lb=lb, ub=ub))
}

fid = file("sim_LC_lds001r000n50.csv", "w")


    for (lds in LDS) {
        for (r in Rtrue) {
            for (n in N) {

                cat(sprintf("%.1f %.2f %d\n", lds, r, n))
                
                cp <- c(0,0)
                nval <- 0
                cr <- 0
                r_est <- 0
                for (k in 1:nrep) {
                    V <- gendat(n, r, lds, pmiss)
                    M <- cbind(V$xobs, V$yobs)
                    M <- data.frame(M)
                    colnames(M) <- c("L1", "U1", "L2", "U2")
                    cr <- cr + mean(is.na(M))
                    if ((lds == Inf) & (pmiss == 0)) {
                        F <- fisher(V)
                        cp[2] <- cp[2] + (r > F$lb) * (r < F$ub)
                        print(c(F$lb, F$ub))
                    }

                    R <- try(clikcorr(M, "L1", "U1", "L2", "U2"))
                    if (class(R) == "try-error") {
			write.table(M, file=paste("N_dataset", k, ".txt"), quote=FALSE, sep="\t", row.names=FALSE, col.names=TRUE)
                        next
                    }
                    r_est <- r_est + R$Cor

                    if (is.finite(R$LCL) & is.finite(R$UCL)) {
                        cp[1] <- cp[1] + (r >= R$LCL) * (r <= R$UCL)
                        nval <- nval + 1
                    }
                }
                if (nval > 0) {
                    cp[1] <- cp[1] / nval
                } else {
                    cp[1] = 0
                }
                if (lds == Inf) {
                    cp[2] <- cp[2] / nrep
                } else {
                    cp[2] = 0
                }
                cr <- cr / nrep
                r_est <- r_est / nrep
                
                cp = c(lds, r, n, cp[1], cp[2], cr)

                s = sprintf("lds=%.1f, r=%.2f, n=%d, cp=%.3f, cp_Fisher=%.3f, censor_R=%.2f, effective_n=%d\n", cp[1],
                  cp[2], cp[3], cp[4], cp[5], cp[6], nval)
                cat(s, file=fid)
                flush(fid)
            }
        }
    }


close(fid)


#########################################################################
#########################################################################
##### (2) Following are the simulation codes in the bivariate t case
#####

# The true correlation coefficients.
Rtrue = c(0.00, 0.50, 0.95)

# Degrees of freedom parameters for the t distribution.
DF = c(5, 10, 20)

# Sample sizes.
N = c(50, 200, 500)

# The actual data are standard normal, the limit of detection is LDS*rnorm
# (lower detection limit if the limit is negative, upper detection
# limit if the limit is positive).
LDS = c(0.1)

# Number of simulation replications.
nrep = 500

# Proportion of missing values.
pmiss <- 0

fisher = function(V) {
    # Use the classical Pearson correlation coefficient and the Fisher
    # transformation method to determine a confidence interval for the
    # population correlation coefficient.  This function should only
    # be used with complete data.
    #
    # Arguments:
    #  V: A list containing elements named xobs and yobs, both of
    #     which are numeric vectors of the same length.
    #
    # Returns:
    #  A list containing elements named r (the Pearson correlation
    #  coefficient), f (the Fisher-transformed correlation
    #  coefficient), lb (the lower bound of the 95% confidence
    #  interval) and ub (the upper bound of the 95% confidence
    #  interval.
    
    r = cor(V$xobs[,1], V$yobs[,1])
    f = 0.5*log((1+r)/(1-r))
    n = length(V$xobs[,1])
    lb = f - 2/sqrt(n-3)
    ub = f + 2/sqrt(n-3)
    lb = (exp(2*lb)-1) / (exp(2*lb)+1)
    ub = (exp(2*ub)-1) / (exp(2*ub)+1)
    return(list(r=r, f=f, lb=lb, ub=ub))
}

fid = file("sim_LC_df5lds01r000n50.csv", "w")


for (df in DF) {
    for (lds in LDS) {
        for (r in Rtrue) {
            for (n in N) {

                cat(sprintf("%d %.1f %.2f %d\n", df, lds, r, n))
                
                cp <- c(0,0)
                nval <- 0
                cr <- 0
                r_est <- 0
                for (k in 1:nrep) {
                    V <- gendat_t(n, df, r, lds, pmiss)
                    M <- cbind(V$xobs, V$yobs)
                    M <- data.frame(M)
                    colnames(M) <- c("L1", "U1", "L2", "U2")
                    cr <- cr + mean(is.na(M))
                    if ((lds == Inf) & (pmiss == 0)) {
                        F <- fisher(V)
                        cp[2] <- cp[2] + (r > F$lb) * (r < F$ub)
                        print(c(F$lb, F$ub))
                    }

                    R <- try(clikcorr(M, "L1", "U1", "L2", "U2", dist = "t"))
                    if (class(R) == "try-error") {
			write.table(M, file=paste("T_dataset", k, ".txt"), quote=FALSE, sep="\t", row.names=FALSE, col.names=TRUE)
                        next
                    }
                    r_est <- r_est + R$Cor

                    if (is.finite(R$LCL) & is.finite(R$UCL)) {
                        cp[1] <- cp[1] + (r >= R$LCL) * (r <= R$UCL)
                        nval <- nval + 1
                    }
                }
                if (nval > 0) {
                    cp[1] <- cp[1] / nval
                } else {
                    cp[1] = 0
                }
                if (lds == Inf) {
                    cp[2] <- cp[2] / nrep
                } else {
                    cp[2] = 0
                }
                cr <- cr / nrep
                r_est <- r_est / nrep
                
                cp = c(df, lds, r, n, cp[1], cp[2], cr)

                s = sprintf("df=%d, lds=%.1f, r=%.2f, n=%d, cp=%.3f, cp_Fisher=%.3f, censor_R=%.2f, effective_n=%d\n", cp[1],
                  cp[2], cp[3], cp[4], cp[5], cp[6], cp[7], nval)
                cat(s, file=fid)
                flush(fid)
            }
        }
    }
}

close(fid)


#########################################################################
#########################################################################
##### (3) Following are R codes for auxilary functions to generate the data in simulations
#####

censor_lod <- function(X, L, U) {
    # censor_lod censors X to the limits of detection L (lower limit
    # of detection) and U (upper limit of detection).
    #
    # Arguments
    #  X: nx1 vector of observed values
    #  L: nx1 vector of lower limits of detection
    #  U: nx1 vector of upper limits of detection
    #
    # Returns
    #  The observed data in the "pairs style" format.
    
    n <- length(X)
    Xobs <- cbind(X, X)

    ## Left censoring.
    ii <- which(X < L)
    if (length(ii) > 0) {
        Xobs[ii,1] <- NA
        Xobs[ii,2] <- L[ii]
    }

    ## Right censoring.
    ii <- which(X > U)
    if (length(ii) > 0) {
        Xobs[ii,1] <- U[ii]
        Xobs[ii,2] <- NA
    }

    return(Xobs)
}


censor_schedule <- function(X, T) {
    # censor_schedule censors the values in X to an assessment schedule T.
    #
    # Arguments
    #  X: nx1 vector of observed values
    #  T: a list of length n containing assessment points for each subject
    #
    # Returns
    #  The observed data in the "pairs style" format.

    n <- length(X)
    Xobs <- array(0, n)

    for (i in 1:n) {

        Ti <- T[[i]]

        ## Get the lower limit of the interval
        if (X[i] < min(Ti)) {
            Xobs[i,1] = NA
        } else {
            Xobs[i,1] = max(Ti[Ti < X[i]])
        }

        ## Get the upper limit of the interval
        if (X[i] > max(Ti)) {
            Xobs[i,2] = NA
        } else {
            Xobs[i,2] = min(Ti[Ti > X[i]])
        }
    }
    
    return(Xobs)
}


induce_missing <- function(Z, pmiss) {
    # Create missing data in the data matrix Z. Each row of Z is
    # randomly changed to missing with probability pmiss.
    
    I <- which(runif(dim(Z)[1]) < pmiss)
    if (length(I) > 0) {
        Z[I,] = NA
    }

    return(Z)
}


gendat <- function(n, r, lds, pmiss) {    
    # Generate a data set of n independent censored paired values.
    # The underlying complete data marginally follow standardized normal, and the correlation
    # between the two true values in each pair is 'r'.  The limit of
    # detection for each value x is random, and follows the
    # distribution lds*x (but is independent of x).  If the limit of
    # detection is negative, the data are left censored, if the limit
    # of detection is positive, the data are right censored.
    #
    # Arguments:
    # n: The sample size
    #
    # r: The population correlation coefficient
    # lds: A scale parameter determinin the amount of censoring
    #
    # Returns:
    # A list containing the observed data and censoring status
    # indicators.  The censoring status indicators are coded as 1
    # (observed) and 0 (censored).
    
    # Population standard deviation.
    s <- 1

    # Generate the fully observed data.
    X <- rnorm(n) / s
    Y <- rnorm(n) / s
    Y <- r*X + sqrt(1-r^2)*Y

    # Generate the limits of detection.
    XL <- lds*rnorm(n) / s
    XU <- lds*rnorm(n) / s
    XU[XU<0] <- Inf
    XL[XL>0] <- -Inf
    YL <- lds*rnorm(n) / s
    YU <- lds*rnorm(n) / s
    YU[YU<0] <- Inf
    YL[YL>0] <- -Inf

    Xobs <- censor_lod(X, XL, XU)
    Yobs <- censor_lod(Y, YL, YU) 

    Xobs <- induce_missing(Xobs, pmiss)
    Yobs <- induce_missing(Yobs, pmiss)
    
    return(list(xobs=Xobs, yobs=Yobs))
}




gendat_t <- function(n, df, r, lds, pmiss) {    
    # Generate a data set of n independent censored paired values.
    # The underlying complete data marginally follow standardized t
    # distributions with 'df' degrees of freedom, and the correlation
    # between the two true values in each pair is 'r'.  The limit of
    # detection for each value x is random, and follows the
    # distribution lds*x (but is independent of x).  If the limit of
    # detection is negative, the data are left censored, if the limit
    # of detection is positive, the data are right censored.
    #
    # Arguments:
    # n: The sample size
    # df: The degrees of freedom of the marginal t distributions
    # r: The population correlation coefficient
    # lds: A scale parameter determinin the amount of censoring
    #
    # Returns:
    # A list containing the observed data and censoring status
    # indicators.  The censoring status indicators are coded as 1
    # (observed) and 0 (censored).
    
    # Population standard deviation.
    s <- sqrt(df / (df - 2))

    # Generate the fully observed data.
    X <- rt(n, df) / s
    Y <- rt(n, df) / s
    Y <- r*X + sqrt(1-r^2)*Y

    # Generate the limits of detection.
    XL <- lds*rt(n, df) / s
    XU <- lds*rt(n, df) / s
    XU[XU<0] <- Inf
    XL[XL>0] <- -Inf
    YL <- lds*rt(n, df) / s
    YU <- lds*rt(n, df) / s
    YU[YU<0] <- Inf
    YL[YL>0] <- -Inf

    Xobs <- censor_lod(X, XL, XU)
    Yobs <- censor_lod(Y, YL, YU) 

    Xobs <- induce_missing(Xobs, pmiss)
    Yobs <- induce_missing(Yobs, pmiss)
    
    return(list(xobs=Xobs, yobs=Yobs))
}



#########################################################################
#########################################################################
##### (4) Following are example R codes for the realdata analysis
#####



# total 22 chemicals, 7 dioxins, 9 furans and 6PCBs

i <-1
j <-2

list <- read.table("list.txt", header=F)
list <- list[,1]

var1Name_L <- toString(list[2*(i-1)+1])
var2Name_L <- toString(list[2*(j-1)+1])

var1Name_U <- toString(list[2*(i-1)+2])
var2Name_U <- toString(list[2*(j-1)+2])


NHANESD <- read.csv("../NHANES.csv", header=T)
clik <-Clikcorr(NHANESD, var1Name_L, var1Name_U, var2Name_L, var2Name_U, cp=.95)

clik

cat(sprintf("%s and %s:\tcorr=%.5f,\tLCL=%.5f,\tUCL=%.5f;\tP0=%.5f\n", var1Name_L, var2Name_L, clik$Cor, clik$LCL, clik$UCL, clik$P0))

