
###### Bootstrap algorithms on networks ######
###### ~ Patchwork bootstrap ######
###### ~~ Labeled snowball sampling with multiple inclusions ######

library(snowboot)
net <- artificial_networks[[1]]

set.seed(1)
LSMI(net, n.seeds = 3, n.neigh = 1)

LSMI(net, seeds = c(532, 744), n.neigh = 1)

patches <- Union_LSMI(net, n.seeds = c(20, 30, 40), n.neigh = c(1:2))
length(patches)

all(patches[[1]]$seeds == patches[[2]]$seeds)

all(is.element(patches[[3]]$seeds, patches[[1]]$seeds))
all(is.element(patches[[5]]$seeds, patches[[3]]$seeds))

empdd <- Oempdegreedistrib(net, n.seeds = 40, n.neigh = 1)
empdd$Oempd[[1]]$Oempd


###### ~~ Resampling procedure ######

B <- 50
bootdd <- bootdeg(sam.out = empdd, n.boot = B)

dim(bootdd$empd[[1]]$empd.w.p0s)

k <- 3
alpha <- 0.05
quantile(bootdd$empd[[1]]$empd.w.p0s[k,], probs = c(alpha/2, 1 - alpha/2))


###### ~~ Cross-validation with LSMI ######

cv <- cross_validation_mean(network = net, n.seeds = c(10, 20, 30), n.neigh = c(1, 2), n.boot = B)
cv


###### ~ Vertex bootstrap ######

a <- scan("http://vlado.fmf.uni-lj.si/pub/networks/data/ucinet/prison.dat", skip = 4)
A <- matrix(a, sqrt(length(a)), byrow = TRUE)

set.seed(1)
B <- 500
Astar <- vertboot(A, B)

library(igraph)
densities <- sapply(1:B, function(x) graph.density(graph_from_adjacency_matrix(Astar[[x]])))

density_obs <- graph.density(graph_from_adjacency_matrix(A))
densities_se <- sd(densities)

boot_ci <- quantile(densities, c(0.025, 0.975))
boot_ci

mu_star <- sapply(1:B, function(x) 
                  mean(degree(graph_from_adjacency_matrix(Astar[[x]]), mode = "in")))
quantile(mu_star, c(0.025, 0.975))

net_transitivity <- sapply(1:B, function(x) 
                           transitivity(graph_from_adjacency_matrix(Astar[[x]]), 
                                        type = "undirected"))
quantile(net_transitivity, c(0.025, 0.975))


###### Simulation studies ######
###### ~ Light- and heavy-tailed degree distributions ######
###### ~~ Figure 3 ######

library(ggplot2)
library(VGAM)

dpoly.log <- function(x, param, lim = 10000) {
  # Function to generate the distribution for the Gutenberg-Richter law
  # ck^{-delta}e^{-k/lambda}
  # c=(li_lambda(e^{-1/lambda})) param=c(delta,lambda)
  if (length(param) != 2)
    stop("the Gutenber-Richter law parameter is wrong") else {
      pdf.s <- x^(-param[1]) * exp(-x/param[2])/li(param[1], exp(-1/param[2]), lim = lim)
    }
  pdf.s
}

li <- function(delta, b, lim = 10000){   
  res <- rep(0, length(b))
  if(length(delta) != 1) stop("delta must be a scalar")
  else res[b == 1] <- zeta(delta)
  #else if(length(delta)==length(b))res[b==1]<-zeta(delta[b==1])
  a <- which(b != 1)
  if(length(a)) for (j in a) res[j] <- sum(b[j]^(1:lim)/(1:lim)^delta)
  res
}

delta1 <- 0.001
lambda1 <- 2.13
delta2 <- 0.987
lambda2 <- 5
x <- seq(1, 13)
poly_0.001_2.13 <- dpoly.log(x, c(delta1, lambda1))
poly_0.987_5 <- dpoly.log(x, c(delta2, lambda2))
D <- rbind(poly_0.001_2.13, poly_0.987_5)
Distribution <- c(rep("polylog(0.001,2.13)", 13), rep("polylog(0.987,5)", 13))
pk_light_heavy_tail <- data.frame(degree = c(1:13, 1:13), pl = c(D[1,], D[2,]), 
                                  Distribution = Distribution)
p <- ggplot(data = pk_light_heavy_tail, 
            aes(x = degree, y = pl, group = Distribution, shape = Distribution, 
                colour = Distribution)) + 
     geom_line() + geom_point(size = 3) + xlab('k') + ylab('f(k)') + theme_bw() +
     scale_color_manual(values = c("#CC0000", "blue3", "green4", "gray6", "maroon2")) +
     scale_x_continuous(trans = "log10", breaks = seq(1, 13, 1)) + 
     scale_y_continuous(trans = "log10", breaks = scales::trans_breaks("log10", function(x) 10^x), 
                        labels = scales::trans_format("log10", scales::math_format(10^.x)))
p


###### ~~ Table 1 ######

library(igraph)
library(snowboot)

# First, load the functions
OparametersEst <- function(outOempd) {
    # This function obtains the parameters based on the empirical distritributions derived 
    # from the samples outOempd is output of Oempdegreedistrib
    num.sam <- outOempd$num.sam
    mean <- rep(NA, num.sam)
    quartiles <- array(NA, c(num.sam, 3))  
    rfreq <- array(NA, c(num.sam, 5))  
    deciles <- array(NA, c(num.sam, 9))  
    for (m in 1:outOempd$num.sam) {
        distrib <- outOempd$Oempd[[m]]$Oempd
        vals <- outOempd$values[[m]]
        mean[m] <- sum(vals * distrib)
        quartiles[m, ] <- vals[sapply(X = c(0.25, 0.5, 0.75), FUN = min.greater, 
                                      v = cumsum(distrib), ge = TRUE)]
        rfreq[m, ] <- c(distribvals(distrib, vals, 0), distribvals(distrib, vals, 1), 
                        distribvals(distrib, vals, 2), distribvals(distrib, vals, 3), 
                        distribvals(distrib, vals, 4))
        deciles[m, ] <- vals[sapply(X = seq(0.1, 0.9, by = 0.1), FUN = min.greater, 
                                    v = cumsum(distrib), ge = TRUE)]
    }
    list(mean = mean, quartiles = quartiles, rfreq = rfreq, deciles = deciles, m = m)
}

table.row <- function(vecdat, vect) {
    table(c(vecdat, vect)) - 1
}

min.greater <- function(v, x, ge = TRUE) {
    # I construct this function to obtain percentiles from a empirical distribution.  
    # This form is to allow obtaining it for a matrix of distributions. v is a vector x is a value
    if (ge) {
        res <- min(which(v >= x))
    } else {
        res <- min(which(v > x))
    }
    res
}

distribvals <- function(distrib, vals, x) {
    if (any(vals == x)) {
        res <- distrib[which(vals == x)]
    } else {
        res <- 0
    }
    res
}

B.EmpDistrib <- function(net, n.seeds, n.neigh, sam.size = 1, n.boot,
                         method = "w", seeds0 = NULL, otherNetParameters = FALSE, grow = T){
    #sam.size is the number of different samples taken from the network for each i and j.
    #otherNetParameters is true if intervals and fallins for the rest of the parmeters
    # (other than mean) are required.
    Obs.distrib.out <- empd <- as.list(rep(NA, length(n.seeds)*length(n.neigh)))
    union_seeds <- Union_LSMI(net, n.seeds, n.neigh, seeds = seeds0)
    num_n.seeds <- length(n.seeds)
    num_n.neigh <- length(n.neigh)
    sequence_n.seeds <- sort(n.seeds)
    counter <- 1
    for(i in n.seeds){
        for(j in n.neigh){
            if(grow == T){
                seeds <- union_seeds[[(i/i) + num_n.neigh*(num_n.seeds - which(sequence_n.seeds==i))]][[1]]
            } else {
                seeds = NULL
            }
            if(j == 0){
                Obs.distrib <- Oempdegreedistrib(net, n.seeds = i, n.neigh = j, num.sam = sam.size,
                                                 seeds = seeds)
                TMP <- Obs.distrib$seeds1
            }else{
                seeds <- union_seeds[[(i/i) + num_n.neigh*(num_n.seeds - which(sequence_n.seeds==i))]][[1]]
                Obs.distrib <- Oempdegreedistrib(net, n.seeds = i, n.neigh = j, num.sam = sam.size, 
                                                 seeds = seeds)
            }
            Oparam <- OparametersEst(Obs.distrib)
            tmp <- bootdeg(Obs.distrib, num.sam = sam.size, n.boot = n.boot, method = method)$empd[[1]]
            Obs.distrib.out[[counter]] <- Obs.distrib
            empd[[counter]] <- tmp
            counter <- counter + 1
        }
    }
    return(list(Obs.distrib.out = Obs.distrib.out, empd = empd))
}

combineLSMINodes <- function(bootEmpD){
    #function combines the unodes(or seed1) from the elements of
    #Obs.distrib.out object, which is inside the bootEmpD list
    nodes <- NULL
    for(i in 1:length(bootEmpD$Obs.distrib.out)){
        if("nodes_of_LSMI"%in%names(bootEmpD$Obs.distrib.out[[i]])){
            tmp = bootEmpD$Obs.distrib.out[[i]]$nodes_of_LSMI
        } else tmp = bootEmpD$Obs.distrib.out[[i]]$seeds1
        nodes = c(nodes,tmp)
    }
    unlist(nodes)
}

bootCIs_mean_proxy <- function(network, n.seeds, n.neigh, n.boot,
                               method = "w", alpha = 0.05, proxyRep = 13, proxyOrder = 100){
    sam.size = 1
    n.seeds <- sort(n.seeds)
    n.neigh <- sort(n.neigh)
    net_order <- network$n
    # Make bootEmpD list for seed-wave combos
    bootEmpD <- B.EmpDistrib(net = network, n.seeds = n.seeds, n.neigh = n.neigh,
                             sam.size = sam.size, n.boot = n.boot, method = "w", grow = T)
    fallin.proxy <- array(0, c(length(n.seeds)*length(n.neigh), proxyRep))
    used <- unique(combineLSMINodes(bootEmpD))
    count <- 1
    res < -matrix(NA, length(n.seeds)*length(n.neigh), 2)
    for(i in 1:length(n.seeds)){
        for(j in 1:length(n.neigh)){
            # Build proxy from bootEmpD$Obs.empd.out
            tmp <- bootEmpD$empd[[count]][[1]]
            values <- bootEmpD$Obs.distrib.out[[count]]$values[[1]]
            est_means <- rowSums(tmp*rep(values, each = n.boot))
            bootCI_mean <- quantile(est_means, c((alpha/2), 1-(alpha/2)))
            res[(i-1)*length(n.neigh)+j,] <- bootCI_mean
            count <- count + 1
        }
    }
    # Calculate the coverage for proxy #
    for(p in 1:(length(n.seeds)*length(n.neigh))){
        for(k in 1:proxyRep){
            proxyNodes <- sample(used, proxyOrder, replace = F)
            proxy_mean <- mean(network$degree[proxyNodes])
            fallin.proxy[p, k] <- ((res[p,1]<proxy_mean) & (proxy_mean<res[p,2]))
        }
    }
    coverage.proxy <- apply(fallin.proxy, 1, mean, na.rm = T)
    matrix_coverage.proxy <- t(matrix(coverage.proxy, length(n.neigh), length(n.seeds)))
    colnames(matrix_coverage.proxy) <- n.neigh
    rownames(matrix_coverage.proxy) <- n.seeds
    matrix_coverage.proxy <- abs(matrix_coverage.proxy - (1 - alpha))
    max_coverage_label <- which(matrix_coverage.proxy == min(matrix_coverage.proxy), arr.ind = TRUE)
    if(dim(max_coverage_label)[1] == 1){
        best_coverage_combination <- data.frame(n.seeds.num = n.seeds[max_coverage_label[1,1]], 
                                              n.neigh.num = n.neigh[max_coverage_label[1,2]])
    }else{
        dimnames(max_coverage_label) <- NULL
        bigger_n.seeds_index <- which(max_coverage_label[,1] != min(max_coverage_label[,1]), 
                                      arr.ind = TRUE)
        if(length(bigger_n.seeds_index) == 0){
            smaller_n.neigh_index <- which(max_coverage_label[,2] == min(max_coverage_label[,2]))
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[max_coverage_label[smaller_n.neigh_index,1]],
                                                    n.neigh.num = n.neigh[max_coverage_label[smaller_n.neigh_index,2]])
        }else if(length(bigger_n.seeds_index) == (length(max_coverage_label[,1]) - 1)){
            coverage_matrix <- max_coverage_label[-c(bigger_n.seeds_index),]
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[coverage_matrix[1]],
                                                    n.neigh.num = n.neigh[coverage_matrix[2]])
        }else{
            coverage_matrix <- max_coverage_label[-c(bigger_n.seeds_index),]
            smaller_n.neigh_index <- which(coverage_matrix[,2] == min(coverage_matrix[,2]))
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[coverage_matrix[smaller_n.neigh_index,1]],
                                                    n.neigh.num = n.neigh[coverage_matrix[smaller_n.neigh_index,2]])
        }
    }
    best_bootCI_mean <- as.matrix(res[(((which(n.seeds == best_coverage_combination[[1]])) - 1)*length(n.neigh) + 
                                           (which(n.neigh == best_coverage_combination[[2]]))),])
    rownames(best_bootCI_mean) <- paste(round(c(alpha/2, (1 - alpha/2))*100, 1), "%", sep = "")
    best_coverage_value <- coverage.proxy[(((which(n.seeds == best_coverage_combination[[1]])) - 1)*length(n.neigh) + 
                                               (which(n.neigh == best_coverage_combination[[2]])))]
    return(list(best_combination = best_coverage_combination, 
                best_bootCI_mean = best_bootCI_mean,
                best_proxy_coverage_value = best_coverage_value))
}

#Filenames for loading simulated data:
Orders <- c(1000, 5000, 10000)
FilesSim <- c(paste("polylog(", delta1, ",", lambda1, ")1000x", Orders, ".Rdata", sep = ""),
              paste("polylog(", delta2, ",", lambda2, ")1000x", Orders, ".Rdata", sep = ""))

#Load each of the files and run bootstrap:
# #DoNotRun:
# for(i in length(FilesSim)){
#     load(FilesSim[i])
#     bootstrap_CIs <- matrix(NA, nrow = 2, ncol = 1000)
#     for(i in 1:1000){
#         bootstrap_CIs[,i] <- bootCIs_mean_proxy(network = networks[[i]], n.seeds = c(20, 30, 40, 50),
#                                                 n.neigh = c(1:5), n.boot = 500, method = "w",
#                                                 alpha = 0.05, proxyRep = 13, proxyOrder = 100)[[2]]
#     }
#     save(bootstrap_CIs, file = paste("CIs_", FilesSim[i], sep = ""))
# }
# #EndDoNotRun

#coverage probabilities for the mean degree || average interval width
#polylog(0.001,2.13):
#97.7% || 0.794 
#96.4% || 0.812 
#97.7% || 0.805
#polylog(0.987,5):
#98.6% || 1.051 
#98.7% || 1.078 
#97.7% || 1.069


###### ~ Node removal ######
###### ~~ Figure 4 ######

library(ggplot2)
library(scales)
library(VGAM)

nnr <- c(rep(c("1%", "2%", "3%", "5%", "10%", "15%"), 2))
covr <- c(0.96, 0.978, 0.976, 0.975, 0.939, 0.851, 0.963, 0.818, 0.547, 0.058, 0, 0)

Method <- c(rep("patchwork", 6), rep("vertboot", 6))
remove_pl_0.001_2.13 <- data.frame(method = Method, 
                                   number_of_nodes_removed = nnr,
                                   Coverage = covr)
p <- ggplot(data = remove_pl_0.001_2.13, aes(x = factor(number_of_nodes_removed), 
                                             y = Coverage, group = Method, shape = Method,
                                             colour = Method)) + 
     geom_point(size=3) +
     scale_x_discrete(limits = c("1%", "2%", "3%", "5%", "10%", "15%")) + theme_bw() + geom_line() +
     xlab('Percent of nodes removed') + scale_y_continuous(labels = percent) + 
     scale_color_manual(values = c("#CC0000", "#000099"))
p


###### ~~ Table 2 ######
#Select networks of order 5000:
FilesSim <- FilesSim[c(2, 5)]

# Set k equal to any number. In this case, k represent the percent of nodes removed
k <- c(1, 2, 3, 5) # only choose one at each time

# #DoNotRun:
# for(i in length(FilesSim)){
#     load(FilesSim[i])
#     ###### ~~~ Method 1: Patchwork
#     bootstrap_CIs <- matrix(NA, nrow = 2, ncol = 1000) 
#     for(i in 1:1000){
#         graph <- igraph::graph_from_edgelist(networks[[i]]$edges, directed = FALSE) 
#         remove_nodes <- base::sample(1:5000, size = (5000*k/100), replace = FALSE)
#         igraph::V(graph)$name <- igraph::V(graph)
#         new_graph <- igraph::delete_vertices(graph, remove_nodes)
#         new_net <- igraph_to_network(new_graph)
#         bootstrap_CIs[,i] <- bootCIs_mean_proxy(network = new_net, n.seeds = c(20, 30, 40, 50),
#                                                 n.neigh = c(1:5), n.boot = 500, method = "w", 
#                                                 alpha = 0.05, proxyRep = 13, proxyOrder = 100)[[2]] 
#     }
#     save(bootstrap_CIs, file = paste("removenodes_patch",  FilesSim[i], sep = ""))
#     ###### ~~~ Method 2: Vertex bootstrap
#     lower_bound <- 0.025
#     upper_bound <- 0.975
#     n.boot = 500
#     bootstrap_CIs <- matrix(NA, nrow = 2, ncol = 1000)
#     for(i in 1:1000){
#         boot_density_vector <- vector(length = n.boot) 
#         graph <- igraph::graph_from_edgelist(networks[[i]]$edges, directed = FALSE) 
#         remove_nodes <- base::sample(1:5000, size = (5000*k/100), replace = FALSE)
#         igraph::V(graph)$name <- igraph::V(graph)
#         new_graph <- igraph::delete_vertices(graph, remove_nodes)
#         m1 <- as.matrix(igraph::as_adjacency_matrix(new_graph))
#         bootlist <- snowboot::vertboot(m1, n.boot)
#         for(j in 1:n.boot){
#             boot_density_vector[j] <- igraph::graph.density(igraph::graph_from_adjacency_matrix(bootlist[[j]]))
#         }
#         bootstrap_CIs[,i] <- quantile(boot_density_vector, c(lower_bound, upper_bound))
#     }
#     save(bootstrap_CIs, file = file = paste("removenodes_vertex",  FilesSim[i], sep = ""))
# }
# #EndDoNotRun

#Result as below
#Observed coverage probabilities || Average interval width || Standard errors
#polylog(0.001,2.13) with patchwork method
#96.0% || 0.807 || 0.187
#97.8% || 0.801 || 0.194
#97.6% || 0.806 || 0.191
#97.5% || 0.795 || 0.196

#polylog(0.987,5) with patchwork method
#99.4% || 1.072 || 0.230
#99.0% || 1.062 || 0.239
#98.9% || 1.062 || 0.249
#99.4% || 1.032 || 0.237

#polylog(0.001,2.13) with vertex bootstrap method
#96.3% || 0.170 || 0.090
#81.8% || 0.170 || 0.091
#54.7% || 0.169 || 0.090
# 5.8% || 0.169 || 0.090

#polylog(0.987,5) with vertex bootstrap method
#96.3% || 0.212 || 0.113
#89.8% || 0.211 || 0.113
#74.0% || 0.211 || 0.113
#25.7% || 0.209 || 0.112


###### Case studies ######
###### ~ The David Copperfield network ######

library(igraph)
graph_david <- read.graph("http://networkdata.ics.uci.edu/data/adjnoun/adjnoun.gml", format = "gml")
A <- as.matrix(as_adjacency_matrix(graph_david))

library(snowboot)
B <- 500
set.seed(1)
Astar <- vertboot(A, B)

boot_density <- sapply(1:B, function(x) graph.density(graph_from_adjacency_matrix(Astar[[x]])))
CIvertboot <- quantile(boot_density, c(0.025, 0.975))
CIvertboot
bootstrap_standard_error <- sd(boot_density)
bootstrap_standard_error

set.seed(5)
igraph_david <- igraph_to_network(graph_david)
CIpatchwork <- cross_validation_mean(network = igraph_david,  
                                     n.seeds = c(3:10), n.neigh = c(1, 2), n.boot = 200, 
                                     method = "w")[[2]]/(igraph_david$n - 1)
CIpatchwork


###### ~ Larger networks ######

bootCIs_density_proxy <- function(network, n.seeds, n.neigh, n.boot,
                                  method = "w", alpha = 0.05, proxyRep = 13, proxyOrder = 100){
    sam.size = 1
    n.seeds <- sort(n.seeds)
    n.neigh <- sort(n.neigh)
    net_order <- network$n
    # Make bootEmpD list for seed-wave combos
    bootEmpD <- B.EmpDistrib(net = network, n.seeds = n.seeds, n.neigh = n.neigh,
                             sam.size = sam.size, n.boot = n.boot, method = "w", grow = TRUE)
    fallin.proxy <- array(0, c(length(n.seeds)*length(n.neigh), proxyRep))
    used <- unique(combineLSMINodes(bootEmpD))
    count <- 1
    res <- matrix(NA,length(n.seeds)*length(n.neigh), 2)
    for(i in 1:length(n.seeds)){
        for(j in 1:length(n.neigh)){
            # Build proxy from bootEmpD$Obs.empd.out
            tmp <- bootEmpD$empd[[count]][[1]]
            values <- bootEmpD$Obs.distrib.out[[count]]$values[[1]]
            est_means <- rowSums(tmp*rep(values, each = n.boot))
            bootCI_mean <- quantile(est_means, c((alpha/2), 1-(alpha/2)))
            res[(i-1)*length(n.neigh)+j,] <- bootCI_mean
            count <- count + 1
        }
    }
    for(p in 1:(length(n.seeds)*length(n.neigh))){
        for(k in 1:proxyRep){
            proxyNodes <- base::sample(used, proxyOrder, replace = F)
            proxy_mean <- mean(network$degree[proxyNodes])
            fallin.proxy[p, k] <- ((res[p,1]<proxy_mean) & (proxy_mean<res[p,2]))
        }
    }
    coverage.proxy <- apply(fallin.proxy, 1, mean, na.rm = TRUE)
    matrix_coverage.proxy <- t(matrix(coverage.proxy,length(n.neigh), length(n.seeds)))
    colnames(matrix_coverage.proxy) <- n.neigh
    rownames(matrix_coverage.proxy) <- n.seeds
    matrix_coverage.proxy <- abs(matrix_coverage.proxy - (1 - alpha))
    max_coverage_label <- which(matrix_coverage.proxy == min(matrix_coverage.proxy), arr.ind = TRUE)
    if(dim(max_coverage_label)[1]==1){
        best_coverage_combination <- data.frame(n.seeds.num = n.seeds[max_coverage_label[1,1]],
                                                n.neigh.num = n.neigh[max_coverage_label[1,2]])
    }else{
        dimnames(max_coverage_label) <- NULL
        bigger_n.seeds_index <- which(max_coverage_label[,1] != min(max_coverage_label[,1]), 
                                      arr.ind = TRUE)
        if(length(bigger_n.seeds_index)==0){
            smaller_n.neigh_index<-which(max_coverage_label[,2]==min(max_coverage_label[,2]))
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[max_coverage_label[smaller_n.neigh_index,1]],
                                                    n.neigh.num = n.neigh[max_coverage_label[smaller_n.neigh_index,2]])
        }else if(length(bigger_n.seeds_index)==(length(max_coverage_label[,1]) - 1)){
            coverage_matrix <- max_coverage_label[-c(bigger_n.seeds_index),]
            best_coverage_combination <- data.frame(n.seeds.num=n.seeds[coverage_matrix[1]],
                                                    n.neigh.num=n.neigh[coverage_matrix[2]])
        }else{
            coverage_matrix <- max_coverage_label[-c(bigger_n.seeds_index),]
            smaller_n.neigh_index <- which(coverage_matrix[,2] == min(coverage_matrix[,2]))
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[coverage_matrix[smaller_n.neigh_index,1]],
                                                    n.neigh.num = n.neigh[coverage_matrix[smaller_n.neigh_index,2]])
        }
    }
    best_bootCI_mean <- as.matrix(res[(((which(n.seeds == best_coverage_combination[[1]])) - 1)*length(n.neigh) + 
                                           (which(n.neigh==best_coverage_combination[[2]]))),])
    rownames(best_bootCI_mean) <- paste(round(c(alpha/2, (1 - alpha/2))*100, 1), "%", sep = "")
    best_coverage_value <- coverage.proxy[(((which(n.seeds==best_coverage_combination[[1]])) - 1)*length(n.neigh) + 
                                               (which(n.neigh==best_coverage_combination[[2]])))]
    return(list(best_combination = best_coverage_combination,
                best_bootCI_density = best_bootCI_mean/((network$n)-1),
                best_proxy_coverage_value = best_coverage_value))
} 


###### ~~ Flight networks of the airline alliances ######

library(tnet)
library(maps)
library(geosphere)
library(snowboot)

# The R code for airport network construction and airport network plots is adapted from 
# http://toreopsahl.com/2011/08/12/%why-anchorage-is-not-that-important-binary-ties-and-sample-selection/

# Construct the networks
# Download airport geolocations from openflights.org/data.html, and set column headings
# "http://openflights.svn.sourceforge.net/viewvc/openflights/openflights/data/airports.dat"
OFairports <- read.csv("airports.dat", header = FALSE, stringsAsFactors = FALSE)
dimnames(OFairports)[[2]] <- c("Airport_ID", "Name", "City", "Country", "IATA_FAA", "ICAO", 
                               "Latitude", "Longitude", "Altitude", "Timezone", "DST")

# Download routes from openflights.org/data.html
# "http://openflights.svn.sourceforge.net/viewvc/openflights/openflights/data/routes.dat"
OF <- read.csv("routes.dat", header = FALSE, stringsAsFactors = FALSE)
dimnames(OF)[[2]] <- c("Airline", "Airline_ID", "Source_airport", "Source_airport_ID", 
                       "Destination_airport", "Destination_airport_ID", "Codeshare", "Stops", 
                       "Equipment")

# Remove code-shares as these are duplicated entries
# net2 <- OF[OF[,"Codeshare"]=="", c("Source_airport_ID", "Destination_airport_ID")]
# 
# # Take out routes from an airport to itself and the missing cases (~1%)
# net2 <- net2[net2[,"Source_airport_ID"]!=net2[,"Destination_airport_ID"],]
# net2 <- net2[net2[,"Source_airport_ID"]!="\\N",]
# net2 <- net2[net2[,"Destination_airport_ID"]!="\\N",]

# As passengers per route is not available, create a weighted network with the weight equal 
# to number of routes
# net2 <- data.frame(i = as.integer(net2[, "Source_airport_ID"]), 
#                    j = as.integer(net2[, "Destination_airport_ID"]))
# net2 <- shrink_to_weighted_network(net2)

#Alliance members
StarAlliance <- c('JP', 'A3', 'AC', 'CA', 'NZ', 'NH', 'OZ', 'OS', 'AV', 'SN', 'CM', 'OU', 'MS', 
                  'ET', 'BR', 'LO', 'LH', 'SK', 'ZH', 'SQ', 'SA', 'LX', 'JJ', 'TP', 'TG', 'TK', 
                  'UA', 'US')
OneWorld <- c('AB', 'AA', 'BA', 'CX', 'AY', 'IB', 'JL', 'LA', 'MH', 'QF', 'QR', 'RJ', 'S7')
SkyTeam <- c('SU', 'AM', 'AR', 'UX', 'AF', 'AZ', 'CI', 'MU', 'CZ', 'OK', 'DL', 'KQ', 'KL', 'KE', 
             'ME', 'SV', 'RO', 'VN', 'MF')
Anames <- c("StarAlliance", "OneWorld", "SkyTeam")
D <- c(9045, 8740, 8921)
ss <- c(6400, 6700, 6800)

for(alliance in 1:length(Anames)){
    net2 <- OF[is.element(OF$Airline, eval(parse(text = Anames[alliance]))), 
               c("Source_airport_ID", "Destination_airport_ID")]
    # 1) Take out routes from an airport to itself and the missing cases (~1%)
    net2 <- net2[net2[,"Source_airport_ID"]!=net2[,"Destination_airport_ID"],]
    net2 <- net2[net2[,"Source_airport_ID"]!="\\N",]
    net2 <- net2[net2[,"Destination_airport_ID"]!="\\N",]
    #sum((net2[,"Source_airport_ID"]==net2[,"Destination_airport_ID"]) | 
    # (net2[,"Source_airport_ID"]=="\\N") | 
    # (net2[,"Destination_airport_ID"]=="\\N"))*100 / dim(net2)[[1]]
    edges <- cbind(as.numeric(net2$Source_airport_ID), as.numeric(net2$Destination_airport_ID))
    nodeID <- unique(sort(edges))
    #dim(edges)
    #2) Count how many times each node appears as a departure airport
    depart <- dest <- rep(0, length(nodeID))
    for (i in 1:length(nodeID)){
        depart[i] <- sum(edges[,1] == nodeID[i])
    }
    #3) Count how many times eaach node appears as a destination airport
    for (i in 1:length(nodeID)){
        dest[i] <- sum(edges[,2] == nodeID[i])
    }
    #4) Compare
    # sum(depart != dest) 
    # (131+84+141)*100/(1289+914+1040)
    # M <- matrix(0, 1, 2)
    # TMP <- t(apply(edges, 1, sort))
    # for(j in 1:dim(edges)[1]){
    #     if(sum(edges[j,]==TMP)<2){
    #         M <- rbind(M, edges[j,])
    #     }
    # }
    
    net <- as.list(rep(NA, 3))
    names(net) <- c("n", "edges", "degree")
    tmp <- t(apply(edges, 1, sort))
    tmp <- unique(tmp)
    #dim(tmp) 
    net$edges <- tmp
    E <- unique(sort(net$edges))
    length(E) 
    net$degree <- rle(sort(net$edges))$lengths
    #mean(net$degree) 
    net$n <- length(net$degree) 
    #net$degree.left <- rep(0, net$n)
    
    ###### ~~ Figure 6 ######
    pdf(paste("net_", Anames[alliance], ".pdf", sep = ""), width = 11, height = 7)
        suppressWarnings(net2 <- shrink_to_weighted_network(net$edges))
        #The warning about "The network might be undirected..." can be ignored. Yes, it is
        #undirected, but also unweighted, so we do not care how many times the ties are repeated --
        #all of them are repeated just once, all weights == 1.
        
        # Symmetrise data for visualisation
        net2s <- as.data.frame(symmetrise_w(net2, method = "SUM"))
        net2s <- net2s[net2s[,"i"] < net2s[,"j"],]
        
        # Sort data so that weak ties are plotted first
        net2s <- net2s[order(net2s[,"w"]),]
        
        #map("world", col="#eeeeee", fill=TRUE, bg="white", lwd=0.05)
        map("world", col="palegreen2", fill=TRUE, bg="white", lwd=0.05)
        #pal <- colorRampPalette(c("#cccccc", "black"))
        #colors <- pal(length(unique(net2s[,"w"])))
        colors <- rep(rgb(0, 0, 0, 0.3), times=as.integer(table(net2s[,"w"])))
        
        # Plot ties
        for(i in 1:nrow(net2s)) {
            # Get longitude and latitude of the two airports
            tmp1 <- as.numeric(OFairports[OFairports["Airport_ID"]==net2s[i,"i"],c("Longitude","Latitude")][1,])
            tmp2 <- as.numeric(OFairports[OFairports["Airport_ID"]==net2s[i,"j"],c("Longitude","Latitude")][1,])
            # Get the geographical distance to see how many points on the Great Circle to plot
            tmp3 <- 10*ceiling(as.numeric(log(3963.1 * acos((sin(tmp1[2]/(180/pi))*sin(tmp2[2]/(180/pi)))+(cos(tmp1[2]/(180/pi))*cos(tmp2[2]/(180/pi))*cos(tmp1[1]/(180/pi)-tmp2[1]/(180/pi)))))))
            # Line coordinates
            inter <- gcIntermediate(tmp1, tmp2, n=round(tmp3), addStartEnd=TRUE, breakAtDateLine=TRUE)
            # Plot one line if the line does not cross the date line; two if so
            if(is.matrix(inter)) {
                lines(inter, col=colors[i], lwd=0.7)
            } else {
                for(j in 1:length(inter)){
                    lines(inter[[j]], col=colors[i], lwd=0.7)
                }
            }
        }
    dev.off()
        
    net_air <- graph_from_edgelist(net$edges, directed = FALSE)
    nodes_index <- sort(unique(c(as.vector(net$edges[,1]), as.vector(net$edges[,2]))))
    delete_nodes_index <- setdiff(c(1:D[alliance]), nodes_index)
    V(net_air)$name <- V(net_air)
    new_net_air <- delete_vertices(net_air, delete_nodes_index)
    V(new_net_air)$name <- c(1:length(nodes_index))
    g_net_air_network <- igraph_to_network(new_net_air)
    set.seed(ss[alliance])
    print(bootCIs_density_proxy(network = g_net_air_network, n.seeds = c(20, 30, 40, 50),
                          n.neigh = c(1:3), n.boot = 500, method = "w", alpha = 0.05, 
                          proxyRep = 10, proxyOrder = 100))     
}


###### ~~ United States and Germany power grids ######

library(snowboot)
library(igraph)

bootCIs_p_k_proxy <- function(network, n.seeds, n.neigh, n.boot, method = "w", alpha = 0.1, 
                              proxyRep = 13, proxyOrder = 100, degree = k){
    sam.size = 1
    n.seeds <- sort(n.seeds)
    n.neigh <- sort(n.neigh)
    net_order <- network$n
    # Make bootEmpD list for seed-wave combos
    bootEmpD <- B.EmpDistrib(net = network, n.seeds = n.seeds, n.neigh = n.neigh,
                             sam.size = sam.size, n.boot = n.boot, method = "w", grow = TRUE)
    fallin.proxy <- array(0, c(length(n.seeds)*length(n.neigh), proxyRep))
    used <- unique(combineLSMINodes(bootEmpD))
    count <- 1
    res <- matrix(NA,length(n.seeds)*length(n.neigh), 2)
    for(i in 1:length(n.seeds)){
        for(j in 1:length(n.neigh)){
            # Build proxy from bootEmpD$Obs.empd.out
            tmp <- bootEmpD$empd[[count]][[1]]
            degree_vector = as.numeric(colnames(tmp))
            if(degree %in% degree_vector){
                bootCI_p_k <- quantile(tmp[,which(degree_vector==degree)], c((alpha/2), 1-(alpha/2)))
                res[(i-1)*length(n.neigh)+j,] <- bootCI_p_k
                count <- count + 1
            }else{
                tmp <- 0
                bootCI_p_k <- quantile(0, c((alpha/2), 1-(alpha/2)))
                res[(i-1)*length(n.neigh)+j,] <- bootCI_p_k
                count <- count + 1
            }
        }
    }
    # Calculate the coverage for proxy#
    for(p in 1:(length(n.seeds)*length(n.neigh))){
        for(q in 1:proxyRep){
            proxyNodes <- base::sample(used, proxyOrder, replace = FALSE)
            proxy_degreeK <- length(which(network$degree[proxyNodes] == degree))/(length(proxyNodes))
            fallin.proxy[p, q] <- ((res[p,1] < proxy_degreeK) & (proxy_degreeK < res[p,2]))
        }
    }
    coverage.proxy <- apply(fallin.proxy, 1, mean, na.rm = TRUE)
    matrix_coverage.proxy <- t(matrix(coverage.proxy, length(n.neigh), length(n.seeds)))
    colnames(matrix_coverage.proxy) <- n.neigh
    rownames(matrix_coverage.proxy) <- n.seeds
    matrix_coverage.proxy <- abs(matrix_coverage.proxy - 0.9)
    max_coverage_label <- which(matrix_coverage.proxy == min(matrix_coverage.proxy), arr.ind = TRUE)
    if(dim(max_coverage_label)[1]==1&&dim(max_coverage_label)[2]==2){
        best_coverage_combination<-data.frame(n.seeds.num=n.seeds[max_coverage_label[1,1]],
                                              n.neigh.num=n.neigh[max_coverage_label[1,2]])
    }else{
        dimnames(max_coverage_label)<-NULL
        bigger_n.seeds_index<-which(max_coverage_label[,1] != min(max_coverage_label[,1]), 
                                    arr.ind = TRUE)
        if(length(bigger_n.seeds_index)==0){
            smaller_n.neigh_index <- which(max_coverage_label[,2]==min(max_coverage_label[,2]))
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[max_coverage_label[smaller_n.neigh_index,1]],
                                                    n.neigh.num = n.neigh[max_coverage_label[smaller_n.neigh_index,2]])
        }else if(length(bigger_n.seeds_index)==(length(max_coverage_label[,1])-1)){
            coverage_matrix <- max_coverage_label[-c(bigger_n.seeds_index),]
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[coverage_matrix[1]],
                                                    n.neigh.num = n.neigh[coverage_matrix[2]])
        }else{
            coverage_matrix <- max_coverage_label[-c(bigger_n.seeds_index),]
            smaller_n.neigh_index <- which(coverage_matrix[,2] == min(coverage_matrix[,2]))
            best_coverage_combination <- data.frame(n.seeds.num = n.seeds[coverage_matrix[smaller_n.neigh_index,1]],
                                                    n.neigh.num = n.neigh[coverage_matrix[smaller_n.neigh_index,2]])
        }
    }
    best_bootCI_p_k <- as.matrix(res[(((which(n.seeds==best_coverage_combination[[1]])) - 1)*length(n.neigh) + 
                                          (which(n.neigh==best_coverage_combination[[2]]))),])
    rownames(best_bootCI_p_k) <- paste(round(c(alpha/2, (1 - alpha/2))*100, 1), "%", sep = "")
    best_coverage_value <- coverage.proxy[(((which(n.seeds==best_coverage_combination[[1]]))-1)*length(n.neigh) + 
                                               (which(n.neigh==best_coverage_combination[[2]])))]
    best_combi_degree_vector = as.numeric(colnames((bootEmpD$empd[[(((which(n.seeds==best_coverage_combination[[1]]))-1)*length(n.neigh) + 
                                                                        (which(n.neigh==best_coverage_combination[[2]])))]][[1]])))
    bootstrapped_degree_distribution_for_k <- (bootEmpD$empd[[(((which(n.seeds==best_coverage_combination[[1]]))-1)*length(n.neigh) + 
                                                                   (which(n.neigh==best_coverage_combination[[2]])))]][[1]])[,which(best_combi_degree_vector==degree)]
    return(list(best_combination = best_coverage_combination,
                best_bootCI_p_k = best_bootCI_p_k,
                boot_degree_k = bootstrapped_degree_distribution_for_k))
}


# Parameter gamma analysis
# 1. US Power Grid --- parameter gamma
# Data from http://konect.uni-koblenz.de/networks/opsahl-powergrid
# setwd() #set your path
g_us_power_grid = read.graph("power.gml",format = c("gml"))
net_g_power_grid = igraph_to_network(g_us_power_grid)
set.seed(3000)
boot_degree_distribution = matrix(NA, nrow = 500, ncol = 8)
for(k in 1:8){
    boot_degree_distribution[,k] = bootCIs_p_k_proxy(network = net_g_power_grid, 
                                                     n.seeds = c(20, 30, 40, 50),
                                                     n.neigh = c(1:5), n.boot = 500, method = "w",
                                                     alpha = 0.1, proxyRep = 13,
                                                     proxyOrder = 100,degree = k)$boot_degree_k
}
scale_boot_degree_distribution = (1/(rowSums(boot_degree_distribution)))*boot_degree_distribution
cum_scale_boot_degree_distribution = matrix(NA, nrow = 500, ncol = 8)
for(i in 1:500){
    cum_scale_boot_degree_distribution[i,] = rev(cumsum(rev(scale_boot_degree_distribution[i,])))}
x1 <- c(1:8)
a_start = 1
b_start = 1
gamma_vector = vector(length = 500)
for(r in 1:500){
    y = cum_scale_boot_degree_distribution[r,]
    mod = nls(y~a*exp(-b*x1),start = list(a=a_start, b = b_start))
    gamma_vector[r] = 1/(summary(mod)$coefficient[[2]])
}
quantile(gamma_vector, c(0.05, 0.95))
# Result:
#    5%        95%
# 1.752413   2.120209

# Germany Power Grid --- parameter gamma
# Data from http://www.scigrid.de/pages/downloads.html
# setwd() #set your path
regular_germany_power <- as.matrix(read.csv("links_germany_power_160718.csv")[-c(3:9)])
net_germany_power <- graph_from_edgelist(regular_germany_power,directed = F)
nodes_index <- sort(unique(c(as.vector(regular_germany_power[,1]),as.vector(regular_germany_power[,2]))))
delete_nodes_index <- setdiff(c(1:523), nodes_index)
V(net_germany_power)$name <- V(net_germany_power)
new_net_germany_power <- delete_vertices(net_germany_power, delete_nodes_index)
V(new_net_germany_power)$name <- c(1:511)
g_net_germany_power_network <- igraph_to_network(new_net_germany_power)
set.seed(200)
boot_degree_distribution <- matrix(NA,nrow = 500, ncol = 8)
for(k in 1:8){
    boot_degree_distribution[,k] = bootCIs_p_k_proxy(network = g_net_germany_power_network,
                                                     n.seeds = c(20,30,40,50), n.neigh = c(1:5),
                                                     n.boot = 500, method = "w", 
                                                     alpha = 0.1, proxyRep = 13,
                                                     proxyOrder = 100, degree = k)$boot_degree_k
}
scale_boot_degree_distribution = (1/(rowSums(boot_degree_distribution)))*boot_degree_distribution
cum_scale_boot_degree_distribution = matrix(NA,nrow = 500,ncol = 8)
for(i in 1:500){
    cum_scale_boot_degree_distribution[i,] = rev(cumsum(rev(scale_boot_degree_distribution[i,])))}
x1 <- c(1:8)
a_start = 1
b_start = 1
gamma_vector = vector(length = 500)
for(r in 1:500){
    y = cum_scale_boot_degree_distribution[r,]
    mod = nls(y~a*exp(-b*x1), start = list(a = a_start, b = b_start))
    gamma_vector[r]=1/(summary(mod)$coefficient[[2]])
}
quantile(gamma_vector,c(0.05,0.95))
# Result:
#    5%        95%
# 2.204080   2.783948

# Calculate the 90% confidence bounds for parameter density
# US Power Grid --- parameter density
set.seed(6000)
bootCIs_density_proxy(network = net_g_power_grid, n.seeds = c(20, 30, 40, 50), n.neigh = c(1:5),
                      n.boot = 500, method = "w", alpha = 0.1, proxyRep = 13, proxyOrder = 100)
# Result:
# 5%  0.0004843117
# 95% 0.0005610179

# Germany Power Grid --- parameter density
set.seed(200)
bootCIs_density_proxy(network = g_net_germany_power_network, n.seeds = c(20, 30, 40, 50),
                      n.neigh = c(1:5), n.boot = 500, method = "w", alpha = 0.1, proxyRep = 13,
                      proxyOrder = 100)
# Result:
# 5%  0.005857945
# 95% 0.006915629
