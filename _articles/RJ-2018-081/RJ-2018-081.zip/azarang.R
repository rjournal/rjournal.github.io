library(idmTPreg)

data(colonTPreg)
head(colonTPreg)
 
co13 <- TPreg( ~ Age + Nodes + treatment, colonTPreg, link = "logit", s = 0, R = 99,
                  t = 365.24*7, trans = "13" )
co13
summary(co13)
plot(co13, covar = c("Age", "Nodes", "treatmentLev", "treatmentLev.5FU"),
       Ylim = list(c(-0.1,0.1), c(-0.5,0.5), c(-2,2), c(-2,2)))
  
  
co11 <- TPreg( ~ Age + Nodes + treatment, colonTPreg, link = "logit", s = 0,
                 R = 199, by = 1, t = 365.24*7, trans = "11" )
co11
plot(co11, covar = c("Age", "Nodes", "treatmentLev", "treatmentLev.5FU"),
       Ylim = list(c(-0.1,0.1), c(-0.5,0.5), c(-2,2), c(-2,2)))