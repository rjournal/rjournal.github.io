# Installing and loading the package
install.packages("npordtests")
library(npordtests)

# Consulting JtTest for Jonckheere's data
JtTest(Y~X,jdata,alpha=0.05,na.rm=TRUE,verbose=TRUE)

# Consulting to use the statistics in the output of JtTest
res<-JtTest(Y~X,jdata,alpha=0.05,na.rm=TRUE,verbose=FALSE)
res$statistic
res$mean
res$variance
res$Z
res$p.value

# Consulting AtTest for Jonckheere's data
LsTest(Y~X,jdata)
RsTest(Y~X,jdata)
StTest(Y~X,jdata)
WsTest(Y~X,jdata)
LtTest(Y~X,jdata)
AtTest(Y~X,jdata)

# Consulting FtmTest for Jonckheere's data
FtmTest(Y~X,jdata)

# Consulting KtpTest for Jonckheere's data
KtpTest(Y~X,jdata)

# Consulting SsTest for Jonckheere's data
SsTest(Y~X,jdata)

# Consulting GcTest for Jonckheere's data
GcTest(Y~X,jdata)

# Consulting JtTest for Lehmann's data
JtTest(Values~Group,lehmann)

# Consulting AtTest for Lehmann's data
AtTest(Values~Group,lehmann)

# Consulting FtmTest for Lehmann's data
FtmTest(Values~Group,lehmann)

# Consulting KtpTest for Lehmann's data
KtpTest(Values~Group,lehmann)

# Consulting SsTest for Lehmann's data
SsTest(Values~Group,lehmann)

# Consulting GcTest for Lehmann's data
GcTest(Values~Group,lehmann)
