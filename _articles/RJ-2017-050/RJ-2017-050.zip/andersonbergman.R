### Example Analysis

library(icenReg)
library(foreach)
library(doParallel)

data(miceData)
head(miceData)
summary(miceData)

# Fitting MLE
mle_fit <- ic_par(cbind(l, u) ~ grp,
                  model = 'ph', 
                  dist  = 'weibull',
                  data = miceData) 
coef(mle_fit)



expertPrior <- function(x){
  # Extracting parameters from input
  shape <- exp(x[1])
  scale <- exp(x[2])
  ge_coef <- x[3]
  
  # ans is log-density of the prior 
  ans <- 0
  # First prior: S(730) ~ beta(1.5, 5.5)
  # Note that we are using a Weibull distribution
  s_730 = 1 - pweibull(730, shape = shape, scale = scale)
  ans = ans + dbeta(s_730, 1.5, 5.5, log = T)
  # Second prior: shape >= 1
  if(shape < 1) ans = -Inf
  return(ans)
}

myClust <- makeCluster(4)
registerDoParallel(myClust)

bayes_fit <- ic_bayes(cbind(l,u) ~ grp, 
                                 data = miceData,
                                 model = 'ph', dist = 'weibull',
                                 logPriorFxn = expertPrior,
                                 useMCores = T)

stopCluster(myClust)

summary(bayes_fit)

plot(bayes_fit$mcmcList)

plot(bayes_fit, 
     col = 'blue', 
     main = "Posterior Baseline Survival", 
     lwd = 2)

newdata <- data.frame(grp = c('ce', 'ge'))
rownames(newdata) <- c("Conventional", "Germ-free")


plot(bayes_fit, 
     newdata = newdata,
     main = "Comparing Survival Curves",
     col = c('blue', 'orange'), 
     lwd = 2, 
     cis = F, 
     lgdLocation = 'topright')


survCIs(bayes_fit, 
        newdata = newdata, 
        p = seq(from = 0.1, to = 0.9, by = .2), 
        ci_level = 0.95)


eventTimeSamples <- ic_sample(bayes_fit, 
                              newdata = newdata,
                              samples = 4000)

ce_dens <- density(eventTimeSamples['Conventional',], 
                   from = 0)
ge_dens <- density(eventTimeSamples['Germ-free',], 
                   from = 0)
plot(ge_dens, 
     main = "Posterior Densities of Event Times",
     col = 'orange', 
     xlim = c(0, 4000), 
     lwd = 2)
lines(ce_dens, 
      col = 'blue', 
      lwd = 2)
legend('topright', 
       c('Conventional', 'Germ-free'), 
       col = c('blue', 'orange'), 
       lwd = 1)


# Adding event time intervals
newdata$l <- c(365,365)
newdata$u <- c(Inf, Inf)
imputedTimes <- imputeCens(bayes_fit, 
                           newdata = newdata, 
                           samples = 4000)

ce_dens <- density(imputedTimes['Conventional',])
ge_dens <- density(imputedTimes['Germ-free',])

plot(ge_dens, 
     main = "Posterior Densities of Event Times\nConditional on Event in First Year",
     col = 'orange', 
     lwd = 2, 
     xlim = c(300, 3000))
lines(ce_dens, 
      col = 'blue', 
      lwd = 2)
legend('topright', 
       c('Conventional', 'Germ-free'), 
       col = c('blue', 'orange'), 
       lwd = 1)
