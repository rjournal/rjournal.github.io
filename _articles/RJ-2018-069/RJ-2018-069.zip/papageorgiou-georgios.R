require(BNSP)
require(colorspace)
require(ggplot2)
require(mvtnorm)
require(coda)
require(plot3D)
require(threejs)
require(gridExtra)
require(Formula)
require(plyr)
require(np)
require(MASS)

##### Simulation studies, Single covariate case: Example 1 #####

mu <- function(u){2 * u}
stdev <- function(u){0.1 + u}
set.seed(1)
n <- 500
u <- sort(runif(n))
y <- rnorm(n, mu(u), stdev(u))
data <- data.frame(y, u)

model <- y ~ sm(u, nknots = 20, bs = "rd") | sm(u, nknots = 20, bs = "rd")

DIR <- getwd()
m1 <- mvrm(formula = model, data = data,
         sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
         c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
         pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

#Summaries

alpha <- mvrm2mcmc(m1, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m1, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m1, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m1, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m1, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m1, "gamma")
delta <- mvrm2mcmc(m1, "delta")

print(m1)

summary(m1, nModels=2)

#Plots

x1 <- seq(0, 1, length.out = 30)

plotOptionsM = list(geom_line(aes_string(x = x1, y = mu(x1)), col = 2, alpha = 0.5, lty = 2),
                              geom_point(data = data, aes(x = u, y = y)))
                                                  
plot(x = m1, model = "mean", term = "sm(u)", plotOptions = plotOptionsM, intercept = TRUE, 
     quantiles = c(0.005, 0.995), grid = 30)


plotOptionsV = list(geom_line(aes_string(x = x1, y = stdev(x1)), col = 2, alpha = 0.5, lty = 2))

plot(x = m1, model = "stdev", term = "sm(u)", plotOptions = plotOptionsV, intercept = TRUE,
     quantiles = c(0.05, 0.95), grid = 30) 

#Predictions     

x1 <- seq(0, 1, length.out = 30)     
p1 <- predict(m1, newdata = data.frame(u = x1), interval = "credible")
p2 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

model <- y ~ sm(u, nknots = 20, bs = "rd") | 1

m1 <- mvrm(formula = model, data = data,
         sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
         c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
         pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

p3 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")


ggplot(data=p1) + geom_line(aes(x = x1, y = fit)) + 
                  geom_ribbon(aes(x = x1, ymin = lwr, ymax = upr), fill = 2, alpha = 0.8) + 
                  geom_ribbon(data = p2, aes(x = x1, ymin = lwr, ymax = upr), fill = 3, color = 3, alpha = 0.4) +
                  geom_ribbon(data = p3, aes(x = x1, ymin = lwr, ymax = upr), fill = 4, color = 4, alpha = 0.2)

##### Simulation studies, Single covariate case: Example 2 #####

mu <- function(u){2 * (1 - u)}
stdev <- function(u){(dnorm(u, mean = 0.2, sd = sqrt(0.004)) + dnorm(u, mean = 0.6, sd = sqrt(0.1))) / 6}
set.seed(1)
n <- 500
u <- sort(runif(n))
y <- rnorm(n, mu(u), stdev(u))
data <- data.frame(y, u)

model <- y ~ sm(u, nknots = 20, bs = "rd") | sm(u, nknots = 20, bs = "rd")

DIR <- getwd()
m1 <- mvrm(formula = model, data = data,
         sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
         c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
         pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

#Summaries

alpha <- mvrm2mcmc(m1, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m1, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m1, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m1, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m1, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m1, "gamma")
delta <- mvrm2mcmc(m1, "delta")

print(m1)

summary(m1, nModels=2)

#Plots

x1 <- seq(0, 1, length.out = 30)

plotOptionsM = list(geom_line(aes_string(x = x1, y = mu(x1)), col = 2, alpha = 0.5, lty = 2),
                    geom_point(data = data, aes(x = u, y = y)))    
                                  
plot(x = m1, model = "mean", term = "sm(u)", plotOptions = plotOptionsM, intercept = TRUE, quantiles = c(0.005, 0.995),
     grid = 30)

plotOptionsV = list(geom_line(aes_string(x = x1, y = stdev(x1)), col = 2, alpha = 0.5, lty = 2))

plot(x = m1, model = "stdev", term = "sm(u)", plotOptions = plotOptionsV, intercept = TRUE,
     quantiles = c(0.05, 0.95), grid = 30) 

#Predictions     

x1 <- seq(0, 1, length.out = 30)     
p1 <- predict(m1, newdata = data.frame(u = x1), interval = "credible")
p2 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

model <- y ~ sm(u, nknots = 20, bs = "rd") | 1

m1 <- mvrm(formula = model, data = data,
         sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
         c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
         pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

p3 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

ggplot(data = p1) + geom_line(aes(x = x1, y = fit)) + 
                    geom_ribbon(aes(x = x1, ymin = lwr, ymax = upr), fill = 2, alpha = 0.8) + 
                    geom_ribbon(data = p2, aes(x = x1, ymin = lwr, ymax = upr), fill = 3, color = 3, alpha = 0.4) +
                    geom_ribbon(data = p3, aes(x = x1, ymin = lwr, ymax = upr), fill = 4, color = 4, alpha = 0.2)

##### Simulation studies, Single covariate case: Example 3 #####

mu <- function(u){(dnorm(u, mean = 0.2, sd = sqrt(0.004)) + dnorm(u, mean = 0.6, sd = sqrt(0.1))) / 4}
stdev <- function(u){0.6 + 0.5 * sin(2 * pi * u)}
set.seed(1)
n <- 500
u <- sort(runif(n))
y <- rnorm(n, mu(u), stdev(u))
data <- data.frame(y, u)

model <- y ~ sm(u, nknots = 20, bs = "rd") | sm(u, nknots = 20, bs = "rd")

DIR <- getwd()
m1 <- mvrm(formula = model, data = data,
           sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
           c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
           pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

#Summaries

alpha <- mvrm2mcmc(m1, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m1, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m1, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m1, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m1, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m1, "gamma")
delta <- mvrm2mcmc(m1, "delta")

print(m1)

summary(m1, nModels=2)

#Plots

x1 <- seq(0, 1, length.out = 30)

plotOptionsM = list(geom_line(aes_string(x = x1, y = mu(x1)), col = 2, alpha = 0.5, lty = 2),
                              geom_point(data = data, aes(x = u, y = y)))  
                                              
plot(x = m1, model = "mean", term = "sm(u)", plotOptions = plotOptionsM, intercept = TRUE, 
     quantiles = c(0.005, 0.995), grid = 30)

plotOptionsV = list(geom_line(aes_string(x = x1, y = stdev(x1)), col = 2, alpha = 0.5, lty = 2))

plot(x = m1, model = "stdev", term = "sm(u)", plotOptions = plotOptionsV, intercept = TRUE,
     quantiles = c(0.05, 0.95), grid = 30) 

#Predictions     

x1 <- seq(0, 1, length.out = 30)
p1 <- predict(m1, newdata = data.frame(u = x1), interval = "credible")
p2 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

model <- y ~ sm(u, nknots = 20, bs = "rd") | 1

m1 <- mvrm(formula = model, data = data,
         sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
         c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
         pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

p3 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

ggplot(data = p1) + geom_line(aes(x = x1, y = fit)) + 
                    geom_ribbon(aes(x = x1, ymin = lwr, ymax = upr), fill = 2, alpha = 0.8) + 
                    geom_ribbon(data = p2, aes(x = x1, ymin = lwr, ymax = upr), fill = 3, color = 3, alpha = 0.4) +
                    geom_ribbon(data = p3, aes(x = x1, ymin = lwr, ymax = upr), fill = 4, color = 4, alpha = 0.2)

##### Simulation studies, Single covariate case: Example 4 #####

mu <- function(u) {(dnorm(u, mean = 0.2, sd = sqrt(0.004)) + dnorm(u, mean = 0.6, sd = sqrt(0.1))) / 4}
stdev <- function(u){(dnorm(u, mean = 0.2, sd = sqrt(0.004)) + dnorm(u, mean = 0.6, sd = sqrt(0.1))) / 6}
set.seed(1)
n <- 500
u <- sort(runif(n))
y <- rnorm(n, mu(u), stdev(u))
data <- data.frame(y, u)

model <- y ~ sm(u, nknots = 20, bs = "rd") | sm(u, nknots = 20, bs = "rd")

DIR <- getwd()
m1 <- mvrm(formula = model, data = data,
           sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
           c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
           pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

#Summaries

alpha <- mvrm2mcmc(m1, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m1, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m1, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m1, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m1, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m1, "gamma")
delta <- mvrm2mcmc(m1, "delta")

print(m1)

summary(m1, nModels=2)

#Plots

x1 <- seq(0, 1, length.out = 30)

plotOptionsM = list(geom_line(aes_string(x = x1, y = mu(x1)), col = 2, alpha = 0.5, lty = 2),
                              geom_point(data = data, aes(x = u, y = y))) 
                                               
plot(x = m1, model = "mean", term = "sm(u)", plotOptions = plotOptionsM, intercept = TRUE,
    quantiles = c(0.005, 0.995), grid = 30)

plotOptionsV = list(geom_line(aes_string(x = x1, y = stdev(x1)), col = 2, alpha = 0.5, lty = 2))

plot(x = m1, model = "stdev", term = "sm(u)", plotOptions = plotOptionsV, intercept = TRUE,
     quantiles = c(0.05, 0.95), grid = 30) 

#Predictions     
     
p1 <- predict(m1, newdata = data.frame(u = x1), interval = "credible")
p2 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

model <- y ~ sm(u, nknots = 20, bs = "rd") | 1

m1 <- mvrm(formula = model, data = data,
         sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR,
         c.betaPrior = "IG(0.5,0.5*n)", c.alphaPrior = "IG(1.1,1.1)",
         pi.muPrior = "Beta(1,1)", pi.sigmaPrior = "Beta(1,1)", sigmaPrior = "HN(2)")

p3 <- predict(m1, newdata = data.frame(u = x1), interval = "prediction")

ggplot(data = p1) + geom_line(aes(x = x1, y = fit)) + 
                    geom_ribbon(aes(x = x1, ymin = lwr, ymax = upr), fill = 2, alpha = 0.8) + 
                    geom_ribbon(data = p2, aes(x = x1, ymin = lwr, ymax = upr), fill = 3, color = 3, alpha = 0.4) +
                    geom_ribbon(data = p3, aes(x = x1, ymin = lwr, ymax = upr), fill = 4, color = 4, alpha = 0.2)

##### Simulation studies, Bivariate covariate case: Example 1 #####

mu1 <- matrix(c(0.25, 0.75))
sigma1 <- matrix(c(0.03, 0.01, 0.01, 0.03), 2, 2)
mu2 <- matrix(c(0.65, 0.35))
sigma2 <- matrix(c(0.09, 0.01, 0.01, 0.09), 2, 2)
mu <- function(x1, x2) {x <- cbind(x1, x2); 0.1 + dmvnorm(x, mu1, sigma1) + dmvnorm(x, mu2, sigma2)}
Sigma <- function(x1, x2) {x <- cbind(x1, x2); 0.1 + (dmvnorm(x, mu1, sigma1) + dmvnorm(x, mu2, sigma2)) / 2}
set.seed(1)
n <- 500
w1 <- runif(n)
w2 <- runif(n)
y <- vector()
for (i in 1:n) y[i] <- rnorm(1, mean = mu(w1[i], w2[i]), sd = sqrt(Sigma(w1[i], w2[i])))
data <- data.frame(y, w1, w2)

Model <- y ~ sm(w1, w2, nknots = 10, bs = "rd") | sm(w1, w2, nknots = 10, bs = "rd")
DIR <- getwd()
m2 <- mvrm(formula = Model, data = data, sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR)

#Summaries

alpha <- mvrm2mcmc(m2, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m2, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m2, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m2, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m2, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m2, "gamma")
delta <- mvrm2mcmc(m2, "delta")

print(m2)

summary(m2, nModels=2)

#Plots

plot(x = m2, model = "mean", term = "sm(w1,w2)", static = TRUE, plotOptions = list(col = diverge_hcl(n = 10)))

plot(x = m2, model = "stdev", term = "sm(w1,w2)", static = TRUE, plotOptions = list(col = diverge_hcl(n = 10)))

#Predictions     
     
p1 <- predict(m2, newdata = data.frame(w1 = c(0, 0.2), w2 = c(0, 0.2)), interval = "credible")
p2 <- predict(m2, newdata = data.frame(w1 = c(0, 0.2), w2 = c(0, 0.2)), interval = "prediction")

##### Simulation studies, Bivariate covariate case: Example 2 #####

mu0 <- function(u){2 * u}
stdev0 <- function(u){0.1 + u}
mu1 <- function(u){2 * (1 - u)}
stdev1 <- function(u){(dnorm(u, mean = 0.2, sd = sqrt(0.004)) + dnorm(u, mean = 0.6, sd = sqrt(0.1))) / 6}
set.seed(1)
n <- 500
u1 <- sample(c(0, 1), n, replace = TRUE) 
u2 <- runif(n)
y <- vector()
for (i in 1:n){ 
    if (u1[i] == 0) y[i] <- rnorm(1, mean = mu0(u2[i]), sd = stdev0(u2[i]))
    if (u1[i] == 1) y[i] <- rnorm(1, mean = mu1(u2[i]), sd = stdev1(u2[i]))
}
u1 <- factor(u1)
data <- data.frame(y, u1, u2)
rm(n,u1,u2,y)

Model <- y ~ sm(u1, u2, nknots = 20, bs = "rd") | sm(u1, u2, nknots = 20, bs = "rd")
DIR <- getwd()

m2 <- mvrm(formula = Model, data = data, sweeps = 10000, burn = 5000, thin = 2, seed = 1, StorageDir = DIR)

#Summaries

alpha <- mvrm2mcmc(m2, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m2, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m2, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m2, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m2, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m2, "gamma")
delta <- mvrm2mcmc(m2, "delta")

print(m2)

summary(m2, nModels=2)

#Plots

PlotOptions <- list(geom_point(data = data, aes(x = u2, y = y, pch = u1, colour = u1), alpha = 0.5, size = 2))

plot(x = m2, model = "mean", term = "sm(u1,u2)", quantiles = c(0.025, 1 - 0.025), plotOptions = PlotOptions)

plot(x = m2, model = "stdev", term = "sm(u1,u2)", quantiles = c(0.025, 1 - 0.025))

#Predictions     
     
p1 <- predict(m2, newdata = data.frame(u1 = rep(c(0, 1), each = 6), u2 = rep(seq(0, 1, 0.2), 2)), interval = "credible")
p2 <- predict(m2, newdata = data.frame(u1 = rep(c(0, 1), each = 6), u2 = rep(seq(0, 1, 0.2), 2)), interval = "prediction")

##### Simulation studies, Multiple covariate case #####

mu1 <- function(x) {1.5 * x}
mu2 <- function(x) {(dnorm(x, mean = 0.2, sd = sqrt(0.004)) + dnorm(x, mean = 0.6, sd = sqrt(0.1))) / 2}
mu3 <- function(x) {1 + sin(2 * pi * x)}
mu4 <- function(x) {- x}
stdev1 <- function(x) {(dnorm(x, mean = 0.2, sd = sqrt(0.004)) + dnorm(x, mean = 0.6, sd = sqrt(0.1))) / 2}
stdev2 <- function(x) {0.6 + 0.5 * sin(2 * pi * x)}
stdev3 <- function(x) {1.1 - x}
stdev4 <- function(x) {0.2 + 1.5 * x}
mu <- function(x) {mu1(x[1]) + mu2(x[2]) + mu3(x[3]) + mu4(x[4])}
stdev <- function(x) {stdev1(x[1]) * stdev2(x[2]) * stdev3(x[3]) * stdev4(x[4])}
set.seed(1)
n <- 500
w1 <- runif(n)
w2 <- runif(n)
w3 <- runif(n)
w4 <- runif(n)
y <- vector()
for (i in 1:n) y[i] <- rnorm(1, mean = mu(c(w1[i], w2[i], w3[i], w4[i])), sd = stdev(c(w1[i], w2[i], w3[i], w4[i])))
data <- data.frame(y, w1, w2, w3, w4)

Model <- y ~ sm(w1, nknots = 15, bs = "rd") + sm(w2, nknots = 15, bs = "rd") + 
             sm(w3, nknots = 15, bs = "rd") + sm(w4, nknots = 15, bs = "rd") |
             sm(w1, nknots = 15, bs = "rd") + sm(w2, nknots = 15, bs = "rd") + 
             sm(w3, nknots = 15, bs = "rd") + sm(w4, nknots = 15, bs = "rd")
DIR <- getwd()

source("~/Dropbox/BNSP/R/mvrm.R")
dyn.load("~/Dropbox/BNSP/src/mvrmGAM.so")

m3 <- mvrm(formula = Model, data = data, sweeps = 50000, burn = 25000, thin = 5, seed = 1, StorageDir = DIR)

#Summaries

alpha <- mvrm2mcmc(m3, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m3, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m3, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m3, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m3, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m3, "gamma")
delta <- mvrm2mcmc(m3, "delta")

print(m3)

summary(m3, nModels=2)

#Plot mean effects with true curves

# Plot 1 
x1 <- seq(0, 1, length.out = 30)
y1 <- mu1(x1)
y1 <- y1 - mean(y1)

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "mean", term = "sm(w1)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = FALSE, quantiles = c(0.005, 1 - 0.005)) 

#Plot 2
x1 <- seq(0, 1, length.out = 30)
y1 <- mu2(x1)
y1 <- y1 - mean(y1)

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "mean", term = "sm(w2)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = FALSE, quantiles = c(0.005, 1 - 0.005))

# Plot 3
x1 <- seq(0, 1, length.out = 30)
y1 <- mu3(x1)
y1 <- y1 - mean(y1)

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "mean", term = "sm(w3)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = FALSE, quantiles=c(0.005, 1 - 0.005)) 

#Plot 4
x1 <- seq(0, 1, length.out = 30)
y1 <- mu4(x1)
y1 <- y1 - mean(y1)

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "mean", term = "sm(w4)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = FALSE, quantiles = c(0.005, 1 - 0.005))

#Plot stdev effects with true curves

#Plot 1
x1 <- seq(0, 1, length.out = 30)
y1 <- stdev1(x1) / mean(stdev1(x1))

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "stdev", term = "sm(w1)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = TRUE, quantiles = c(0.025, 1 - 0.025))

#Plot 2
x1 <- seq(0, 1, length.out = 30)
y1 <- stdev2(x1) / mean(stdev2(x1))

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "stdev", term = "sm(w2)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = TRUE, quantiles = c(0.025, 1 - 0.025))

#Plot 3
x1 <- seq(0, 1, length.out = 30)
y1 <- stdev3(x1) / mean(stdev3(x1))

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "stdev", term = "sm(w3)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = TRUE, quantiles = c(0.025, 1 - 0.025)) 

#Plot 4
x1 <- seq(0, 1, length.out = 30)
y1 <- stdev4(x1) / mean(stdev4(x1))

PlotOptions <- list(geom_line(aes_string(x = x1, y = y1), col = 2, alpha = 0.5, lty = 2))

plot(x = m3, model = "stdev", term = "sm(w4)", plotOptions = PlotOptions, intercept = FALSE,
     centreEffects = TRUE, quantiles = c(0.025, 1 - 0.025))

##### Data analyses, Univariate case #####

data(cps71)
cps71$nage <- (cps71$age - min(cps71$age)) / (max(cps71$age) - min(cps71$age))

DIR <- getwd()

model <- logwage ~ sm(nage, nknots = 30, bs = "rd") | sm(nage, nknots = 30, bs = "rd")

m4 <- mvrm(formula = model, data = cps71, sweeps = 100000, burn = 25000, thin = 5, seed = 1, StorageDir = DIR)

#Summaries

alpha <- mvrm2mcmc(m4, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m4, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m4, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m4, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m4, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m4, "gamma")
delta <- mvrm2mcmc(m4, "delta")

print(m4)

summary(m4, nModels=2)

# Plots 

wagePlotOptions <- list(geom_point(data = cps71, aes(x = nage, y = logwage)))

plot(x = m4, model = "mean", term = "sm(nage)", plotOptions = wagePlotOptions)

plot(x = m4, model = "stdev", term = "sm(nage)")

#Predictions     
     
x1 <- seq(0, 1, length.out = 20)     
p1 <- predict(m4, newdata = data.frame(nage = x1), interval = "credible")
p2 <- predict(m4, newdata = data.frame(nage = x1), interval = "prediction")

model <- logwage ~ sm(nage, nknots = 30, bs = "rd") | 1

m4 <- mvrm(formula = model, data = cps71, sweeps = 100000, burn = 25000, thin = 5, seed = 1, StorageDir = DIR)

p3<-predict(m4, newdata = data.frame(nage = x1), interval = "prediction")

predA <- ggplot(data = p1) + geom_line(aes(x = x1,y = fit)) + 
         geom_ribbon(aes(x = x1, ymin = lwr, ymax = upr), fill = 2, alpha = 0.8) + 
         geom_ribbon(data = p2, aes(x = x1, ymin = lwr, ymax = upr), fill = 3, color = 3, alpha = 0.4) +
         geom_ribbon(data = p3, aes(x = x1, ymin = lwr, ymax = upr), fill = 4, color = 4, alpha = 0.2)

##### Data analyses, General case #####

data(wage1)
wage1$ntenure <- (wage1$tenure - min(wage1$tenure)) / (max(wage1$tenure) - min(wage1$tenure))
wage1$nexper <- (wage1$exper - min(wage1$exper)) / (max(wage1$exper) - min(wage1$exper))
wage1$neduc <- (wage1$educ - min(wage1$educ)) / (max(wage1$educ) - min(wage1$educ))
wage1$fmarried <- factor(wage1$married)
wage1$ffemale <- factor(wage1$female)

knots1 <- seq(min(wage1$nexper), max(wage1$nexper), length.out = 30)
knots2 <- c(0, 1)
knotsD <- as.matrix(expand.grid(knots1, knots2))

model <- lwage ~ fmarried + sm(ntenure, nknots=30) + 
                 sm(neduc, knots = seq(min(wage1$neduc), max(wage1$neduc), length.out = 30)) +
                 sm(nexper, ffemale, knots = knotsD) | 
                 sm(nexper, knots = seq(min(wage1$nexper), max(wage1$nexper), length.out=30))

DIR <- getwd()

m5 <- mvrm(formula = model, data = wage1, sweeps = 100000, burn = 25000, thin = 5, seed = 1, StorageDir = DIR)

#Summaries

alpha <- mvrm2mcmc(m5, "alpha")
summary(alpha)
plot(alpha)

calpha <- mvrm2mcmc(m5, "calpha")
summary(calpha)
plot(calpha)

beta <- mvrm2mcmc(m5, "beta")
summary(beta)
plot(beta)

ceta <- mvrm2mcmc(m5, "cbeta")
summary(ceta)
plot(ceta)

sigma2 <- mvrm2mcmc(m5, "sigma2")
summary(sigma2)
plot(sigma2)

gamma <- mvrm2mcmc(m5, "gamma")
delta <- mvrm2mcmc(m5, "delta")

print(m5)

summary(m5, nModels=2)

# Plots 

#Tenure 
PlotOptionsT <- list(geom_point(data = wage1, aes(x = ntenure, y = lwage)))
plot(x = m5, model = "mean", term = "sm(ntenure)", quantiles = c(0.025, 0.975),
     plotOptions = PlotOptionsT)

#Education
PlotOptionsEdu <- list(geom_point(data = wage1, aes(x = neduc, y = lwage)))
plot(x = m5, model = "mean", term = "sm(neduc)", quantiles = c(0.025, 0.975), plotOptions = PlotOptionsEdu)

#Interaction 
pchs <- as.numeric(wage1$female)
pchs[pchs == 1] <- 17
pchs[pchs == 2] <- 19
cols <- as.numeric(wage1$female)
cols[cols == 2] <- 3
cols[cols == 1] <- 2 

PlotOptionsE <- list(geom_point(data = wage1, aes(x = nexper, y = lwage), col = cols, pch = pchs, group = wage1$ffemale))
plot(x = m5, model = "mean", term = "sm(nexper,ffemale)", quantiles = c(0.025, 0.975), plotOptions = PlotOptionsE)

#Stdev function
plot(x = m5, model = "stdev", term = "sm(nexper)", quantiles = c(0.025, 0.975))

#Married
PlotOptionsF <- list(geom_boxplot(fill = 2, color = 1))
plot(x = m5, model = "mean", term = "fmarried", quantiles = c(0.025, 0.975), plotOptions = PlotOptionsF)

#Predictions     
     
p1 <- predict(m5, newdata = data.frame(fmarried = rep(c("Married", "Notmarried"), 2), 
      ntenure = rep(0.5, 4), neduc = rep(0.5, 4), nexper = rep(0.5, 4), 
      ffemale = rep(c("Female", "Male"), each = 2)), interval = "credible")
