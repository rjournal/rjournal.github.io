library(mvtnorm)
library(PortfolioOptim)
library(parma) 
library(xts)
library(quantmod)

data(etfdata) 

generate_data_normal <- function (means, covmat, num)
{
    k <- ncol(covmat)
    sim_data <- rmvnorm  (n=num, mean = means, sigma=covmat)
    sim_data <- matrix(num, k, data = sim_data)
    colnames(sim_data) <- colnames(covmat) 
    prob <- matrix(1/num,num,1)
	mod_returns <- cbind(sim_data, prob)	 
    return (mod_returns)
}


prepare_data_KM <- function ()
{
	sample_cov <- matrix(5,5, data = c( 0.003059 ,  0.002556 , 0.002327 , 0.000095 , 0.000533,
 0.002556 ,  0.003384 , 0.002929 ,  0.000032 ,  0.000762,
 0.002327 ,  0.002929 , 0.003509 ,  0.000036 ,  0.000908,
 0.000095 ,  0.000032 , 0.000036 ,  0.000069  , 0.000048 ,
 0.000533 ,  0.000762 , 0.000908  , 0.000048  , 0.000564))
	sample_mean <- c( 0.007417,  0.005822,   0.004236,  0.004231,   0.005534)
	colnames(sample_cov) <- c("MSCI.CH", "MSCI.E", "MSCI.W", "Pictet.Bond", "JPM.Global")
	return(list( sample_mean = sample_mean, sample_cov = sample_cov))
}	

prepare_data <- function (k)
{
	quotData = as.xts(etfdata[1:500 , 1:k])
	retData = NULL
	for (i in 1:k){ 
		retData = cbind(retData,weeklyReturn(quotData[,i], type='arithmetic'))
	} 
	colnames(retData) <- colnames(quotData)
	sample_cov <- cov(retData)  
	sample_mean <- colMeans(retData)
	return(list(sample_mean = sample_mean, sample_cov = sample_cov))
}	


############################################################
#
#  Each test can be run separately by commenting other tests
#
#############################################################

'
#################   Tests 1 and 2  #########################
 
data_nA <- prepare_data_KM()
sample_cov <- data_nA$sample_cov 
sample_mean <-  data_nA$sample_mean 

k <- ncol(sample_cov) 
a0 <- rep(1,k)
Aconstr <- rbind(a0,-a0)
bconstr <- c(1+1e-8, -1+1e-8)

lbound <- rep(0,k)
ubound <- rep(1,k)

R0 = 0.005
ET <- NULL
weights <- NULL	
repetition = 10
sample_size = 100000  # also run for 100 000 and 1 000 0000

ptm <- proc.time()[3] 

	for (i in 1:repetition ){
		mod_returns <- generate_data_normal (sample_mean, sample_cov, sample_size)
		res  <-  BDportfolio_optim (mod_returns, R0, risk = "CVAR",  alpha = 0.95, 
            Aconstr, bconstr,lbound, ubound, maxiter = 200, tol = 1e-10 )
		ET <- c(ET, proc.time()[3] - ptm)
		ptm <- proc.time()[3]              
		weights <- rbind(weights, t(res$theta))
	}
cat("running time and its standard deviation \n")
print(mean(ET))
print(sqrt(var(ET)))

cat("optimal portfolio and confidence intervals of its weights \n")
print((colMeans(weights))*100)
print(sqrt(apply(weights, 2, var))*100*4/sqrt(repetition))	

#################   End of Tests 1 and 2   #################	


#################   Test 3   ###############################



data_nA <- prepare_data (5)  # also run with prepare_data (10)
sample_cov <- data_nA$sample_cov 
sample_mean <-  data_nA$sample_mean 

k <- ncol(sample_cov) 
a0 <- rep(1,k)
Aconstr <- rbind(a0,-a0)
bconstr <- c(1+1e-8, -1+1e-8)
lbound <- rep(0,k)
ubound <- rep(1,k)

R0= 0.004 
weights <- NULL	
repetition = 100
sample_size = 10000  # also run for 100 000 and 1 000 0000
	for (i in 1:repetition ){
		mod_returns <- generate_data_normal (sample_mean, sample_cov, sample_size)
		res  <-  BDportfolio_optim (mod_returns, R0, risk = "CVAR",  alpha = 0.95, 
            Aconstr, bconstr,lbound, ubound, maxiter = 200, tol = 1e-10 )            
		weights <- rbind(weights, t(res$theta))
	}
print(sum(sqrt(apply(weights, 2, var))*100*4/sqrt(repetition))/k)
 
 
#################   End of Test 3   ######################## 
'

#################   Test 4   ###############################	

data_nA <- prepare_data (5)  # also run with prepare_data (10)
sample_cov <- data_nA$sample_cov 
sample_mean <-  data_nA$sample_mean 

k <- ncol(sample_cov) 
a0 <- rep(1,k)
Aconstr <- rbind(a0,-a0)
bconstr <- c(1+1e-8, -1+1e-8)
lbound <- rep(0,k)
ubound <- rep(1,k)
w_m = rep(1/k,k)
R0= 0.005

repetition = 10
sample_size = 500  # also run for 250 and 500

ET <- NULL
ptm <- proc.time()[3] 
	for (i in 1:repetition ){
		mod_returns <- generate_data_normal(sample_mean, sample_cov, sample_size )
		res  <-  PortfolioOptimProjection (mod_returns, R0 , risk = "CVAR",  alpha = 0.95, 
			w_m, Aconstr, bconstr,lbound, ubound, 800, tol = 1e-6 )
		print("A")	
		ET <- c(ET, proc.time()[3] - ptm)
		ptm <- proc.time()[3]
	}	
 
cat("Mean running time and its standard deviation \n")
print(c( mean(ET), sqrt(var(ET))))

#################   End of Test 4   ########################



 
