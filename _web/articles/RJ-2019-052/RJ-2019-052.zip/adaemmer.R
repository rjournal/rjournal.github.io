
## This code replicates all figures in the paper 
## "lpirfs: An R-package to estimate impulse response functions by local projections"
#  Author: Philipp Adämmer


# Load necessary libraries
  library(lpirfs)
  library(tidyverse)

# Load data from lpirfs package 
 endog_data <- interest_rules_var_data

################################################################################ 
#                 ---   Code for Figure 1  ---
################################################################################  
 
# Estimate linear model with lpirfs function
 results_lin <- lp_lin(endog_data,
                       lags_endog_lin = 4,
                       trend          = 0,
                       shock_type     = 0,
                       confint        = 1.96,
                       hor            = 12)

 # Make plots
 linear_plots <- plot_lin(results_lin)

 # Show all plots by using 'ggpubr' and 'gridExtra'
 # lpirfs does not depend on those packages so they have to be installed
 library(ggpubr)
 library(gridExtra)

 # The plot corresponds to Figure 1 in the paper
 lin_plots_all <- sapply(linear_plots, ggplotGrob)
 lp_lin_plots  <- marrangeGrob(lin_plots_all, nrow = ncol(endog_data), 
                                              ncol = ncol(endog_data), top = NULL)
 lp_lin_plots
 
# --- End code for Figure 1

 
################################################################################ 
#                 ---  Code for Figure 2 ---
################################################################################  
 
 # Choose data for switching variable (here Federal Funds Rate)
 switching_data <-  if_else(dplyr::lag(endog_data$Infl, 3) > 4.75, 1, 0)


 # switching_data_log <-  dplyr::lag(endog_data$Infl, 3) %>%
 #                      replace_na(0)

 # Estimate model and save results
 results_nl    <- lp_nl(endog_data,
                        lags_endog_lin  = 4,
                        lags_endog_nl   = 4,
                        trend           = 0,
                        shock_type      = 0,
                        confint         = 1.96,
                        hor             = 12,
                        switching       = switching_data,
                        lag_switching   = F,
                        use_logistic    = F)


 # Use plot functions
 nl_plots <- plot_nl(results_nl)

 # Combine plots by using 'ggpubr' and 'gridExtra'
 single_plots      <- nl_plots$gg_s1[c(3, 6, 9)]
 single_plots[4:6] <- nl_plots$gg_s2[c(3, 6, 9)]

 all_plots <- sapply(single_plots, ggplotGrob)

 # Show all plots
 nl_all_plots <- marrangeGrob(all_plots, nrow = 3, ncol = 2, top = NULL)
 nl_all_plots

# --- End code for Figure 2
 
 
################################################################################ 
#                 ---  Code for Figure 3 ---
################################################################################  
 

# Load data
 ag_data       <- ag_data
 sample_start  <- 7
 sample_end    <- dim(ag_data)[1]

# Endogenous data
 endog_data    <- ag_data[sample_start:sample_end,3:5]

# Variable to shock with. Here government spending due to
# Blanchard and Perotti (2002) framework
 shock         <- ag_data[sample_start:sample_end, 3]

# Estimate linear model
 results_lin_iv <- lp_lin_iv(endog_data,
                             lags_endog_lin = 4,
                             shock          = shock,
                             trend          = 0,
                             confint        = 1.96,
                             hor            = 20)


# Make and save plots
 iv_lin_plots    <- plot_lin(results_lin_iv)

# This example replicates results from the Supplementary Appendix
# by Ramey and Zubairy (2018) (RZ-18).

# Load and prepare data
 ag_data           <- ag_data
 endog_data        <- ag_data[sample_start:sample_end, 3:5]

# The nonlinear shock is estimated by RZ-18.
 shock             <- ag_data[sample_start:sample_end, 7]

# Include four lags of the 7-quarter moving average growth rate of GDP
# as exogenous variables (see RZ-18)
 exog_data         <- ag_data[sample_start:sample_end, 6]

# Use the 7-quarter moving average growth rate of GDP as switching variable
# and adjust it to have suffiently long recession periods.
 switching_variable <- ag_data$GDP_MA[sample_start:sample_end] - 0.8

# Estimate local projections
 results_nl_iv <- lp_nl_iv(endog_data,
                           lags_endog_nl     = 3,
                           shock             = shock,
                           exog_data         = exog_data,
                           lags_exog         = 4,
                           trend             = 0,
                           confint           = 1.96,
                           hor               = 20,
                           switching         = switching_variable,
                           use_hp            = FALSE,
                           gamma             = 3)

# Make and save plots
 plots_nl_iv <- plot_nl(results_nl_iv)

# Make to list to save all plots
 combine_plots <- list()

# Save linear plots in list
 combine_plots[[1]] <- iv_lin_plots[[1]]
 combine_plots[[2]] <- iv_lin_plots[[3]]

# Save nonlinear plots for expansion period
 combine_plots[[3]] <- plots_nl_iv$gg_s1[[1]]
 combine_plots[[4]] <- plots_nl_iv$gg_s1[[3]]

# Save nonlinear plots for recession period
 combine_plots[[5]] <- plots_nl_iv$gg_s2[[1]]
 combine_plots[[6]] <- plots_nl_iv$gg_s2[[3]]

 lin_plots_all     <- sapply(combine_plots, ggplotGrob)
 combine_plots_all <- marrangeGrob(lin_plots_all, nrow = 2, ncol = 3, top = NULL)
 combine_plots_all

 # --- End code for Figure 3

 
################################################################################ 
#                 ---  Code for Figure 4 ---
################################################################################  
 
# Load necessary libraries
  library(httr)
  library(readxl)
  library(dplyr)
 
# Retrieve the external JST Macrohistory Database
  url_jst <-"http://www.macrohistory.net/JST/JSTdatasetR3.xlsx"
  GET(url_jst, write_disk(jst_link <- tempfile(fileext = ".xlsx")))
  jst_data <- read_excel(jst_link, 2L)
 
# Swap the first two columns 
  jst_data <- jst_data                    %>%
              dplyr::filter(year <= 2013) %>%
              dplyr::select(country, year, everything())
 
# Prepare variables
  data_set <- jst_data %>%
             mutate(stir    = stir)                         %>%
             mutate(mortgdp = 100*(tmort/gdp))              %>%
             mutate(hpreal  = hpnom/cpi)                    %>%
             group_by(country)                              %>%
             mutate(hpreal  = hpreal/hpreal[year==1990][1]) %>%
             mutate(lhpreal = log(hpreal))                  %>%
   
             mutate(lhpy    = lhpreal - log(rgdppc))        %>%
             mutate(lhpy    = lhpy - lhpy[year == 1990][1]) %>%
             mutate(lhpreal = 100*lhpreal)                  %>%
             mutate(lhpy    = 100*lhpy)                     %>%
             ungroup()                                      %>%
   
             mutate(lrgdp   = 100*log(rgdppc))              %>%
             mutate(lcpi    = 100*log(cpi))                 %>%
             mutate(lriy    = 100*log(iy*rgdppc))           %>%
             mutate(cay     = 100*(ca/gdp))                 %>%
             mutate(tnmort  = tloans - tmort)               %>%
             mutate(nmortgdp = 100*(tnmort/gdp))            %>%
             dplyr::select(country, year, mortgdp, stir, ltrate, 
                                                    lhpy, lrgdp, lcpi, lriy, cay, nmortgdp)
 
 
# Exclude observations from WWI and WWII
  data_sample <- seq(1870, 2016)[which(!(seq(1870, 2016) %in%
                                            c(seq(1914, 1918), 
                                            seq(1939, 1947))))]
 
# Estimate linear panel model
  results_panel <- lp_lin_panel(data_set  = data_set,  data_sample  = data_sample,
                                endog_data        = "mortgdp", cumul_mult   = TRUE,
                                shock             = "stir",    diff_shock   = TRUE,
                                panel_model       = "within",  panel_effect = "individual",
                                robust_cov        = "vcovSCC", c_exog_data  = "cay",
                                c_fd_exog_data    = colnames(data_set)[c(seq(4,9),11)],
                                l_fd_exog_data    = colnames(data_set)[c(seq(3,9),11)],
                                lags_fd_exog_data = 2,      confint      = 1.67,
                                hor               = 10)
 
# Create and plot irfs
  plot_lin_panel <- plot_lin(results_panel)
  plot(plot_lin_panel[[1]])
 

# --- End code for Figure 4
  
  
################################################################################ 
#                 ---  Code for Figure 5 ---
################################################################################  
  
  
# Estimate panel model
 results_panel <- lp_nl_panel(data_set          = data_set,  
                              data_sample       = data_sample,
                              endog_data        = "mortgdp", cumul_mult     = TRUE,
                              shock             = "stir",    diff_shock     = TRUE,
                              panel_model       = "within",  panel_effect   = "individual",
                              robust_cov        = "vcovSCC", switching      = "lrgdp",
                              lag_switching     = TRUE,      use_hp         = TRUE,
                              lambda            = 6.25,      gamma          = 10,
                              c_exog_data       = "cay",     
                              c_fd_exog_data    = colnames(data_set)[c(seq(4,9),11)],
                              l_fd_exog_data    = colnames(data_set)[c(seq(3,9),11)], 
                              lags_fd_exog_data = 2,      
                              confint           = 1.67,
                              hor               = 10)
 
# Create and show linear plots
  nl_plots      <- plot_nl(results_panel)
  combine_plots <- list(nl_plots$gg_s1[[1]], nl_plots$gg_s2[[1]])
  nonlinear_panel_plots <- marrangeGrob(combine_plots, nrow = 1, ncol = 2, top = NULL)
  nonlinear_panel_plots
  

# --- End code for Figure 5


