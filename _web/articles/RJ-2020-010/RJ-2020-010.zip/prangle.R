## REPRODUCTION CODE FOR G&K PAPER
## nb each of the code blocks that follow can be run separately of the others


## CODE FOR FIGURE 1

library(gk)

pdf(file="densities.pdf", width=8, height=4)

par(mfrow=c(1,3))
x = seq(-10,10,0.01)
plot(x,x,ylim=c(0,0.4),type='n',ylab='Density')
ks = seq(0, 2, 0.5)
for (i in 1:length(ks)) {
    lines(x, dgk(x,0,1,0,ks[i]), col=i)
}
legend('topright', legend=ks, lty=1, col=1:length(ks), title='k', bty='n')

x = seq(-5,5,0.01)
plot(x,x,ylim=c(0,1.05),type='n',ylab='')
gs = seq(0, 1, 0.2)
for (i in 1:length(gs)) {
    lines(x, dgk(x,0,1,gs[i],0), col=i)
}
legend('topright', legend=gs, lty=1, col=1:length(gs), title='g', bty='n')

x = seq(-4,4,0.01)
plot(x,dgk(x,0,1,0,-0.4),type='l',ylab='', ylim=c(0,0.7))
lines(x,dgk(x,0,1,-0.5,-0.1), col='red')
legend('topright', legend=c('g=0, k=-0.4', 'g=-0.5,k=-0.1'), lty=1, col=1:2, title=' ', bty='n')

dev.off()


## CODE FOR TABLE 1

library(gk)
library(microbenchmark)
library(magrittr)
library(xtable)

##Expects 3 inputs: normal, gk, gh
timings = function(...) {
    s = microbenchmark(...) %>% summary
    out = c(s$mean, s$mean[2:3]/s$mean[1])
    names(out) = c("Normal time", "gk time", "gh time", "gk ratio", "gh ratio")
    out
}

N = 100
set.seed(1)
rbind(
    timings(rnorm(N), rgk(N,1,2,3,4), rgh(N,1,2,3,4)),
    timings(qnorm(runif(N)), qgk(runif(N),1,2,3,4), qgh(runif(N),1,2,3,4)),
    timings(pnorm(rnorm(N)), pgk(rnorm(N),1,2,3,4), pgh(rnorm(N),1,2,3,4)),
    timings(dnorm(rnorm(N)), dgk(rnorm(N),1,2,3,4), dgh(rnorm(N),1,2,3,4))
) %>% xtable


## CODE FOR FIGURE 2

library(gk)
library(ggplot2)
gk_grid = expand.grid(g = seq(-10,10,0.1), k = seq(-0.6,0.1,0.01))
v = isValid(gk_grid$g, gk_grid$k)
gk_grid = cbind(gk_grid, valid=v)
g = seq(-8,8,0.1)
gk_line = data.frame(g=g, k=-0.045-0.01*g^2)
gk_line = gk_line[gk_line$k>=-0.6,]
# Next line from http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/#a-colorblind-friendly-palette
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
ggplot() +
    geom_raster(aes(x=g, y=k, fill=valid), gk_grid) +
    geom_line(aes(g, k), gk_line) +
    theme_bw() +
    scale_fill_manual(values=cbPalette)
ggsave("gk_validity.pdf", width=8, height=4)


## CODE FOR ILLUSTRATION SECTION

library(gk)
fx("for paper") # See this function's code for full details


## CODE FOR FIGURE 8

tomin = function(u) 1/(u/cosh(u)^2 + tanh(u))
cstar = optimise(tomin, c(0.1,2))$objective

pdf(file="cplot.pdf", height=4, width=8)

u = seq(0.1,6,length.out=1000)
cval = tomin(u)
plot(u, cval, type='l', ylim=c(0.8,1.2), ylab='c', las=1)
abline(h=cstar, lty=2)
axis(side=2, at=cstar, labels='0.83', las=1)

dev.off()
