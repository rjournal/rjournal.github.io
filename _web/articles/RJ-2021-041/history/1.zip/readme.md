## Files for bestNormalize JSS submission 

Cover letter: Submission-Letter.txt
Manuscript: RJournal_Submission.pdf
Figure/Table Replication script: RJournal_Submission.R

Ancillary files needed for text reproduction:

- RJournal-Submission.tex
- RJwrapper.tex
- RJournal-Submission.bib
- figs/ subdirectory containing all figures

Ancillary files needed for full reproduction:

  R packages: 
  - bestNormalize 1.6.1+ (version 1.6.1 submitted with paper)
  - kableExtra
  - recipes
  - caret
  - tibble
  - visreg
  - tidymodels
  - rsample
  - arsenal
  
  Other files (provided)
  - caret_application_results.RData (or, to reproduce these, run caret_application.R)
  - Rmd submission file was converted to R script for submission via 
    knitr::purl("RJournal-Submission.Rmd"); Rjournal-Submission.Rmd also provided for reference. 
  - figs/parallel_timings.pdf

