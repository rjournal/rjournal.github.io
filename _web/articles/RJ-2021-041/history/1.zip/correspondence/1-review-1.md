I enjoyed reading the paper. It is very well written and the topic is very good. The examples are very good at illustrating the topics and I found the discussion about the pros and cons of the methods to be excellent. The references are very interesting. 

My comments are mostly minor. 

\- Please use `TRUE` and `FALSE` instead of `T` and `F`. 

\- In the first paragraph, I would suggestion "transform it into a specific scale" rather than "transform it to the 0-1 scale". 

\- For the discussion of the BC and YJ transformations, it is important to put out that these are originally used to transform the outcome data by estimating the transformation from the residuals resulting from a specific model. You might want to discuss this more generally and describe how one might use the residuals from a linear model to estimate the outcome transformation (if that is possible) since that is really the assumption in basic linear regression using ordinary least squares. 

\- Somewhere there should be a discussion on how some of these transformations will improve some variance calculations. For example, some predictors manipulations rely on second order statistics (e.g. PCA or PLS measuring _predictor_ variation). These normalizing transformations can improve the quality of downstream computations by not letting skewed distributions adversely affect second order functions that are sensitive to "outliers".

\- The `scales` package is important to the `ggplot2` package since it defines some empirically determined transformation scales (e.g. BV and YJ). It might be nice to add at least an `OrderNorm` scale (if not a `bestNormalize` one). 

\- The initial recipes code should have more specificity about the selectors (instead of `all_numeric()`). That might unintentionally transform the outcome and the reader should be warned about that. 

\- While the `juice()` function still exists, it is deprecated in favor of using `bake(recipe, new_data = NULL)`. The code should be changed to use `bake()`. 

\- Please add some common delimiters to the larger numbers in table 1. 

\- The `tidy()` method for `step_bestNormaliuze()` could use some work. The goal of that method should be to provide the underlying data about the method in an easy-to-use format. The entire `bestNormalize()` output is there but the user would have to do a lot to use that data. I suggest writing a `tidy()` method for the `bestNormalize()` object that returns those statistics in a tidy format. 

\- For the step function, we try to avoid carrying around statistics/data from the training set that could be recreated later. For large data set, this blows up the size of the recipe. I suggest adding a step function option to remove as much of the data as possible (and provide the minimal parts for applying or inverting the transformation). If you do add an option, I suggest calling it `axe` to be consistent with the `butcher` package. 

\- Also, for the step function, tidymodels prefers snake case to camel case (we are slowly reverting current functions that use camel case). Can you rename `step_bestNormalize()` to something like `step_trans_normal()` or `step_transform_best()`? We also use the phrase "normalize" in recipes to denote centering and scaling. (This was already submitted as a GitHub issue).  

\- If you know of a reference that compares different statistics to evaluated normality, that would be helpful in the custom code section. 

