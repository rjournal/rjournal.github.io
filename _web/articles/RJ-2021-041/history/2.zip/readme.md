## Files for bestNormalize R Journal submission 

Response to reviewer comments/cover letter: author_response.md
Manuscript: RJwrapper.pdf
Figure/Table Replication script: RJournal_Submission.R

Ancillary files needed for text reproduction:

- RJournal-Resubmission.tex
- RJwrapper.tex
- RJournal-Resubmission.bib
- figs/ subdirectory containing all figures

Ancillary files needed for full reproduction:

  R packages: 
  - bestNormalize 1.7.0+ (submitted with paper, available on GitHub, CRAN pending)
  - kableExtra 
  - recipes
  - caret
  - tibble
  - visreg
  - tidymodels
  - rsample
  - arsenal
  
  Other files (provided)
  - caret_application_results.RData (or, to reproduce these, run caret_application.R)
  - Rmd submission file was converted to R script for submission via 
    knitr::purl("RJournal-Resubmission.Rmd"); Rjournal-Resubmission.Rmd also provided for reference. 
  - figs/parallel_timings.pdf

