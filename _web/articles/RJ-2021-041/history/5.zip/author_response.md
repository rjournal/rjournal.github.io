# Cover letter and author response to reviewer comments

March 1, 2021

Dear Editor,

Thank you for facilitating this manuscript's review and accepting a 
revised manuscript for publication in the R Journal. I have addressed each 
of the reviewers request below. 

Please note: 

- All reviewer comments are marked with "> "
- My comments are not indented
- Quotes from resubmission are indented, but not marked with "> ". 

Please reach out with any questions or needs. 

Sincerely,

Ryan A. Peterson
Assistant Professor
Biostatistics and Informatics
Colorado School of Public Health
University of Colorado Anschutz Medical Campus

--- Begin review and response ---

> I enjoyed reading the paper. It is very well written and the topic is very good. The examples are very good at illustrating the topics and I found the discussion about the pros and cons of the methods to be excellent. The references are very interesting. 

> My comments are mostly minor. 

> \- Please use `TRUE` and `FALSE` instead of `T` and `F`. 

All instances of `T`/`F` in the paper and in the package itself have been changed to `TRUE` and `FALSE` respectively.

> \- In the first paragraph, I would suggestion "transform it into a specific scale" rather than "transform it to the 0-1 scale". 

Great suggestion - this has been updated in the resubmission. 

> \- For the discussion of the BC and YJ transformations, it is important to put out that these are originally used to transform the outcome data by estimating the transformation from the residuals resulting from a specific model. You might want to discuss this more generally and describe how one might use the residuals from a linear model to estimate the outcome transformation (if that is possible) since that is really the assumption in basic linear regression using ordinary least squares. 

I now mention the first part of reviewer's comment in the second paragraph : 

    In fact, many of the more complex normalization methods mentioned in the following
    section were designed in order to find the best transformation that would render
    regression residuals Gaussian.

I also have added the following to the discussion to explain how this might be used to address the classical linear regression problem.
I don't want to encourage this necessarily, since this "beat the data to look normal" approach is often not the optimal solution. 

    So, while normalization transformations may well be able to increase robustness of 
    results and mitigate violations to the classical linear regression assumption of 
    Gaussian residuals, it is by no means a universal solution.

> \- Somewhere there should be a discussion on how some of these transformations will improve some variance calculations. For example, some predictors manipulations rely on second order statistics (e.g. PCA or PLS measuring _predictor_ variation). These normalizing transformations can improve the quality of downstream computations by not letting skewed distributions adversely affect second order functions that are sensitive to "outliers".

This is a very good point. I have added a short mention of this in the first paragraph: 

    Normalization of covariates can mitigate their leverage and influence, thereby 
    allowing for easier model selection and more robust downstream predictor 
    manipulations (such as principal components analysis), which can otherwise be very 
    sensitive to skew or outliers.

as well as in the discussion:

    For example, in machine learning contexts, some predictor manipulations rely on 
    second order statistics (e.g. principal components analysis or partial least 
    squares), for which the variance calculation can be sensitive to skew and outliers.
    Normalizing transformations can improve the quality and stability of these 
    calculations. 

> \- The `scales` package is important to the `ggplot2` package since it defines some empirically determined transformation scales (e.g. BV and YJ). It might be nice to add at least an `OrderNorm` scale (if not a `bestNormalize` one). 

Thank you for the good suggestion. It's actually quite easy to use `predict` in order to use `scales` with all of the normalization transformations including `bestNormalize` and `orderNorm`, however a bit challenging to define a scale within the package (since a user may wish to have multiple bestNormalize scales for different variables). 

I have included a section in the package vignette on how a user can do this, and added a footnote to the paper pointing this out:

    Alternatively, one can use \CRANpkg{scales} and \CRANpkg{ggplot2} to visualize any 
    transformation fit using \CRANpkg{bestNormalize}; instructions are included in the 
    package vignette.

> \- The initial recipes code should have more specificity about the selectors (instead of `all_numeric()`). That might unintentionally transform the outcome and the reader should be warned about that. 

I've updated the manuscript to use `all_predictors(), -all_nominal()` to avoid the recommendation to use `all_numeric()` for the reasons mentioned. I did not include any warnings in the software itself, as it's possible users might want to include the outcome in this step, and  `all_numeric()` should be expected to work in this manner. 

> \- While the `juice()` function still exists, it is deprecated in favor of using `bake(recipe, new_data = NULL)`. The code should be changed to use `bake()`. 

Thank you for pointing this out, this is now changed. 

> \- Please add some common delimiters to the larger numbers in table 1. 

Done. 

> \- The `tidy()` method for `step_bestNormaliuze()` could use some work. The goal of that method should be to provide the underlying data about the method in an easy-to-use format. The entire `bestNormalize()` output is there but the user would have to do a lot to use that data. I suggest writing a `tidy()` method for the `bestNormalize()` object that returns those statistics in a tidy format. 

I have written a tidy method for `bestNormalize`, which is called then in the tidy method for `step_bestNormalize`. Unfortunately, I need to include the full transformation object in this tidy output, as in order to apply each transform (well, the ORQ transform anyway), I need all of the training data (see my response to the next comment for improving scalability).   

> \- For the step function, we try to avoid carrying around statistics/data from the training set that could be recreated later. For large data set, this blows up the size of the recipe. I suggest adding a step function option to remove as much of the data as possible (and provide the minimal parts for applying or inverting the transformation). If you do add an option, I suggest calling it `axe` to be consistent with the `butcher` package. 


I have added functionality to `axe` the `bestNormalize` and `orderNorm` step functions with the `butcher` package. I believe this current implementation will act similar to the axing methodology on existing `step_*` methods in the recipes package. It's perhaps possible to improve the scalability even further by axing away even more (than extraneous data contained the environment), but this is somewhat beyond my expertise. 

The new axing functionality has been added to the package documentation and to unit tests. 

> \- Also, for the step function, tidymodels prefers snake case to camel case (we are slowly reverting current functions that use camel case). Can you rename `step_bestNormalize()` to something like `step_trans_normal()` or `step_transform_best()`? We also use the phrase "normalize" in recipes to denote centering and scaling. (This was already submitted as a GitHub issue).  

I was unaware of these preferences within the tidymodels ecosystem. `step_bestNormalize` has been changed to `step_best_normalize` to better be accommodated into the tidymodels infrastructure. 

> \- If you know of a reference that compares different statistics to evaluated normality, that would be helpful in the custom code section. 

I have added a mention and citation to Royston (1991) who discussed another statistic to estimate the departure from normality. It seems as though besides this article, the literature has been too focused on hypothesis testing for normality rather than estimating the departures from it. I also added the following, to the custom code section: 

    A p-value for normality should not be routinely used as the sole selector of a   
    normalizing transformation. A normality test's p-value, as a measure of the
    departure from normality, is confounded by the sample size (a high sample size
    may yield strong evidence of a practically insignificant departure from normality).
    Therefore, we suggest the statistic used should  estimate the departure from
    normality, rather the strength of evidence against normality [e.g., @normality].
    
