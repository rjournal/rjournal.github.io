# ------------------------------------------------------------------------------
# Reproducible code for figures and tables 
# Note that figures and numerical results may appear different due to
# the purposeful randomness of the algorithm
# ------------------------------------------------------------------------------

devtools::install_github("jreisner/biclustermd")
library(biclustermd)
library(tidyverse)
library(stringr)
library(reshape2)

# Figure 1 ---------------------------------------------------------------------
A <- matrix(1:9, nrow = 3, ncol = 3)
B <- matrix(5, nrow = 3, ncol = 3)
chb <- kronecker(A, B)

rownames(chb) <- 1:9
colnames(chb) <- 1:9

chb1 <- matrix(jitter(c(chb), amount = 1/3), nrow = 9, ncol = 9)

nc <- ncol(chb1)
nr <- nrow(chb1)


y_title <- expression(paste("Row (", italic("i"), ")"))
x_title <- expression(paste("Column (", italic("j"), ")"))

chb3 <- chb1[sample(nrow(chb1)), sample(ncol(chb1))]
data.frame(chb3) %>%
  mutate(Row = as.factor(1:9)) %>%
  gather(Column, value, -Row) %>%
  mutate(Column = as.factor(rep(1:9, each = 9)),
         value = as.numeric(value)) %>%
  ggplot(aes(x = Column, y = Row)) +
  geom_tile(aes(fill = as.numeric(value))) +
  scale_fill_viridis_c(guide = FALSE) +
  theme_bw(base_size = 16) +
  ggtitle("Raw Data Matrix") +
  labs(y = y_title, x = x_title) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        aspect.ratio = 1)
ggsave("RawDataMatrix0805.pdf", width = 4.28, height = 4.21, units = 'in')


# below I assign x and y labels by visually pairing the "raw data matrix" (chb3) 
#   to the "shuffled data matrix" (chb1)
data.frame(chb1) %>%
  mutate(Variety = as.factor(1:9)) %>%
  gather(Location, value, -Variety) %>%
  mutate(Location = as.factor(rep(1:9, each = 9)),
         value = as.numeric(value)) %>%
  ggplot(aes(x = Location, y = Variety)) +
  geom_tile(aes(fill = as.numeric(value))) +
  scale_fill_viridis_c(guide = FALSE) +
  scale_x_discrete(labels = c(6, 1, 9, 3, 5, 8, 4, 2, 7)) +
  scale_y_discrete(labels = c(6, 3, 8, 1, 2, 9, 4, 5, 7)) +
  theme_bw(base_size = 16) +
  ggtitle("Shuffled Data Matrix") +
  labs(y = y_title, x = x_title) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        aspect.ratio = 1)
ggsave("ShuffledDataMatrix0805.pdf", width = 4.28, height = 4.21, units = 'in')


# FLIGHTS DATA -----------------------------------------------------------------
library(scales)
library(nycflights13)
data("flights")

# Data prep needed for Figures 2 - 9 
flights <- flights %>%
  select(month, dest, arr_delay)

flights <- flights %>%
  group_by(month, dest) %>%
  summarise(mean_arr_delay = mean(arr_delay, na.rm = TRUE)) %>%
  spread(dest, mean_arr_delay) %>% 
  as.data.frame()

rownames(flights) <- flights$month
flights <- as.matrix(flights[, -1])

bc <- biclustermd(data = flights, col_clusters = 6, row_clusters = 4,
                  miss_val = mean(flights, na.rm = TRUE), miss_val_sd = 1,
                  row_min_num = 3, col_min_num = 5,
                  row_num_to_move = 1, col_num_to_move = 1,
                  row_shuffles = 1, col_shuffles = 1,
                  max.iter = 20, verbose = TRUE)
bc
saveRDS(bc, "reproducible bc.rds")
bc <- readRDS("reproducible bc.rds")

# Figure 2 
autoplot(bc$Similarities, ncol = 3) + 
  theme_bw() +
  theme(aspect.ratio = 1) + 
  scale_x_continuous(breaks = 0:9)
ggsave("ri_NYC_0618.pdf", width = 9, height = 3, units = 'in')

# Figure 3 
autoplot(bc$SSE) + 
  theme_bw() +
  theme(aspect.ratio = 1) + 
  scale_y_continuous(labels = comma) + 
  scale_x_continuous(breaks = 0:9)
ggsave("sse_NYC_0618.pdf", width = 4, height = 4, units = 'in')


# Figure 4 
autoplot(bc) +
  scale_fill_viridis_c(na.value = 'white') +
  labs(x = "Destination Airport",
       y = "Month",
       fill = "Average Delay")
ggsave("bc1_0618.pdf", width = 6.4, height = 4.6, units = 'in')

# Figure 5 
autoplot(bc, transform_colors = TRUE, c = 1/15) +
  scale_fill_viridis_c(na.value = 'white') +
  labs(x = "Destination Airport",
       y = "Month",
       fill = "Average Delay")
ggsave("bc2_0618.pdf", width = 6.4, height = 4.6, units = 'in')

# Figure 6 
autoplot(bc, reorder = TRUE, transform_colors = TRUE, c = 1/15) +
  scale_fill_viridis_c(na.value = 'white') +
  labs(x = "Destination Airport",
       y = "Month",
       fill = "Average Delay")
ggsave("bc3_0618.pdf", width = 6.4, height = 4.6, units = 'in')

# Figure 7 
autoplot(bc, col_clusts = c(3, 4), row_clusts = c(1, 4)) +
  scale_fill_viridis_c(na.value = 'white') +
  labs(x = "Destination Airport",
       y = "Month",
       fill = "Average Delay")
ggsave("bc4_0618.pdf", width = 6.4, height = 4.6, units = 'in')

# Figure 8 
mse_heatmap(bc) +
  theme_bw() +
  scale_fill_viridis_c() +
  labs(fill = "Cell MSE") +
  scale_x_continuous(breaks = 1:6)
ggsave("mse_heatmap_NYC_0618.pdf", width = 5.4, height = 4.1, units = 'in')

# Figure 9 
cell_heatmap(bc) +
  theme_bw() +
  scale_fill_viridis_c()
ggsave("cell_size_NYC_0618.pdf", width = 5.4, height = 4.1, units = 'in')



# SOYBEAN YIELD DATA --------------------------------------------------------------
yield <- readRDS("Soybeans_Direct_Yield.rds")

yield_bc <- biclustermd(yield, col_clusters = 10, row_clusters = 11, 
                        similarity = "Jaccard",
                        miss_val = mean(yield, na.rm = TRUE),
                        miss_val_sd = sd(yield, na.rm = TRUE),
                        col_min_num = 3, row_min_num = 3,
                        col_num_to_move = 1, row_num_to_move = 1,
                        row_shuffles = 1, col_shuffles = 1,
                        max.iter = 100)
yield_bc
saveRDS(yield_bc, "reproducible yield bc.rds")
yield_bc <- readRDS("reproducible yield bc.rds")

# Figure 10 
autoplot(yield_bc$Similarities, facet = TRUE, ncol = 3, size = 0) + 
  theme_bw() +
  theme(aspect.ratio =  1)
ggsave("ri_yield_0618.pdf", width = 9, height = 3, units = 'in')

# Figure 11 
autoplot(yield_bc$SSE, size = 1) + 
  theme_bw() +
  theme(aspect.ratio =  1) + 
  scale_y_continuous(labels = scales::comma)
ggsave("sse_yield_0618.pdf", width = 5.4, height = 4.1, units = 'in')

# Tuned bicluster
yield_tbc <- tune_biclustermd(
  yield, 
  nrep = 10,
  tune_grid = expand.grid(
    col_clusters = 10,
    row_clusters = 11,
    similarity = "Jaccard",
    miss_val_sd = sd(yield, na.rm = TRUE),
    col_min_num = 3, 
    row_min_num = 3,
    row_shuffles = c(1, 3, 6), 
    col_shuffles = c(1, 3, 6)
    ),
  parallel = TRUE,
  ncores = 2
  )
saveRDS(yield_tbc, file = "yield_tbc.rds")

# MOVIE DATA RUN TIME ----------------------------------------------------------
times <- read.csv("movieTimesExperiment1_again.csv")
times <- times %>% as_tibble()

times2 <- read.csv("movieTimesExperiment2_again.csv")
times2 <- times2 %>% as_tibble()

fulltimes <- bind_rows(
  times %>% mutate(set = "first"), 
  times2 %>% mutate(set = "second")
)

fulltimes <- fulltimes %>% 
  add_count(rows, cols, N, col_clusts, row_clusts, name = "trials") %>% 
  filter(trials == 30)

fulltimes <- fulltimes %>% 
  mutate(
    avg_row_clust_size = rows / row_clusts,
    avg_col_clust_size = cols / col_clusts
  )

# Table 1
ft_summ_tbl <- bind_rows(
  fulltimes %>% 
    summarise_at(
      vars(rows:col_clusts, avg_row_clust_size, avg_col_clust_size),
      min
    ) %>% mutate(stat = "min"),
  fulltimes %>% 
    summarise_at(
      vars(rows:col_clusts, avg_row_clust_size, avg_col_clust_size),
      mean
    ) %>% mutate(stat = "mean"),
  fulltimes %>% 
    summarise_at(
      vars(rows:col_clusts, avg_row_clust_size, avg_col_clust_size),
      max
    ) %>% mutate(stat = "max")
) %>% 
  select(stat, rows:avg_col_clust_size) %>% 
  mutate_at(vars(rows:avg_col_clust_size), round) %>% 
  rename(
    Rows = rows,
    Columns = cols,
    `Column Clusters` = col_clusts,
    `Row Clusters` = row_clusts,
    `Mean Row Cluster Size` = avg_row_clust_size,
    `Mean Column Cluster Size` = avg_col_clust_size
  ) %>% 
  select(1, 4, 2, 3, 6, 5, 7, 8) %>% 
  xtable::xtable(auto = TRUE)
ft_summ_tbl
print(ft_summ_tbl, include.rownames = FALSE)

# Table 2
rt_mat <- matrix(summary(fulltimes$elapsed))
rownames(rt_mat) <- names(summary(fulltimes$elapsed))
rt_mat
rt_df <- t(rt_mat) %>% as.data.frame()
rt_df

ft_stat_tbl <- fulltimes %>%
  select(sparsity:col_clusts, elapsed, iterations) %>% 
  mutate(
    diff_from_min = abs(elapsed - min(elapsed)) == min(abs(elapsed - min(elapsed))),
    diff_from_q1 = abs(elapsed - quantile(elapsed, 0.25)) == min(abs(elapsed - quantile(elapsed, 0.25))),
    diff_from_median = abs(elapsed - median(elapsed)) == min(abs(elapsed - median(elapsed))),
    diff_from_mean = abs(elapsed - mean(elapsed)) == min(abs(elapsed - mean(elapsed))),
    diff_from_q3 = abs(elapsed - quantile(elapsed, 0.75)) == min(abs(elapsed - quantile(elapsed, 0.75))),
    diff_from_max = abs(elapsed - max(elapsed)) == min(abs(elapsed - max(elapsed)))
  ) %>% 
  filter(diff_from_min | diff_from_q1 | diff_from_median | diff_from_mean | diff_from_q3 | diff_from_max) %>% 
  arrange(-diff_from_min, -diff_from_q1, -diff_from_median, -diff_from_mean, -diff_from_q3, -diff_from_max) %>% 
  mutate(
    stat = c("Min", "Q1", "Median", "Median", "Mean", "Q3", "Max")
  ) %>% 
  select(stat, Seconds = elapsed, rows:col_clusts, Sparsity = sparsity) %>% 
  mutate(
    Seconds = round(Seconds, 1),
    Sparsity = paste0(round(Sparsity, 3) * 100, "%"),
    rows = scales::comma(rows),
    cols = scales::comma(cols),
    N = scales::comma(N)
  ) %>% 
  xtable::xtable(auto = TRUE)
ft_stat_tbl
print(ft_stat_tbl, include.rownames = FALSE)

# Figure 12
variable_cleaned <- fulltimes %>% 
  group_by(sparsity, rows, cols, N, col_clusts, row_clusts, avg_row_clust_size, avg_col_clust_size, set) %>% 
  summarise(avg_time = mean(elapsed)) %>% 
  ungroup() %>% 
  mutate(ind = row_number()) %>% 
  gather(variable, value, -ind, -set) %>% 
  distinct(variable) %>% 
  mutate(
    cleaned = c(
      "Sparsity",
      "Rows", 
      "Columns",
      "N",
      "Column Clusters",
      "Row Clusters",
      "Avg Row Cluster Size",
      "Avg Column Cluster Size",
      "Avg Time (seconds)"
    )
  )

fulltimes %>% 
  group_by(sparsity, rows, cols, N, col_clusts, row_clusts, avg_row_clust_size, avg_col_clust_size, set) %>% 
  summarise(avg_time = mean(elapsed)) %>% 
  ungroup() %>% 
  mutate(ind = row_number()) %>% 
  gather(variable, value, -ind, -avg_time, -set) %>% 
  left_join(variable_cleaned) %>% 
  mutate(
    cleaned = factor(cleaned, levels = c(
      "N", "Rows", "Columns", "Row Clusters", "Column Clusters",
      "Avg Row Cluster Size", "Avg Column Cluster Size", "Sparsity"
    ))
  ) %>% 
  ggplot(aes(value, avg_time)) +
  geom_point(alpha = 1/4) +
  facet_wrap(~ cleaned, scales = "free_x") + 
  scale_y_continuous("Average Time (sec)", labels = scales::comma)
ggsave("time_pairs.pdf", width = 9, height = 6, units = 'in')

# Figure 13
fulltimes %>% 
  group_by(avg_row_clust_size, avg_col_clust_size, set) %>% 
  summarise(avg_time = mean(elapsed)) %>% 
  ungroup() %>% 
  mutate(ind = row_number()) %>% 
  gather(variable, value, -ind, -avg_time, -set) %>% 
  left_join(
    tibble(
      variable = c("avg_row_clust_size", 'avg_col_clust_size'),
      cleaned = c("Rows", "Columns")
    )
  ) %>% 
  mutate(
    cleaned = factor(cleaned, levels = c("Rows", "Columns"))
  ) %>% 
  ggplot(aes(value, avg_time)) +
  geom_point(alpha = 1/1) +
  facet_wrap(~ cleaned, scales = "free_x") + 
  scale_x_log10("Average Cluster Size", labels = scales::comma) + 
  scale_y_log10("Average Time (sec)", labels = scales::comma)
ggsave("time_clust_sizes.pdf", width = 6, height = 3, units = 'in')
