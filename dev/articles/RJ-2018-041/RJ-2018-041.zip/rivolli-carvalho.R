library(utiml)

# It's necessary download the flags dataset from http://mulan.sourceforge.net/datasets-mlc.html
#flags <- mldata(mldr("flags"))

# Change default options
options(utiml.base.algorithm = "RF", utiml.cores=8)

# Reset the options as default:
options(utiml.base.algorithm = "SVM", utiml.cores=1)

# Pre-processing examples
new.toyml <- remove_attributes(toyml, c("iatt8", "iatt9", "ratt10"))
pre.process <- function (mdata) {
   aux <- remove_skewness_labels(mdata, 5)  # Remove infrequent labels (less than 5)
   aux <- remove_unlabeled_instances(aux)   # Remove instances without labels 
   aux <- remove_unique_attributes(aux)     # Remove constant attributes
   return(mdata)
}
new.toyml <- pre.process(new.toyml)

# Simple train/test experiment
# Note: requires the randomForest package
set.seed(123)
ds <- create_holdout_partition(new.toyml, c(train=0.7, test=0.3))
model <- br(ds$train, "RF")
predictions <- predict(model, ds$test)
print(multilabel_evaluate(ds$test, predictions, c("example-based", "macro-F1")))

# Run baseline prediction
base.predictions <- predict(baseline(ds$train, "general"), ds$test)
print(multilabel_evaluate(ds$test, base.predictions, c("hamming-loss", "F1")))

# Show prediction results
cat("\nProbability/Score\n")
print(head(predictions))
cat("Bipartitions\n")
print(head(as.bipartition(predictions)))
cat("Ranking\n")
print(head(as.ranking(predictions)))
cat("Threshold\n")
print(head(mcut_threshold(predictions)))

# Using KNN with k = 5 and changing ECC parameters
# Note: Requires kknn package
model1 <- ecc(ds$train, "KNN", m=7, subsample=0.8, k=5)

# Using C5.0 and changing ECC parameters
# Note: Requires C50 package
model2 <- ecc(ds$train, "C5.0", subsample=0.6, attr.space=1)

# Using SVM with cost = 10 and gamma = 0.5 and default ECC parameters
# Note: Requires e1071 package
model3 <- ecc(ds$train, "SVM", cost=10, gamma=0.5)

# Houldout using 3 partitions
set.seed(123)
partitions <- c(train=0.7, test=0.2, val=0.1)
strat <- create_holdout_partition(new.toyml, partitions, "iterative")

#Experiment using k-fold cross validation
set.seed(123)
folds <- create_kfold_partition(new.toyml, 10, "stratified")

# Train and predict the folds
# Note: Requires the parallel package
preds <- lapply(seq(10), function (k){
    ds <- partition_fold(folds, k)
    model <- rakel(ds$train, "SVM", cores=4, seed=1)
    predict(model, ds$test, cores=4, seed=1)
})

measures <- c("hamming-loss", "subset-accuracy", "one-error")

# Evaluation of each separated fold
print(sapply(seq(10), function (k){
    ds <- partition_fold(folds, k)
    multilabel_evaluate(ds$test, preds[[k]], measures)
}))

# Evaluation of all folders together
allpreds <- do.call(rbind, preds)[rownames(new.toyml$dataset), ]
print(multilabel_evaluate(new.toyml, allpreds, measures))

# Confusion matrix example
cm <- multilabel_confusion_matrix(new.toyml, allpreds)
print(data.frame(TP=cm$TPl, TN=cm$TNl, FP=cm$FPl, FN=cm$FNl))