##############################################
# TABLE 3. CHARACTERISTICS OF THE POPULATION #
##############################################
library(addhaz)
data(disabData)

# Age #-------------------------------------------------------------
# Total
table(disabData$age)
round(prop.table(table(disabData$age)), 3) * 100

# By disab cat
table(disabData$age, disabData$dis.mult)
round(prop.table(table(disabData$age, disabData$dis.mult), 2),
      3) * 100
# Diseases #--------------------------------------------------------

# Diabetes
# Total
table(disabData$diab)
round(prop.table(table(disabData$diab)), 3) * 100

# By disab cat
table(disabData$diab, disabData$dis.mult)
round(prop.table(table(disabData$diab, disabData$dis.mult), 2), 
      3) * 100

# Arthritis
# Total
table(disabData$arth)
round(prop.table(table(disabData$arth)), 3) * 100

# By disab cat
table(disabData$arth, disabData$dis.mult)
round(prop.table(table(disabData$arth, disabData$dis.mult), 2), 
      3) * 100

# Stroke
# Total
table(disabData$stro)
round(prop.table(table(disabData$stro)), 3) * 100

# By disab cat
table(disabData$stro, disabData$dis.mult)
round(prop.table(table(disabData$stro, disabData$dis.mult), 2), 
      3) *100

# Diabarth
disabData$diabarth <- 0
disabData$diabarth[disabData$diab == 1 & disabData$arth == 1] <- 1

# Total
table(disabData$diabarth)
round(prop.table(table(disabData$diabarth)), 3) * 100

# By disab cat
table(disabData$diabarth, disabData$dis.mult)
round(prop.table(table(disabData$diabarth, disabData$dis.mult), 2),
      3) * 100

# Diabstro
disabData$diabstro <- 0
disabData$diabstro[disabData$diab == 1 & disabData$stro == 1] <- 1

# Total
table(disabData$diabstro)
round(prop.table(table(disabData$diabstro)), 3) * 100

# By disab cat
table(disabData$diabstro, disabData$dis.mult)
round(prop.table(table(disabData$diabstro, disabData$dis.mult), 2), 
      3) * 100

# Arthstro
disabData$arthstro <- 0
disabData$arthstro[disabData$arth == 1 & disabData$stro == 1] <- 1

# Total
table(disabData$arthstro)
round(prop.table(table(disabData$arthstro)), 3) * 100

# By disab cat
table(disabData$arthstro, disabData$dis.mult)
round(prop.table(table(disabData$arthstro, disabData$dis.mult), 2), 
      3) * 100

###################
# BINOMIAL MODELS #
###################
library(addhaz)

# Model 1 ----------------------------------------------------------
data(disabData)
names(disabData)

model1 <- BinAddHaz(dis.bin ~ diab + arth + stro , data = disabData, weights = wgt,
                    attrib = TRUE, type.attrib = "both", collapse.background = FALSE,
                    attrib.disease = FALSE)

summary(model1)

sort(model1$coefficients, decreasing = TRUE)

model1$ci

model1$contribution
model1$contribution$att.abs[order(model1$contribution$att.abs[, 1], decreasing = TRUE), ]

# Model 2 ----------------------------------------------------------
model2 <- BinAddHaz(dis.bin ~ factor(age) -1 + diab + arth + stro , data = disabData,
                    weights = wgt, attrib = TRUE, type.attrib = "both",
                    collapse.background = FALSE, attrib.disease = FALSE, seed = 111,
                    bootstrap = TRUE, conf.level = 0.95, nbootstrap = 1000,
                    parallel = TRUE, type.parallel = "snow", ncpus = 4)
summary(model2)
model2$contribution

# Model 3 ----------------------------------------------------------
disease <- as.matrix(disabData[, c("diab", "arth", "stro")])
head(disease)

model3 <- BinAddHaz(dis.bin ~ disease:factor(age), data = disabData, weights = wgt,
                    attrib = TRUE, attrib.var = age, type.attrib = "abs",
                    collapse.background = FALSE, attrib.disease = TRUE)
summary(model3)
model3$contribution

# Model 4 ----------------------------------------------------------
model4 <- BinAddHaz(dis.bin ~ factor(age) - 1 + disease:factor(age), data = disabData,
                    weights = wgt, attrib = TRUE, attrib.var = age, type.attrib = "abs",
                    collapse.background = FALSE, attrib.disease = TRUE, seed = 111,
                    bootstrap = TRUE, conf.level = 0.95, nbootstrap = 1000,
                    parallel = TRUE, type.parallel = "snow", ncpus = 4)

summary(model4)
coef.age0 <- model4$coefficients[seq(1, length(model4$coefficients), 2)]
coef.age1 <- model4$coefficients[seq(0, length(model4$coefficients), 2)]
sort(coef.age0, decreasing = TRUE)
sort(coef.age1, decreasing = TRUE)

model4$contribution
cont.age0 <- model4$contribution[c(1:5), ]
cont.age1 <- model4$contribution[c(6:10), ]
cont.age0[order(cont.age0[, 1], decreasing = TRUE), ]
cont.age1[order(cont.age1[, 1], decreasing = TRUE), ]

# Model 5 ----------------------------------------------------------
model5 <- BinAddHaz(dis.bin ~ (diab + arth + stro)^2, data = disabData, weights = wgt,
                    attrib = TRUE, collapse.background = FALSE, attrib.disease = FALSE,
                    type.attrib = "both")

summary(model5)

# Likelihood ratio test --------------------------------------------
LRTest(model4, model2)

######################
# MULTINOMIAL MODELS #
######################
# Model 6 ----------------------------------------------------------
model6 <- MultAddHaz(dis.mult ~ factor(age) - 1 + diab + arth + stro, data = disabData,
                     weights = wgt, attrib = TRUE, seed = 111, collapse.background = FALSE,
                     attrib.disease = FALSE, type.attrib = "both")
summary(model6)

coef.mild <- model6$coefficients[1:5, ]
coef.sev <- model6$coefficients[6:10, ]

sort(coef.mild, decreasing = TRUE)
sort(coef.sev, decreasing = TRUE)

model6$contribution
rel.cont.mild <- model6$contribution$att.rel[1:5, ]
rel.cont.sev <- model6$contribution$att.rel[6:10, ]
sort(rel.cont.mild, decreasing = TRUE)
sort(rel.cont.sev, decreasing = TRUE)

# Model 7 ----------------------------------------------------------
start.time <- Sys.time()
model7 <- MultAddHaz(dis.mult ~ factor(age) -1 + disease:factor(age),
                     data = disabData, weights = wgt, attrib = TRUE, attrib.var = age,
                     seed = 111, collapse.background = FALSE, attrib.disease = TRUE,
                     type.attrib = "both", bootstrap = TRUE, conf.level = 0.95,
                     nbootstrap = 1000, parallel = TRUE, type.parallel = "snow",
                     ncpus = 4)
end.time <- Sys.time()
time.taken <- end.time - start.time 

cbind(model7$coefficients, model7$ci)

mild.age0 <- model7$coefficients[seq(1, length(model7$coefficients), 2), ][1:4]
sev.age0 <- model7$coefficients[seq(1, length(model7$coefficients), 2), ][5:8]
mild.age1 <- model7$coefficients[seq(0, length(model7$coefficients), 2), ][1:4]
sev.age1 <- model7$coefficients[seq(0, length(model7$coefficients), 2), ][5:8]
mild.age0[order(mild.age0, decreasing = TRUE)]
sev.age0[order(sev.age0, decreasing = TRUE)]
mild.age1[order(mild.age1, decreasing = TRUE)]
sev.age1[order(sev.age1, decreasing = TRUE)]

cont.mild.age0 <- model7$contribution$att.abs[1:5, ]
cont.sev.age0 <- model7$contribution$att.abs[6:10, ]
cont.mild.age1 <- model7$contribution$att.abs[11:15, ]
cont.sev.age1 <- model7$contribution$att.abs[16:20, ]
cont.mild.age0[order(cont.mild.age0[, 1], decreasing = TRUE), ]
cont.sev.age0[order(cont.sev.age0[, 1], decreasing = TRUE), ]
cont.mild.age1[order(cont.mild.age1[, 1], decreasing = TRUE), ]
cont.sev.age1[order(cont.sev.age1[, 1], decreasing = TRUE), ]

