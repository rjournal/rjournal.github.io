library(fICA)
library(JADE)
options(digits = 4)

dataset <- matrix(scan("https://www.jstatsoft.org/index.php/jss/article/
downloadSuppFile/v076i02/foetal_ecg.dat"), 2500, 9, byrow = TRUE)
X <- dataset[ , 2:9]
plot.ts(X, nc = 1, main = "Data")


g <- function(x){ x^2 }
dg <- function(x){ 2*x }
gf_new <- c(gf[1:3], g)
dgf_new <- c(dgf[1:3], dg)
gnames_new <- c(gnames[1:3], "skew")

res <- adapt_fICA(X, gs = gf_new, dgs = dgf_new, name = gnames_new, kj = 1)

res

plot.ts(bss.components(res), nc = 1, main = "Estimated components")

#######################################################################
library(fICA)
library(fastICA)
library(ica)
library(BSSasymp)
library(JADE)

options(digits = 4)
set.seed(1145)

rort <- function(p){qr.Q(qr(matrix(rnorm(p * p), p)))}


n <- 5000
p <- 3
A <- matrix(rnorm(p^2), p, p)

Ws1 <- Ws2 <- Ws3 <- vector("list", 1000)

for(i in 1:1000){
  Z <- cbind(rt(n, 9) / sqrt(9/7), rexp(n, 1) - 1, rnorm(n))
  
  X <- tcrossprod(Z,A)
  
  init = rort(p)
  
  Ws1[[i]] <- reloaded_fICA(X, g = "tanh")$W
  res <- fastICA(X, n.comp = 3, alg.typ = "deflation" )
  Ws2[[i]] <- t(res$W) %*% t(res$K)
  Ws3[[i]] <- icafast(X, nc = 3, alg = "def", Rmat = init)$W
}

f1 <- function(x){ dt(x*sqrt(9/7),9)*sqrt(9/7) }
f2 <- function(x){ dexp(x+1,1) }
f3 <- function(x){ dnorm(x) }
supp <- matrix(c(-Inf, -1, -Inf, Inf, Inf, Inf), p, 2) 

COV <- ASCOV_FastICAdefl(c(f1,f2,f3), gf[2], dgf[2], Gf[2], 
method = "adapt", name = c("tanh"), supp = supp, A = A)$COV_W
matrix(diag(COV), p, p)

COV_est <- ASCOV_FastICAdefl_est(X, gf[2], dgf[2], Gf[2], 
method="adapt", name=c("tanh"))$COV_W
matrix(diag(COV_est), p, p)*n

apply(simplify2array(Ws1), c(1,2), var)*n

EMD_opt <- ASCOV_FastICAdefl(c(f1,f2,f3), gf[2], dgf[2], Gf[2], 
method = "adapt", name = c("tanh"), supp = supp, A = A)$EMD
EMD_opt

EMD2 <- ASCOV_FastICAdefl(c(f1,f2,f3), gf[2], dgf[2], Gf[2], 
method = "regular", name = c("tanh"), supp = supp, A = A)$EMD
EMD2

MD1 <- unlist(lapply(Ws1, MD, A=A))
MD2 <- unlist(lapply(Ws2, MD, A=A))
MD3 <- unlist(lapply(Ws3, MD, A=A))

mean(MD1^2)*n*(p-1) # fICA
mean(MD2^2)*n*(p-1) # fastICA
mean(MD3^2)*n*(p-1) # ica 


