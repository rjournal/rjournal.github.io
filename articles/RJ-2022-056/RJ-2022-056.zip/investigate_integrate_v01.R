## as of 2019-03-07:  Nailed it.  With Nolan's help, got stable up and running for R/3.5.2
## on biowulf.

## as of 8/14/2018 "~/stable_5.3_R_x86_64-pc-linux-gnu.tar.gz" not installing:
##
##Error: package or namespace load failed for ‘stable’:
## package ‘stable’ was installed by an R version with different internals; it needs to be reinstalled for use with this R version

## GB 1st; PD 2nd
##new token as of 2020-04-18: 14683366cc4ada52a88de4f7d02dc33e29be56c9
#devtools::install_github("swihart/mvsubgaussGB", args=c('--library="/home/swihartbj/RLIBS/"'), auth_token="14683366cc4ada52a88de4f7d02dc33e29be56c9", force=TRUE)
#devtools::install_github("swihart/mvsubgaussPD", args=c('--library="/home/swihartbj/RLIBS/"'), auth_token="14683366cc4ada52a88de4f7d02dc33e29be56c9", force=TRUE)
#these tokens had "been removed automatically" by Github in late March 2020  because they weren't use for a year.  Thus the new ones on 2020-04-18.
##devtools::install_github("swihart/mvsubgaussGB", args=c('--library="/home/swihartbj/RLIBS/"'), auth_token="bb287461b20ee9dfeefdb043e0d478159589dec7", force=TRUE)
##devtools::install_github("swihart/mvsubgaussPD", args=c('--library="/home/swihartbj/RLIBS/"'), auth_token="bb287461b20ee9dfeefdb043e0d478159589dec7", force=TRUE)
## withr::with_libpaths(new="/home/swihartbj/RLIBS/",
##                      devtools::install_github("swihart/mvsubgaussGB",
##                                               auth_token="bb287461b20ee9dfeefdb043e0d478159589dec7")
##                      )
## withr::with_libpaths(new="/home/swihartbj/RLIBS/",
##                      devtools::install_github("swihart/mvsubgaussPD",
##                                               auth_token="bb287461b20ee9dfeefdb043e0d478159589dec7")
##                      )

##### install.packages("~/stable_5.3_R_x86_64-pc-linux-gnu.tar.gz", repos=NULL, type="source", lib="~/RLIBS")
#####  see gmail for 2018-03-07 nolan stable notes

library(data.table)
library(ggplot2)
library(libstableR)
library(mvsubgaussGB, lib.loc="~/RLIBS")
library(mvsubgaussPD, lib.loc="~/RLIBS")
library(stable)
library(bench )
library(broman)
library(stabledist)
library(cubature)
library(mvtnorm)
library(matrixcalc)
library(Matrix)

set.seed(10) ##DOES Seed cause segfault?

######################################
### BEGIN  dim d; alpha ##############
######################################


## dimension d is > 1 integer
d<-5

## exchangeable or arbitrary shape matrix?
## Pick one:
shape_exch_or_arbi<-"exch"
#shape_exch_or_arbi<-"toep"
#shape_exch_or_arbi<-"arbi"

## integration limits the same or different?
## Pick one:
int_lim_same_or_diff <- "same"
#int_lim_same_or_diff <- "diff"

## 0<alpha<2 `alp.in`
alp.in<-df.in <- 1.70

covariation<-function(qij, qjj, a) qij*qjj^(a/2 - 1)
qjj <-V <- 1
rho <- 0.90
qij <- rho*V
covariation(qij=qij,qjj = qjj,a=alp.in)

######################################
### END dim d; alpha   ###############
######################################

######################################
### BEGIN shape matrix ###############
######################################


##########################################################
# source: https://stat.ethz.ch/pipermail/r-help/2008-February/153708
# Generating a random positive-definite matrix with user-specified positive eigenvalues
# If eigenvalues are not specified, they are generated from a uniform distribution
## Posdef <- function (n, ev = runif(n, 0, 10))
pos_def_mat <- function (n, ev = runif(n, 0, 10))
{
  Z <- matrix(ncol=n, rnorm(n^2))
  decomp <- qr(Z)
  Q <- qr.Q(decomp)
  R <- qr.R(decomp)
  d <- diag(R)
  ph <- d / abs(d)
  O <- Q %*% diag(ph)
  Z <- t(O) %*% diag(ev) %*% O
  ZnearPD <- matrix(Matrix::nearPD(Z)$mat,n,n) ## bruce adds line to Ravi's fcn
  return(ZnearPD)
}

S_exch <- suppressWarnings(matrix(c(V, rep(V*rho, d)), d,d))
matrixcalc::is.positive.definite(S_exch, tol=1e-8)
S_toep <- toeplitz(c(V, seq(from=0.90*V,by=-0.1*V, length.out=(d-1))))
matrixcalc::is.positive.definite(S_toep, tol=1e-8)
S_arbi <- pos_def_mat(n=d, ev= eigen(S_toep)$val)
eigen(S_arbi)$val
matrixcalc::is.positive.definite(S_arbi, tol=1e-8)


ifelse(shape_exch_or_arbi=="exch", S <- S_exch, ifelse(shape_exch_or_arbi=="arbi", S <- S_arbi, S <- S_toep))


######################################
### END shape matrix #################
######################################


######################################
### BEGIN limits of integration ######
######################################

ifelse(int_lim_same_or_diff=="same",
       ## ab_same:
       {bb.upp <- rep(2,d);
       bb.low <- -bb.upp
       },
       ## ab_diff:
       {bb.upp <- rep(c(1,2,3,4),length.out=d);
       bb.low <- -rev(bb.upp)
       }
)
######################################
### END limits of integration ########
######################################


######################################
### BEGIN bench::mark error   ########
######################################

bm.abs.err <- 1e-4

######################################
### END bench::mark error     ########
######################################

print(paste0("Benchmark Testing for d=", d))
print(paste0("alpha: ", alp.in))
print("Shape matrix, S:")
print(S)
print(paste0("With integration bounds:"))
print(cbind(bb.low, bb.upp))
print(paste0("At an accuracy level of abs(W-Y) < ", bm.abs.err))


# pdest<-
# mvsubgaussPD::pmvsubgaussPD(lower=bb.low,
#                             upper=bb.upp,
#                                 Q=S,
#                             alpha=alp.in)$val
# pdest
#
# gbest <-
# mvsubgaussGB::pmvsubgaussGB(lower=bb.low,
#                             upper=bb.upp,
#                                 Q=S,
#                             alpha=alp.in)
# gbest[1]
# gbest

# use cubature to test new method of computing prob. of a hyperrectangle
# for a sub-Gaussian distribution
# test1 <- function( lower, upper, alpha, R, tol ) {
#
#     fn1 <- function( x, alpha, R ) {
#           dmvstable.elliptical(matrix(x,ncol=1), alpha, R )
#           }
#
#     a <- hcubature( fn1, lower, upper, alpha=alpha, R=R, tol=tol)
#     return(a)
# }
# ###############################################################
# truth_tol <- 1e-3
#  begin.truth <- Sys.time()
#  nsest3 <- test1(lower=bb.low, upper=bb.upp, alpha=alp.in, R=S, tol=truth_tol )
#  end.truth <- Sys.time()
# # nsest3 # tol<- 1e-05:
# #        # tol<- 1e-07:
# print(paste0("The hcubature TRUTH integral took:" ))
# time_for_truth <- end.truth - begin.truth
# print(time_for_truth)
# print(paste0("The hcubature TRUTH integral value:" ))
#  print(nsest3)





pmv2_1e03 <-
  function(lower=rep(-Inf,d), upper=rep(Inf,d), alpha=1, Q = NULL, delta=rep(0,d),

           outermost.int = c("stats::integrate","cubature::adaptIntegrate")[1],

           subdivisions.si = 100L,
           rel.tol.si = .Machine$double.eps^0.25,
           abs.tol.si = rel.tol.si,
           stop.on.error.si = TRUE,

           tol.ai = 1e-05,
           fDim.ai = 1,
           maxEval.ai = 0,
           absError.ai=0,
           doChecking.ai=FALSE,

           which.stable=c("libstableR", "stabledist")[1]

  ){


    f_A <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      libstableR::stable_pdf(x,
                                             pars=c(
                                               alpha = alpha/2,
                                               beta = 1,
                                               sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                               mu = 0),
                                             parametrization = 1L)
                  ,
                  "stabledist"=
                    function(x, alpha)
                      stabledist::dstable(x,
                                          alpha = alpha/2,
                                          beta = 1,
                                          gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                          delta = 0,
                                          pm = 1)
    )




    f_B <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      2*x*
                    libstableR::stable_pdf(x^2,
                                           pars=c(
                                             alpha = alpha/2,
                                             beta = 1,
                                             sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                             mu = 0),
                                           parametrization = 1L)
                  ,
                  "stabledist" =
                    function(x, alpha)
                      2*x*
                    stabledist::dstable(x^2,
                                        alpha = alpha/2,
                                        beta = 1,
                                        gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                        delta = 0,
                                        pm = 1)
    )


    d <- length(lower)
    lower <- lower - delta
    upper <- upper - delta
    integrand <- function(b,llp, ulp, Qmat=Q, alp=alpha)
      f_B(b, alp) * mvtnorm::pmvnorm(lower=llp/b, upper=ulp/b, sigma=Qmat,
                                     algorithm=mvtnorm::GenzBretz(maxpts = 25000, abseps = 0.001, releps = 0))

    # integrand2 <- function(b,llp, ulp, Qmat=Q, alp=alpha)
    #   f_B(b, alp) * mvtnorm::pmvnorm(llp/b, ulp/b)


    switch(outermost.int,
           "cubature::adaptIntegrate"=
             adaptIntegrate_inf_limPD(integrand,
                                      lowerLimit=0,
                                      upperLimit=Inf,
                                      llp=lower,
                                      ulp=upper,
                                      tol.ai = tol.ai,
                                      fDim.ai = fDim.ai,
                                      maxEval.ai = maxEval.ai,
                                      absError.ai=absError.ai,
                                      doChecking.ai=doChecking.ai
             )

           ,
           "stats::integrate" =
             integrate(Vectorize(integrand,vectorize.args = "b"),
                       lower=0,
                       upper=Inf,
                       llp=lower,
                       ulp=upper,
                       subdivisions = subdivisions.si,
                       rel.tol=rel.tol.si,
                       abs.tol=abs.tol.si,
                       stop.on.error=stop.on.error.si)
    )





  }



pmv2_1e03_highest <-
  function(lower=rep(-Inf,d), upper=rep(Inf,d), alpha=1, Q = NULL, delta=rep(0,d),

           outermost.int = c("stats::integrate","cubature::adaptIntegrate")[1],

           subdivisions.si = 100L,
           rel.tol.si = .Machine$double.eps^0.25,
           abs.tol.si = rel.tol.si,
           stop.on.error.si = TRUE,

           tol.ai = 1e-05,
           fDim.ai = 1,
           maxEval.ai = 0,
           absError.ai=0,
           doChecking.ai=FALSE,

           which.stable=c("libstableR", "stabledist")[1]

  ){


    f_A <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      libstableR::stable_pdf(x,
                                             pars=c(
                                               alpha = alpha/2,
                                               beta = 1,
                                               sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                               mu = 0),
                                             parametrization = 1L)
                  ,
                  "stabledist"=
                    function(x, alpha)
                      stabledist::dstable(x,
                                          alpha = alpha/2,
                                          beta = 1,
                                          gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                          delta = 0,
                                          pm = 1)
    )




    f_B <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      2*x*
                    libstableR::stable_pdf(x^2,
                                           pars=c(
                                             alpha = alpha/2,
                                             beta = 1,
                                             sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                             mu = 0),
                                           parametrization = 1L)
                  ,
                  "stabledist" =
                    function(x, alpha)
                      2*x*
                    stabledist::dstable(x^2,
                                        alpha = alpha/2,
                                        beta = 1,
                                        gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                        delta = 0,
                                        pm = 1)
    )


    d <- length(lower)
    lower <- lower - delta
    upper <- upper - delta
    integrand <- function(b,llp, ulp, Qmat=Q, alp=alpha)
      (f_B(b, alp)+1e-12) * (mvtnorm::pmvnorm(lower=llp/b, upper=ulp/b, sigma=Qmat,
                                              algorithm=mvtnorm::GenzBretz(maxpts = 25000, abseps = 0.001, releps = 0))+0.001)

    # integrand2 <- function(b,llp, ulp, Qmat=Q, alp=alpha)
    #   f_B(b, alp) * mvtnorm::pmvnorm(llp/b, ulp/b)


    switch(outermost.int,
           "cubature::adaptIntegrate"=
             adaptIntegrate_inf_limPD(integrand,
                                      lowerLimit=0,
                                      upperLimit=Inf,
                                      llp=lower,
                                      ulp=upper,
                                      tol.ai = tol.ai,
                                      fDim.ai = fDim.ai,
                                      maxEval.ai = maxEval.ai,
                                      absError.ai=absError.ai,
                                      doChecking.ai=doChecking.ai
             )

           ,
           "stats::integrate" =
             integrate(Vectorize(integrand,vectorize.args = "b"),
                       lower=0,
                       upper=Inf,
                       llp=lower,
                       ulp=upper,
                       subdivisions = subdivisions.si,
                       rel.tol=rel.tol.si,
                       abs.tol=abs.tol.si,
                       stop.on.error=stop.on.error.si)
    )





  }


pmv2_1e03_lowest <-
  function(lower=rep(-Inf,d), upper=rep(Inf,d), alpha=1, Q = NULL, delta=rep(0,d),

           outermost.int = c("stats::integrate","cubature::adaptIntegrate")[1],

           subdivisions.si = 100L,
           rel.tol.si = .Machine$double.eps^0.25,
           abs.tol.si = rel.tol.si,
           stop.on.error.si = TRUE,

           tol.ai = 1e-05,
           fDim.ai = 1,
           maxEval.ai = 0,
           absError.ai=0,
           doChecking.ai=FALSE,

           which.stable=c("libstableR", "stabledist")[1]

  ){


    f_A <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      libstableR::stable_pdf(x,
                                             pars=c(
                                               alpha = alpha/2,
                                               beta = 1,
                                               sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                               mu = 0),
                                             parametrization = 1L)
                  ,
                  "stabledist"=
                    function(x, alpha)
                      stabledist::dstable(x,
                                          alpha = alpha/2,
                                          beta = 1,
                                          gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                          delta = 0,
                                          pm = 1)
    )




    f_B <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      2*x*
                    libstableR::stable_pdf(x^2,
                                           pars=c(
                                             alpha = alpha/2,
                                             beta = 1,
                                             sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                             mu = 0),
                                           parametrization = 1L)
                  ,
                  "stabledist" =
                    function(x, alpha)
                      2*x*
                    stabledist::dstable(x^2,
                                        alpha = alpha/2,
                                        beta = 1,
                                        gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                        delta = 0,
                                        pm = 1)
    )


    d <- length(lower)
    lower <- lower - delta
    upper <- upper - delta
    integrand <- function(b,llp, ulp, Qmat=Q, alp=alpha)
      (f_B(b, alp)-1e-12) * (mvtnorm::pmvnorm(lower=llp/b, upper=ulp/b, sigma=Qmat,
                                              algorithm=mvtnorm::GenzBretz(maxpts = 25000, abseps = 0.001, releps = 0))-0.001)

    # integrand2 <- function(b,llp, ulp, Qmat=Q, alp=alpha)
    #   f_B(b, alp) * mvtnorm::pmvnorm(llp/b, ulp/b)


    switch(outermost.int,
           "cubature::adaptIntegrate"=
             adaptIntegrate_inf_limPD(integrand,
                                      lowerLimit=0,
                                      upperLimit=Inf,
                                      llp=lower,
                                      ulp=upper,
                                      tol.ai = tol.ai,
                                      fDim.ai = fDim.ai,
                                      maxEval.ai = maxEval.ai,
                                      absError.ai=absError.ai,
                                      doChecking.ai=doChecking.ai
             )

           ,
           "stats::integrate" =
             integrate(Vectorize(integrand,vectorize.args = "b"),
                       lower=0,
                       upper=Inf,
                       llp=lower,
                       ulp=upper,
                       subdivisions = subdivisions.si,
                       rel.tol=rel.tol.si,
                       abs.tol=abs.tol.si,
                       stop.on.error=stop.on.error.si)
    )





  }



pmv2_1e05 <-
  function(lower=rep(-Inf,d), upper=rep(Inf,d), alpha=1, Q = NULL, delta=rep(0,d),

           outermost.int = c("stats::integrate","cubature::adaptIntegrate")[1],

           subdivisions.si = 100L,
           rel.tol.si = .Machine$double.eps^0.25,
           abs.tol.si = rel.tol.si,
           stop.on.error.si = TRUE,

           tol.ai = 1e-05,
           fDim.ai = 1,
           maxEval.ai = 0,
           absError.ai=0,
           doChecking.ai=FALSE,

           which.stable=c("libstableR", "stabledist")[1]

  ){


    f_A <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      libstableR::stable_pdf(x,
                                             pars=c(
                                               alpha = alpha/2,
                                               beta = 1,
                                               sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                               mu = 0),
                                             parametrization = 1L)
                  ,
                  "stabledist"=
                    function(x, alpha)
                      stabledist::dstable(x,
                                          alpha = alpha/2,
                                          beta = 1,
                                          gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                          delta = 0,
                                          pm = 1)
    )




    f_B <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      2*x*
                    libstableR::stable_pdf(x^2,
                                           pars=c(
                                             alpha = alpha/2,
                                             beta = 1,
                                             sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                             mu = 0),
                                           parametrization = 1L)
                  ,
                  "stabledist" =
                    function(x, alpha)
                      2*x*
                    stabledist::dstable(x^2,
                                        alpha = alpha/2,
                                        beta = 1,
                                        gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                        delta = 0,
                                        pm = 1)
    )


    d <- length(lower)
    lower <- lower - delta
    upper <- upper - delta
    integrand <- function(b,llp, ulp, Qmat=Q, alp=alpha)
      f_B(b, alp) * mvtnorm::pmvnorm(lower=llp/b, upper=ulp/b, sigma=Qmat,
                                     algorithm=mvtnorm::GenzBretz(maxpts = 25000*25, abseps = 1e-05, releps = 0))

    # integrand2 <- function(b,llp, ulp, Qmat=Q, alp=alpha)
    #   f_B(b, alp) * mvtnorm::pmvnorm(llp/b, ulp/b)


    switch(outermost.int,
           "cubature::adaptIntegrate"=
             adaptIntegrate_inf_limPD(integrand,
                                      lowerLimit=0,
                                      upperLimit=Inf,
                                      llp=lower,
                                      ulp=upper,
                                      tol.ai = tol.ai,
                                      fDim.ai = fDim.ai,
                                      maxEval.ai = maxEval.ai,
                                      absError.ai=absError.ai,
                                      doChecking.ai=doChecking.ai
             )

           ,
           "stats::integrate" =
             integrate(Vectorize(integrand,vectorize.args = "b"),
                       lower=0,
                       upper=Inf,
                       llp=lower,
                       ulp=upper,
                       subdivisions = subdivisions.si,
                       rel.tol=rel.tol.si,
                       abs.tol=abs.tol.si,
                       stop.on.error=stop.on.error.si)
    )





  }



pmv2_1e05_highest <-
  function(lower=rep(-Inf,d), upper=rep(Inf,d), alpha=1, Q = NULL, delta=rep(0,d),

           outermost.int = c("stats::integrate","cubature::adaptIntegrate")[1],

           subdivisions.si = 100L,
           rel.tol.si = .Machine$double.eps^0.25,
           abs.tol.si = rel.tol.si,
           stop.on.error.si = TRUE,

           tol.ai = 1e-05,
           fDim.ai = 1,
           maxEval.ai = 0,
           absError.ai=0,
           doChecking.ai=FALSE,

           which.stable=c("libstableR", "stabledist")[1]

  ){


    f_A <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      libstableR::stable_pdf(x,
                                             pars=c(
                                               alpha = alpha/2,
                                               beta = 1,
                                               sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                               mu = 0),
                                             parametrization = 1L)
                  ,
                  "stabledist"=
                    function(x, alpha)
                      stabledist::dstable(x,
                                          alpha = alpha/2,
                                          beta = 1,
                                          gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                          delta = 0,
                                          pm = 1)
    )




    f_B <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      2*x*
                    libstableR::stable_pdf(x^2,
                                           pars=c(
                                             alpha = alpha/2,
                                             beta = 1,
                                             sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                             mu = 0),
                                           parametrization = 1L)
                  ,
                  "stabledist" =
                    function(x, alpha)
                      2*x*
                    stabledist::dstable(x^2,
                                        alpha = alpha/2,
                                        beta = 1,
                                        gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                        delta = 0,
                                        pm = 1)
    )


    d <- length(lower)
    lower <- lower - delta
    upper <- upper - delta
    integrand <- function(b,llp, ulp, Qmat=Q, alp=alpha)
      (f_B(b, alp)+1e-12) * (mvtnorm::pmvnorm(lower=llp/b, upper=ulp/b, sigma=Qmat,
                                              algorithm=mvtnorm::GenzBretz(maxpts = 25000*25, abseps = 1e-5, releps = 0))+1e-5)

    # integrand2 <- function(b,llp, ulp, Qmat=Q, alp=alpha)
    #   f_B(b, alp) * mvtnorm::pmvnorm(llp/b, ulp/b)


    switch(outermost.int,
           "cubature::adaptIntegrate"=
             adaptIntegrate_inf_limPD(integrand,
                                      lowerLimit=0,
                                      upperLimit=Inf,
                                      llp=lower,
                                      ulp=upper,
                                      tol.ai = tol.ai,
                                      fDim.ai = fDim.ai,
                                      maxEval.ai = maxEval.ai,
                                      absError.ai=absError.ai,
                                      doChecking.ai=doChecking.ai
             )

           ,
           "stats::integrate" =
             integrate(Vectorize(integrand,vectorize.args = "b"),
                       lower=0,
                       upper=Inf,
                       llp=lower,
                       ulp=upper,
                       subdivisions = subdivisions.si,
                       rel.tol=rel.tol.si,
                       abs.tol=abs.tol.si,
                       stop.on.error=stop.on.error.si)
    )





  }


pmv2_1e05_lowest <-
  function(lower=rep(-Inf,d), upper=rep(Inf,d), alpha=1, Q = NULL, delta=rep(0,d),

           outermost.int = c("stats::integrate","cubature::adaptIntegrate")[1],

           subdivisions.si = 100L,
           rel.tol.si = .Machine$double.eps^0.25,
           abs.tol.si = rel.tol.si,
           stop.on.error.si = TRUE,

           tol.ai = 1e-05,
           fDim.ai = 1,
           maxEval.ai = 0,
           absError.ai=0,
           doChecking.ai=FALSE,

           which.stable=c("libstableR", "stabledist")[1]

  ){


    f_A <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      libstableR::stable_pdf(x,
                                             pars=c(
                                               alpha = alpha/2,
                                               beta = 1,
                                               sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                               mu = 0),
                                             parametrization = 1L)
                  ,
                  "stabledist"=
                    function(x, alpha)
                      stabledist::dstable(x,
                                          alpha = alpha/2,
                                          beta = 1,
                                          gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                          delta = 0,
                                          pm = 1)
    )




    f_B <- switch(which.stable,
                  "libstableR" =
                    function(x, alpha)
                      2*x*
                    libstableR::stable_pdf(x^2,
                                           pars=c(
                                             alpha = alpha/2,
                                             beta = 1,
                                             sigma = 2*cos(pi*alpha/4)^(2/alpha),
                                             mu = 0),
                                           parametrization = 1L)
                  ,
                  "stabledist" =
                    function(x, alpha)
                      2*x*
                    stabledist::dstable(x^2,
                                        alpha = alpha/2,
                                        beta = 1,
                                        gamma = 2*cos(pi*alpha/4)^(2/alpha),
                                        delta = 0,
                                        pm = 1)
    )


    d <- length(lower)
    lower <- lower - delta
    upper <- upper - delta
    integrand <- function(b,llp, ulp, Qmat=Q, alp=alpha)
      (f_B(b, alp)-1e-12) * (mvtnorm::pmvnorm(lower=llp/b, upper=ulp/b, sigma=Qmat,
                                              algorithm=mvtnorm::GenzBretz(maxpts = 25000*25, abseps = 1e-5, releps = 0))-1e-5)

    # integrand2 <- function(b,llp, ulp, Qmat=Q, alp=alpha)
    #   f_B(b, alp) * mvtnorm::pmvnorm(llp/b, ulp/b)


    switch(outermost.int,
           "cubature::adaptIntegrate"=
             adaptIntegrate_inf_limPD(integrand,
                                      lowerLimit=0,
                                      upperLimit=Inf,
                                      llp=lower,
                                      ulp=upper,
                                      tol.ai = tol.ai,
                                      fDim.ai = fDim.ai,
                                      maxEval.ai = maxEval.ai,
                                      absError.ai=absError.ai,
                                      doChecking.ai=doChecking.ai
             )

           ,
           "stats::integrate" =
             integrate(Vectorize(integrand,vectorize.args = "b"),
                       lower=0,
                       upper=Inf,
                       llp=lower,
                       ulp=upper,
                       subdivisions = subdivisions.si,
                       rel.tol=rel.tol.si,
                       abs.tol=abs.tol.si,
                       stop.on.error=stop.on.error.si)
    )





  }



est <-
  pmv2_1e03(bb.low,
            bb.upp,
            Q=S,
            alpha=alp.in)

upp3 <-
  pmv2_1e03_highest(bb.low,
                    bb.upp,
                    Q=S,
                    alpha=alp.in)

low3 <-
  pmv2_1e03_lowest(bb.low,
                   bb.upp,
                   Q=S,
                   alpha=alp.in)


c(est$value-est$abs.error, est$value+est$abs.error)

c(low$value-low$abs.error,upp$value+upp$abs.error)



est05 <-
  pmv2_1e05(bb.low,
            bb.upp,
            Q=S,
            alpha=alp.in)

upp05 <-
  pmv2_1e05_highest(bb.low,
                    bb.upp,
                    Q=S,
                    alpha=alp.in)

low05 <-
  pmv2_1e05_lowest(bb.low,
                   bb.upp,
                   Q=S,
                   alpha=alp.in)

est05$value
c(est05$value-est05$abs.error, est05$value+est05$abs.error)

c(low05$value-low05$abs.error,upp05$value+upp05$abs.error)

pmv_sim_val <- 4e7
NS   = pmvstable.MC(a=bb.low,
                    b=bb.upp,
                    dist=mvstable.elliptical(R=S,alpha=alp.in),
                    n=pmv_sim_val)
NS

## works some of the time...
# > mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
#                    +                  algorithm=mvtnorm::GenzBretz(maxpts = 25000*80, abseps = 1e-6, releps = 0))
# [1] 0.9067209
# attr(,"error")
# [1] 8.341443e-07
# attr(,"msg")
# [1] "Normal Completion"

## works some of the time...
mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
                 algorithm=mvtnorm::GenzBretz(maxpts = 25000*700   , abseps = 1e-7, releps = 0))

## works some of the time...
mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
                 algorithm=mvtnorm::GenzBretz(maxpts = 25000*4000  , abseps = 1e-8, releps = 0))

# > mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
#                    +                  algorithm=mvtnorm::GenzBretz(maxpts = 25000*70000, abseps = 1e-9, releps = 0))
# [1] 0.9067209
# attr(,"error")
# [1] 1.911827e-09
# attr(,"msg")
# [1] "Completion with error > abseps"
# > mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
#                    +                  algorithm=mvtnorm::GenzBretz(maxpts = 25000*80000, abseps = 1e-9, releps = 0))
# [1] 0.9067209
# attr(,"error")
# [1] 1.708126e-09
# attr(,"msg")
# [1] "Completion with error > abseps"
# >
## worked!  holy cow.  took forever.  1e-9! 25000*85000=2.125e9
# mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
#                  algorithm=mvtnorm::GenzBretz(maxpts = 25000*85000, abseps = 1e-9, releps = 0))

# > mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
#                    +                  algorithm=mvtnorm::GenzBretz(maxpts = 25000*85000, abseps = 1e-9, releps = 0))
# [1] 0.9067209
# attr(,"error")
# [1] 9.790298e-10
# attr(,"msg")
# [1] "Normal Completion"
# mvtnorm::pmvnorm(bb.low, bb.upp, sigma=S,
#                  algorithm=mvtnorm::GenzBretz(maxpts = 25000*86000, abseps = 1e-9, releps = 0))
# Error in probval.GenzBretz(algorithm, n, df, lower, upper, infin, corr,  :
#                              NAs in foreign function call (arg 8)
#                            In addition: Warning message:
#                              In probval.GenzBretz(algorithm, n, df, lower, upper, infin, corr,  :
#                                                     NAs introduced by coercion to integer range


