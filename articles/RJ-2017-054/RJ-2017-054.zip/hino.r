## demo code for ider

## Please install the ider package in advance
## install.packages("ider")
library(ider)

## test for gendata and corint
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estcorint <- corint(x=x,k1=5,k2=10)
print(estcorint)

## test for convU
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estconvU <- convU(x=x,maxDim=5)
print(estconvU)

## test for distance matrix input
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estcorint <- corint(x=dist(x),DM=TRUE,k1=5,k2=10)
print(estcorint)


## test for packG and packT
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estpackG <- pack(x=x,greedy=TRUE)  ## estimate the packing number by greedy method
## note: the procedure inside relys on random sampling and the result could vary for different trial
print(estpackG)
estpackC <- pack(x=x,greedy=FALSE) ## estimate the packing number by cluttering
print(estpackC)

## test for mada
set.seed(123)
tmp <- gendata(DataName='ldbl',n=300)
x <- tmp$x
estmada <- mada(x=x,local=TRUE)
estmada[c(which(tmp$tDim==1)[1],which(tmp$tDim==2)[1],which(tmp$tDim==3)[1])]


## test for side with 'disc'
set.seed(123)
tmp <- gendata(DataName='ldbl', n=300)
x <- tmp$x
idx <- c(sample(which(tmp$tDim==1)[1:10],3), sample(which(tmp$tDim==2)[1:30],3))
estside <- side(x=x[1:100,], local=TRUE,method='disc')
print(estside[idx]) ## estimated discrete local intrinsic dimensions by side

## test for side with 'cont'
estside <- side(x=x[1:100,], local=TRUE,method='cont')
print(estside[idx]) ## estimated continuous local intrinsic dimensions by side


## global IDE with local methods
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estmada <- mada(x=x, local=FALSE, comb='median')
estmada

estside <- side(x=x, local=FALSE, comb='median', method='disc')
estside


## test for lbmle
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estmle <- lbmle(x=x, k1=3,k2=5, BC=FALSE)
estmle

## test for lbmle (bias corrected)
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estmle <- lbmle(x=x, k1=3,k2=5,BC=TRUE)
estmle


## test for nii
set.seed(123)
x <- gendata(DataName='SwissRoll',n=300)
estnni <- nni(x=x)
estnni



## test with CMU Hand Rotation dataset
data(handD)
str(handD)
dim(as.matrix(handD))

lbmle(x=handD,DM=TRUE,k1=3,k2=5,BC=TRUE,p=NULL)
corint(x=handD,DM=TRUE,k1=3,k2=10)
pack(x=handD,DM=TRUE,greedy=TRUE)
pack(x=handD,DM=TRUE,greedy=FALSE)
nni(handD,DM=TRUE)
side(x=handD,DM=TRUE,local=FALSE,method='disc',comb='median')
side(x=handD,DM=TRUE,local=FALSE,method='cont',comb='median')

