Supplement to "moonboot: An R Package Implementing m-out-of-n Bootstrap Methods"
--------------------------------------------------------------------------------

This supplement contains the scripts to reproduce the simulation results
in the article. As the computation of the comparative evaluation results
presented in section 4.2 had a runtime of eight weeks on a parallel computer
with 40 cores, we have split the scripts for reproducing the results in three
subdirectories:

data/
  Contains the results of all simulations as CSV files.

scripts/
  Contains the scripts that run under a minute and require no parallelization.
  These scripts will reproduce all figures and the data files
  estimate-tau.csv (table 2) and volatility-politis.csv (figure 2).
  Scripts must be run from the scripts/ directory and will write their
  output to the same directory so that data/ stuff is not overwritten.

supplement/
  Contains the parallelized scripts that run several weeks and reproduce
  the data files pcov-fixed-m.scv (figure 3), pcov-databased-m.csv (figure 4)
  and mean-noonboot.csv (figure 5). Although rerunning these scripts might
  be infeasible due to the runtime, the scripts are provided for transparency
  reasons.

Christoph Dalitz, Felix Lögler
