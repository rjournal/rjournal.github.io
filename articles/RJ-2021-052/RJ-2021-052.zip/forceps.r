## ---- Rlogo, echo=FALSE, fig.cap='The logo of R.', out.width='2in', fig.align='center', fig.pos='htbp'----
knitr::include_graphics('Rlogo.pdf')


## -----------------------------------------------------------------------------
x <- 1:10
plot(x)

