# Replication Script for R Code MANOVA.RM

#library(devtools)
#install_github("smn74/MANOVA.RM")
library(MANOVA.RM)

# Example 1
data("o2cons")
model1 <- RM(O2 ~ Group * Staphylococci * Time, data = o2cons, 
	       subject = "Subject",  no.subf = 2, iter = 1000, 
               resampling = "Perm", seed = 1234)
summary(model1)

# Example 2
data("EEG")
EEG_model <- RM(resp ~ sex * diagnosis * feature * region, 
                data = EEG, subject = "id", no.subf = 2, resampling = "WildBS",
                iter = 1000,  alpha = 0.01, CPU = 4, seed = 123)
summary(EEG_model)

# Plotting
plot(EEG_model, factor = "sex", main = "Effect of sex on EEG values")
plot(EEG_model, factor = "sex:diagnosis", legendpos = "topleft", col = c(4, 2), ylim =c(-1.8, 0.8), CI.info = TRUE)
plot(EEG_model, factor = "sex:diagnosis:feature", legendpos = "bottomright", gap = 0.05)

#### MANOVA
data("EEG")
EEG_MANOVA <- MANOVA(resp ~ sex * diagnosis, data = EEG,
	               subject = "id", resampling = "paramBS", 
	               iter = 1000,  alpha = 0.01, CPU = 1, seed = 987)
summary(EEG_MANOVA)

## MANOVA.wide
data("EEGwide")
EEG_wide <- MANOVA.wide(cbind(brainrate_temporal, brainrate_frontal, brainrate_central, complexity_temporal, complexity_frontal, complexity_central) ~ sex * diagnosis,
                        data = EEGwide,
                        resampling = "paramBS", 
                        iter = 1000,  alpha = 0.01, CPU = 1, seed = 987)
summary(EEG_wide)

# Confidence Regions
library(HSAUR)
data(water)
test <- MANOVA.wide(cbind(mortality, hardness) ~ location, data = water, iter = 1000, resampling = "paramBS", CPU = 1, seed = 123)
summary(test)
cr <- conf.reg(test)
cr
plot(cr, xlab = "Difference in mortality", ylab ="Difference in water hardness")

# nested design
library(GFD)
data(curdies)
set.seed(123)
curdies$dug2 <- curdies$dugesia + rnorm(36)

# first possibility: MANOVA.wide
fit1 <- MANOVA.wide(cbind(dugesia, dug2) ~ season + season:site, data = curdies, iter = 1000, nested.levels.unique = TRUE, seed = 123, CPU = 1)

# second possibility: MANOVA (long format)
dug <- c(curdies$dugesia, curdies$dug2)
season <- rep(curdies$season, 2)
site <- rep(curdies$site, 2)
curd <- data.frame(dug, season, site, subject = rep(1:36, 2))

fit2 <- MANOVA(dug ~ season + season:site, data = curd, subject = "subject", nested.levels.unique = TRUE, seed = 123, iter = 1000, CPU = 1)

# comparison of results
summary(fit1)
summary(fit2)

# post-hoc comparisons
# pairwise comparison using Tukey contrasts
simCI(EEG_MANOVA, contrast = "pairwise", type = "Tukey")

oneway <- MANOVA.wide(cbind(brainrate_temporal, brainrate_central) ~ diagnosis, data = EEGwide,
                      iter = 1000, CPU = 1)
# a user-defined contrast matrix
H <- as.matrix(cbind(rep(1, 5), -1*Matrix::Diagonal(5)))
simCI(oneway, contrast = "user-defined", contmat = H)

EEG1 <- MANOVA.wide(brainrate_temporal ~ diagnosis, data = EEGwide, iter = 1000, seed = 987, CPU = 1)
EEG2 <- MANOVA.wide(brainrate_central ~ diagnosis, data = EEGwide, iter = 1000, seed = 987, CPU = 1)
p.adjust(c(EEG1$resampling[, 2], EEG2$resampling[, 2]), method = "bonferroni")


### GUI
GUI.RM()
GUI.MANOVA()
GUI.MANOVAwide()
