###############################################################################
######-------------------------------------------------------------------######
###------            This code reproduces the examples in             ------###
###-->>   "BondValuation: An R Package for Fixed Coupon Bond Analysis"  <<--###
###-->>                                by                               <<--###
###-->>                        Wadim Djatschenko                        <<--###
###-->>                                                                 <<--###
###### . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ######

install.packages("Rcpp")
install.packages("BondValuation")

#------------------------------------------------------------------------------
# example 1
library(BondValuation)
print(List.DCC, row.names = FALSE)
#==============================================================================

#------------------------------------------------------------------------------
# example 2
library(BondValuation)
DCC_Comparison<-data.frame(Start = rep(as.Date("2011-08-31"), 16),
                           End = rep(as.Date("2012-02-29"), 16),
                           Coup = rep(5.25, 16),
                           DCC = seq(1, 16),
                           DCC.Name = List.DCC[, 2],
                           RV = rep(100, 16),
                           CpY = rep(2, 16),
                           Mat = rep(as.Date("2021-08-31"), 16),
                           YearNCP = rep(2012, 16),
                           EOM = rep(1, 16))
AccrIntOutput <- suppressWarnings(
  apply(
    DCC_Comparison[, c('Start', 'End', 'Coup', 'DCC', 'RV', 'CpY', 'Mat',
                       'YearNCP', 'EOM')], 1,
    function(y) AccrInt(y[1], y[2], y[3], y[4], y[5], y[6], y[7], y[8], y[9])
  )
)
Accrued_Interest <- do.call(rbind, lapply(AccrIntOutput, function(x) x[[1]]))
Days_Accrued <- do.call(rbind, lapply(AccrIntOutput, function(x) x[[2]]))
DCC_Comparison <- cbind(DCC_Comparison, Accrued_Interest, Days_Accrued)
print(DCC_Comparison[, c('DCC.Name', 'Start', 'End', 'Days_Accrued', 
                         'Accrued_Interest')], row.names = FALSE)
#==============================================================================


#------------------------------------------------------------------------------
# example 3
library(BondValuation)
AnnivDates(as.Date("2019-05-31"), "2021-07-31")
#==============================================================================


#------------------------------------------------------------------------------
# example 4
library(BondValuation)
# example 4a: computing DateVectors for EOM = 1
EOM.input <- 1
AnnivDates(Em = as.Date("2019-05-31"),
           Mat = as.Date("2021-07-31"),
           CpY = 2,
           FIPD = as.Date("2020-02-29"),
           LIPD = as.Date("2021-02-28"),
           EOM = EOM.input)$DateVectors

# example 4b: computing DateVectors for EOM = 0
EOM.input <- 0
AnnivDates(Em = as.Date("2019-05-31"),
           Mat = as.Date("2021-07-31"),
           CpY = 2,
           FIPD = as.Date("2020-02-29"),
           LIPD = as.Date("2021-02-28"),
           EOM = EOM.input)$DateVectors
#==============================================================================


#------------------------------------------------------------------------------
# example 5
library(BondValuation)
TempStruct.by.DCC <- data.frame(Em = rep(as.Date("2019-05-31"), 16),
                                Mat = rep(as.Date("2021-07-31"), 16),
                                CpY = rep(2, 16),
                                FIPD = rep(as.Date("2020-02-29"), 16),
                                LIPD = rep(as.Date("2021-02-28"), 16),
                                FIAD = rep(as.Date("2019-05-31"), 16),
                                DCC = seq(1, 16),
                                EOM = rep(0, 16),
                                DCC.Name = List.DCC[, 2])

# Applying AnnivDates() to the data frame TempStruct.by.DCC for EOM = 0
suppressWarnings(
  FullAnalysis.EOM0 <- apply(
    TempStruct.by.DCC[, c('Em','Mat','CpY','FIPD','LIPD','FIAD','DCC','EOM')],
    1, function(y) AnnivDates(
      y[1], y[2], y[3], y[4], y[5], y[6], , , y[7], y[8])
  )
)
FCPLength.EOM0 <- lapply(lapply(lapply(FullAnalysis.EOM0, `[[`, 2), `[[`, 15)
                         , na.omit)
FCPLength.EOM0 <- as.data.frame(do.call(rbind, lapply(FCPLength.EOM0, round, 4)))
LCPLength.EOM0 <- lapply(lapply(lapply(FullAnalysis.EOM0, `[[`, 2), `[[`, 17)
                         , na.omit)
LCPLength.EOM0 <- as.data.frame(do.call(rbind, lapply(LCPLength.EOM0, round, 4)))
TempStruct.EOM0 <- lapply(lapply(lapply(FullAnalysis.EOM0, `[[`, 3), `[[`, 2)
                          , na.omit)
TempStruct.EOM0 <- lapply(TempStruct.EOM0, `length<-`, 
                          max(lengths(TempStruct.EOM0)))
TempStruct.EOM0 <- as.data.frame(do.call(rbind, lapply(TempStruct.EOM0, round, 4)))
TempStruct.by.DCC.EOM0 <- cbind(TempStruct.by.DCC, TempStruct.EOM0,
                                FCPLength.EOM0, LCPLength.EOM0)
names(TempStruct.by.DCC.EOM0)[c(10:16)] <- c("E", "01", "02", "03", "M",
                                             "FCPLength", "LCPLength")
print(TempStruct.by.DCC.EOM0[, c(9:ncol(TempStruct.by.DCC.EOM0))],
      row.names = FALSE)
#==============================================================================


#------------------------------------------------------------------------------
# example 6
library(BondValuation)
TempStruct.by.DCC <- data.frame(Em = rep(as.Date("2019-10-31"), 16),
                                Mat = rep(as.Date("2024-02-29"), 16),
                                CpY = rep(2, 16),
                                FIPD = rep(as.Date("2020-03-30"), 16),
                                LIPD = rep(as.Date("2023-03-30"), 16),
                                FIAD = rep(as.Date("2019-10-31"), 16),
                                DCC = seq(1, 16),
                                EOM = rep(0, 16),
                                DCC.Name = List.DCC[, 2])

# Applying AnnivDates() to the data frame TempStruct.by.DCC for EOM = 0
suppressWarnings(
  FullAnalysis.EOM0 <- apply(
    TempStruct.by.DCC[, c('Em','Mat','CpY','FIPD','LIPD','FIAD','DCC','EOM')],
    1, function(y) AnnivDates(
      y[1], y[2], y[3], y[4], y[5], y[6], , , y[7], y[8])
  )
)
FCPLength.EOM0 <- lapply(lapply(lapply(FullAnalysis.EOM0, `[[`, 2), `[[`, 15)
                         , na.omit)
FCPLength.EOM0 <- as.data.frame(do.call(rbind, lapply(FCPLength.EOM0, round, 4)))
LCPLength.EOM0 <- lapply(lapply(lapply(FullAnalysis.EOM0, `[[`, 2), `[[`, 17)
                         , na.omit)
LCPLength.EOM0 <- as.data.frame(do.call(rbind, lapply(LCPLength.EOM0, round, 4)))
TempStruct.EOM0 <- lapply(lapply(lapply(FullAnalysis.EOM0, `[[`, 3), `[[`, 2)
                          , na.omit)
TempStruct.EOM0 <- lapply(TempStruct.EOM0, `length<-`, 
                          max(lengths(TempStruct.EOM0)))
TempStruct.EOM0 <- as.data.frame(do.call(rbind, lapply(TempStruct.EOM0, round, 4)))
TempStruct.by.DCC.EOM0 <- cbind(TempStruct.by.DCC, TempStruct.EOM0,
                                FCPLength.EOM0, LCPLength.EOM0)
names(TempStruct.by.DCC.EOM0)[c(10:20)] <- c("E","01","02","03","04","05","06",
                                             "07","M","FCPLength","LCPLength")
print(TempStruct.by.DCC.EOM0[, c(9:ncol(TempStruct.by.DCC.EOM0))],
      row.names = FALSE)
#==============================================================================


#------------------------------------------------------------------------------
# example 7
library(BondValuation)
CashFlows.by.DCC <- data.frame(Em = rep(as.Date("2019-10-31"), 16),
                               Mat = rep(as.Date("2024-02-29"), 16),
                               CpY = rep(2, 16),
                               FIPD = rep(as.Date("2020-03-30"), 16),
                               LIPD = rep(as.Date("2023-03-30"), 16),
                               FIAD = rep(as.Date("2019-10-31"), 16),
                               RV = rep(100, 16),
                               Coup = rep(10, 16),
                               DCC = seq(1, 16),
                               EOM = rep(0, 16),
                               DCC.Name = List.DCC[, 2])

# Applying AnnivDates() to the data frame CashFlows.by.DCC for EOM = 0
# with option RegCF.equal = 0 and RegCF.equal = 1
Suffix <- c("RegCFvary","RegCFequal")
for (i in c(0,1)) {
  suppressWarnings(
    FullAnalysis <- apply(
      CashFlows.by.DCC[, c('Em','Mat','CpY','FIPD','LIPD','FIAD','RV',
                           'Coup','DCC','EOM')],
      1, function(y) AnnivDates(
        y[1],y[2],y[3],y[4],y[5],y[6],y[7],y[8],y[9],y[10], RegCF.equal = i)
    )
  )
  CashFlows <- lapply(lapply(lapply(FullAnalysis, `[[`, 4), `[[`, 2)
                      , na.omit)
  CashFlows <- as.data.frame(do.call(rbind, lapply(CashFlows, round, 4)))
  CashFlows <- cbind(CashFlows.by.DCC, CashFlows)
  names(CashFlows)[c(12:19)] <- c(
    "CF.1","CF.2","CF.3","CF.4","CF.5","CF.6","CF.7","CF.M")
  assign(paste0("CashFlows.by.DCC.",Suffix[i+1]),CashFlows)
  rm(FullAnalysis,CashFlows)
}

# RegCF.equal = 0, i.e., regular cash flows may vary
print(CashFlows.by.DCC.RegCFvary[, c(11:ncol(CashFlows.by.DCC.RegCFvary))],
      row.names = FALSE)

# RegCF.equal = 1, i.e., regular cash flows forced to be equal
print(CashFlows.by.DCC.RegCFequal[, c(11:ncol(CashFlows.by.DCC.RegCFequal))],
      row.names = FALSE)
#==============================================================================


#------------------------------------------------------------------------------
# example 8
library(BondValuation)
AccrIntDP.by.DCC <- data.frame(CP = 105,
                               SETT1 = rep(as.Date("2020-09-28"), 16),
                               SETT2 = rep(as.Date("2023-03-30"), 16),
                               SETT3 = rep(as.Date("2024-01-15"), 16),
                               Em = rep(as.Date("2019-10-31"), 16),
                               Mat = rep(as.Date("2024-02-29"), 16),
                               CpY = rep(2, 16),
                               FIPD = rep(as.Date("2020-03-30"), 16),
                               LIPD = rep(as.Date("2023-03-30"), 16),
                               FIAD = rep(as.Date("2019-10-31"), 16),
                               RV = rep(100, 16),
                               Coup = rep(10, 16),
                               DCC = seq(1, 16),
                               EOM = rep(0, 16),
                               DCC.Name = List.DCC[, 2])

Suffix <- c("SETT1","SETT2","SETT3")
for (i in c(1:3)) {
  DP.Output<-suppressWarnings(
    apply(AccrIntDP.by.DCC[,c('CP',paste0('SETT',i),'Em','Mat','CpY','FIPD',
                              'LIPD','FIAD','RV','Coup','DCC')],
          1,function(y) DP(y[1],y[2],y[3],y[4],y[5],y[6],y[7],
                           y[8],y[9],y[10],y[11])))
  AI<-do.call(rbind,lapply(lapply(lapply(DP.Output, `[[`, 2), `[[`, 3), round, 4))
  DP<-do.call(rbind,lapply(lapply(lapply(DP.Output, `[[`, 2), `[[`, 1), round, 4))
  AccrIntDP.by.DCC<-cbind(AccrIntDP.by.DCC,AI,DP)
  names(AccrIntDP.by.DCC)[
    c((ncol(AccrIntDP.by.DCC) - 1) : ncol(AccrIntDP.by.DCC))] <- c(
    paste0("AI.", Suffix[i]), paste0("DP.", Suffix[i]))
  rm(DP.Output,AI,DP)
}
print(AccrIntDP.by.DCC[,c(15:ncol(AccrIntDP.by.DCC))], row.names = FALSE)
#==============================================================================


# example 9
library(BondValuation)
YtM.by.DCC <- data.frame(CP = 105,
                         SETT1 = rep(as.Date("2020-09-28"), 16),
                         SETT2 = rep(as.Date("2023-03-30"), 16),
                         SETT3 = rep(as.Date("2024-01-15"), 16),
                         Em = rep(as.Date("2019-10-31"), 16),
                         Mat = rep(as.Date("2024-02-29"), 16),
                         CpY = rep(2, 16),
                         FIPD = rep(as.Date("2020-03-30"), 16),
                         LIPD = rep(as.Date("2023-03-30"), 16),
                         FIAD = rep(as.Date("2019-10-31"), 16),
                         RV = rep(100, 16),
                         Coup = rep(10, 16),
                         DCC = seq(1, 16),
                         EOM = rep(0, 16))

Suffix <- c("S1","S2","S3")
i<-1
for (i in c(1:3)) {
  BondValYield.Output<-suppressWarnings(
    apply(YtM.by.DCC[,c('CP',paste0('SETT',i),'Em','Mat','CpY','FIPD',
                        'LIPD','FIAD','RV','Coup','DCC')],
          1,function(y) BondVal.Yield(y[1],y[2],y[3],y[4],y[5],y[6],y[7],
                                      y[8],y[9],y[10],y[11])))
  
  YtM<-do.call(rbind,lapply(lapply(BondValYield.Output, `[[`, 4), round, 3))
  ModDUR<-do.call(rbind,lapply(lapply(BondValYield.Output, `[[`, 5), round, 4))
  Conv<-do.call(rbind,lapply(lapply(BondValYield.Output, `[[`, 7), round, 4))
  YtM.by.DCC<-cbind(YtM.by.DCC,YtM,ModDUR,Conv)
  names(YtM.by.DCC)[
    c((ncol(YtM.by.DCC) - 2) : ncol(YtM.by.DCC))] <- c(
      paste0("YtM.", Suffix[i]), paste0("DUR.", Suffix[i]),
      paste0("Conv.", Suffix[i]))
  rm(BondValYield.Output,YtM,ModDUR,Conv)
}
print(YtM.by.DCC[,c(13,15:ncol(YtM.by.DCC))], row.names = FALSE)
#==============================================================================


#------------------------------------------------------------------------------
# example 10
library(BondValuation)
summary(SomeBonds2016)

# example 10: continued (I)

# Applying AnnivDates() to the data frame SomeBonds2016.
FullAnalysis<-suppressWarnings(
  apply(
    SomeBonds2016[,c('Issue.Date','Mat.Date','CpY.Input','FIPD.Input',
                     'LIPD.Input','FIAD.Input','RV.Input','Coup.Input',
                     'DCC.Input','EOM.Input')], 1,
    function(y) AnnivDates(y[1], y[2], y[3], y[4], y[5], y[6], y[7],
                           y[8], y[9], y[10])
  )
)
# Extracting the data frame Warnings and binding the Warnings to the bonds
BondsWithWarnings<-cbind(
  SomeBonds2016, do.call(
    rbind, lapply(FullAnalysis, `[[`, 1)
  )
)
summary(BondsWithWarnings[,c((ncol(SomeBonds2016)+1):ncol(BondsWithWarnings))])

# example 10: continued (II)

# manual examination of the rows where ChronErrorFlag = 1
print(BondsWithWarnings[
  which(BondsWithWarnings$ChronErrorFlag == 1),
  c('ID.No','Issue.Date', 'FIAD.Input', 'FIPD.Input', 'LIPD.Input', 'Mat.Date')],
  row.names = FALSE)

# manual examination of the rows where IPD_CpY_Corrupt = 1
print(BondsWithWarnings[
  which(BondsWithWarnings$IPD_CpY_Corrupt == 1),
  c('ID.No', 'Issue.Date', 'FIAD.Input', 'FIPD.Input', 'LIPD.Input', 'Mat.Date',
    'CpY.Input')], row.names = FALSE)

# example 10: continued (III)

# Printing data frame DateVectors for bond with ID.No = 2
print(
  as.data.frame(do.call(rbind, lapply(FullAnalysis, `[[`, 3)[2])),
  row.names = FALSE)

# Printing data frame PaySched for bond with ID.No = 2
print(
  as.data.frame(do.call(rbind, lapply(FullAnalysis, `[[`, 4)[2])),
  row.names = FALSE)

# example 10: continued (IV)

# Extracting the data frame Warnings and binding the Warnings to the bonds
BondsWithTraits<-cbind(
  SomeBonds2016, do.call(
    rbind, lapply(FullAnalysis, `[[`, 2)
  )
)
summary(BondsWithTraits[, c('FCPType', 'LCPType', 'FCPLength', 'LCPLength')])

#==============================================================================


#------------------------------------------------------------------------------
# example 11

library(BondValuation)
dim(PanelSomeBonds2016)
summary(PanelSomeBonds2016[, c(13:16)])
#==============================================================================


#------------------------------------------------------------------------------
# example 12
# analysis of PanelSomeBonds2016 with BondValuation
library(BondValuation)
Panel <- PanelSomeBonds2016
Vars <- c("tau","AccrInt","DP","YtM","ModDUR","MacDUR","Conv")
Panel[, c((ncol(Panel) + 1) : (ncol(Panel) + length(Vars)))] <- as.numeric(NA)
names(Panel)[(ncol(Panel) - length(Vars) + 1) : ncol(Panel)] <- Vars

# Alternative 1: loop through the data frame 
#                applying BondVal.Yield to each row
Time.Alt01 <- system.time(
  for (i in c(1:nrow(Panel))) {
    BondVal.Out <- suppressWarnings(
      BondVal.Yield(CP = Panel$CP.Input[i],
                    SETT = Panel$SETT[i],
                    Em = Panel$Issue.Date[i],
                    Mat = Panel$Mat.Date[i],
                    CpY = Panel$CpY.Input[i],
                    FIPD = Panel$FIPD.Input[i],
                    LIPD = Panel$LIPD.Input[i],
                    FIAD = Panel$FIAD.Input[i],
                    RV = Panel$RV.Input[i],
                    Coup = Panel$Coup.Input[i],
                    DCC = Panel$DCC.Input[i],
                    EOM = Panel$EOM.Input[i],
                    Precision = .Machine$double.eps^0.5
      )
    )
    Panel[i, c((ncol(Panel) - length(Vars) + 1) : ncol(Panel))] <-
      round(as.numeric(BondVal.Out[c(11, 2 : 7)]), 4)
  }, gcFirst = TRUE
)


# Alternative 2: Run AnnivDates() once per Bond-ID and pass its output
#                to BondVal.Yield() for every row with the same Bond-ID
NonDuplID <- c(which(!duplicated(Panel$ID.No)), (nrow(Panel)+1))
Time.Alt02 <- system.time(
  for (i in c(1 : (length(NonDuplID) - 1))) {
    BondCount <- NonDuplID[i]
    AnnivDates.Out <- suppressWarnings(
      AnnivDates(Em = Panel$Issue.Date[BondCount],
                 Mat = Panel$Mat.Date[BondCount],
                 CpY = Panel$CpY.Input[BondCount],
                 FIPD = Panel$FIPD.Input[BondCount],
                 LIPD = Panel$LIPD.Input[BondCount],
                 FIAD = Panel$FIAD.Input[BondCount],
                 RV = Panel$RV.Input[BondCount],
                 Coup = Panel$Coup.Input[BondCount],
                 DCC = Panel$DCC.Input[BondCount],
                 EOM = Panel$EOM.Input[BondCount]
      )
    )
    for (j in c(NonDuplID[i] : (NonDuplID[i + 1] - 1))) {
      BondVal.Out <- suppressWarnings(
        BondVal.Yield(CP = Panel$CP.Input[j],
                      SETT = Panel$SETT[j],
                      Em = Panel$Issue.Date[j],
                      Mat = Panel$Mat.Date[j],
                      CpY = Panel$CpY.Input[j],
                      FIPD = Panel$FIPD.Input[j],
                      LIPD = Panel$LIPD.Input[j],
                      FIAD = Panel$FIAD.Input[j],
                      RV = Panel$RV.Input[j],
                      Coup = Panel$Coup.Input[j],
                      DCC = Panel$DCC.Input[j],
                      EOM = Panel$EOM.Input[j],
                      InputCheck = 0,
                      Precision = .Machine$double.eps^0.5,
                      AnnivDatesOutput = AnnivDates.Out
        )
      )
      Panel[j, c((ncol(Panel) - length(Vars) + 1) : ncol(Panel))] <-
        round(as.numeric(BondVal.Out[c(11, 2 : 7)]), 4)
    }
  }, gcFirst = TRUE
)

round(Time.Alt02[[3]] / Time.Alt01[[3]], 2)

#==============================================================================

