
print.libsl <- function (x, ...)
{
  print(x$model)
}
