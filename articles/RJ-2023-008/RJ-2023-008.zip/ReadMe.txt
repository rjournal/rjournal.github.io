Before running 'Yu_dycdtools.R' to reproduce the figures in the manuscript,
Please go to https://github.com/SongyanYu/ExampleData_dycdtools to download
the required example data.

On that website, the two zip files named 'calibration_data' and 'plotting_data'
should be downloaded and unzipped to the 'code_to_reproduce' folder.
i.e., 'code_to_reproduce/calibration_data', 'code_to_reproduce/plotting_data'

To reproduce the figures in the manuscript, simply open and run "Yu_dycdtools.R".