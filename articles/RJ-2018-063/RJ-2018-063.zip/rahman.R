###Replication Materials for all results shown in sdpt3r paper
###Author: Adam Rahman

library(sdpt3r)             #requires sdpt3r to be installed from supplied tarball

### Replication of Max-Cut problem presented in Section 3.2 ###

data(Bmaxcut)               #data is available in sdpt3r

out <- maxcut(Bmaxcut)      #use maxcut to create input variables necessary for sqlp
blk <- out$blk
At <- out$At
C <- out$C
b <- out$b

foo <- sqlp(blk,At,C,b)     #solve the maxcut problem

foo$pobj                    #Optimal value of primal objective function (i.e. the Max Cut)
foo$X[[1]]                  #optimal matrix (which happens to be a correlation matrix).
                            #Matrix is rounded to three decimal places in paper for readability


### Replication of Nearest Correlation Matrix problem presented in Section 3.3 ###

data(Hnearcorr)             #Data is available in sdpt3r

out <- nearcorr(Hnearcorr)  #Use nearcorr to create input variables necessary for sqlp
blk <- out$blk
At <- out$At
C <- out$C
b <- out$b

foo <- sqlp(blk,At,C,b)     #Solve the nearest correlation matrix problem

foo$X[[1]]                  #the nearest correlation matrix 

### Replication of the D-Optimal Experimental Design Results in Section 3.4 ###

data(DoptDesign)            #Data is available in sdpt3r package

out <- doptimal(DoptDesign) #Use doptimal to create input variables necessary for sqlp
blk <- out$blk
At <- out$At
C <- out$C
b <- out$b
OPTIONS <- out$OPTIONS

foo <- sqlp(blk,At,C,b, OPTIONS)    #Solve the D-Optimal Experimental Design Problem

foo$y                      #the optimal lambda vector
                           #rounded to three decimal places in paper for readability


#All of the examples shown (but not run) in Section 4 can be computed 
#by simply running the example given in the help page for each helper function presented. 

#All other code in the manuscript is not run, it is simply there for demonstration purposes