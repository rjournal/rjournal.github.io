library(testthat)
library(bestNormalize)

test_check(package = 'bestNormalize', filter = "parallel|custom")
