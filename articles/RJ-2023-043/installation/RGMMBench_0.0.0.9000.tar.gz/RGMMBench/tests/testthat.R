library(testthat)
library(RGMMBench)

test_check("RGMMBench")
