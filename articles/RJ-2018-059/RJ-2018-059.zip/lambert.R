install.packages("rFSA")
library(rFSA)
library(rFSA)
library(parallel)
library(ggplot2)
library(tidyr)


#this code is broken down into 3 parts. Part 1 is for the census example at the end of the paper. Part 2 is for
# the simulation code for best subsets of size 3 and 5. Part 2 requires you to change p=1 to 2,3,4,5,6, and 
# finally 7. Part 3 is for making the timing plots in the paper. 

##### 
# Census Example

download.file("http://raw.githubusercontent.com/joshuawlambert/data/master/census_data_nopct.csv",destfile = "tmp.csv")
census_data_nopct <- read.csv(file = "tmp.csv")

# find two-way interactions
set.seed(123)
fit_2_way <- FSA(formula = "y~1", data = census_data_nopct, fitfunc = lm,
                 fixvar = NULL, quad = F, m = 2, numrs = 50, cores = 1, 
                 interactions = T, criterion = int.p.val, minmax = "min")

print(fit_2_way)    # summary of solutions found
summary(fit_2_way)  # list of summaries from each lm fit
plot(fit_2_way)     # diagnostic plots


# find three-way interactions
set.seed(1234)
fit_3_way <- FSA(formula = "y~1", data = census_data_nopct, fitfunc = lm,
                 fixvar = NULL, quad = F, m = 3, numrs = 50, cores = 1, 
                 interactions = T, criterion = int.p.val, minmax = "min")

print(fit_3_way)    # summary of solutions found
summary(fit_3_way)  # list of summaries from each lm fit
plot(fit_3_way)     # diagnostic plots

##### 
# Timing Simulation Code
# 3 Way

p=1 #in actual simulations p ran from 1 to 7. 7 will take the longest.

#simulation function
simcompare<-function(ncontvars=10,ncatvars=10,nsamp=100,subsetsize){
  dat<<-data.frame(matrix(rnorm(nsamp*(ncontvars+1)),ncol=(ncontvars+1)),matrix(rbinom(nsamp*ncatvars,size = 1,prob=c(0.5)),ncol=ncatvars))
  
  #leaps
  show("leaps")
  start<-Sys.time()
  a<-regsubsets(x = dat[,-1],y = dat[,1],nbest = 1,nvmax = subsetsize,really.big = T,method = "exhaustive")
  end<-Sys.time()
  leaps.time<-difftime(end,start,units = "secs")
  fit<-lm(paste("X1~",paste(names(summary(a)$which[subsetsize,])[summary(a)$which[subsetsize,]==TRUE][2:(subsetsize+1)],collapse = "+")),data=dat)
  leaps.criterion<-AIC(fit)
  
  #rFSA
  show("rFSA")
  start<-Sys.time()
  tmp<-FSA(X1~1,data=dat,interactions=F,m=subsetsize,numrs = 1,criterion=AIC,minmax ="min",fitfunc = lm,cores = 1)
  end<-Sys.time()
  fsa.time<-difftime(end,start,units = "secs")
  fsa.criterion<-tmp$table$criterion
  
  tab<-c(
    c(as.numeric(leaps.time), paste0(names(summary(a)$which[subsetsize,])[summary(a)$which[subsetsize,]==TRUE],collapse = " ")),
    c(as.numeric(fsa.time),print(tmp)[[1]][[2]])
  )
  
  return(as.character(tab))
}

#best subset of size 3
x1<-NULL
nvars<-c(rep(150,25),rep(250,25),rep(350,25),rep(450,25),rep(650,25),rep(750,25),rep(850,25))[((p-1)*25+1):(p*25)]

x1<-mclapply(X=1:25,mc.cores = 1,FUN = function(x){ #on our linux machine we did mc.cores=25
  vars<-nvars[x]
  c(simcompare(ncontvars = vars/2,ncatvars = vars/2,nsamp = 250,subsetsize = 3),vars)
})

results<-data.frame(matrix(unlist(x1),ncol=5,byrow = T))
colnames(results)<-c("leaps.time","leaps.sol","rfsa.time","rfsa.sol","num_p")
results$num_p<-factor(results$num_p,levels(results$num_p)[c(7,1,2,3,4,5,6)])

write.table(results,paste0('~/3way_results_p',p,'.csv'))


# 5 Way

#best of size 5
x1<-NULL
nvars<-c(rep(50,25),rep(100,25),rep(150,25),rep(200,25),rep(250,25),rep(300,25),rep(350,25))[((p-1)*25+1):(p*25)]


x1<-mclapply(X=1:25,mc.cores = 1,FUN = function(x){ #on our linux machine we did mc.cores=25
  vars<-nvars[x]
  c(simcompare(ncontvars = vars/2,ncatvars = vars/2,nsamp = 250,subsetsize = 5),vars)
})

results<-data.frame(matrix(unlist(x1),ncol=5,byrow = T))
colnames(results)<-c("leaps.time","leaps.sol","rfsa.time","rfsa.sol","num_p")
results$num_p<-factor(results$num_p,levels(results$num_p)[c(7,1,2,3,4,5,6)])

write.table(results,paste0('~/rFSA/Results/5way_results_p',p,'.csv'))

#####
# Make timing plots

set.wd("") #set to location of results folder
resp1_3way<-read.table("moreres/3way_results_p1.csv")
resp1_5way<-read.table("moreres/5way_results_p1.csv")
resp2_3way<-read.table("moreres2/3way_results_p2.csv")
resp2_5way<-read.table("moreres2/5way_results_p2.csv")
resp3_3way<-read.table("moreres3/3way_results_p3.csv")
resp3_5way<-read.table("moreres3/5way_results_p3.csv")
resp4_3way<-read.table("moreres4/3way_results_p4.csv")
resp4_5way<-read.table("moreres4/5way_results_p4.csv")
resp5_3way<-read.table("moreres5/3way_results_p5.csv")
resp5_5way<-read.table("moreres5/5way_results_p5.csv")
resp6_3way<-read.table("moreres6/3way_results_p6.csv")
resp6_5way<-read.table("moreres6/5way_results_p6.csv")
resp7_3way<-read.table("moreres7/3way_results_p7.csv")
resp7_5way<-read.table("moreres7/5way_results_p7.csv")

all_res<-rbind(resp1_3way,resp1_5way,
               resp2_3way,resp2_5way,
               resp3_3way,resp3_5way,
               resp4_3way,resp4_5way,
               resp5_3way,resp5_5way,
               resp6_3way,resp6_5way,
               resp7_3way,resp7_5way
)
#make way column
all_res$way<-NA
for(i in 1:dim(all_res)[1]){
  if(length(all.vars(formula(as.character(all_res$rfsa.sol[i]))))==4){
    all_res$way[i]<-3
  } else{
    all_res$way[i]<-5
  }
}


new_all_res<-gather(all_res,Time,Value,leaps.time,rfsa.time)
View(new_all_res)


#check solutions
#3-way
vec_row<-which(new_all_res$way==3)
vec<-NULL
for(i in 1:dim(new_all_res[vec_row,])[1]){
  vec<-c(vec,all(strsplit(as.character(new_all_res[vec_row,]$leaps.sol)," ")[[i]][-1] %in%
                   all.vars(as.formula(as.character(new_all_res[vec_row,]$rfsa.sol[i])))[-1]))
}
table(vec)

#5-way
vec_row<-which(new_all_res$way==5)
vec<-NULL
for(i in 1:dim(new_all_res[vec_row,])[1]){
  vec<-c(vec,all(strsplit(as.character(new_all_res[vec_row,]$leaps.sol)," ")[[i]][-1] %in%
                   all.vars(as.formula(as.character(new_all_res[vec_row,]$rfsa.sol[i])))[-1]))
}
table(vec)[1]/sum(table(vec))



###### 3 way plot
vec_row<-which(new_all_res$way==3)

ggplot(aes(y =log(Value), x = Time, fill = factor(num_p)), data = new_all_res[vec_row,]) + 
  geom_boxplot()+labs(x = "",y="log(Seconds)",fill="Number of Variables")+
  scale_x_discrete(labels=c("leaps.time" = "leaps", "rfsa.time" = "rFSA"))
last_plot()+theme_bw()

#largest 3way difference
place<-which.max(all_res[which(all_res$way==3),]$leaps.time-all_res[which(all_res$way==3),]$rfsa.time)
p<-all_res[which(all_res$way==3),][place,]
paste((p$leaps.time-p$rfsa.time)/60 ," minutes")


###### 5 way plot
vec_row<-which(new_all_res$way==5)

ggplot(aes(y =log(Value), x = Time, fill = factor(num_p)), data = new_all_res[vec_row,]) + 
  geom_boxplot()+labs(x = "",y="log(Seconds)",fill="Number of Variables")+
  scale_x_discrete(labels=c("leaps.time" = "leaps", "rfsa.time" = "rFSA"))
last_plot()+theme_bw()

#largest 5way difference
place<-which.max(all_res[which(all_res$way==5),]$leaps.time-all_res[which(all_res$way==5),]$rfsa.time)
p<-all_res[which(all_res$way==5),][place,]
paste((p$leaps.time-p$rfsa.time)/60/60," hours")

