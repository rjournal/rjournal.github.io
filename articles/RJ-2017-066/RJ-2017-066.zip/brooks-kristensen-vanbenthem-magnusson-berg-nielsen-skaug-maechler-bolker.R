## ----Packages-------------------
library(glmmTMB)
library(bbmle)
library(ggplot2); theme_set(theme_bw())
options(scipen = 1, digits = 2)
library(reshape)
library(plyr)
library(directlabels)

## ----This model summary is described in the main text---------------------------------------
summary(glmmTMB(count~mined+(1|site), zi=~mined , disp=~DOY, Salamanders, family=nbinom2))

###########################################################################

## APPENDIX A: SALAMANDER EXAMPLE 
## COMPARING GLMMS, ZERO-INFLATED GLMMS, 
## AND HURDLE MODELS USING GLMMTMB 

## ----Figure 3
## ----This is a plot of the salamander data
ggplot(Salamanders, aes(x=count, fill=mined))+geom_histogram(position="identity" , alpha=.7, binwidth = 1)+facet_wrap(~spp, scale="free")+ylab(NULL)+xlab(NULL)

## ----Now fit models with different formulas and distributions
## ----Poisson
pm0 = glmmTMB(count~spp + (1|site), Salamanders, family=poisson)
pm1 = glmmTMB(count~spp + mined + (1|site), Salamanders, family=poisson)
pm2 = glmmTMB(count~spp * mined + (1|site), Salamanders, family=poisson)

## ----Conway-Maxwell-Poisson
## These are slow because TMB is solving for the CMP parameters that match the mean.
cmpm0 = glmmTMB(count~spp + (1|site), Salamanders, family=compois)
cmpm1 = glmmTMB(count~spp + mined + (1|site), Salamanders, family=compois)
cmpm2 = glmmTMB(count~spp * mined + (1|site), Salamanders, family=compois)

## ----Negative Binomial
nbm0 = glmmTMB(count~spp + (1|site), Salamanders, family=nbinom2)
nbm1 = glmmTMB(count~spp + mined + (1|site), Salamanders, family=nbinom2)
nbm2 = glmmTMB(count~spp * mined + (1|site), Salamanders, family=nbinom2)

## ----Negative Binomial with a dispersion model
nbdm0 = glmmTMB(count~spp + (1|site), disp=~DOY, Salamanders, family=nbinom2)
nbdm1 = glmmTMB(count~spp + mined + (1|site), disp=~DOY, Salamanders, family=nbinom2)
nbdm2 = glmmTMB(count~spp * mined + (1|site), disp=~DOY, Salamanders, family=nbinom2)

## ----Zero-Inflated Poisson
zipm0 = glmmTMB(count~spp +(1|site), zi=~spp, Salamanders, family=poisson)
zipm1 = glmmTMB(count~spp + mined +(1|site), zi=~spp, Salamanders, family=poisson)
zipm2 = glmmTMB(count~spp + mined +(1|site), zi=~spp + mined, Salamanders, family=poisson)
zipm3 = glmmTMB(count~spp * mined +(1|site), zi=~spp * mined, Salamanders, family=poisson)

## ----Zero-Inflated Conway-Maxwell-Poisson
## These are slow because TMB is solving for the CMP parameters that match the mean.
zicmpm0 = glmmTMB(count~spp +(1|site), zi=~spp, Salamanders, family=compois)
zicmpm1 = glmmTMB(count~spp + mined +(1|site), zi=~spp, Salamanders, family=compois)
zicmpm2 = glmmTMB(count~spp + mined +(1|site), zi=~spp + mined, Salamanders, family=compois)
zicmpm3 = glmmTMB(count~spp * mined +(1|site), zi=~spp * mined, Salamanders, family=compois)

## ----Zero-Inflated Negative Binomial
zinbm0 = glmmTMB(count~spp +(1|site), zi=~spp, Salamanders, family=nbinom2)
zinbm1 = glmmTMB(count~spp + mined +(1|site), zi=~spp, Salamanders, family=nbinom2)
zinbm2 = glmmTMB(count~spp + mined +(1|site), zi=~spp + mined, Salamanders, family=nbinom2)
zinbm3 = glmmTMB(count~spp * mined +(1|site), zi=~spp * mined, Salamanders, family=nbinom2)

## ----Poisson hurdle
hpm0 = glmmTMB(count~spp + (1|site), zi=~spp, Salamanders, family=truncated_poisson)
hpm1 = glmmTMB(count~spp + mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_poisson)
hpm2 = glmmTMB(count~spp * mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_poisson)
hnbm0 = glmmTMB(count~spp + (1|site), zi=~spp, Salamanders, family=truncated_nbinom2)
hnbm1 = glmmTMB(count~spp + mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_nbinom2)
hnbm2 = glmmTMB(count~spp * mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_nbinom2)

## ----Model Comparison
 AICtab(pm0, pm1, pm2,
        cmpm0, cmpm1, cmpm2,
        nbm0, nbm1, nbm2,
        nbdm0, nbdm1, nbdm2,
        zipm0, zipm1, zipm2, zipm3,
        zicmpm0, zicmpm1, zicmpm2, zicmpm3,
        zinbm0, zinbm1, zinbm2, zinbm3,
        hpm0, hpm1, hpm2,
        hnbm0, hnbm1, hnbm2)

###########################################################################
## ----Figure 4
## ----A quick and dirty plot of fixed effects (ignorming correaltion structure)
zinbm3FE = glmmTMB(count~spp * mined, zi=~spp * mined, Salamanders, family=nbinom2)
newdata0 = newdata = unique(Salamanders[,c("mined","spp")])
temp = predict(zinbm3FE, newdata, se.fit=TRUE, zitype="response")
newdata$predFE = temp$fit
newdata$predFE.min = temp$fit-1.96*temp$se.fit
newdata$predFE.max = temp$fit+1.96*temp$se.fit

real=ddply(Salamanders, ~site+spp+mined, summarize, m=mean(count))
  
ggplot(newdata, aes(spp, predFE, colour=mined))+geom_point()+
  geom_errorbar(aes(ymin=predFE.min, ymax=predFE.max))+
  geom_point(data=real, aes(x=spp, y=m) )+
  ylab("Average abundance \n including presences and absences")+
  xlab("Species")

###########################################################################

## ----Now for the predictions that account for the correlation
## ----Predict the mode
X.cond = model.matrix(lme4::nobars(formula(zinbm3)[-2]), newdata0)
beta.cond = fixef(zinbm3)$cond
pred.cond = X.cond %*% beta.cond

ziformula = zinbm3$modelInfo$allForm$ziformula #$
X.zi = model.matrix(lme4::nobars(ziformula), newdata0)
beta.zi = fixef(zinbm3)$zi
pred.zi = X.zi %*% beta.zi
pred.ucount = exp(pred.cond)*(1-plogis(pred.zi))

## ----Draw points from the joint distribution to get CI
## ----Do it separately for the conditional (cond) and zero-inflation (zi) models
library(MASS)
set.seed(101)
pred.condpar.psim = mvrnorm(1000,mu=beta.cond,Sigma=vcov(zinbm3)$cond)
pred.cond.psim = X.cond %*% t(pred.condpar.psim)
pred.zipar.psim = mvrnorm(1000,mu=beta.zi,Sigma=vcov(zinbm3)$zi)
pred.zi.psim = X.zi %*% t(pred.zipar.psim)
## ---Then put the cond and the zi together
pred.ucount.psim = exp(pred.cond.psim)*(1-plogis(pred.zi.psim))
ci.ucount = t(apply(pred.ucount.psim,1,quantile,c(0.025,0.975)))
ci.ucount = data.frame(ci.ucount)
names(ci.ucount) = c("ucount.low","ucount.high")
pred.ucount = data.frame(newdata0, pred.ucount, ci.ucount)

## ----plot the model's CI and mode with the real data
real.count = ddply(Salamanders, ~spp+mined, summarize, m=median(count), mu=mean(count))
ggplot(pred.ucount, aes(x=spp, y=pred.ucount, colour=mined))+geom_point(shape=1, size=2)+
  geom_errorbar(aes(ymin=ucount.low, ymax=ucount.high))+
  geom_point(data=real.count,  aes(x=spp, y=m, colour=mined), shape=0, size=2)+
  geom_point(data=real.count,  aes(x=spp, y=mu, colour=mined), shape=5, size=2)+
  ylab("Abundance \n including presences and absences")+
  xlab("Species")

###########################################################################
## ----Simulate 1000 data sets from the most parsimonious model
## ----Each simulated response has the same number of obs as the original--
sims=simulate(nbm2, seed = 1, nsim = 1000)

## ----bind the simulated counts with the relevant predictor variables from
##  the original data-----
simdatlist=lapply(sims, function(count){ 
  cbind(count, Salamanders[,c('site', 'mined', 'spp')])
})
simdatsums=lapply(simdatlist, function(x){
  ddply(x, ~spp+mined, summarize, 
        absence=mean(count==0),
        mu=mean(count))
})
ssd=do.call(rbind, simdatsums)

## ----organize the real data to be plotted
real = ddply(Salamanders, ~spp+mined, summarize, 
             absence=mean(count==0),
             mu=mean(count))
## ----plot the real and simulated data together
## ----Figure 6
ggplot(ssd, aes(x=absence, color=mined))+
  geom_density(adjust=4)+
  facet_wrap(~spp)+
  geom_point(data=real, aes(x=absence, y=1, color=mined), size=2)+
  xlab("Probability that salamanders are not observed")+ylab(NULL)


## ----Figure 7
ggplot(ssd, aes(x=mu, color=mined))+
  geom_density(adjust=4)+
  facet_wrap(~spp)+
  geom_point(data=real, aes(x=mu, y=.5, color=mined), size=2)+
  xlab("Abundance including presences and absences")+ylab(NULL)

###########################################################################
## APPENDIX B: OWLS EXAMPLE
## COMPARE ZERO-INFLATED MIXED MODELS ACROSS R PACKAGES 

## ----Packages
library(glmmTMB)
library(glmmADMB)
library(MCMCglmm)
library(brms)
library(INLA)
library(mgcv)
#Install this version of broom  -> devtools::install_github("bbolker/broom")
library(broom) #for tidy functions 
library(plyr)
library(dplyr) #tidyverse
library(ggplot2); theme_set(theme_bw())
library(ggstance)#for position_dodgev

## ----data organization 
data(Owls,package="glmmTMB")
Owls = plyr::rename(Owls, c(SiblingNegotiation="NCalls"))
Owls = transform(Owls,
                 ArrivalTime=scale(ArrivalTime, center=TRUE, scale=FALSE),
                 obs=factor(seq(nrow(Owls))))

## ----helper functions
options(scipen = 1, digits = 3)#larger than above needed for 0.975 quantile
# time 
tfun = function(...) unname(system.time(capture.output(...))["elapsed"])
abbfun = function(x) {
  gsub("[()]","", # (Intercept) -> Intercept
    gsub("(Sol\\.)*(trait|at.level\\(trait, 1\\):)*","", # simplify MCMCglmm labs
     gsub("FoodTreatment","FT",x)))  # shorten
}

# broom tidy method for class "brmsfit"
tidy.brmsfit = function(x, effects=c("fixed"),...) {
    ss = summary(x)
    tidy(ss$fixed) %>%
        mutate(effect="fixed",group="fixed") %>%
        select(effect,.rownames,Estimate,Est.Error,l.95..CI,u.95..CI,group) %>%
        rename(term=.rownames,estimate=Estimate,std.error=Est.Error,
               conf.low=l.95..CI,conf.high=u.95..CI)
}
# broom tidy method for class "inla"
tidy.inla = function(x, effects=c("fixed"),...) {
    ss = summary(x)
    tidy(ss$fixed) %>%
        mutate(effect="fixed",group="fixed") %>%
        select(effect,.rownames,mean,sd,X0.025quant,X0.975quant,group) %>%
        rename(term=.rownames,estimate=mean,std.error=sd,
               conf.low=X0.025quant,conf.high=X0.975quant)
}
# broom tidy method for class "gam"
tidy.gam = function(x, effects=c("fixed"),quasi=TRUE,...) {
    ss = summary(x)
    disp = if (!quasi) 1 else deviance(m1.gam)/df.residual(m1.gam)
    tidy(ss$p.table)  %>%
        mutate(effect="fixed",group="fixed",
               Std..Error=sqrt(disp)*Std..Error,
               conf.low=Estimate-1.96*Std..Error,
               conf.high=Estimate+1.96*Std..Error) %>%
        select(.rownames,Estimate,Std..Error, conf.low, conf.high) %>%
    rename(term=.rownames,estimate=Estimate,std.error=Std..Error)
}
###########################################################################
## ----Models with constant zero-inflation 

## ----glmmTMB 
fixef1 = NCalls~(FoodTreatment + ArrivalTime) * SexParent + logBroodSize
form1 =  update(fixef1, . ~ . + (1|Nest)+(1|obs))
time.tmb = tfun(m1.tmb <<- glmmTMB(form1,
                                  ziformula=~1, data = Owls,
                                  family=poisson))

## ----MCMCglmm
fixef2 = NCalls~trait-1+ # intercept terms for both count and binary terms
    # other fixed-effect terms only apply to count term
    at.level(trait,1):logBroodSize+
    at.level(trait,1):((FoodTreatment+ArrivalTime)*SexParent)
nfix = 8
# residual variances independent for count and binary terms;
#    fixed to 1 for binary term
# random-effects variances independent for count and binary terms;
#    fixed very small (1e-6) for binary term
prior_overdisp  = list(R=list(V=diag(c(1,1)),nu=0.002,fix=2),   
                       G=list(list(V=diag(c(1,1e-6)),nu=0.002,fix=2)))
prior_overdisp_broodoff = c(prior_overdisp,
                            list(B=list(mu=rep(0,nfix),
                                        V=diag(rep(1e4,nfix)))))
set.seed(101)
time.MCMCglmm = tfun(m1.MCMCglmm <<- MCMCglmm(fixef2,
                                   rcov=~idh(trait):units,
                                   random=~idh(trait):Nest,
                                   prior=prior_overdisp_broodoff,
                                   data=Owls,
                                   nitt=103000,
                                   thin=100,
                                   family="zipoisson",
                                   verbose=FALSE))

## ----brms
time.brms = tfun(m1.brms <<- brm(form1, data = Owls,
                                 iter=1000,
                                 family="zero_inflated_poisson"))

## ----brms (timing without compilation)
time.brms2 = tfun(m1.brms2 <<- update(m1.brms))

## ----INLA
form2 = update(fixef1, . ~ . + f(Nest, model="iid") + f(obs, model="iid"))
time.inla = tfun(m1.inla <<-
       inla(form2,
            family= "zeroinflatedpoisson1",
            data=Owls))

## ----mgcv
form3 = update(fixef1, . ~ . + s(Nest, bs="re"))
time.mgcv = tfun(m1.gam <<- gam(list(form3, ~ 1),
                                data = Owls,
                                family = ziplss(), method = "REML"))

## ----times
timeVec = c(glmmTMB=time.tmb,
             MCMCglmm=time.MCMCglmm,
             `brms (with compilation)`=time.brms,
             `brms (no compilation)`=time.brms2,
             INLA=time.inla,
             mgcv=time.mgcv
             )
sort(round(timeVec,1))

## ----arrange all the coeficients
modList = list(glmmTMB=m1.tmb,
               MCMCglmm=m1.MCMCglmm,
               brms=m1.brms,
               INLA=m1.inla,
               gam=m1.gam
               )
coefs = ldply(modList,tidy,effect="fixed",conf.int=TRUE,
              .id="model") %>%
    mutate(term=abbfun(term)) %>%
    select(model,term,estimate,conf.low,conf.high) %>%
    filter(!term %in% c("Intercept","Intercept.1","NCalls","zi_NCalls"))

## ----Plot the coefficients
gg0 = ggplot(coefs, aes(color=model,shape=model,y=term, x=estimate))+
    labs(x="Regression estimate",y="")+
    geom_pointrangeh(aes(xmax=conf.high, xmin=conf.low),
                     position = position_dodgev(height = 0.6))+
     ## flip legend to match order in plot
     guides(colour = guide_legend(reverse = TRUE),
            shape =  guide_legend(reverse = TRUE))
gg1 = gg0 + scale_colour_brewer(palette="Set1")+
    scale_shape_manual(values=15:20)
print(gg1)

###########################################################################
## Models with complex zero-inflation 

## ----glmmTMB
form0 = update(fixef1, . ~ . + (1|Nest))
ziform = ~FoodTreatment+(1|Nest)
time.tmb_czi = tfun(m1.tmb_czi <<- glmmTMB(form0,
                                           ziformula=ziform,
                                           data = Owls, family=nbinom2))

## ----MCMCglmm
fixef3 = NCalls~trait-1+ # intercept terms for both count and binary terms
    # fixed-effect terms for count term
    at.level(trait,1):logBroodSize+
    at.level(trait,1):((FoodTreatment+ArrivalTime)*SexParent)+
    # fixed-effect terms for binary term
    at.level(trait,2):FoodTreatment
nfix = 9
# residual variances independent for count and binary terms;
#    fixed to 1 for binary term
# random-effects variances now allow estimated variance for binary term
#   as well
prior_overdisp_czi  = list(R=list(V=diag(c(1,1)),nu=0.002,fix=2),   
                       G=list(list(V=diag(c(1,1)),nu=0.002)))
prior_overdisp_broodoff_czi = c(prior_overdisp_czi,
                              list(B=list(mu=rep(0,nfix),
                                          V=diag(rep(1e4,nfix)))))
set.seed(101)
time.mcmc_czi=tfun(m1.mcmc_czi <<- MCMCglmm(fixef3,
                                   rcov=~idh(trait):units,
                                   random=~idh(trait):Nest,
                                   prior=prior_overdisp_broodoff_czi,
                                   data=Owls,
                                   nitt=153000,
                                   family="zipoisson",
                                   verbose=FALSE))
## warning message suppressed ...

## ----brms
time.brms_czi = tfun(m1.brms_czi <<- brm(brmsformula(form1, zi=ziform),
                                 data = Owls,
                                 family="zero_inflated_poisson"))

## ----brms (timing without compilation)
time.brms_czi2 = tfun(m1.brms_czi2 <<- update(m1.brms_czi))

## ----mgcv
time.mgcv_czi = tfun(m1.gam_czi <<- gam(list(form3,
                                             ~FoodTreatment+ s(Nest, bs = "re")),
                                        data = Owls, family = ziplss(), method = "REML"))

## ----times
timeVec_czi = c(TMB=time.tmb_czi,
                 MCMCglmm=time.mcmc_czi,
                 `brms (with compilation)`=time.brms_czi,
                 `brms (no compilation)`=time.brms_czi2,
                 mgcv=time.mgcv_czi)
knitr::kable(sort(round(timeVec_czi,1)),
                  format="latex", col.names="time (sec)", align="r", booktabs=TRUE)

## ----arrange all the coeficients
modList_czi = list(glmmTMB=m1.tmb_czi,
                MCMCglmm=m1.mcmc_czi,
                brms=m1.brms_czi,
                mgcv=m1.gam_czi)
coefs_czi = ldply(modList_czi,tidy,effect="fixed",conf.int=TRUE,
                  .id="model") %>%
    mutate(term=abbfun(term)) %>%
    select(model,term,estimate,conf.low,conf.high) %>%
    filter(!term %in% c("Intercept","Intercept.1", "NCalls","zi_NCalls","logBroodSize",
                        "zi_Intercept","zi_FTSatiated","FTSatiated.1",
                        "FTDeprived:at.level, 2"))

## ----plot the coeficients
pal = RColorBrewer::brewer.pal("Set1",n=5)
newmods = c(1,2,3,5)
## ugh, repeat code
## can't figure out how to change scales/keep colors consistent
gg0_czi = ggplot(coefs_czi, aes(color=model,shape=model,y=term, x=estimate))+
    labs(x="Regression estimate",y="")+
    geom_pointrangeh(aes(xmax=conf.high, xmin=conf.low),
                     position = position_dodgev(height = 0.6))+
     ## flip legend to match order in plot
     guides(colour = guide_legend(reverse = TRUE),
            shape =  guide_legend(reverse = TRUE))+
    scale_colour_manual(values=pal[newmods])+
    scale_shape_manual(values=(15:20)[newmods])
print(gg0_czi)


## ----save the fits
save("modList","modList_czi","timeVec","timeVec_czi",
     file="modList.RData")
