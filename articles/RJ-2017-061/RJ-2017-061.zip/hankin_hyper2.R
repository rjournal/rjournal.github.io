
 library("hyper2")
 chess <- hyper2(list(1, 2, 3), c(30, 36, 22))
 chess



 chess[c(1, 2)] <- -35
 chess[c(2, 3)] <- -35
 chess[c(1, 3)] <- -18
 chess



 pnames(chess) <- c("Topalov", "Anand", "Karpov")
 chess



 lhyper2(chess, c(1/3, 1/3))




 gradient(chess, c(1/3, 1/3))



 maxp(chess)



 data("rowing")
 H <- hyper2(pnames = allrowers)
 H



 heat1 <- c("fournier", "cabrera", "bhokanal", "saensuk", "kelmelis", "teilemb")
 H <- H + order_likelihood(char2num(heat1, allrowers))
 H

 head(sculls2016)

 dotchart(maxp(sculls2016))

 team_red <- c("Jamie", "Tracy", "Ben", "Amy", "Renae", "Georgia")
 team_blue <- c("Brent", "Laura", "Emelia", "Colin", "Kira", "Tash")

 

 H <- hyper2(pnames = c(
    "Amy", "Ben", "Brent", "Colin", "Emelia",
    "Georgia", "Jamie", "Kira", "Laura", "Renae",
    "Sarah", "Tash", "Tracy"))
 H



 H[team_red] <- +1
 H[c(team_red, team_blue)] <- -1
 H

 blue   <- c("Laura", "Jamie")   
 yellow <- c("Emelia", "Amy")    
 green  <- c("Brent", "Tracy")   
 red    <- c("Ben", "Renae")


 H[blue] <- 1
 H[c(blue, yellow, green, red)] <- -1
 H[yellow] <- 1
 H[c(yellow, green, red)] <- -1
 H[green] <- 1
 H[c(green, red)] <- -1
 H



 L <- ggol(H, 
    winner     = "Laura",
    btm4       = c("Brent", "Tracy", "Ben"),
    eliminated = "Renae")




 data("masterchef")
 n <- 13   
 equal_strengths <- rep(1/n,n-1)
 like_series(equal_strengths, masterchef_series6)




 UI <- rbind(diag(n-1), -1)  
 CI <- c(rep(0, n-1), -1)

# following takes a long time to run:
 constrOptim(
    theta = equal_strengths,
    f = function(p){-like_series(p, masterchef_series6)}, 
    ui = UI, ci = CI,
    grad = NULL)


 pmax_masterchef6

 like_series(indep(pmax_masterchef6), masterchef_series6)

 pchisq(2*(78.7-66.2), df = 12, lower.tail = FALSE)

 UI <- rbind(UI, c(0, 0, 1, 0, 0, 0, 0, 0, -1, 0, 0, 0))  
 CI <- c(CI, 0)

 equal_strengths[3] <-  equal_strengths[3] + 0.0001 
 ans2 <-
    constrOptim(
      theta = equal_strengths,
      f = function(p){-like_series(p, masterchef_series6)},  
      grad = NULL,
      ui = UI, ci = CI)


 like_series(indep(pmax_masterchef6_constrained), masterchef_series6)
