## ----rpostgis-init-------------------------------------------------------
## Requires a PostgreSQL server with a valid database to start with.
## Set db_host, db_name, db_user, and db_pwd accordingly.
library(rpostgis)
library(sp)
conn <- dbConnect("PostgreSQL", host = db_host, dbname = db_name,
    user = db_user, password = db_pwd)
dbSendQuery(conn, paste0("DROP DATABASE IF EXISTS rpostgis_paper;")) ## DON'T CHANGE THIS - ONLY DROP rpostgis_paper !!!
dbSendQuery(conn, paste0("CREATE DATABASE rpostgis_paper WITH OWNER = ",
    cred[3], " ENCODING = 'UTF8'")) # DON'T CHANGE DATABASE
dbSendQuery(conn, "COMMENT ON DATABASE rpostgis_paper is 'temporary database for rpostgis R journal article';")
dbDisconnect(conn)
conn <- dbConnect("PostgreSQL", host = db_host, dbname = "rpostgis_paper",
    user = db_user, password = db_pwd) # DON'T CHANGE DATABASE
pgPostGIS(conn)

## ----pgsrid-demo---------------------------------------------------------
crs <- sp::CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0")
pgSRID(conn, crs)

## ----meuse---------------------------------------------------------------
library(sp)
data("meuse")
meuse <- SpatialPointsDataFrame(meuse[, 1:2], data = meuse[,
    3:length(meuse)], proj4string = sp::CRS("+init=epsg:28992"))
class(meuse)
head(meuse@data)

## ----pginsert-demo-------------------------------------------------------
pgInsert(conn, "meuse", meuse, new.id = "gid")

## ----pggetgeom-demo------------------------------------------------------
meuse.db <- pgGetGeom(conn, "meuse")

## ----pggetgeom-demo-query------------------------------------------------
query <- "SELECT gid, ST_Transform(ST_Buffer(geom, 100), 4326) AS geom FROM meuse;"
meuse.buff <- pgGetGeom(conn, name = "meuse_buff", query = query,
    gid = "gid")
par(mar = c(2, 2, 2, 2))
plot(meuse.buff, axes = TRUE, asp = 1)

## ----meuse-grid----------------------------------------------------------
data("meuse.grid")
meuse.grid <- SpatialPointsDataFrame(meuse.grid[, 1:2], data = meuse.grid[,
    3:length(meuse.grid)], proj4string = sp::CRS("+init=epsg:28992"))
gridded(meuse.grid) <- TRUE
class(meuse.grid)

## ----meuse-dist----------------------------------------------------------
pgWriteRast(conn, "meuse_rast", meuse.grid)

## ----pggetrast-demo------------------------------------------------------
lc.db <- pgGetRast(conn, "meuse_rast")
summary(lc.db)

## ----rlogo---------------------------------------------------------------
rlogo <- raster::brick(system.file("external/rlogo.grd", package = "raster"))
pgWriteRast(conn, "rlogo", rlogo)
just.r <- pgGetRast(conn, "rlogo", bands = TRUE, boundary = c(60, 0, 95, 35))
just.r

## ----rlogo-fig-----------------------------------------------------------
raster::plotRGB(just.r)

## ----pggetboundary-demo--------------------------------------------------
(m.bound <- pgGetBoundary(conn, "meuse_rast", "rast"))

## ----dbwritedataframe-meuse----------------------------------------------
data("meuse")
meuse$example_time <- seq(as.POSIXct("2010-01-01 12:00", tz = "Europe/Amsterdam"),
    by = "1 day", length.out = nrow(meuse))
head(meuse$example_time)

## ----dbwritedataframe-table----------------------------------------------
RPostgreSQL::dbWriteTable(conn, "meuse_base", meuse)
meuse.base <- RPostgreSQL::dbReadTable(conn, "meuse_base")
all.equal(meuse, meuse.base)

## ----dbwritedataframe-df-------------------------------------------------
dbWriteDataFrame(conn, "meuse_df", meuse)
meuse.df <- dbReadDataFrame(conn, "meuse_df")
all.equal(meuse, meuse.df)

## ----dbwritedataframe-insert---------------------------------------------
meuse <- SpatialPointsDataFrame(meuse[, 1:2], data = meuse[,
    3:length(meuse)], proj4string = sp::CRS("+init=epsg:28992"))
pgInsert(conn, "meuse_df", meuse, df.mode = TRUE, overwrite = TRUE)
meuse_df <- pgGetGeom(conn, "meuse_df")
all.equal(meuse, meuse_df)

## ----dbschema-demo-------------------------------------------------------
dbSchema(conn, "rpostgis_demo")

## ----dbschema-insert-----------------------------------------------------
meuse$example_time <- as.character(meuse$example_time)
pgInsert(conn, c("rpostgis_demo", "meuse"), meuse, new.id = "meuse_id",
    alter.names = TRUE)

## ----dbcomment-demo----------------, tidy = FALSE------------------------
dbComment(conn, "rpostgis_demo",
    comment = "Schema storing example data for the 'rpostgis' paper.",
    type = "schema")
dbComment(conn, c("rpostgis_demo", "meuse"),
    comment = "Meuse river example dataset from R 'sp' package.",
    type = "table")

## ----dbcolumn-demo-------------------------------------------------------
dbColumn(conn, c("rpostgis_demo", "meuse"), "dist", action = "drop")

## ----dbaddkey-demo-------------------------------------------------------
dbAddKey(conn, c("rpostgis_demo", "meuse"), "meuse_id", type = "primary")

## ----dbindex-demo--------------------------------------------------------
dbIndex(conn, c("rpostgis_demo", "meuse"), "geom", method = "gist")

## ----dbasdate-demo-------------------------------------------------------
dbAsDate(conn, c("rpostgis_demo", "meuse"), "example_time", tz = "Europe/Amsterdam")

## ----dbvacuum-demo-------------------------------------------------------
dbVacuum(conn, c("rpostgis_demo", "meuse"))

## ----dbdrop-demo---------------------------------------------------------
dbDrop(conn, "meuse_base")

## ----dbtableinfo-demo----------------------------------------------------
dbTableInfo(conn, c("rpostgis_demo", "meuse"))

## ----disconnect----------------------------------------------------------
pgListGeom(conn)
pgListRast(conn)
RPostgreSQL::dbDisconnect(conn)
