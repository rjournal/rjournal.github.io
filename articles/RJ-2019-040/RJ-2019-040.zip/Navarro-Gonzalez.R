# replication script for unival: An FA-based R Package For Assessing Essential Unidimensionality Using External Validity Information
# 

install.packages("unival")

library(unival)
y = SAS3f[,1]
FP = as.matrix(SAS3f[,2:4])
fg = SAS3f[,5]
PHI = cbind(c(1,0.408,0.504),c(0.408,1,0.436),c(0.504,0.436,1))

unival(y = y, FP = FP, fg = fg, PHI = PHI, type = "EAP")

remove(y, FP, fg, PHI)

