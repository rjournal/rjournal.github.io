# R code examples for:
# The IDSpatialStats R package: Quantifying spatial dependence of infectious disease spread
# John R Giles. Henrik Salje, and Justin Lessler

#install.packages('IDSpatialStats')
#install.packages('sparr')
library(IDSpatialStats)
library(sparr)

############################################################################
# Epidemic simulations with variable R value
R1 <- 2
R2 <- 0.5
tot.gen <- 12
R.vec <- seq(R1, R2, (R2 - R1)/(tot.gen - 1))
dist.func <- alist(n=1, a=1/100, rexp(n, a))
sim <- sim.epidemic(R=R.vec, gen.t.mean=7, gen.t.sd=2, min.cases=100,
                    tot.generations=tot.gen, trans.kern.func=dist.func)

head(sim, n=4)

sim.plot(sim)


############################################################################
# Calculating Wallinga-Teunis matrices
case.times <- c(1,2,2,3,3) # times each case occurs
g.x <- c(0, 2/3, 1/3, 0, 0) # hypothetical generation distribution time of a pathogen

mat.wts <- est.wt.matrix.weights(case.times=case.times, gen.t.dist=g.x)

# Calculate infector-infectee Wallinga-Teunis matrix
wt.mat1 <- est.wt.matrix(case.times=case.times, gen.t.dist=g.x,
                         basic.wt.weights=mat.wts)
wt.mat2 <- est.wt.matrix(case.times=case.times, gen.t.dist=g.x) 

identical(wt.mat1, wt.mat2) # the two methods are equivalent


############################################################################
# Estimate theta weights
case.times <- c(1,2,2,3,3) # times each case occurs
g.x <- c(0, 2/3, 1/3, 0, 0) # hypothetical generation time distribution of a pathogen
gen.time <- 1 # mean generation time
n.gen <- round((max(case.times) - min(case.times)) / gen.time) + 1 # total number of generations

# Calculate infector-infectee Wallinga-Teunis matrix
wt.mat <- est.wt.matrix(case.times=case.times, gen.t.dist=g.x)

# Estimated theta weights from five randomized transmission trees
theta.wts <- est.transdist.theta.weights(case.times=case.times, n.rep=5,
                                         gen.t.mean=gen.time, t1=0, t.density=g.x)
theta.wts[,,1]


############################################################################
# Estimate transmission distance for simulated data
set.seed(123)

dist.func <- alist(n=1, a=1/100, rexp(n, a))
sim <- sim.epidemic(R=2, gen.t.mean=7, gen.t.sd=2, min.cases=100,
                    tot.generations=8, trans.kern.func=dist.func)

sim.transdist <- est.transdist(epi.data=sim, gen.t.mean=7, gen.t.sd=2, t1=0,
                               max.sep=1e10, max.dist=1e10, n.transtree.reps=10)

sim.transdist


sim.transdist.ci <- est.transdist.bootstrap.ci(epi.data=sim,
                                               gen.t.mean=7,
                                               gen.t.sd=2,
                                               t1=0,
                                               max.sep=1e10,
                                               max.dist=1e10,
                                               n.transtree.reps=10,
                                               boot.iter=5,
                                               ci.low=0.025,
                                               ci.high=0.975)
sim.transdist.ci

############################################################################
# Estimate temporal transmission distance for simulated data
set.seed(123)
dist.func <- alist(n=1, a=1/100, rexp(n, a)) # Dispersal kernel
sim <- sim.epidemic(R=2, gen.t.mean=7, gen.t.sd=2, min.cases=100,
                    tot.generations=8, trans.kern.func=dist.func)

# Estimate mean and confidence intervals at each time step
sim.temp.transdist.ci <- est.transdist.temporal.bootstrap.ci(epi.data=sim,
                                                             gen.t.mean=7,
                                                             gen.t.sd=2,
                                                             t1=0,
                                                             max.sep=1e10,
                                                             max.dist=1e10,
                                                             n.transtree.reps=10,
                                                             boot.iter=5,
                                                             ci.low=0.025,
                                                             ci.high=0.975,
                                                             parallel=TRUE,
                                                             n.cores=detectCores())
head(sim.temp.transdist.ci)


############################################################################
# Estimate temporal transmission distance for FMD data

data(fmd) 
fmd <- cbind(fmd$cases$x, fmd$cases$y, fmd$cases$marks)
head(fmd, n=4)

sim.plot(fmd)

# NOTE: this function may take a while depending on the data set
fmd.trans <- est.transdist.temporal.bootstrap.ci(epi.data=fmd,
                                                 gen.t.mean=6.1,
                                                 gen.t.sd=4.6,
                                                 t1=0,
                                                 max.sep=1e10,
                                                 max.dist=1e10,
                                                 n.transtree.reps=5,
                                                 boot.iter=10,
                                                 ci.low=0.025,
                                                 ci.high=0.975,
                                                 parallel=TRUE,
                                                 n.cores=detectCores())
par(mfrow=c(1,1))
fmd.trans[,2:4] <- fmd.trans[,2:4]/1000 # Convert to km
plot(fmd.trans$t, fmd.trans$pt.est, pch=19, col='grey', ylim=range(fmd.trans[,3:4], na.rm=T), 
     xlab='Time step', ylab='Estimated mean of transmission kernel (km)')

tmp <- seq(1, nrow(fmd.trans), 5)
axis(3, tmp, fmd.trans[tmp,5])
mtext('Sample size (n)', side=3, line=3)

tmp <- which(fmd.trans$n >= 30)[1]
abline(v=tmp, lty=2)
text(16, 1, 'n = 30')

tmp <- tmp:nrow(fmd.trans)
lty <- c(NA,1,2,2)

for(i in 2:4) {
     low <- loess(fmd.trans[tmp,i] ~ as.vector(tmp), span=0.3)
     low <- predict(low, newdata=data.frame(as.vector(tmp)))
     lines(c(rep(NA, tmp[1]), low), lwd=2, lty=lty[i], col='blue')
}


############################################################################
# Calculate cross-K and cross pair correlation functions with simulated data
data(DengueSimRepresentative)

r.vals <- seq(0, 1000, 20)
labs <- seq(0, 1000, 200)

k <- get.cross.K(epi.data=DengueSimRepresentative, type=5, hom=1, het=NULL,
                 r=r.vals, correction='border')
head(k, n=3)

g <- get.cross.PCF(epi.data=DengueSimRepresentative, type=5, hom=1, het=NULL,
                   r=r.vals, correction='border')
head(g, n=3)

par(mfrow=c(1,2))
plot(k[,3], type='l', lwd=2, xaxt='n', xlab='distance (m)', ylab='cross K function')
lines(k[,2], col='red', lty=2, lwd=2)
axis(1, at=which(r.vals %in% labs), labels=labs)

legend(-3, 4.15e6, legend=c("Theoretical Poisson process", "Observed function"),
       col=c("red", "black"), lty=2:1, box.lty=0, bg='transparent', 
       x.intersp=0.7, y.intersp = 1.2)

plot(g$pcf, type='l', lwd=2, xaxt='n', xlab='distance (m)', 
     ylab='cross pair correlation function')
abline(h=1, col='red', lty=2, lwd=2)
axis(1, at=which(r.vals %in% labs), labels=labs)

#########################################################################

# Calculate tau-statistic using get.pi.typed functions
data(DengueSimRepresentative)
type <- 2 - (DengueSimRepresentative[,'serotype'] == 1)
typed.data <- cbind(DengueSimRepresentative, type=type)
d2 <- seq(20, 1000, 20)
d1 <- d2 - 20

# Static definition of case type homology
num <- get.pi.typed(typed.data, typeA=1, typeB=2, r.low=d1, r=d2)
den <- get.pi.typed(typed.data, typeA=1, typeB=2, r.low=0, r=1e10)
head(num$pi/den$pi, n=4)

tau <- get.tau.typed(typed.data, typeA=1, typeB=2, r.low=d1, r=d2,
                   comparison.type = "representative") # Equivalent
head(tau, n=4)

# Calculate tau-statistic using dynamic expression indicating serotype homology
ind.func <- function(a, b){
     if (a[5] == 1 & b[5] == 1) { 
          x <- 1
     } else { 
          x <- 2
     }
     return(x) 
}

num <- get.pi(posmat=DengueSimRepresentative, fun=ind.func, r.low=d1, r=d2)
den <- get.pi(posmat=DengueSimRepresentative, fun=ind.func, r.low=0, r=Inf)
head(num$pi/den$pi, n=4)

tau <- get.tau(posmat=DengueSimRepresentative, fun=ind.func, r.low=d1,  r=d2,
               comparison.type="representative") # Equivalent
head(tau, n=4)

par(mfrow=c(1,1))
plot(tau$r, tau$tau, type='l', lwd=2, col='blue', xlab='distance (m)', ylab='tau')
abline(h=1, lty=2, lwd=2, col='red')
abline(v=100)


#################################################################################
# Calculate tau-statistic using serotype homology and time
data(DengueSimR01)
d2 <- seq(20, 1000, 20)
d1 <- d2 - 20

# Dynamic expression indicating serotype homology and temporal proximity
ind.func <- function(a, b, t.limit=20){
     if (a[5] == b[5] & (abs(a[3] - b[3]) <= t.limit)){ 
          x <- 1
     } else { 
          x <- 2
     }
     return(x) 
}

num <- get.theta(DengueSimR01, ind.func, r.low=d1, r=d2)
den <- get.theta(DengueSimR01, ind.func, r.low=0, r=Inf)
head(num$theta/den$theta, n=4)

tau <- get.tau(posmat=DengueSimR01, fun=ind.func, r.low=d1, r=d2,
               comparison.type="independent") # Equivalent
head(tau, n=4)

par(mfrow=c(1,1))
plot(tau$r, tau$tau, type='l', lwd=2, col='blue', xlab='distance (m)', ylab='tau')
abline(h=1, lty=2, lwd=2, col='red')
abline(v=100)


########################################################################
# Calculate variance around point estimates of the tau-statistic
data(DengueSimR02)

d2 <- seq(20, 1000, 20)
d1 <- d2 - 20

# Function indicating genotype homology
ind.func <- function(a, b){
     if(a[4] == b[4]){
          x = 1
     } else{
          x = 2
     }
     return(x)
}

# Bootstrapped estimates of the mean 
tau.boot <- get.tau.bootstrap(DengueSimR02, ind.func, r.low=d1, r=d2, boot.iter=5)
head(tau.boot, n=4)

# Wrapper function of get.tau.bootstrap calculates confidence intervals
tau.ci <- get.tau.ci(DengueSimR02, ind.func, r.low=d1, r=d2, boot.iter=25)
head(tau.ci, n=4)

par(mfrow=c(1,1))
plot(tau.ci$r, tau.ci$pt.est, ylim=range(tau.ci[,4:5]), type="l", lwd=2, col='blue', 
     xlab='distance (m)', ylab='tau')
lines(tau.ci$r, tau.ci$ci.low, lty=2, lwd=1, col='blue')
lines(tau.ci$r, tau.ci$ci.high, lty=2, lwd=1, col='blue')
abline(h=1, lty=2, lwd=2, col='red')


########################################################################################
# Compare tau statistic to its null distribution using permutation
data(DengueSimR02)
set.seed(123)

d2 <- seq(20, 1000, 20)
d1 <- d2 - 20

# Compare spatial dependence by time case occurs
type <- 2 - (DengueSimR02[,"time"] < 120)
typed.data <- cbind(DengueSimR02, type=type)

typed.tau <- get.tau.typed(typed.data, typeA=1, typeB=2, r.low=d1, r=d2,  
                           comparison.type = "independent")

head(typed.tau, n=4)

# Perform permutations of observed case times and locations for null distribution
typed.tau.null <- get.tau.typed.permute(typed.data, typeA=1, typeB=2, r.low=d1, r=d2, 
                                        permutations=100,
                                        comparison.type = "independent")
head(typed.tau.null[,1:7], n=4)

# 95% confidence intervals of null distribution
null.ci <- apply(typed.tau.null[,-(1:2)], 1, quantile, probs=c(0.025, 0.975), data.frame=F)
head(t(null.ci), n=4)

par(mfrow=c(1,1))
plot(typed.tau$r, typed.tau$tau, type='l', lwd=2, ylim=range(c(typed.tau$tau, null.ci)),
     xlab="distance (m)", ylab="tau")
lines(typed.tau$r, null.ci[1,], lty=2)
lines(typed.tau$r, null.ci[2,], lty=2)
abline(h=1, lty=2, lwd=2, col='red')

