## -------------------------------------------------------------------
## Sampling with TBRSS using a concomitant variable
## -------------------------------------------------------------------

##Loading packages
library("RSSampling")
library("LearnBayes")

## Imperfect ranking example for interested (X) and concomitant (Y) variables
## from multivariate normal dist.
set.seed(1)
mu <- c(10,8)
variance<- c(5,3)
a <- matrix(c(1,0.9,0.9,1),2,2)
v <- diag(variance)
Sigma <- v%*%a%*%v
x <- rmnorm(10000, mu, Sigma)
xx <- as.numeric(x[,1])
xy <- as.numeric(x[,2])

## Selecting a truncation-based ranked set sample
con.Rrss(xx, xy, m=4, r=2,type="tb", sets=TRUE, concomitant=FALSE, alpha=0.25)




## -------------------------------------------------------------------
## Obtaining observation number in MRSS method
## -------------------------------------------------------------------

## Loading packages
library("RSSampling")	

## Generating concomitant variable (Y) from Exponential Dist.
set.seed(5)
y = rexp(10000)

## Determining the observation numbers of the units which are chosen to sample
obsno.Mrss(y, m = 3, r = 5, type = "m")



## -------------------------------------------------------------------
## Simulation study
## -------------------------------------------------------------------

## Loading packages
library("RSSampling")
library("LearnBayes")

## Imperfect ranking example for interested (X) and concomitant (Y) variables
## from multivariate normal dist.
mu <- c(10,8)
variance<- c(5,3)
rho=seq(0,0.9,0.1)
se.x = mse.x = numeric()
repeatsize=10000
for (i in 1:length(rho)){
  set.seed(1)
  a <- matrix(c(1,rho[i],rho[i],1),2,2)
  v <- diag(variance)
  Sigma <- v%*%a%*%v
  x <- rmnorm(10000, mu, Sigma)
  xx <- as.numeric(x[,1])
  xy <- as.numeric(x[,2])
  for (j in 1:repeatsize){
    set.seed(j)
    samplex=con.Mrss(xx,xy,m=5,r=10,type="r", sets=FALSE,
                     concomitant=FALSE)$sample.x
    se.x[j]=(mean(samplex)-mu[1])^2
  }
  mse.x[i]=sum(se.x)/repeatsize
}
plot(rho[-1],mse.x[-1],type="o",lwd=2,
     main="MSE values based on increasing correlation levels", xlab= "corr.coef.",
     ylab="MSE",cex=1.5, xaxt="n")
axis(1, at = seq(0.1, 0.9, by = 0.1))	


## -------------------------------------------------------------------
## Real data example
## -------------------------------------------------------------------

## Loading packages
library("RSSampling")
##import data
abaloneData <- read.csv(url("https://archive.ics.uci.edu/ml/machine-learning-databases/abalone/abalone.data"),header=FALSE, 
                        col.names =c("sex", "length", "diameter", "height", "whole.weight", "shucked.weight", "viscera.weight", "shell.weight", "rings"))
##see the correlation between interested and concomitant variable
cor(abaloneData$viscera.weight,abaloneData$whole.weight)
##obtain a sample
set.seed(50)
sampleRSS=con.rss(abaloneData$viscera.weight,abaloneData$whole.weight,m=5,r=5,sets=TRUE,concomitant=FALSE)$sample.x
##mean estimation based on RSS
meanRSS(sampleRSS,m=5,r=5,alpha=0.05,alternative="two.sided",mu_0=0.18)
##variance estimation based on RSS
varRSS(sampleRSS,m=5,r=5,type="Stokes")









