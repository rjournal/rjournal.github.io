# Replication file for: "coxed: An R Package for Computing          #
# Duration Based Quantities from the Cox Proportional Hazards       #
# Model"                                                            #
#                                                                   #
# Jonathan Kropko                                                   #
# University of Virginia                                            #
# jkropko@virginia.edu                                              #
#                                                                   #
# Jeffrey J. Harden                                                 #
# University of Notre Dame                                          #
# jeff.harden@nd.edu                                                #
#                                                                   #
# Martin and Vanberg (2003) replication (GAM approach)              #
# Last update: September 19, 2018                                   #
#####################################################################
## Packages ##
library(coxed)
library(ggplot2)
library(dplyr)

## Load and prepare data ##
data(martinvanberg)
set.seed(2443)

## Model estimation ##
mv.surv <- Surv(martinvanberg$formdur, event = rep(1, nrow(martinvanberg)))
mv.cox <- coxph(mv.surv ~ postel + prevdef + cont + ident + rgovm + pgovno + 
                  tpgovno + minority, data = martinvanberg)

## coxed() function ##
ed <- coxed(mv.cox, method = "gam", bootstrap = TRUE, B = 30)
head(ed$exp.dur)

summary(ed, stat = "mean")
summary(ed, stat = "median")

new.coalitions <- data.frame(postel = c(1, 1, 1, 0, 1),
                             prevdef = c(0, 0, 1, 1, 0),
                             cont = c(1, 0, 1, 0, 1),
                             ident = c(1, 2, 2, 3, 3),
                             rgovm = c(.3, .8, 1.1, .2, .35),
                             pgovno = c(2, 3, 3, 2, 4),
                             tpgovno = c(3.2, 0, 5, 0, 2.6),
                             minority = c(0, 0, 1, 0, 0))
forecast <- coxed(mv.cox, newdata = new.coalitions, method = "gam",
                  bootstrap = TRUE, B = 30)
forecast$exp.dur

## Plot ELP rank against expected duration ##
d.mvlped <- data.frame(rank = 1:nrow(ed$gam.data), x = ed$gam.data$rank.xb, y = ed$gam.data$y, pe = ed$gam.data$gam_fit, lo = ed$gam.data$gam_fit_95lb, hi = ed$gam.data$gam_fit_95ub, failed = ed$gam.data$failed) 

pdf("kropko-harden-figure1.pdf")

ggplot(d.mvlped, aes(x = x, y = y)) + 
  geom_point(shape = 16, position = "identity", color = "black", lwd = 2) +
  geom_line(aes(x = x, y = pe), color = "black", lwd = 1) +
  geom_ribbon(aes(x = x, min = lo, max = hi), alpha = .35) +
  scale_y_continuous(limits = c(-10.2, 220), breaks = seq(0, 220, 20)) +
  scale_x_continuous(breaks = c(max(ed$gam.data$rank.xb), seq(29, 179, 25), min(ed$gam.data$rank.xb)), labels = (nrow(ed$gam.data) + 1) - c(max(ed$gam.data$rank.xb), seq(29, 179, 25), min(ed$gam.data$rank.xb)), minor_breaks = c(15, 42, 67, 92, 117, 141, 166, 191)) +
  theme(legend.position = "none", axis.text = element_text(size = 12), axis.title.y = element_text(size = 14, vjust = 1.5), axis.title.x = element_text(size = 14, vjust = -.1)) + labs(fill = "") +             
  ylab("Duration (days)") + xlab("Cox model ELP rank") 

dev.off()

## First differences ##
me <- coxed(mv.cox, method = "gam", bootstrap = TRUE, B = 30,
            newdata = mutate(martinvanberg, rgovm = 0),
            newdata2 = mutate(martinvanberg, rgovm = 1.24))

summary(me, stat = "mean")
summary(me, stat = "median")







