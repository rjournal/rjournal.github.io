# Load package from github
install.packages("trafo")

# Load needed packages
library(trafo)
library(Ecdat)


# Code in study case -----------------------------------------------------------
# Laod data set: Provision of University Teaching and Research
data(University) 

# Fit the linear model
linMod <- lm(nassets ~ stfees, data = University)


# Fast check for assumptions
assumptions(linMod)


# Get trafo object
linMod_trafo <- trafo_lm(object = linMod)

# Check residuals
diagnostics(linMod_trafo)


# Get residual plots
plot(linMod_trafo)


# Get a trafo_mod object with another transformation and estimation method
linMod_trafo2 <- trafo_lm(object = linMod, trafo = "logshiftopt", 
                          method = "skew")

# Compare the simple log with Box-Cox
boxcox_uni <- boxcox(linMod)
log_uni <- logtrafo(linMod)

# Show the first six rows of the data frame
head(as.data.frame(boxcox_uni))

# Use compare_trafo function
linMod_comp <- trafo_compare(object = linMod,trafos = list(boxcox_uni, log_uni))
diagnostics(linMod_comp)


# Code in extract the transformed model and vector -----------------------------
class(linMod_trafo$trafo_mod)
head(linMod_trafo$trafo_mod$model)

# Code in customized transformation --------------------------------------------

# Define a customized transformation
tukey <- function(y, lambda = lambda) {
  lambda_cases <- function(y, lambda = lambda) {
    lambda_absolute <- abs(lambda)
    if (lambda_absolute <= 1e-12) {  #case lambda=0
      y <- log(y)
    } else {
      y <- y^2
    }
    return(y)
  }
  y <- lambda_cases(y = y, lambda = lambda)
  
  return(y = y)
} # End box_cox


tukey_std <- function(y, lambda) {
  gm <- exp(mean(log(y)))
  if (abs(lambda) > 1e-12) {
    y <- (y^lambda) / (lambda * ((gm)^(lambda - 1)))
  } else {
    y <- gm * log(y)
  }
  return(y)
}

# Insert customized transformation to trafo_lm
linMod_custom <- trafo_lm(linMod, trafo = "custom_one", 
                          lambdarange = c(0, 2),
                          custom_trafo = list(tukey, tukey_std))







