# Jan-Philipp Kolb
# Wed Jan 23 06:20:34 2019
###########################################################
# code chunk 1

library("OpenStreetMap")
map <- openmap(c(52.278174,4.729242),
               c(52.431064,5.079162),
               type="osm")
plot(map)

###########################################################
# code chunk 2

map_stt <- OpenStreetMap::openmap(c(52.385914, 4.874383), c(52.35514, 4.92054),
                                  type = "stamen-toner")
map_st <- OpenStreetMap::openmap(c(52.278174, 4.729242), c(52.431064, 5.079162),
                                 type = "stamen-watercolor")
plot(map_st)
plot(map_stt)

###########################################################
# code chunk 3

library(leaflet)
leaflet() %>%
  addTiles() %>%  
  addMarkers(lng=4.891013, lat=52.38054, popup = "Amsterdam")

###########################################################
# code chunk 4

library("RJSONIO")
con <- url("http://nominatim.openstreetmap.org/search?format=json&addressdetails=1&extratags=1&q=Amsterdam+Niederlande+Rozengracht+1")
geoc <- fromJSON(paste0(readLines(con,warn=F)))
close(con)

###########################################################
# code chunk 5

names(geoc[[1]])

###########################################################
# code chunk 6

geoloc <- c(geoc[[1]][which(names(geoc[[1]])=="lat")],
            geoc[[1]][which(names(geoc[[1]])=="lon")])

###########################################################
# code chunk 7

link <- url("http://nominatim.openstreetmap.org/search?format=json&addressdetails=1&extratags=1&q=Amsterdam+Niederlande+Rozengracht+1")
geoc2 <- jsonlite::fromJSON(link)
geoc2df <- with(geoc2,data.frame(osm_id,lat,lon))
geoc2df$house_number <-  geoc2$address$house_number

###########################################################
# code chunk 8

library("tmaptools")
gc_tma <- geocode_OSM("Amsterdam, Buiten Brouwersstraat")

###########################################################
# code chunk 9

library(sp)
poi <- data.frame(lon=gc_tma$coords["x"],
                  lat=gc_tma$coords["y"])
sp::coordinates(poi) <- c("lat", "lon")
sp::proj4string(poi) <- sp::CRS("+init=epsg:4326")
res <- spTransform(poi, CRS("+init=epsg:3035"))

###########################################################
# code chunk 10

library(sf)
poi2 <- st_sfc (st_point(gc_tma$coords), crs = 4326)
res2 <- st_transform (poi2, crs = 3035)

###########################################################
# code chunk 11

poi <- data.frame(lon=gc_tma$coords["x"],
                  lat=gc_tma$coords["y"])
adm_map <- openproj(map_stt, projection = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
library(ggmap)
autoplot(adm_map) + geom_point(aes(x = lon, y = lat), data = poi,size=5, col="red") 

###########################################################
# code chunk 12

url2 <-"https://www.openstreetmap.org/api/0.6/node/4290854847"
download.file(url2,"4290854847.xml")

###########################################################
# code chunk 13

ghURL2<-"https://www.openstreetmap.org/api/0.6/relation/47811"
download.file(ghURL2,"amsterdam.osm")

###########################################################
# code chunk 14

library(curl)
uac<-"https://api.openstreetmap.org/api/0.6/map?bbox=4.89359,52.37640,4.90589,52.38172"
curl_download(uac,"amsterdamcentraal.osm")
  
###########################################################
# code chunk 15

library(XML)
AM <- xmlParse("amsterdam.osm")

###########################################################
# code chunk 16

xpathApply(AM,"//tag[@k = 'population']")

###########################################################
# code chunk 17

library(sf)
st_layers("amsterdam.osm")

###########################################################
# code chunk 18

points_am <- st_read("amsterdam.osm","points")

###########################################################
# code chunk 19

library(sf)
st_layers("4290854847.xml")

###########################################################
# code chunk 20

centraal <- st_read("4290854847.xml","points")

###########################################################
# code chunk 21

centraal$geometry

###########################################################
# code chunk 22

library(osmdata)
dat_rw <- opq(bbox = 'Amsterdam') %>%
  add_osm_feature(key = 'railway', 
                  value = 'tram_stop') %>%
  osmdata_sf ()

###########################################################
# code chunk 23

library(osmplotr)
bbox <- getbb("Amsterdam")
dat_pa <- extract_osm_objects(key='highway', 
                              value="primary",
                              bbox=bbox)
dat_sa <- extract_osm_objects(key='highway', 
                              value="secondary",
                              bbox=bbox)


###########################################################
# code chunk 24

map <- osm_basemap(bbox = bbox, bg = c("white"))
map <- add_osm_objects(map, dat_pa, col = c("#00008B"))
map <- add_osm_objects(map, dat_sa, col = "green")
# further objects can be added
print_osm_map(map)

###########################################################
# code chunk 25

library(tmap)
qtm(dat_pa$geometry,fill = "#8B1A1A")

###########################################################
# code chunk 26

library(mapview)
mapview(centraal)

###########################################################
# code chunk 27

library(sf)
st_layers("amsterdamcentraal.osm")
am_cen <- st_read("amsterdamcentraal.osm","multipolygons")

###########################################################
# code chunk 28

houses <- am_cen[!is.na(am_cen$building),]
other_tags <- am_cen[!is.na(am_cen$other_tags),]

###########################################################
# code chunk 29

library(tmap)
tm_shape(houses) + tm_fill("royalblue") + tm_shape(other_tags) + tm_borders("gray")

