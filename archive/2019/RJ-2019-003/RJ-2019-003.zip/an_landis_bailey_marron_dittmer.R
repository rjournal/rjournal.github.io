
# -----------------------------------------------------------------------------
### Reproduction material of tables and figures in the manuscript
### "dr4pl: A stable convergence algorithm for the 4 Parameter Logistic model"
### submitted to The R Journal.
###
### Author of this code: Hyowon An
# -----------------------------------------------------------------------------

# ------------------
### Load libraries.
# ------------------
library(drc)
library(dr4pl)
library(ggplot2)
library(gridExtra)
library(plyr)

# --------------------------
### User-defined functions.
# --------------------------

Draw4PLModel <- function(log10.x) {
  # Compute mean response values evaluated at the given log 10 dose levels.
  #
  # Args:
  #   log10.x: Log 10 dose levels
  #
  # Returns:
  #   Mean responses evaluated at the given log 10 dose levels
  
  x <- 10^log10.x
  
  return(parms[1] + (parms[4] - parms[1])/(1 + (x/parms[2])^parms[3]))
}

ErrorForTheta2and3 <- function(theta2.vec, theta3.vec) {
  # Compute the values of the sum-of-squares loss function for given values of
  # the log 10 IC50 and slope parameters while the upper and lower asymptotes are
  # fixed at some values.
  #
  # Args:
  #   theta2.vec: Vector of IC50 parameter values.
  #   theta3.vec: Vector of slope parameter values.
  
  # Need x and y in advance
  n.row <- length(theta2.vec)
  n.col <- length(theta3.vec)
  error.matr <- matrix(data = 0, nrow = n.row, ncol = n.col)
  
  for(i in 1:n.row) {
    
    for(j in 1:n.col) {
      
      theta2 <- theta2.vec[i]
      theta3 <- theta3.vec[j]
      
      f <- theta1 + (theta4 - theta1)/(1 + 10^(theta3*(log10(x) - theta2)))
      error.matr[i, j] <- sum((y - f)^2)/length(y)
    }
  }
  
  return(error.matr)
}

MeanResponse <- function(x, theta) {
  # Compute mean response values evaluated at the given dose levels and parameter
  # values.
  #
  # Args:
  #   log10.x: Log 10 dose levels
  #
  # Returns:
  #   Mean responses evaluated at the given log 10 dose levels

  ### Check whether function arguments are appropriate
  if(any(is.na(theta))) {
    
    stop("One of the parameter values is NA.")
  }
  if(theta[2]<=0) {
    
    stop("An IC50 estimate should always be positive.")
  }
  
  f <- theta[1] + (theta[4] - theta[1])/(1 + (x/theta[2])^theta[3])
  
  return(f)
}

# -------------
### Load data.
# -------------
n.error.case <- 4
data.error.list <- vector("list", n.error.case)

data.error.list[[1]] <- drc_error_1
data.error.list[[2]] <- drc_error_2
data.error.list[[3]] <- drc_error_3
data.error.list[[4]] <- drc_error_4

# ------------
### Figure 1.
# ------------
png(filename = "Figure1.png",
     width = 8, height = 4, units = "in", res = 600)

## Left plot.
par(mar = c(6, 4, 1, 1) + 0.1, mfrow = c(1, 2))
parms = c(100, 0.1, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      main = "",
      xlab = "",
      ylab = "Mean response",
      xaxt = "n",
      yaxt = "n",
      bty = "l",
      lwd = 2,
      col = "red")
legend(x = "topright",
       lwd = 2,
       lty = c(1, 2, 3),
       col = c("red", "magenta", "blue"),
       legend = c(expression(paste(theta[2], "=0.1")),
                  expression(paste(theta[2], "=1")),
                  expression(paste(theta[2], "=10"))),
       bty = "n")
axis(side = 1, at = seq(from = -5, to = 5, by = 1),
     labels = 10^seq(from = -5, to = 5, by = 1),
     las = 2)
axis(side = 2, at = seq(from = 0, to = 100, by = 20),
     labels = c(expression(theta[4]), 20, 40, 60, 80, expression(theta[1])),
     las = 2)
mtext(side = 1, text = "Dose", line = 4)

parms = c(100, 1, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE,
      lty = 2,
      lwd = 2,
      col = "magenta")

parms = c(100, 10, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE,
      lty = 3,
      lwd = 2,
      col = "blue")
abline(h = 0, lty = 2, col = "darkgray")

## Right plot.
parms = c(100, 1, -0.5, 0)
curve(Draw4PLModel, from = -5, to = 5,
      main = "",
      xlab = "",
      ylab = "Mean response",
      ylim = c(0, 100),
      xaxt = "n",
      yaxt = "n",
      bty = "l",
      lwd = 2,
      col = "red")
legend(x = "topright",
       lty = c(1, 2, 3),
       lwd = 2,
       col = c("red", "magenta", "blue"),
       legend = c(expression(paste(theta[3], "=-0.5")),
                  expression(paste(theta[3], "=-1")),
                  expression(paste(theta[3], "=-2"))),
       bty = "n")
axis(side = 1, at = seq(from = -5, to = 5, by = 1),
     labels = 10^seq(from = -5, to = 5, by = 1),
     las = 2)
axis(side = 2, at = seq(from = 0, to = 100, by = 20),
     labels = c(expression(theta[4]), 20, 40, 60, 80, expression(theta[1])),
     las = 2)
mtext(side = 1, text = "Dose", line = 4)

parms = c(100, 1, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE,
      lty = 2,
      lwd = 2,
      col = "magenta")
parms = c(100, 1, -2, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE,
      lty = 3,
      lwd = 2,
      col = "blue")

abline(h = 0, lty = 2, col = "darkgray")

dev.off()

# ------------
### Figure 2.
# ------------
png(filename = "Figure2.png", width = 10, height = 11, units = "in", res = 600)

ggplot.list <- vector("list", 4)

for(i in 1:n.error.case) {
  
  data.error <- data.error.list[[i]]
  x <- data.error$Dose
  y <- data.error$Response
  n <- length(y)
  
  dr4pl.error <- dr4pl(Response ~ Dose,
                       data = data.error,
                       method.robust = "absolute",
                       method.init = "logistic",
                       use.Hessian = TRUE)
  
  theta <- dr4pl.error$parameters
  residuals <- y - MeanResponse(x, theta)
  indices.outlier <- dr4pl.error$idx.outlier
  
  gg <- plot(dr4pl.error,
             type.curve = "data",
             text.title = paste("Error Case", i),
             indices.outlier = indices.outlier)
  gg <- gg + scale_x_log10(breaks = sort(unique(data.error$Dose)),
                           labels = sort(unique(data.error$Dose)))
  gg <- gg + theme(axis.text.x = element_text(angle = 90))
  
  ggplot.list[[i]] <- gg
}

grid.arrange(ggplot.list[[1]], ggplot.list[[2]], ggplot.list[[3]], ggplot.list[[4]],
             nrow = 2, ncol = 2)

dev.off()

# ------------
### Figure 3.
# ------------
png(filename = "Figure3.png",
    width = 10, height = 10, units = "in", res = 600)

par(mfrow = c(2, 2), mar = c(6, 4, 2, 1) + 0.1)

for(i in 1:4) {
  
  data.error <- data.error.list[[i]]
  doses <- data.error$Dose
  responses <- data.error$Response
  
  x <- doses[doses != 0]
  y <- responses[doses != 0]
  
  scale.inc <- 0.001
  y.range <- range(y)
  len.y.range <- scale.inc * diff(y.range)
  
  theta1 <- max(y) + len.y.range
  theta4 <- min(y) - len.y.range
  
  beta0.vec <- seq(from = log10(min(x)), to = log10(max(x)), length = 300)
  beta1.vec <- seq(from = -1, to = 0, length = 300)
  error.matr <- ErrorForTheta2and3(beta0.vec, beta1.vec)
  
  contour(x = beta0.vec,
          y = beta1.vec,
          z = error.matr,
          main = "",
          xlab = "",
          ylab = expression(theta[3]),
          nlevels = 20,
          labcex = 1,
          xaxt = "n",
          bty = "l",
          cex.lab = 1.2)
  
  at.x=seq(from = floor(log10(min(x))), to = ceiling(log10(max(x))), by = 1)
  axis(1, at = at.x, labels = 10^(at.x), las=2)
  
  mtext(text = paste("Error Case ", i), side = 3, line = 1, cex = 1.2)
  mtext(text = expression(theta[2]), side = 1, line = 4)
}

dev.off()

# ------------
### Figure 4.
# ------------

png(filename = "Figure4.png",
    width = 8, height = 4, units = "in", res = 600)

par(mar = c(6, 4, 2, 2) + 0.1, mfrow = c(1, 2))

## Left plot.
parms = c(100, 0.01, -0.5, 0)
curve(Draw4PLModel, from = -5, to = 1,
      main = "Dose response curve",
      xlab = "", 
      ylab = "Mean response",
      ylim = c(0, 120),
      xaxt = "n",
      yaxt = "n",
      bty = "l",
      lwd = 2,
      col = "red")
legend(x = "bottomleft",
       cex = 0.8,
       lwd = 2,
       lty = c(1, 2, 3, 1, 2, 3, 1, 2, 3),
       col = c("red", "red", "red", "magenta", "magenta", "magenta",
               "blue", "blue", "blue"),
       legend = c("Model 1", "Model 2", "Model 3", "Model 4", "Model 5", "Model 6",
                  "Model 7", "Model 8", "Model 9"),
       bty = "n")
axis(side = 1, at = seq(from = -5, to = 1, by = 1),
     labels = 10^seq(from = -5, to = 1, by = 1),
     las = 2)
axis(side = 2, at = seq(from = 0, to = 120, by = 20),
     labels = seq(from = 0, to = 120, by = 20),
     las = 2)
mtext(side = 1, text = "Dose", line = 4)

parms = c(100, 0.01, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, lty = 2, col = "red")
parms = c(100, 0.01, -1.5, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, lty = 3, col = "red")

parms = c(100, 0.1, -0.5, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, col = "magenta")
parms = c(100, 0.1, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, lty = 2, col = "magenta")
parms = c(100, 0.1, -1.5, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, lty = 3, col = "magenta")

parms = c(100, 1, -0.5, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, col = "blue")
parms = c(100, 1, -1, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, lty = 2, col = "blue")
parms = c(100, 1, -1.5, 0)
curve(Draw4PLModel, from = -5, to = 5,
      add = TRUE, lwd = 2, lty = 3, col = "blue")

## Right plot.
levels.dose <- c(0.00001, 0.0001, 0.001, 0.01, 0.1, 1)
parms = c(100, 1, -0.5, 0)
stdev <- 7.5
doses <- rep(levels.dose, each = 5)
responses <- MeanResponse(doses, parms) + rnorm(length(doses), mean = 0, sd = stdev)

plot(x = log10(doses), y = responses,
     xlim = c(-5, 1),
     ylim = c(0, 120),
     pch = 16,
     main = "Example data (Model 7)",
     xlab = "",
     ylab = "Response",
     bty = "l",
     xaxt = "n",
     yaxt = "n")
curve(Draw4PLModel,
      add = TRUE,
      lwd = 2, col = "blue")
axis(side = 1, at = seq(from = -5, to = 1, by = 1),
     labels = 10^seq(from = -5, to = 1, by = 1),
     las = 2)
axis(side = 2, at = seq(from = 0, to = 120, by = 20),
     labels = seq(from = 0, to = 120, by = 20),
     las = 2)
mtext(side = 1, text = "Dose", line = 4)

dev.off()

# ----------------------------------
### Table 1 was not generated by R.
# ----------------------------------

# -----------
### Table 2.
# -----------
stdev <- 5

n.simul <- 1000
n.obs.dose <- 5
n.settings <- 9  # No. of simulation settings

theta.mat <- matrix(c(100, 0.01, -0.5, 0,
                      100, 0.01, -1, 0,
                      100, 0.01, -1.5, 0,
                      100, 0.1, -0.5, 0,
                      100, 0.1, -1, 0,
                      100, 0.1, -1.5, 0,
                      100, 1, -0.5, 0,
                      100, 1, -1, 0,
                      100, 1, -1.5, 0),
                    nrow = n.settings,
                    ncol = 4,
                    byrow = TRUE)
levels.dose <- 10^seq(from = -4, to = 0, by = 1)
n.doses <- length(levels.dose)
n.obs <- n.doses*n.obs.dose

result.mat <- matrix(nrow = n.simul, ncol = n.settings)

for(i in 1:n.simul) {
  
  for(j in 1:n.settings) {
    
    theta <- theta.mat[j, ]
    
    x <- rep(levels.dose, each = n.obs.dose)
    y <- MeanResponse(x, theta) + rnorm(length(x), mean = 0, sd = stdev)
    
    ## Obtain initial parameter estimates.
    theta.init <- FindInitialParms(x, y,
                                   trend = "auto",
                                   method.init = "Mead",
                                   method.robust = NULL)
    
    Hill.bounds <- FindHillBounds(x, y, theta.init)
    
    result.mat[i, j] <- (log10(theta[2]) >= Hill.bounds$LogTheta2[1])&&
      (log10(theta[2]) <= Hill.bounds$LogTheta2[2])&&
      (theta[3] >= Hill.bounds$Theta3[1])&&
      (theta[3] <= Hill.bounds$Theta3[2])
  }
}

results <- rep(0, ncol(result.mat))

for(j in 1:ncol(result.mat)) {
  
  results[j] <- mean(result.mat[!is.na(result.mat[, j]), j])
}

print(matrix(data = 1 - results, nrow = 3, ncol = 3, byrow = TRUE))

# -----------
### Table 3.
# -----------

conf.level <- 0.9999
stdev <- 5

n.simul <- 1000
n.obs.dose <- 5
n.settings <- 9  # No. of simulation settings

theta.mat <- matrix(c(100, 0.01, -0.5, 0,
                      100, 0.01, -1, 0,
                      100, 0.01, -1.5, 0,
                      100, 0.1, -0.5, 0,
                      100, 0.1, -1, 0,
                      100, 0.1, -1.5, 0,
                      100, 1, -0.5, 0,
                      100, 1, -1, 0,
                      100, 1, -1.5, 0),
                    nrow = n.settings,
                    ncol = 4,
                    byrow = TRUE)
levels.dose <- 10^seq(from = -4, to = 0, by = 1)
n.doses <- length(levels.dose)
n.obs <- n.doses*n.obs.dose

result.mat <- matrix(nrow = n.simul, ncol = n.settings)

for(i in 1:n.simul) {
  
  for(j in 1:n.settings) {
    
    theta <- theta.mat[j, ]
    
    x <- rep(levels.dose, each = n.obs.dose)
    y <- MeanResponse(x, theta) + rnorm(length(x), mean = 0, sd = stdev)
    
    data.simul <- data.frame(Dose = x, Response = y)
    
    dr4pl.simul <- dr4pl(Response ~ Dose,
                         data = data.simul)
    
    result.mat[i, j] <- dr4pl.simul$convergence
  }
}

results <- rep(0, ncol(result.mat))

for(j in 1:ncol(result.mat)) {
  
  results[j] <- mean(result.mat[!is.na(result.mat[, j]), j])
  
}

matrix(data = 1 - results, nrow = 3, ncol = 3, byrow = TRUE)

# ------------
### Figure 5.
# ------------

squared.loss <- function(r) {
  return(r^2)
}

absolute.loss <- function(r) {
  return(abs(r))
}

huber.loss <- function(r) {
  # Values of Huber's loss function evaluated at residuals r.
  #
  # Args:
  #   r: Residuals
  #
  # Returns:
  #   result: Huber's loss function values evaluated at residuals r.
  const <- 1.345  # This value should be chosen in an adaptive fashion.
  
  ret.val <- r^2  # Vector of results
  outer.term <- 2*const*abs(r) - const^2
  
  outer.idx <- abs(r) > const
  
  ret.val[outer.idx] <- outer.term[outer.idx]
  
  return(ret.val)
}

tukey.biweight.loss <- function(r) {
  # Values of Tukey's biweight loss function evaluated at residuals r.
  #
  # Args:
  #   r: Residuals
  #
  # Returns:
  #   result: Tukey's biweight loss function values evaluated at residuals r.
  const <- 4.685
  
  ret.val <- (r^6)/(const^4) - 3*(r^4)/(const^2) + 3*r^2
  
  ret.val[abs(r) > const] <- const^2
  
  return(ret.val)
}

png(filename = "Figure5.png",
    width = 6, height = 4, units = "in", res = 600)

par(mar = c(4, 4, 3, 1) + 0.1, mfrow = c(1, 1))

plot(squared.loss,
     xlim = c(-10, 10),
     ylim = c(0, 25),
     xlab = "Residual",
     ylab = "Loss value",
     main = "Robust methods",
     bty = "l",
     lwd = 2)
curve(absolute.loss, add = TRUE, lwd = 2, col = "blue")
curve(huber.loss, add = TRUE, lwd = 2, col = "red", lty = 2)
curve(tukey.biweight.loss, add = TRUE, lwd = 2, col = "darkgreen", lty = 2)
legend(x = "bottomright", legend = c("Squared", "Absolute", "Huber", "Biweight"),
       lty = c(1, 1, 2, 2),
       lwd = c(2, 2, 2, 2),
       cex = 0.8,
       col = c("black", "blue", "red", "darkgreen"),
       bg = "white")

dev.off()

# ------------
### Figure 6.
# ------------

png(filename = "Figure6.png", width = 10, height = 11, units = "in", res = 600)

ggplot.list <- vector("list", 4)

for(i in 1:n.error.case) {

  data.error <- data.error.list[[i]]
  x <- data.error$Dose
  y <- data.error$Response
  n <- length(y)
  
  dr4pl.error <- dr4pl(Response ~ Dose,
                       data = data.error,
                       method.init = "logistic",
                       method.robust = "absolute",
                       use.Hessian = TRUE)
  
  theta <- dr4pl.error$parameters
  residuals <- y - MeanResponse(x, theta)
  indices.outlier <- dr4pl.error$idx.outlier
  
  gg <- dr4pl.error$robust.plot
  gg <- gg + labs(title = paste("Error Case", i))
  gg <- gg + scale_x_log10(breaks = sort(unique(data.error$Dose)),
                           labels = sort(unique(data.error$Dose)))
  gg <- gg + theme(axis.text.x = element_text(angle = 90))
  
  ggplot.list[[i]] <- gg
}

grid.arrange(ggplot.list[[1]], ggplot.list[[2]], ggplot.list[[3]], ggplot.list[[4]],
             nrow = 2, ncol = 2)

dev.off()

# -----------
### Table 4.
# -----------

stdev <- 5

n.simul <- 1000
n.obs.dose <- 5
n.settings <- 9  # No. of simulation settings

theta.mat <- matrix(c(100, 0.01, -0.5, 0,
                      100, 0.01, -1, 0,
                      100, 0.01, -1.5, 0,
                      100, 0.1, -0.5, 0,
                      100, 0.1, -1, 0,
                      100, 0.1, -1.5, 0,
                      100, 1, -0.5, 0,
                      100, 1, -1, 0,
                      100, 1, -1.5, 0),
                    nrow = n.settings,
                    ncol = 4,
                    byrow = TRUE)
levels.dose <- 10^seq(from = -4, to = 0, by = 1)
n.doses <- length(levels.dose)
n.obs <- n.doses*n.obs.dose

cnts.win.logistic <- rep(0, n.settings)
cnts.win.Mead <- rep(0, n.settings)

for(i in 1:n.simul) {
  
  for(j in 1:n.settings) {
    
    theta <- theta.mat[j, ]
    
    x <- rep(levels.dose, each = n.obs.dose)
    y <- MeanResponse(x, theta) + rnorm(length(x), mean = 0, sd = stdev)
    
    data.dr4pl <- data.frame(Dose = x, Response = y)

    # theta.logistic <- FindInitialParms(x = data.dr4pl$Dose,
    #                                    y = data.dr4pl$Response,
    #                                    method.init = "logistic")
    # theta.Mead <- FindInitialParms(x = data.dr4pl$Dose,
    #                                y = data.dr4pl$Response,
    #                                method.init = "Mead")
        
    dr4pl.logistic <- dr4pl(formula = Response ~ Dose,
                            data = data.dr4pl,
                            method.init = "logistic",
                            use.Hessian = TRUE)
    loss.logistic <- dr4pl.logistic$loss.value
    dr4pl.Mead <- dr4pl(formula = Response ~ Dose,
                        data = data.dr4pl,
                        method.init = "Mead",
                        use.Hessian = TRUE)
    loss.Mead <- dr4pl.Mead$loss.value
    
    # plot(x = log10(data.dr4pl$Dose), y = data.dr4pl$Response, pch = 16)
    # parms <- dr4pl.logistic$parameters
    # curve(Draw4PLModel, add = TRUE, col = "red", lwd = 2)
    # parms <- dr4pl.Mead$parameters
    # curve(Draw4PLModel, add = TRUE, col = "blue", lwd = 2, lty = 2)
    # legend(x = "bottomleft",
    #        lty = c(1, 2),
    #        lwd = 2,
    #        col = c("red", "blue"),
    #        legend = c(paste("logistic =",loss.logistic),
    #                   paste("Mead =",loss.Mead)))
    
    cnts.win.logistic[j] <- cnts.win.logistic[j] + as.numeric(loss.logistic<loss.Mead)
    cnts.win.Mead[j] <- cnts.win.Mead[j] + as.numeric(loss.logistic>loss.Mead)
  }
}

print(matrix(data = cnts.win.Mead, nrow = 3, ncol = 3, byrow = TRUE))
print(matrix(data = cnts.win.logistic, nrow = 3, ncol = 3, byrow = TRUE))

# ------------
### Figure 7.
# ------------

png(filename = "Figure7.png", width = 10, height = 5, units = "in", res = 600)

dr4pl.logistic.5 <- dr4pl(Response~Dose,
                          data = sample_data_5,
                          method.init = "logistic")
ggplot.logistic <- plot(dr4pl.logistic.5, text.title = "Logistic method")

dr4pl.Mead.5 <- dr4pl(Response~Dose,
                      data = sample_data_5)
ggplot.Mead <- plot(dr4pl.Mead.5, text.title = "Mead's method")

grid.arrange(ggplot.logistic, ggplot.Mead, nrow = 1, ncol = 2)

dev.off()