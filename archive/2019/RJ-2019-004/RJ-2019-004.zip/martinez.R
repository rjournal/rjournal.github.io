# Installing and loading the package
install.packages("tsfknn")
library(tsfknn)

# Consulting the examples of a KNN model
timeS <- window(nottem, end = c(1930, 12))
pred <- knn_forecasting(timeS, h = 1, lags = 1:12, k = 2)
head(knn_examples(pred))

# Consulting (and plotting) the prediction
pred$prediction
plot(pred)

# Consulting (and plotting) the nearest neighbors used in a prediction
nearest_neighbors(pred)
library(ggplot2)
autoplot(pred, highlight = "neighbors", faceting = FALSE)

# MIMO strategy for multi-step ahead forecasting
timeS <- window(UKDriverDeaths, end = c(1979, 12))
pred <- knn_forecasting(timeS, h = 12, lags = 1:12, k = 2, msas = "MIMO")
autoplot(pred, highlight = "neighbors", faceting = FALSE)

# Recursive or iterative strategy for multi-step ahead forecasting
pred <- knn_forecasting(USAccDeaths, h = 2, lags = 1:12, k = 2, msas = "recursive")
autoplot(pred, highlight = "neighbors", faceting = FALSE)

# Combining several models with different k parameters
pred <- knn_forecasting(ldeaths, h = 12, lags = 1:12, k = c(2, 4))
pred$prediction

# Assessing forecast accuracy (without rolling origin evaluation)
pred <- knn_forecasting(ldeaths, h = 12, lags = 1:12, k = 2)
ro <- rolling_origin(pred, h = 6, rolling = FALSE)
print(ro$test_sets)
print(ro$predictions)
print(ro$errors)
ro$global_accu
plot(ro)

# Assessing forecast accuracy (with rolling origin evaluation)
pred <- knn_forecasting(ldeaths, h = 12, lags = 1:12, k = 2)
ro <- rolling_origin(pred, h = 6)
print(ro$test_sets)
print(ro$predictions)
print(ro$errors)
ro$global_accu
ro$h_accu
plot(ro, h = 2)

