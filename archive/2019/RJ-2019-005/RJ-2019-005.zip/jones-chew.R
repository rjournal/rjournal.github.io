# I, Kasey Jones, give permission for the reproduction of examples used in this
# paper. Datasets are avaialble in the rollmatch CRAN package. 


# Example Number 1 - Straight from the Paper
library(rollmatch)
data(package="rollmatch", "rem_synthdata_small")
# Function #1: Reduce data
reduced_data <- reduce_data(data = rem_synthdata_small, treat = "treat",
                            tm = "quarter", entry = "entry_q",
                            id = "indiv_id", lookback = 1)
fm <- as.formula(treat ~ qtr_pmt + yr_pmt + age)
vars <- all.vars(fm)
# Function #2: Score Data - Create propensity score column
scored_data <- score_data(model_type = "logistic", match_on = "logit", fm = fm,
                          reduced_data = reduced_data, treat = "treat",
                          tm = "quarter", entry = "entry_q", id = "indiv_id")
# FUnction #3: Run the rolling entry matching algorithm 
output <- rollmatch(scored_data, data=rem_synthdata_small, treat = "treat",
                    tm = "quarter", entry = "entry_q", id = "indiv_id",
                    vars = vars, lookback = 1, alpha = .2,
                    standard_deviation = "average", num_matches = 3,
                    replacement = TRUE)



# Example Number 2. This can only be ran using the utility functions from the 
# rollmatch package
formula <- as.formula(treat ~ qtr_pmt + yr_pmt + age)
vars <- all.vars(formula)
treat <- "treat"
tm = 'quarter'
entry = 'entry_q'
id = 'indiv_id'
lookback = 1
match_on = 'logit'
model_type = 'logistic'


reduced_data <- reduce_data(data = rem_synthdata_small, treat = treat,
                            tm = tm, entry = entry,
                            id = id, lookback = lookback)
# Convert Columns to Factor
reduced_data <- change_to_factor(reduced_data, vars)

scored_data <- score_data(model_type = model_type, match_on = match_on, fm = fm,
                          reduced_data = reduced_data, treat = treat,
                          tm = tm, entry = entry, id = id)
comparison_pool <- compare_pool(scored_data, treat = treat,
                                tm = tm, entry = entry,
                                id = id)


(var_treat <- var(scored_data[(scored_data$treat == 1), "score"]))
(var_untreat <- var(scored_data[(scored_data$treat == 0), "score"]))
# Average
(apsd <- sqrt( (var_treat + var_untreat) / 2))
# Weighted
(wpsd <-
    sqrt(( (nrow(scored_data[(scored_data$treat == 1), ]) - 1) * var_treat +
             (nrow(scored_data[(scored_data$treat == 0), ]) - 1) * var_untreat) /
           (dim(scored_data)[1] - 2)))

# Alpha .2
dim(trim_pool(alpha = .2, comparison_pool, scored_data, treat, 'average'))
dim(trim_pool(alpha = .2, comparison_pool, scored_data, treat, 'weighted'))

# Alpha .6
dim(trim_pool(alpha = .6, comparison_pool, scored_data, treat, 'average'))
dim(trim_pool(alpha = .6, comparison_pool, scored_data, treat, 'weighted'))

# Alpha 1.0 
dim(trim_pool(alpha = 1, comparison_pool, scored_data, treat, 'average'))
dim(trim_pool(alpha = 1, comparison_pool, scored_data, treat, 'weighted'))


