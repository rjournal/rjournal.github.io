
# -------------------------------------------------------
# R script with the source code of the manuscript:
#        The welchADF Package for Robust Hypothesis Testing in Unbalanced
#        Multivariate Mixed Models with Heteroscedastic and Non-normal Data
# by Pablo J. Villacorta, University of Granada - <pjvi@decsai.ugr.es>
#
# submitted to The R Journal on 2017-04-23
# -------------------------------------------------------

library(welchADF)

# -------------------------------------------------------
# Case study #1 (page 9) 
# Univariate one-way between-subject design
# -------------------------------------------------------
str(perceptionData)
omnibus_LSM <- welchADF.test(perceptionData, response = "y", between.s = "Group")
omnibus_trimmed <- update(omnibus_LSM, trimming = TRUE)
omnibus_trimmed_boot <- update(omnibus_trimmed, bootstrap = TRUE, seed = 12345)

pairwise_LSM <- welchADF.test(y ~ Group, data = perceptionData, effect = "Group", contrast = "all.pairwise")
pairwise_trimmed <- update(pairwise_LSM, trimming = TRUE, effect.size = TRUE)
pairwise_trimmed_boot <- update(pairwise_trimmed, bootstrap = TRUE, seed = 12345)

summary(omnibus_LSM, verbose = TRUE)
str(pairwise_trimmed)
summary(pairwise_trimmed)
confint(pairwise_trimmed)

# -------------------------------------------------------
# Case study #2 (page 10)
# Two-way factorial (between-subjects) design
# -------------------------------------------------------
str(womenStereotypeData)
omnibus_LSM <- welchADF.test(womenStereotypeData, response = "y", between.s = c("condition", "sex"), 
                            contrast = "omnibus")
omnibus_trimmed <- update(omnibus_LSM, trimming = TRUE)
pairwise_LSM <- welchADF.test(y ~ condition*sex, data = womenStereotypeData, contrast = "all.pairwise", effect = c("condition", "sex"))
pairwise_trimmed <- update(pairwise_LSM, trimming = TRUE)
pairwise_trimmed_boot <- update(pairwise_trimmed, bootstrap = TRUE, seed = 12345)

summary(omnibus_LSM)
summary(omnibus_trimmed)
summary(pairwise_trimmed)
summary(pairwise_trimmed_boot)

# -------------------------------------------------------
# Case study #3 (page 11)
# Multivariate (mixed) between- x within-subjects design
# -------------------------------------------------------
str(adhdData)
str(adhdData2)
omnibus_LSM_mixed_implicit <- welchADF.test(adhdData, response = c("TargetAlone", "Congruent", "Neutral", "Incongruent"), 
                                  within.s = "multivariate", between.s = "Group", contrast = "omnibus")
omnibus_LSM_multi_oneway <- welchADF.test(cbind(TargetAlone, Congruent, Neutral, Incongruent) ~ Group, data = adhdData)
omnibus_LSM_mixed <- welchADF.test(adhdData2, response = "Milliseconds", between.s = "Group", 
                             within.s = "Stimulus", subject = "Subject", contrast = "omnibus")
omnibus_LSM_mixed_formula <- welchADF.test(Milliseconds ~ Group*Stimulus + (Stimulus|Subject), data = adhdData2)
omnibus_trimmed_formula <- update(omnibus_LSM_mixed_formula, trimming = TRUE)
omnibus_trimmed_boot <- update(omnibus_trimmed_formula, bootstrap = TRUE, seed = 12345)

summary(omnibus_LSM_mixed_implicit)
summary(omnibus_LSM_multi_oneway)

pairwise_trimmed_formula <- update(omnibus_trimmed_formula, contrast = "all.pairwise", effect = "Stimulus")
pairwise_trimmed_formula_boot <- update(pairwise_trimmed_formula, bootstrap = TRUE, seed = 123456)

summary(pairwise_trimmed_formula_boot)

# -------------------------------------------------------
# Case study #4 (page 13)
# Doubly multivariate design
# -------------------------------------------------------
head(miceData)
omnibus_LSM <- welchADF.test(miceData, response = c("visits", "time", "latency"), 
                              between.s = "nurs", within.s = "tunnel", subject = "Subject", contrast = "omnibus")

omnibus_LSM_formula <- welchADF.test(cbind(visits, time, latency) ~ nurs*tunnel + (tunnel | Subject), data = miceData)

pairwise_LSM_nurs <- update(omnibus_LSM_formula, effect = "nurs", contrast = "all.pairwise")
pairwise_LSM_tunnel <- update(pairwise_LSM_nurs, effect = "tunnel")
pairwise_LSM_nurstunnel <- update(pairwise_LSM_nurs, effect = c("nurs", "tunnel"))
pairwise_tunnel_trimmed <- update(pairwise_LSM_tunnel, trimming = TRUE)
pairwise_nurs_trimmed <- update(pairwise_LSM_nurs, trimming = TRUE)

pairwise_nurs_trimmed_boot <- update(pairwise_nurs_trimmed, bootstrap = TRUE, seed = 123)
pairwise_tunnel_trimmed_boot <- update(pairwise_nurs_trimmed_boot, effect = "tunnel")
