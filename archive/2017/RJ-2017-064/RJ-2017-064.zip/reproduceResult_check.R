library(carx)
library(xts)


arOrder <- 3

s1 <- logP ~ logQ
s2 <- logP ~ tInMonth + logQ
s3 <- logP ~ logQ:as.factor(season)
s4 <- logP ~ tInMonth + logQ:as.factor(season)
s5 <- logP ~ as.factor(season) + logQ - 1
s6 <- logP ~ tInMonth + as.factor(season) + logQ - 1
s7 <- logP ~ as.factor(season) + logQ:as.factor(season) - 1
s8 <- logP ~ tInMonth + as.factor(season) +  logQ:as.factor(season) - 1
fmls <- c(s1,s2,s3,s4,s5,s6,s7,s8)
names(fmls) <- paste0('M',seq(1,8))


#check why the result in carxSelect is different
#m4ar2 <- carx(s4,data = pts['1998/2012'],p=2)

#m5ar2 <- carx(s5,data= pts['1998/2012'],p=2)
#m5ar2out <- outlier(m5ar2)
#summary(m5ar2out)

#m6ar2 <- carx(s6,data = pts['1998/2012'],p=2)
#summary(m6ar2)
#m6ar2out <- outlier(m6ar2)
#summary(m6ar2out)

#pts2 = pts['1998/2012']
#m6ar3 <- carx(logP ~ tInMonth + as.factor(season) + logQ - 1,data = pts2,p=3)
#summary(m6ar3)
#m6ar3out <- outlier(m6ar3)
#summary(m6ar3out)
############end check


nRep = 100
cs0 <- carxSelect(fmls, arOrder, data = pts['1998/2012'], detect.outlier = TRUE, CI.compute = F)
print(cs0$selectionInfo$aicMat)
for(i in 1:nRep)
{
  message("Iter: ",i)
  cs <- carxSelect(fmls, arOrder, data = pts['1998/2012'], detect.outlier = TRUE, CI.compute = F)
  if(any(cs$selectionInfo$aicMat!=cs0$selectionInfo$aicMat))
  {
    message("results different at iteration: i",i)
    print(cs$selectionInfo$aicMat)
  }
}
