# creating boxplots for all table type with noise=0  and noise = 0.5 
# Plotting density graphs of log p.values for all pattern types of simulate.tables
# creats discrete.patterns
# created by: Ruby Sharma and Dr. Joe Song
# Date : Februrary 28 2017


pkgs <- c("FunChisq", "ggplot2", "plyr")
for(pkg in pkgs) {
  if(! pkg %in% rownames(installed.packages())) {
    install.packages(pkg)
  }
  require(pkg, character.only = TRUE, quietly = TRUE)
}

performance=function(
  nrow = 5, ncol =5, 
  types = c("functional", "dependent.non.functional", 
            "many.to.one", "independent"), 
  names = c("Functional", "Non-functional", 
            "Many-to-one", "Independent"),
  n.sam=c(100,500,1000,10000), 
  noise1 = 0, noise2 = 0.5, iter = 100
)
{
  cat("\tsample size =", n.sam, "iternations =", iter, "...\n")
  
  for(i in seq_along(types)) {
    
    name <- names[i]
    type <- types[i]
    
    cat("\t\t", name, "\n")
    cat("\t\t\tnoise =", noise1, "...\n")
    
    obtain.time(nrow, ncol, type, n.sam, noise1, iter)
    
    cat("\t\t\tnoise =", noise2, "...\n")
    
    obtain.time(nrow, ncol, type, n.sam, noise2, iter)
  }
  
  pdf(paste("performance.pdf"), width=5.125, height=5.125)
  
  for(i in seq_along(types)) {
    plotfun(types[i], noise1, n.sam, iter, names[i])
    plotfun(types[i], noise2, n.sam, iter, names[i])
  }
  
  dev.off() 
  
  file.remove("functional0.txt", "functional0.5.txt", 
              "dependent.non.functional0.txt", 
              "dependent.non.functional0.5.txt")
  file.remove("many.to.one0.txt", "many.to.one0.5.txt", 
              "independent0.txt", "independent0.5.txt")
}


plotfun =function(type, noise, n.sam, iter, name)
{ 
  
  data1=read.table(file=paste(type,noise,".txt",sep=""),sep = ",",stringsAsFactors = FALSE)
  data2=data.frame(stack(data1[,1:length(n.sam)]))
  data2[,2]=c(rep(n.sam[1],iter),rep(n.sam[2],iter),rep(n.sam[3],iter),rep(n.sam[4],iter))
  colnames(data2)=c("time", "samples")
  data2[,2]=as.factor(data2[,2])
  
  
  p=ggplot2::ggplot(data=data2,mapping=ggplot2::aes(x=samples,y=time*1000, fill = samples)) + 
    ggplot2::labs(x="Sample size n", y = "Runtime (millisec)") + 
    ggplot2::geom_jitter(shape=16, position=ggplot2::position_jitter(0.3)) +ggplot2::geom_boxplot()+
    ggplot2::theme(text = ggplot2::element_text(size=20),
                   plot.margin = ggplot2::unit(c(.5,.5,.5,.5),"cm"), 
                   axis.line = ggplot2::element_line(colour = "black"),
                   title = ggplot2::element_text(size=20,face = "bold"), 
                   plot.title = ggplot2::element_text(hjust=0.5),
                   axis.title.x = ggplot2::element_text(size=25,face="bold"),
                   axis.title.y = ggplot2::element_text(size=25,face="bold"),
                   axis.text = ggplot2::element_text(size=20,face = "bold"),
                   legend.position="none"
                   #legend.key.size  = ggplot2::unit(1.3,"cm"),
                   #legend.text = ggplot2::element_text(size=21,face = "bold"),
                   #legend.background = ggplot2::element_blank(), 
    )+
    ggplot2::labs(title=paste(name," (Noise: ",noise,")", sep=""))
  plot(p)
  
  
}


obtain.time=function(nrow,ncol,type,n.sam, noise,iter)
{
  eval = as.data.frame(matrix(nrow=iter,ncol=length(n.sam)))
  colnames(eval)=n.sam
  for (j  in 1:length(n.sam))
  {
    n=n.sam[j]
    for (i in  1:iter)
    {
      t = system.time(simulate_tables(nrow=nrow,ncol=ncol,type=type,n=n, noise=noise))
      eval[i,j]= sum(t[1], t[4], na.rm = TRUE)
    }
  }
  
  write.table(eval,file=paste(type,noise,".txt",sep = ""),sep = ",")
}


generate_density=function(
  type1="functional", type2="dependent.non.functional", 
  type3="many.to.one", type4="independent", 
  n.tab=1000, noise=0.1
)                                                            
{
  # calling function to get random dimensions
  dim.matrix= get_dim(n.tab) 
  
  predictsfun <- list()
  predictsnon.fun <- list()
  predictsmono <- list()
  predictsindep <- list()
  
  cat("\tSimulating tables ...\n")
  for(i in 1:n.tab)
  {   
    cat(i, " / ", n.tab, "\r")
    nr = dim.matrix[i,1]
    nc = dim.matrix[i,2]
    sam = dim.matrix[i,3]
    
    # setting seed 
    set.seed((nr+nc+sam)*i)
    table = simulate_tables(n = sam, type = type1, nrow = nr , ncol = nc, noise = noise)
    predictsfun[[i]] = table$noise.list[[1]]
    
    set.seed((nr+nc+sam)*i)
    table = simulate_tables(n = sam, type = type2, nrow = nr , ncol = nc, noise = noise)
    predictsnon.fun[[i]] = table$noise.list[[1]]
    
    set.seed((nr+nc+sam)*i)
    table = simulate_tables(n = sam, type = type3, nrow = nr , ncol = nc, noise = noise)
    predictsmono[[i]] = table$noise.list[[1]]
    
    set.seed((nr+nc+sam)*i)
    table= simulate_tables(n = sam, type = type4,  nrow = nr , ncol = nc, noise = noise)
    predictsindep[[i]] = table$noise.list[[1]]
  }
  
  cat("\tPerforming hypothesis testing ...\n")
  # function call for getting p.values of generated tables
  get.pval(predictsfun, predictsnon.fun, predictsmono, predictsindep, n.tab)
  
}


get.pval = function(predictsfun, predictsnon.fun, predictsmono, predictsindep, n.tab)
{
  
  fun.tables.funchi <- c()
  fun.tables.chi <- c()
  non.fun.tables.funchi <- c()
  non.fun.tables.chi <- c()
  non.mono.tables.funchi <- c()
  mono.tables.funchi <- c()
  indep.tables.chi <- c()
  indep.tables.funchi <- c()
  
  for(i in 1:n.tab)
  {
    cat(i, " / ", n.tab, "\r")
    
    table =  remo_whole0_col_row(as.data.frame(predictsfun[[i]]))
    results = fun.chisq.test(table)
    Xsquare = results$statistic
    df = prod(dim(predictsfun[[i]])-1) 
    fun.tables.funchi[i] = (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    results = chisq.test(table) 
    Xsquare = results$statistic
    fun.tables.chi[i] = (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    
    
    table = remo_whole0_col_row(as.data.frame(predictsnon.fun[[i]]))
    results = fun.chisq.test(table)
    Xsquare = results$statistic
    df = prod(dim(predictsnon.fun[[i]])-1) 
    non.fun.tables.funchi[i] = (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    results = chisq.test(table) 
    Xsquare = results$statistic
    non.fun.tables.chi[i] = (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    
    
    table = remo_whole0_col_row(as.data.frame(predictsmono[[i]]))
    results = fun.chisq.test(table)
    Xsquare = results$statistic
    df = prod(dim(predictsmono[[i]])-1)
    non.mono.tables.funchi[i] = (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    results = fun.chisq.test(t(table))
    Xsquare = results$statistic
    mono.tables.funchi[i] = (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    
    
    table = remo_whole0_col_row(as.data.frame(predictsindep[[i]]))
    results =  chisq.test(table) 
    Xsquare = results$statistic
    df = prod(dim(predictsindep[[i]])-1)
    indep.tables.chi[i] =  (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
    results = fun.chisq.test(table)
    Xsquare = results$statistic
    indep.tables.funchi[i] =  (pchisq(Xsquare, df , lower.tail=F, log.p = TRUE))
  }
  all.pval= as.data.frame(matrix(nrow = n.tab, ncol=8))
  all.pval[,1] = fun.tables.funchi
  all.pval[,2] = fun.tables.chi
  all.pval[,3] = non.fun.tables.funchi
  all.pval[,4] = non.fun.tables.chi
  all.pval[,5] = non.mono.tables.funchi
  all.pval[,6] = mono.tables.funchi
  all.pval[,7] = indep.tables.funchi
  all.pval[,8] = indep.tables.chi
  
  plotting(all.pval)
  
}


plotting=function(p.val)
{
  pdf(paste("density_plots.pdf"), width=6, height=6)
  colnames(p.val)=c("FunChisq", "Pearson's Chi-square","FunChisq", "Pearson's Chi-square",
                    "FunChisq", "Inverse FunChisq","FunChisq", "Pearson's Chi-square")
  
  lg.pos <- c(0.35, 0.75) # c(1-0.618, 0.618) # c(.4, .6)
  
  h=data.frame(stack(p.val[,1:2]))
  colnames(h)=c("p.val","Methods")
  cdat <- ddply(h, "Methods", summarise, p.val.mean=mean(p.val))
  
  p=ggplot(data=h, aes(x=p.val, fill=Methods)) + 
    geom_density(alpha=.3)+
    geom_vline(data=cdat, aes(xintercept=p.val.mean,colour=Methods),linetype="solid", size=1)+
    theme(legend.title = element_blank(), legend.position = lg.pos, legend.text = element_text(size=15,face = "bold"),
          legend.background = element_blank(), plot.margin = unit(c(1,1,1,1),"cm"), axis.line = element_line(colour = "black"),
          legend.key.size  = unit(1.3,"cm"),title = element_text(size=15,face = "bold"), plot.title = element_text(hjust=0.5),
          axis.title.x = element_text(size=15,face="bold"),
          axis.title.y = element_text(size=15,face="bold"),
          axis.text = element_text(size=15,face = "bold"))+
    labs(title="Functional Patterns")+
    labs(x="Log p-values", y="Density")
  plot(p)
  
  
  
  h=data.frame(stack(p.val[,3:4]))
  colnames(h)=c("p.val","methods")
  cdat <- ddply(h, "methods", summarise, p.val.mean=mean(p.val))
  p=ggplot(data=h, aes(x=p.val, fill=methods)) + 
    geom_density(alpha=.3)+
    geom_vline(data=cdat, aes(xintercept=p.val.mean, colour=methods),linetype="solid", size=1)+ 
    theme(legend.position = lg.pos,legend.text = element_text(size=15,face = "bold"),
          legend.background = element_blank(), plot.margin = unit(c(1,1,1,1),"cm"), axis.line = element_line(colour = "black"),
          legend.title = element_blank(), legend.key.size  = unit(1.3,"cm"),
          title = element_text(size=15,face = "bold"), plot.title = element_text(hjust=0.5),
          axis.title.x = element_text(size=15,face="bold"),
          axis.title.y = element_text(size=15,face="bold"),
          axis.text = element_text(size=15,face = "bold"))+
    labs(title="Non-functional Patterns") +
    labs(x="Log p-values", y="Density")
  plot(p)
  
  
  
  h=data.frame(stack(p.val[,c(5,6)]))
  colnames(h)=c("p.val","methods")
  cdat <- ddply(h, "methods", summarise, p.val.mean=mean(p.val))
  p=ggplot(data=h, aes(x=p.val, fill= methods)) + 
    geom_density(alpha=.3)+
    geom_density(alpha=.3)+
    geom_vline(data=cdat, aes(xintercept=p.val.mean,colour=methods),linetype="solid", size=1)+ 
    theme(legend.position = lg.pos,legend.text = element_text(size=15,face = "bold"),
          legend.background = element_blank(), plot.margin = unit(c(1,1,1,1),"cm"), axis.line = element_line(colour = "black"),
          legend.title = element_blank(), legend.key.size  = unit(1.3,"cm"),title = element_text(size=15,face = "bold"), plot.title = element_text(hjust=0.5),
          axis.title.x = element_text(size=15,face="bold"),axis.title.y = element_text(size=15,face="bold"),axis.text = element_text(size=15,face = "bold"))+
    labs(title="Many-to-one Patterns") +
    labs(x="Log  p-values", y="Density")
  plot(p)
  
  
  h=data.frame(stack(p.val[,7:8]))
  colnames(h)=c("p.val","methods")
  cdat <- ddply(h, "methods", summarise, p.val.mean=mean(p.val))
  p= ggplot(data=h, aes(x=p.val, fill=methods)) + 
    geom_density(alpha=.3)+
    geom_density(alpha=.3)+
    geom_vline(data=cdat, aes(xintercept=p.val.mean, colour= methods),linetype = c("solid", "dashed"), size=c(1,1))+ 
    theme(legend.position = lg.pos,legend.text = element_text(size=15,face = "bold"),
          legend.background = element_blank(), plot.margin = unit(c(1,1,1,1),"cm"), axis.line = element_line(colour = "black"),
          legend.title = element_blank(), legend.key.size  = unit(1.3,"cm"),title = element_text(size=15,face = "bold"), plot.title = element_text(hjust=0.5),
          axis.title.x = element_text(size=15,face="bold"),axis.title.y = element_text(size=15,face="bold"),axis.text = element_text(size=15,face = "bold"))+
    labs(title="Independent Patterns") +
    labs(x="Log  p-values", y="Density")
  
  plot(p)
  dev.off()
  
}

get_dim = function(n.tab)
{
  nr.vec <- c()
  nc.vec <- c()
  sam.vec <- c()
  for(i in 1:n.tab)
  {   
    nr = sample(3:10,1)
    nc = sample(3:10,1)
    sam = sample(10:1000,1)
    
    if(sam< nr*nc)
    {
      sam = nr*nc
    }
    nr.vec = c(nr, nr.vec)
    nc.vec = c(nc, nc.vec)
    sam.vec = c(sam, sam.vec)
  }
  dim.matrix = as.data.frame(matrix(nrow = n.tab,ncol = 3))
  colnames(dim.matrix) = c("nrow", "ncol", "sample.size")
  dim.matrix[,1] = nr.vec
  dim.matrix[,2] = nc.vec
  dim.matrix[,3] = sam.vec
  return(dim.matrix)
  
}


remo_whole0_col_row=function(table)
{
  c_indeces=which((apply(table,2,sum))==0)
  r_indeces=which((apply(table,1,sum))==0)
  if(length(c_indeces)>0)
  {
    table=table[,-(c_indeces)]
    
  }
  if(length(r_indeces)>0)
  {
    table=table[-(r_indeces),]
    
  }
  return(table)
  
}


discrete_patterns = function()
{
  pdf("patterns.pdf", width=4, height=3)
  
  par(mar=c(2,2,2,1))
  
  cols <- c("green", "orange", "royalblue", "red")
  
  types <- c("Functional", "Many-to-one",
             "Dependent non-functional", "Independent")
  
  type.args <- c("functional", "many.to.one",
                 "dependent.non.functional", "independent")
  
  for(i in seq_along(types))
  {
    type <- types[i]
    
    pal <- colorRampPalette(c("white", cols[i]), space = "Lab")
    
    nrow <- 5
    ncol <- 3
    n <- 100
    
    l <- simulate_tables(n=n, nrow=nrow, ncol=ncol, type=type.args[i])
    
    m <- 1 - as.matrix(l$pattern.list[[1]])
    
    m <- as.matrix(l$sample.list[[1]])
    
    ncols <- length(unique(as.vector(m)))
    
    image(m, main=type, #paste0("type = ", "\"", type, "\""),
          xlab="", ylab="", xaxt="n", yaxt="n",
          col=pal(ncol*nrow) #pal(ncols) # rev(terrain.colors(nrow*ncol))
    )
    
    mtext("X", 1, 0.5)
    mtext("Y", 2, 0.5)
    
    grid(nx=nrow, ny=ncol)
    
    text((rep(1:nrow, times=ncol)-1)/(nrow-1),
         (rep(1:ncol, each=nrow)-1)/(ncol-1),
         as.vector(m))
    
  }
  
  dev.off()
}

cat("Figure 1: patterns.pdf ...\n")
discrete_patterns()

cat("\nFigure 2: density_plots.pdf ...\n")
generate_density() # n.tab=10

cat("\nFigure 3: performance.pdf ...\n")
performance() #iter=5
