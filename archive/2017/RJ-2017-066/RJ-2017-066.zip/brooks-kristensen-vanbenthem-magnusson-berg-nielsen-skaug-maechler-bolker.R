## ----prelims, echo=FALSE, message=FALSE, warning=FALSE-------------------
library(glmmTMB)
library(bbmle)
library(knitr)
library(ggplot2); theme_set(theme_bw())
knitr::opts_chunk$set(echo = TRUE, fig.width = 5.75, fig.height=4, cache=TRUE)
options(scipen = 1, digits = 2)
library(reshape)
library(plyr)
library(directlabels)

## ----ziandh, eval=FALSE--------------------------------------------------
## zinb = glmmTMB(count~spp * mined + (1|site), zi=~spp * mined,
## 		data=Salamanders, family=nbinom2)
## hnb = glmmTMB(count~spp * mined + (1|site), zi=~spp * mined,
## 		data=Salamanders, family=truncated_nbinom2)

## ----dummymodel, eval=FALSE----------------------------------------------
## glmmTMB(count ~ mined + (1|site), zi=~mined , disp=~DOY, Salamanders, family=nbinom2)

## ----summary2------------------------------------------------------------
summary(glmmTMB(count~mined+(1|site), zi=~mined , disp=~DOY, Salamanders, family=nbinom2))

## ----loadbig, echo=FALSE, message=FALSE, cache=FALSE---------------------
load("bigfit.RData")
bigtimes=subset(bigtimes, package !="brms")
tab1=ddply(bigtimes, ~package, "summarize", exponent=coef(lm(log(time)~log(nobs)))[2])
colnames(tab1)[2]="exponent"
tab1=join(tab1, subset(bigtimes, nobs==3864))

## ----plotbig, echo=FALSE, message=FALSE, warning=FALSE, cache=FALSE, eval=FALSE----
## ggplot(bigtimes, aes(x=nobs, y=time, colour=package))+geom_point()+
##   geom_smooth(method="lm", se=FALSE)+
##   scale_y_log10(breaks=c(1,5,10,50,100,500,1000))+
##   xlab("number of observations")+
##   ylab("estimation time (seconds)")+
##   scale_x_log10(breaks=unique(bigtimes$nobs))+
##   geom_label(data=tab1, aes(nobs, time, label=round(exponent, 1), colour=package), show.legend=FALSE, position = position_dodge(0.35), label.size =.15)

## ----plotbig2, echo=FALSE, message=FALSE, warning=FALSE, cache=FALSE-----
bigtimes2 = transform(bigtimes,
      package=factor(package,levels=levels(package),
                     labels=paste(levels(package),
                                  round(tab1$exponent,1),sep=": ")))
ggtime = ggplot(bigtimes2, aes(x=nobs, y=time, colour=package))+
    geom_point()+
  geom_smooth(method="lm", se=FALSE)+
  scale_y_log10(breaks=c(1,5,10,50,100,500,1000))+
  xlab("number of observations")+
  ylab("estimation time (seconds)")+
  scale_x_log10(breaks=unique(bigtimes$nobs))#+
  #  expand_limits(x=15000)  ## a bit more space on x-axis for labels

#direct.label(ggtime,list(dl.trans(x=x+0.1), ## shift labels right by 0.1 cm
#                         "last.bumpup"))
direct.label(ggtime,list("angled.boxes"))

## ----loadbigRE, echo=FALSE, message=FALSE, warning=FALSE, cache=FALSE----
load("bigfitRE.RData")
bigtimes=subset(bigtimes, package !="brms")
tab=ddply(bigtimes, ~package, summarize, exponent=coef(lm(log(time)~log(nRE)))[2])
#colnames(tab)[2]="exponent"
#tab=join(tab, subset(bigtimes, nRE==92))
#manually move some label locations
#tab[7,"nRE"]=60 
#tab[6,"time"]=400 
#tab[1,"nRE"]=110 

bigtimes = join(bigtimes, tab)

## ----plotbigRE, echo=FALSE, message=FALSE, warning=FALSE, eval=FALSE-----
## ggplot(bigtimes, aes(x=nRE, y=time, colour=package))+
##   geom_point()+
##   geom_smooth(method="lm", se=FALSE)+
##   scale_y_log10(breaks=c(1,5,10,50,100,500,1000,5000,10000))+
##   xlab("random effect levels (sites)")+
##   ylab("estimation time (seconds)")+
##   scale_x_log10(breaks=unique(bigtimes$nRE))+
##   geom_label(data=tab, aes(nRE, time, label=round(exponent, 1), colour=package), show.legend=FALSE, position = position_dodge(0.65), label.size =.15)

## ----plotbigRE2, echo=FALSE, message=FALSE, warning=FALSE, cache=FALSE----
tab2 = transform(tab, 
                  labels= paste(package,round(exponent,1),sep=": ")
)
bigtimes2 = transform(join(bigtimes, tab2) ,
      package=factor(labels))
ggtime2 =ggplot(bigtimes2, aes(x=nRE, y=time, colour=package))+
    geom_point()+
  geom_smooth(method="lm", se=FALSE)+
    scale_y_log10(breaks=c(1,5,10,50,100,500,1000,5000,10000))+
    xlab("random effect levels (sites)")+
  ylab("estimation time (seconds)")+
  scale_x_log10(breaks=unique(bigtimes$nRE))+
    expand_limits(x=10)  ## a bit more space on x-axis for labels 

#direct.label(ggtime2,list(dl.trans(x=x+0.1), ## shift labels right by 0.1 cm
#"last.bumpup"))
direct.label(ggtime2,list("angled.boxes"))
## would be nice to have these in boxes as in geom_label ... ?


## ----scalingRE, echo=FALSE, cache=FALSE----------------------------------
tab=ddply(bigtimes, ~package, "summarize", exponent=coef(lm(log(time)~log(nRE)))[2])
tab[4,2]=NA
colnames(tab)[2]="exponent"

## ----firstplot, echo=FALSE-----------------------------------------------
ggplot(Salamanders, aes(x=count, fill=mined))+geom_histogram(position="identity" , alpha=.7, binwidth = 1)+facet_wrap(~spp, scale="free")+ylab(NULL)+xlab(NULL)

## ----pmodels-------------------------------------------------------------
pm0 = glmmTMB(count~spp + (1|site), Salamanders, family=poisson)
pm1 = glmmTMB(count~spp + mined + (1|site), Salamanders, family=poisson)
pm2 = glmmTMB(count~spp * mined + (1|site), Salamanders, family=poisson)

## ----cmpmodels-----------------------------------------------------------
cmpm0 = glmmTMB(count~spp + (1|site), Salamanders, family=compois)
cmpm1 = glmmTMB(count~spp + mined + (1|site), Salamanders, family=compois)
cmpm2 = glmmTMB(count~spp * mined + (1|site), Salamanders, family=compois)

## ----nbmodels------------------------------------------------------------
nbm0 = glmmTMB(count~spp + (1|site), Salamanders, family=nbinom2)
nbm1 = glmmTMB(count~spp + mined + (1|site), Salamanders, family=nbinom2)
nbm2 = glmmTMB(count~spp * mined + (1|site), Salamanders, family=nbinom2)

## ----disp_nbmodels-------------------------------------------------------
nbdm0 = glmmTMB(count~spp + (1|site), disp=~DOY, Salamanders, family=nbinom2)
nbdm1 = glmmTMB(count~spp + mined + (1|site), disp=~DOY, Salamanders, family=nbinom2)
nbdm2 = glmmTMB(count~spp * mined + (1|site), disp=~DOY, Salamanders, family=nbinom2)

## ----zipmodels-----------------------------------------------------------
zipm0 = glmmTMB(count~spp +(1|site), zi=~spp, Salamanders, family=poisson)
zipm1 = glmmTMB(count~spp + mined +(1|site), zi=~spp, Salamanders, family=poisson)
zipm2 = glmmTMB(count~spp + mined +(1|site), zi=~spp + mined, Salamanders, family=poisson)
zipm3 = glmmTMB(count~spp * mined +(1|site), zi=~spp * mined, Salamanders, family=poisson)

## ----zicmpmodels---------------------------------------------------------
zicmpm0 = glmmTMB(count~spp +(1|site), zi=~spp, Salamanders, family=compois)
zicmpm1 = glmmTMB(count~spp + mined +(1|site), zi=~spp, Salamanders, family=compois)
zicmpm2 = glmmTMB(count~spp + mined +(1|site), zi=~spp + mined, Salamanders, family=compois)
zicmpm3 = glmmTMB(count~spp * mined +(1|site), zi=~spp * mined, Salamanders, family=compois)

## ----zinbmodels----------------------------------------------------------
zinbm0 = glmmTMB(count~spp +(1|site), zi=~spp, Salamanders, family=nbinom2)
zinbm1 = glmmTMB(count~spp + mined +(1|site), zi=~spp, Salamanders, family=nbinom2)
zinbm2 = glmmTMB(count~spp + mined +(1|site), zi=~spp + mined, Salamanders, family=nbinom2)
zinbm3 = glmmTMB(count~spp * mined +(1|site), zi=~spp * mined, Salamanders, family=nbinom2)

## ----hurdle--------------------------------------------------------------
hpm0 = glmmTMB(count~spp + (1|site), zi=~spp, Salamanders, family=truncated_poisson)
hpm1 = glmmTMB(count~spp + mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_poisson)
hpm2 = glmmTMB(count~spp * mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_poisson)
hnbm0 = glmmTMB(count~spp + (1|site), zi=~spp, Salamanders, family=truncated_nbinom2)
hnbm1 = glmmTMB(count~spp + mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_nbinom2)
hnbm2 = glmmTMB(count~spp * mined + (1|site), zi=~spp + mined, Salamanders, 
                family=truncated_nbinom2)

## ----AIC, eval=FALSE-----------------------------------------------------
## AICtab(pm0, pm1, pm2,
##        cmpm0, cmpm1, cmpm2,
##        nbm0, nbm1, nbm2,
##        nbdm0, nbdm1, nbdm2,
##        zipm0, zipm1, zipm2, zipm3,
##        zicmpm0, zicmpm1, zicmpm2, zicmpm3,
##        zinbm0, zinbm1, zinbm2, zinbm3,
##        hpm0, hpm1, hpm2,
##        hnbm0, hnbm1, hnbm2)

## ----AIC4, echo=FALSE----------------------------------------------------
tab4 = AICtab(pm0, pm1, pm2,
       cmpm0, cmpm1, cmpm2, 
       nbm0, nbm1, nbm2, 
       nbdm0, nbdm1, nbdm2, 
       zipm0, zipm1, zipm2, zipm3,
       zicmpm0, zicmpm1, zicmpm2, zicmpm3,
       zinbm0, zinbm1, zinbm2, zinbm3,
       hpm0, hpm1, hpm2, 
       hnbm0, hnbm1, hnbm2)
tab5=data.frame(model=attr(tab4, "row.names"), df=tab4$df, dAIC=tab4$dAIC)

## ----AIC3, echo=FALSE----------------------------------------------------
kable(tab5[1:5,], format = "latex", booktabs=TRUE)

## ----AIC5, echo=FALSE----------------------------------------------------
kable(tab5[26:30,], format = "latex", row.names = FALSE, booktabs=TRUE)

## ----estsFE--------------------------------------------------------------
zinbm3FE = glmmTMB(count~spp * mined, zi=~spp * mined, Salamanders, family=nbinom2)
newdata0 = newdata = unique(Salamanders[,c("mined","spp")])
temp = predict(zinbm3FE, newdata, se.fit=TRUE, zitype="response")
newdata$predFE = temp$fit
newdata$predFE.min = temp$fit-1.96*temp$se.fit
newdata$predFE.max = temp$fit+1.96*temp$se.fit

real=ddply(Salamanders, ~site+spp+mined, summarize, m=mean(count))
  
ggplot(newdata, aes(spp, predFE, colour=mined))+geom_point()+
  geom_errorbar(aes(ymin=predFE.min, ymax=predFE.max))+
  geom_point(data=real, aes(x=spp, y=m) )+
  ylab("Average abundance \n including presences and absences")+
  xlab("Species")


## ----predmode------------------------------------------------------------
X.cond = model.matrix(lme4::nobars(formula(zinbm3)[-2]), newdata0)
beta.cond = fixef(zinbm3)$cond
pred.cond = X.cond %*% beta.cond

ziformula = zinbm3$modelInfo$allForm$ziformula #$
X.zi = model.matrix(lme4::nobars(ziformula), newdata0)
beta.zi = fixef(zinbm3)$zi
pred.zi = X.zi %*% beta.zi

## ----pred----------------------------------------------------------------
pred.ucount = exp(pred.cond)*(1-plogis(pred.zi))

## ----postpredsim---------------------------------------------------------
library(MASS)
set.seed(101)
pred.condpar.psim = mvrnorm(1000,mu=beta.cond,Sigma=vcov(zinbm3)$cond)
pred.cond.psim = X.cond %*% t(pred.condpar.psim)
pred.zipar.psim = mvrnorm(1000,mu=beta.zi,Sigma=vcov(zinbm3)$zi)
pred.zi.psim = X.zi %*% t(pred.zipar.psim)
pred.ucount.psim = exp(pred.cond.psim)*(1-plogis(pred.zi.psim))
ci.ucount = t(apply(pred.ucount.psim,1,quantile,c(0.025,0.975)))
ci.ucount = data.frame(ci.ucount)
names(ci.ucount) = c("ucount.low","ucount.high")
pred.ucount = data.frame(newdata0, pred.ucount, ci.ucount)

## ----MCMCplotCI----------------------------------------------------------
real.count = ddply(Salamanders, ~spp+mined, summarize, m=median(count), mu=mean(count))
ggplot(pred.ucount, aes(x=spp, y=pred.ucount, colour=mined))+geom_point(shape=1, size=2)+
  geom_errorbar(aes(ymin=ucount.low, ymax=ucount.high))+
  geom_point(data=real.count,  aes(x=spp, y=m, colour=mined), shape=0, size=2)+
  geom_point(data=real.count,  aes(x=spp, y=mu, colour=mined), shape=5, size=2)+
  ylab("Abundance \n including presences and absences")+
  xlab("Species")

## ----sims----------------------------------------------------------------
sims=simulate(nbm2, seed = 1, nsim = 1000)

## ----simsums-------------------------------------------------------------
simdatlist=lapply(sims, function(count){ 
  cbind(count, Salamanders[,c('site', 'mined', 'spp')])
})
simdatsums=lapply(simdatlist, function(x){
  ddply(x, ~spp+mined, summarize, 
        absence=mean(count==0),
        mu=mean(count))
})
ssd=do.call(rbind, simdatsums)

## ----plotsimsE-----------------------------------------------------------
real = ddply(Salamanders, ~spp+mined, summarize, 
             absence=mean(count==0),
             mu=mean(count))
ggplot(ssd, aes(x=absence, color=mined))+
  geom_density(adjust=4)+
  facet_wrap(~spp)+
  geom_point(data=real, aes(x=absence, y=1, color=mined), size=2)+
  xlab("Probability that salamanders are not observed")+ylab(NULL)


## ----plotsimsmu----------------------------------------------------------
ggplot(ssd, aes(x=mu, color=mined))+
  geom_density(adjust=4)+
  facet_wrap(~spp)+
  geom_point(data=real, aes(x=mu, y=.5, color=mined), size=2)+
  xlab("Abundance including presences and absences")+ylab(NULL)

## ----libs,warning=FALSE, message=FALSE, cache=FALSE----------------------
library(glmmTMB)
library(glmmADMB)
library(MCMCglmm)
library(brms)
library(INLA)
library(mgcv)
library(broom) #for tidy devtools::install_github("bbolker/broom")
library(plyr)
library(dplyr) #tidyverse
library(ggplot2); theme_set(theme_bw())
library(ggstance)#for position_dodgev

## ----data----------------------------------------------------------------
data(Owls,package="glmmTMB")
Owls = plyr::rename(Owls, c(SiblingNegotiation="NCalls"))
Owls = transform(Owls,
                 ArrivalTime=scale(ArrivalTime, center=TRUE, scale=FALSE),
                 obs=factor(seq(nrow(Owls))))

## ----helper,echo=FALSE---------------------------------------------------
options(scipen = 1, digits = 3)#larger than above needed for 0.975 quantile
# time 
tfun = function(...) unname(system.time(capture.output(...))["elapsed"])
abbfun = function(x) {
  gsub("[()]","", # (Intercept) -> Intercept
    gsub("(Sol\\.)*(trait|at.level\\(trait, 1\\):)*","", # simplify MCMCglmm labs
     gsub("FoodTreatment","FT",x)))  # shorten
}
tidy.brmsfit = function(x, effects=c("fixed"),...) {
    ss = summary(x)
    tidy(ss$fixed) %>%
        mutate(effect="fixed",group="fixed") %>%
        select(effect,.rownames,Estimate,Est.Error,l.95..CI,u.95..CI,group) %>%
        rename(term=.rownames,estimate=Estimate,std.error=Est.Error,
               conf.low=l.95..CI,conf.high=u.95..CI)
}
# broom tidy method for class "inla"

tidy.inla = function(x, effects=c("fixed"),...) {
    ss = summary(x)
    tidy(ss$fixed) %>%
        mutate(effect="fixed",group="fixed") %>%
        ## ??? why did 0.0975 turn into 0.097 ???
        select(effect,.rownames,mean,sd,X0.025quant,X0.975quant,group) %>%
        rename(term=.rownames,estimate=mean,std.error=sd,
               conf.low=X0.025quant,conf.high=X0.975quant)
}
tidy.gam = function(x, effects=c("fixed"),quasi=TRUE,...) {
    ss = summary(x)
    disp = if (!quasi) 1 else deviance(m1.gam)/df.residual(m1.gam)
    tidy(ss$p.table)  %>%
        mutate(effect="fixed",group="fixed",
               Std..Error=sqrt(disp)*Std..Error,
               conf.low=Estimate-1.96*Std..Error,
               conf.high=Estimate+1.96*Std..Error) %>%
        select(.rownames,Estimate,Std..Error, conf.low, conf.high) %>%
    rename(term=.rownames,estimate=Estimate,std.error=Std..Error)
}

## ----tmbfit--------------------------------------------------------------
fixef1 = NCalls~(FoodTreatment + ArrivalTime) * SexParent + logBroodSize
form1 =  update(fixef1, . ~ . + (1|Nest)+(1|obs))
time.tmb = tfun(m1.tmb <<- glmmTMB(form1,
                                  ziformula=~1, data = Owls,
                                  family=poisson))

## ----mcmcglmmfit---------------------------------------------------------
fixef2 = NCalls~trait-1+ # intercept terms for both count and binary terms
    # other fixed-effect terms only apply to count term
    at.level(trait,1):logBroodSize+
    at.level(trait,1):((FoodTreatment+ArrivalTime)*SexParent)
nfix = 8
# residual variances independent for count and binary terms;
#    fixed to 1 for binary term
# random-effects variances independent for count and binary terms;
#    fixed very small (1e-6) for binary term
prior_overdisp  = list(R=list(V=diag(c(1,1)),nu=0.002,fix=2),   
                       G=list(list(V=diag(c(1,1e-6)),nu=0.002,fix=2)))
prior_overdisp_broodoff = c(prior_overdisp,
                            list(B=list(mu=rep(0,nfix),
                                        V=diag(rep(1e4,nfix)))))
set.seed(101)
time.MCMCglmm = tfun(m1.MCMCglmm <<- MCMCglmm(fixef2,
                                   rcov=~idh(trait):units,
                                   random=~idh(trait):Nest,
                                   prior=prior_overdisp_broodoff,
                                   data=Owls,
                                   nitt=103000,
                                   thin=100,
                                   family="zipoisson",
                                   verbose=FALSE))

## ----brmsfitE------------------------------------------------------------
time.brms = tfun(m1.brms <<- brm(form1, data = Owls,
                                 iter=1000,
                                 family="zero_inflated_poisson"))

## ----brmsfit2------------------------------------------------------------
time.brms2 = tfun(m1.brms2 <<- update(m1.brms))

## ----inlafit-------------------------------------------------------------
form2 = update(fixef1, . ~ . + f(Nest, model="iid") + f(obs, model="iid"))
time.inla = tfun(m1.inla <<-
       inla(form2,
            family= "zeroinflatedpoisson1",
            data=Owls))

## ----mgcvfit-------------------------------------------------------------
form3 = update(fixef1, . ~ . + s(Nest, bs="re"))
time.mgcv = tfun(m1.gam <<- gam(list(form3, ~ 1),
                                data = Owls,
                                family = ziplss(), method = "REML"))

## ----times, echo=FALSE---------------------------------------------------
timeVec = c(glmmTMB=time.tmb,
             MCMCglmm=time.MCMCglmm,
             `brms (with compilation)`=time.brms,
             `brms (no compilation)`=time.brms2,
             INLA=time.inla,
             mgcv=time.mgcv
             )
knitr::kable(sort(round(timeVec,1)),
             format="latex", col.names="time (sec)", align="r", booktabs=TRUE)

## ----arrange_coefs,echo=FALSE--------------------------------------------
modList = list(glmmTMB=m1.tmb,
               MCMCglmm=m1.MCMCglmm,
               brms=m1.brms,
               INLA=m1.inla,
               gam=m1.gam
               )
coefs = ldply(modList,tidy,effect="fixed",conf.int=TRUE,
              .id="model") %>%
    mutate(term=abbfun(term)) %>%
    select(model,term,estimate,conf.low,conf.high) %>%
    filter(!term %in% c("Intercept","Intercept.1","NCalls","zi_NCalls"))

## ----coefplot, echo=FALSE, fig.width=7, cache=TRUE-----------------------
gg0 = ggplot(coefs, aes(color=model,shape=model,y=term, x=estimate))+
    labs(x="Regression estimate",y="")+
    geom_pointrangeh(aes(xmax=conf.high, xmin=conf.low),
                     position = position_dodgev(height = 0.6))+
     ## flip legend to match order in plot
     guides(colour = guide_legend(reverse = TRUE),
            shape =  guide_legend(reverse = TRUE))
gg1 = gg0 + scale_colour_brewer(palette="Set1")+
    scale_shape_manual(values=15:20)
print(gg1)

## ----tmbfit_czi,dependson="tmbfit"---------------------------------------
form0 = update(fixef1, . ~ . + (1|Nest))
ziform = ~FoodTreatment+(1|Nest)
time.tmb_czi = tfun(m1.tmb_czi <<- glmmTMB(form0,
                                           ziformula=ziform,
                                           data = Owls, family=nbinom2))

## ----MCMCglmm_czi,warning=FALSE------------------------------------------
fixef3 = NCalls~trait-1+ # intercept terms for both count and binary terms
    # fixed-effect terms for count term
    at.level(trait,1):logBroodSize+
    at.level(trait,1):((FoodTreatment+ArrivalTime)*SexParent)+
    # fixed-effect terms for binary term
    at.level(trait,2):FoodTreatment
nfix = 9
# residual variances independent for count and binary terms;
#    fixed to 1 for binary term
# random-effects variances now allow estimated variance for binary term
#   as well
prior_overdisp_czi  = list(R=list(V=diag(c(1,1)),nu=0.002,fix=2),   
                       G=list(list(V=diag(c(1,1)),nu=0.002)))
prior_overdisp_broodoff_czi = c(prior_overdisp_czi,
                              list(B=list(mu=rep(0,nfix),
                                          V=diag(rep(1e4,nfix)))))
set.seed(101)
time.mcmc_czi=tfun(m1.mcmc_czi <<- MCMCglmm(fixef3,
                                   rcov=~idh(trait):units,
                                   random=~idh(trait):Nest,
                                   prior=prior_overdisp_broodoff_czi,
                                   data=Owls,
                                   nitt=153000,
                                   family="zipoisson",
                                   verbose=FALSE))
## warning message suppressed ...

## ----brmszifit,dependson="tmbfit"----------------------------------------
time.brms_czi = tfun(m1.brms_czi <<- brm(brmsformula(form1, zi=ziform),
                                 data = Owls,
                                 family="zero_inflated_poisson"))

## ----brmszifit2----------------------------------------------------------
time.brms_czi2 = tfun(m1.brms_czi2 <<- update(m1.brms_czi))

## ----mgcvfit_czi---------------------------------------------------------
time.mgcv_czi = tfun(m1.gam_czi <<- gam(list(form3,
                                             ~FoodTreatment+ s(Nest, bs = "re")),
                                        data = Owls, family = ziplss(), method = "REML"))

## ----times_czi, echo=FALSE-----------------------------------------------
timeVec_czi = c(TMB=time.tmb_czi,
                 MCMCglmm=time.mcmc_czi,
                 `brms (with compilation)`=time.brms_czi,
                 `brms (no compilation)`=time.brms_czi2,
                 mgcv=time.mgcv_czi)
knitr::kable(sort(round(timeVec_czi,1)),
                  format="latex", col.names="time (sec)", align="r", booktabs=TRUE)

## ----arrange_coefs_czi,echo=FALSE,cache=FALSE----------------------------
modList_czi = list(glmmTMB=m1.tmb_czi,
                MCMCglmm=m1.mcmc_czi,
                brms=m1.brms_czi,
                mgcv=m1.gam_czi)
coefs_czi = ldply(modList_czi,tidy,effect="fixed",conf.int=TRUE,
                  .id="model") %>%
    mutate(term=abbfun(term)) %>%
    select(model,term,estimate,conf.low,conf.high) %>%
    filter(!term %in% c("Intercept","Intercept.1", "NCalls","zi_NCalls","logBroodSize",
                        "zi_Intercept","zi_FTSatiated","FTSatiated.1",
                        "FTDeprived:at.level, 2"))

## ----coefplot_czi, fig.width=7, echo=FALSE, cache=FALSE------------------
pal = RColorBrewer::brewer.pal("Set1",n=5)
newmods = c(1,2,3,5)
## ugh, repeat code
## can't figure out how to change scales/keep colors consistent
gg0_czi = ggplot(coefs_czi, aes(color=model,shape=model,y=term, x=estimate))+
    labs(x="Regression estimate",y="")+
    geom_pointrangeh(aes(xmax=conf.high, xmin=conf.low),
                     position = position_dodgev(height = 0.6))+
     ## flip legend to match order in plot
     guides(colour = guide_legend(reverse = TRUE),
            shape =  guide_legend(reverse = TRUE))+
    scale_colour_manual(values=pal[newmods])+
    scale_shape_manual(values=(15:20)[newmods])
print(gg0_czi)


## ----save,echo=FALSE,cache=FALSE-----------------------------------------
save("modList","modList_czi","timeVec","timeVec_czi",
     file="modList.RData")

## ----pkg_versions,echo=FALSE---------------------------------------------
model_pkgs <- sort(c("glmmADMB","MCMCglmm","glmmTMB",
                     "brms","INLA","mgcv"))
##print(paste(paste0('"',pkgs_CRAN,'"'),collapse=","),quote=FALSE)
vers <- sapply(model_pkgs,function(x) as.character(packageVersion(x)))
print(vers,quote=FALSE)

