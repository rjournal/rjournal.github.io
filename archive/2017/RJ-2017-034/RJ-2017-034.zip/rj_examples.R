#library(devtools)
#install_github("hsavoy/anchoredDistr")
#install.packages("anchoredDistr_1.0.0.tar.gz", repos=NULL, type="source")
library(anchoredDistr)

### EXAMPLE 1
data(tutorial)
plotMAD(tutorial, "priors")

testConvergence(tutorial) #Note: Random selection of samples
tutorial <- calcLikelihood(tutorial)
tutorial <- calcPosterior(tutorial)
plotMAD(tutorial, "posteriors")


### EXAMPLE 2
data(pumping)
plotMAD(pumping, "observations")
plotMAD(pumping, "priors")
plotMAD(pumping, "realizations")

pumping.min <- reduceData(pumping, min)
plotMAD(pumping.min, "realizations")

pumping.min <- calcLikelihood(pumping.min)
pumping.min <- calcPosterior(pumping.min)
plotMAD(pumping.min, "posteriors")

