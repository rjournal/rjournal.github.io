# Supplementary Code
# For the article "volesti: Volume Approximation and Sampling for Convex Polytopes in R"

# The following packages are needed to run the examples. The listed version numbers
# are the ones that we used in our testing. Note that we have used R 3.4.4 and R 3.6.3
# * volesti 1.1.2-2
# * ggplot2 3.1.0
# * plotly 4.8.0
# * rgl 0.100.50
# * Rfast 2.0.3
# * pracma 2.2.9

library(volesti)
library(ggplot2)
library(plotly) 
library(rgl)
library(Rfast)
library(pracma)

#create a list to store the results of each script
script_results = list()


# Section "Package"

#-----------1st script-----------#
d = 100
P = gen_cube(d, 'H')

samples = sample_points(P, random_walk = list(
  "walk" = "RDHR", "burn-in"=1000, "walk_length" = 5), n = 1000)  

script_results$section_3_script_1st = samples


#------------2nd script-----------#
## here we add the code of Figure 3
d = 200
num_of_points = 1000
P = gen_cube(d, 'H')
retList = rotate_polytope(P, rotation = list("seed" = 5))
T = retList$T
P = retList$P

for (i in c(1, seq(from = 50, to = 200, by = 50))){
  
  points1 = t(T) %*% sample_points(P, n = num_of_points, 
                                   random_walk = list("walk" = "BaW",              
                                                      "walk_length" = i,
                                                      "seed" = 5))
  
  points2 = t(T) %*% sample_points(P, n = num_of_points, 
                                   random_walk = list("walk" = "CDHR",                        
                                                      "walk_length" = i,
                                                      "seed" = 5))
  
  points3 = t(T) %*% sample_points(P, n = num_of_points, 
                                   random_walk = list("walk" = "RDHR", 
                                                      "walk_length" = i,
                                                      "seed" = 5))
  
  points4 = t(T) %*% sample_points(P, n = num_of_points, 
                                   random_walk = list("walk" = "BiW", 
                                                      "walk_length" = i,
                                                      "seed" = 5))
  
  rgl::open3d()
  rgl::plot3d(x=points1[1,], y=points1[2,], z=points1[3,], xlim = c(-1,1), 
              ylim = c(-1,1), zlim = c(-1,1), col = "cyan", size=2, main = "",
              sub = "", ann = FALSE, axes = FALSE, xlab="", ylab="", zlab="")
  rgl::box3d()
  rgl::rgl.snapshot( filename=paste0("BaW_",i,".png"), fmt = "png", top = TRUE )
  rgl::rgl.close()
  
  rgl::open3d()
  rgl::plot3d(x=points2[1,], y=points2[2,], z=points2[3,], xlim = c(-1,1), 
              ylim = c(-1,1), zlim = c(-1,1), col = "black", size=2, main = "",
              sub = "", ann = FALSE, axes = FALSE, xlab="", ylab="", zlab="")
  rgl::box3d()
  rgl::rgl.snapshot( filename=paste0("CDHR_",i,".png"), fmt = "png", top = TRUE )
  rgl::rgl.close()
  
  rgl::open3d()
  rgl::plot3d(x=points3[1,], y=points3[2,], z=points3[3,], xlim = c(-1,1), 
              ylim = c(-1,1), zlim = c(-1,1), col = "red", size=2, main = "",
              sub = "", ann = FALSE, axes = FALSE, xlab="", ylab="", zlab="")
  rgl::box3d()
  rgl::rgl.snapshot( filename=paste0("RDHR_",i,".png"), fmt = "png", top = TRUE )
  rgl::rgl.close()
  
  rgl::open3d()
  rgl::plot3d(x=points4[1,], y=points4[2,], z=points4[3,], xlim = c(-1,1), 
              ylim = c(-1,1), zlim = c(-1,1), col = "blue", size=2, main = "",
              sub = "", ann = FALSE, axes = FALSE, xlab="", ylab="", zlab="")
  rgl::box3d()
  rgl::rgl.snapshot( filename=paste0("BiW_",i,".png"), fmt = "png", top = TRUE )
  rgl::rgl.close()    
}


#-------------3rd script-----------------#
d = 100
S = matrix(rnorm(d*d, mean=0, sd=1), d, d) 
S = S %*% t(S)
shift = rep(1/d, d)
A = -diag(d)
b = rep(0,d)
b = b = b - A %*% shift
Aeq = t(as.matrix(rep(1,d), 10, 1))
N = pracma::nullspace(Aeq)
A = A %*% N
S = t(N) %*% S %*% N

#cholesky decomposition
A = A %*% t(chol(S))
#the new truncation
P = Hpolytope(A = A, b = as.numeric(b))

samples = sample_points(P, n = 100000, random_walk = 
    list("walk"="CDHR", "burn-in"=1000, "starting_point" = rep(0, d-1),
    distribution = list("density" = "gaussian", "mode" = rep(0, d-1)))) 
                           
#apply the inverse transformation
samples_initial_space = N %*% samples + 
    kronecker(matrix(1, 1, 100000), matrix(shift, ncol = 1))

script_results$section_3_script_3rd = list("samples_projected space" = samples, "samples_initial_space" = samples_initial_space)


#------------4th script----------#
# this script is for error 0.2, and can be edited to generate results for error 0.02
P = gen_cube(10, 'H')
volumes <- list()
for (i in seq_len(20)) {
  volumes[[i]] <- volume(P, settings = list("error" = 0.2))
}
# generate the boxplot for error 0.2
options(digits = 10)
statistics = summary(as.numeric(volumes))
boxplot(as.numeric(volumes),ylim = c(as.numeric(statistics[1]), as.numeric(statistics[6])), ylab = "volume")
title("Error parameter e = 0.2")

script_results$section_3_script_4th = volumes


#------------5th script-----------#
d = 80
P = gen_cross(80, 'V')  #generate a cross polytope in V-representation

time = system.time({volume_estimation = volume(P, settings = list(
  "algorithm" = "CB", "random_walk" = "BiW", "seed" = 127)) })

exact_volume = 2^d/prod(1:d)
#cat(time[3], abs(volume_estimation - exact_volume) / exact_volume)

script_results$section_3_script_5th_a = list("volume_estimation" = abs(volume_estimation - exact_volume) / exact_volume, "runtime" = as.numeric(time)[3])

P = gen_cube(d, 'H')   #generate a hypercube polytope in H-representation

time = system.time({volume_estimation = volume(P, settings = list(
  "algorithm" = "CB", "random_walk" = "CDHR", "seed" = 23)) })

exact_volume = 2^d
#cat(time[3], abs(volume_estimation - exact_volume) / exact_volume)

script_results$section_3_script_5th_b = list("volume_estimation" = abs(volume_estimation - exact_volume) / exact_volume, "runtime" = as.numeric(time)[3])


#------------6th script-----------#
P = gen_rand_vpoly(20, 40, generator = list("body" =  "cube", "seed" = 1729))
volume_estimation1 = volume(P)

P = gen_rand_hpoly(60, 180, generator = list('constants' = 'sphere'))
volume_estimation2 = volume(P)

script_results$section_3_script_6th = list("volume_estimation1" =  volume_estimation1, "volume_estimation2" = volume_estimation2)


## Section "Applications"

#------------1st script-----------#
MatReturns = read.table("https://stanford.edu/class/ee103/data/returns.txt",
                        sep = ",")
MatReturns = MatReturns[-c(1, 2), ]
dates = as.character(MatReturns$V1)
MatReturns = as.matrix(MatReturns[ ,-c(1, 54)])
MatReturns = matrix(as.numeric(MatReturns), nrow = dim(MatReturns )[1],
                    ncol = dim(MatReturns )[2], byrow = FALSE)
nassets = dim(MatReturns)[2]

script_results$section_4_script_1st = list("MatReturns" = MatReturns, "nassets" = nassets)


#-----------2nd script-----------#

## This script generates left and right plot in Figure 10 

#left plot
row1 = which(dates %in% "2007-05-31")
row2 = which(dates %in% "2007-03-07")
compound_asset_return = Rfast::colprods(1 + MatReturns[row1:row2, ]) - 1  #compute the Asset compound return
mass1 = copula(r1 = compound_asset_return, sigma = cov(MatReturns[row1:row2, ]), m = 100, n = 1e+06, seed = 5)

az <- list(
  title = "",
  zeroline = FALSE,
  showline = FALSE,
  showticklabels = FALSE,
  showgrid = FALSE
)

fig = plot_ly(z = ~mass1) %>% add_surface(showscale = FALSE)
fig = fig %>% layout(
  title = "07/03/2007 - 31/05/2007",
  scene = list(
    xaxis = list(title = "Portfolio return", font = 20),
    yaxis = list(title = "Portfolio volatility"),
    zaxis = az
  ))

#right plot
row1 = which(dates %in% "2008-12-18")
row2 = which(dates %in% "2009-03-13")
cR = Rfast::colprods(1 + MatReturns[row1:row2, ]) - 1  #compute the Asset compound return
mass2 = copula(r1 = cR, sigma = cov(MatReturns[row1:row2, ]), m = 100, n = 1e+06, seed = 5)
fig = plot_ly(z = ~mass2) %>% add_surface(showscale = FALSE)
fig = fig %>% layout(
  title = "18/12/2008 - 13/03/2009",
  scene = list(
    xaxis = list(title = "Portfolio return", font = 20),
    yaxis = list(title = "Portfolio volatility"),
    zaxis = az
  ))

script_results$section_4_script_2nd = list("mass1" = mass1, "mass2" = mass2)


#-----------3rd script-----------#
## here we add the code of the Figure 5
row1 = which(dates %in% "2007-01-04")
row2 = which(dates %in% "2010-01-04")
market_analysis = compute_indicators(returns =  MatReturns[row1:row2, ],
                                     parameters = list("win_length" = 60,
                                                       "m" = 100,
                                                       "n" = 1e+06,
                                                       "nwarning" = 30,
                                                       "ncrisis" = 60,
                                                       "seed" = 5))                            
I = market_analysis$indicators
market_states = market_analysis$market_states

script_results$section_4_script_3rd = list("I" = I, "market_states" = market_states)

n = length(I)
crisis_per = rep(NaN, n)
crisis_per[which(market_states %in% "crisis")] =
  I[which(market_states %in% "crisis")]

normal_per = rep(NaN, n)
normal_per[which(market_states %in% "normal")] =            
  I[which(market_states %in% "normal")]

warning_per = rep(NaN, n)
warning_per[which(market_states %in% "warning")] =
  I[which(market_states %in% "warning")]

indi.data <- data.frame(x=rep(1:707,3), y=c(normal_per, warning_per,
                                            crisis_per), period = rep(market_states,3))
ggplot(indi.data, aes(x=x, y=y))+ geom_line(aes(color=period)) +
  geom_point(aes(color=period)) + labs(x ="Dates", y="Indicator") +
  scale_y_continuous(breaks = 0:12)+ 
  scale_x_continuous(breaks=seq(from=1, to =707, by=50),
                     labels=c(dates[seq(from=1, to =707, by=50)])) +
  scale_color_manual(values=c("red", "blue", "orange")) +
  theme(legend.position="top",text = element_text(size=20),
        axis.text.x = element_text(size=10), axis.text.y = element_text(size=20))


#------------4th script-----------#
R = MatReturns[which(dates %in% "2009-03-13"), ]
R0 = 0.002
tim = system.time({ exact_score = frustum_of_simplex(R, R0) })

#cat(exact_score, tim[3])

script_results$section_4_script_4th = list("exact_score" = exact_score, "runtime" = as.numeric(tim)[3])


#-----------5th script-----------#
## here we add the code of the plot in Figure 6
Z = gen_rand_zonotope(2, 8, generator = list("distribution" = "uniform", "seed" = 1729))
points1 = sample_points(Z, random_walk = list("walk" = "BRDHR"), n = 10000)
retList = zonotope_approximation(Z = Z, fit_ratio = TRUE, settings = list("seed" = 5))
P = retList$P
points2 = sample_points(P, random_walk = list("walk" = "BRDHR", "seed" = 5),
                        n = 10000)
#cat(retList$fit_ratio)

script_results$section_4_script_5th = list("fit_ratio" = retList$fit_ratio)

cbp1 <- c("#999999", "#0072B2")
ggplot(data.frame(x = c(points1[1,],points2[1,]),
                  body = c(rep("zonotope",10000), rep("PCA_poly",10000)),
                  y = c(points1[2,],points2[2,])) , aes(x=x, y=y)) +
  geom_line(aes(color=body)) + geom_point(shape=20) +
  labs(x =" ", y = " ") + scale_color_manual(values = cbp1) +
  theme(legend.position="top",text = element_text(size=20))


#-----------6th script-----------#
integral_vals = c()
num_of_points = 5000
f = function(x) { sum(x^2) + (2 * x[1]^2 + x[2] + x[3]) }
for (d in seq(from = 5, to = 20, by = 5)) {
  P = gen_rand_vpoly(d, 2 * d, generator = list("seed" = 127))
  
  points = sample_points(P, random_walk = list("walk" = "BiW", 
                                               "walk_length" = 1, "seed" = 5), n = num_of_points)
  sum_f = 0
  for (i in seq_len(num_of_points)){
    sum_f = sum_f + f(points[, i])
  }
  V = volume(P, settings = list("error" = 0.05, "seed" = 5))
  I2 = (sum_f * V) / num_of_points
  integral_vals = append(integral_vals, I2)
}

script_results$section_4_script_6th = list("integral_vals" = integral_vals)


#------------7th script-----------#
A = matrix(c(
  -1,0,1,0,0,0,
  -1,1,0,0,0,-1,
  0,1,0,0,0,0,-1,
  1,1,0,0,0,0,0,
  1,0,0,0,0,0,1,
  0,0,0,0,0,1,0,
  0,0,0,0,1,-1,
  0,0,0,0,0,-1,
  0,0,0,0,0,-1,
  0,0,0,0,0,-1,
  0,0,0,0,0,-1), 
  ncol = 5, nrow = 14, byrow = TRUE)
b = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1 , 1, 1, 1)
P_LE = Hpolytope(A = A, b = b)
time = system.time({ LE = volume(P_LE, settings = list("error" = 0.01, "seed" = 1927)) * factorial(5) })

#cat(time[3], LE)

script_results$section_4_script_7th = list("linear_extensions" = LE)
