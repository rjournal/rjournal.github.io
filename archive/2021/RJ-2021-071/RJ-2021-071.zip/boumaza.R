library(dad)

#### Calculation of distances / divergences between discrete densities
x1 <- data.frame(x = factor(c("A", "A", "A", "B", "B", "B")),
                 y = factor(c("a", "a", "a", "b", "b", "b")))
x2 <- data.frame(x = factor(c("A", "A", "A", "B", "B")),
                 y = factor(c("a", "a", "b", "a", "b")))
p1 <- table(x1)/nrow(x1)
p1
p2 <- table(x2)/nrow(x2)
p2
ddlppar(p1, p2)   # L1 distance
ddjeffreyspar(p1, p2)  # Jeffreys divergence


#### Calculation of distance / divergence between Gaussian densities
# (i) knowing their parameters
m1 <- c(1,1)
v1 <- matrix(c(4,1,1,9),ncol = 2)
m2 <- c(0,1)
v2 <- matrix(c(1,0,0,1),ncol = 2)
jeffreyspar(m1,v1,m2,v2)  # Jeffreys divergence
# (ii) knowing a sample of each
library(MASS)
set.seed(100)
x1 <- mvrnorm(40, m1, v1)
x2 <- mvrnorm(30, m2, v2)
jeffreys(x1, x2)   # an estimate


#### Calculation of distance between non Gaussian densities
set.seed(40)
x1 <- c(rnorm(5, mean = 0, sd = 1), rnorm(5, mean = 1, sd  = 2))
x2 <- c(rnorm(10, mean = 2, sd = 3), rnorm(5, mean = 0, sd = 2))
distl2d(x1, x2, method = "kern") # estimate of l2 distance


#### MDS of probability density functions
data("roses")
rosesf <- as.folder(roses[,c("Sha", "Den", "Sym", "rose")], groups = "rose")
resultmds <- fmdsd(rosesf, gaussiand = FALSE, distance = "l2") 
names(resultmds)
# Numeric results
print(resultmds) # By default, displays only some elements of the list
# Graphical results
plot(resultmds) # Graphics of the first three principal scores
#
interpret(resultmds)
#
interpret(resultmds, moment = "sd")

# Figure 3
# Plotting means and standard deviations of the variables
xm <- as.data.frame(do.call(rbind, resultmds$means))
names(xm) <- paste("mean", names(xm), sep=".")
xv <- lapply(resultmds$variances, FUN = diag)
xsd <- sqrt(as.data.frame(do.call(rbind, xv)))
names(xsd) <- paste("sd", names(xsd), sep=".")
for(j in 1:3)
  {#dev.new()
   plot(xm[,j],xsd[,j], type="n", xlab = names(xm)[j], ylab = names(xsd)[j])
   text(xm[,j],xsd[,j],rownames(xm))
  } 


#### Hierarchical clustering analysis
# data("roses")
# rosesf <- as.folder(roses[,c("Sha", "Den", "Sym", "rose")], groups = "rose")
resulthca <- fhclustd(rosesf, gaussiand = FALSE, distance = "l2")
round(resulthca$distances, digits = 2)
#
plot(resulthca, xlab = "Roses", sub = " ", hang = -1)


#### Discriminant analysis of probability density functions:
#### the 'fdiscd.misclass' function.
data("castles.dated")
levels(castles.dated$periods$period) <- c("1", "2", "2", "2", "3", "3")
castlesfh <- folderh(castles.dated$periods, "castle", castles.dated$stones)
#
fdiscd.misclass(castlesfh, class.var = "period", distance = "l2")

### Calculation of the misclassification ratios of the tables 6 and 7
# Table 6. gaussiand = TRUE
for(vd in c("jeffreys", "hellinger", "wasserstein", "l2"))
  {print(vd)
  if(! vd == "l2")
    {mdiscd <- fdiscd.misclass(castlesfh, class.var = "period", gaussiand = TRUE, distance = vd, crit = 1)
    print(mdiscd$misclassed)} else {
    for(vc in c(1:3))
       {print(vc)
       mdiscd <- fdiscd.misclass(castlesfh, class.var = "period", gaussiand = TRUE, distance = vd, crit = vc)
       print(mdiscd$misclassed)
       }
    }
  }
# Table 7. gaussiand = FALSE   (time more than 2mn per iteration using a laptop computer equipped with an i5 processor)
for(vw in seq(from=0.1, to=0.9, by=0.1))
  {print(vw)
  mdiscd <- fdiscd.misclass(castlesfh, class.var = "period", gaussiand = FALSE, distance = "l2", windowh = vw)
  print(mdiscd$misclassed)
  }


#### Appendix B: Computation of the misclassification ratios of table 10 or 11
#
n <- 30
ne <- 10
nrep <- 1000
l1 <- 1
l2 <- 2
#
nmisclass1 <- 0
set.seed(135)
e1 <- rpois(n, lambda = l1)
e2 <- rpois(n, lambda = l2)
for(index in (1:nrep))
  { x <- rpois(ne, lambda = l1)
   d1 <- ddchisqsym(x,e1)
   d2 <- ddchisqsym(x,e2)
   if(d1 > d2) nmisclass1 <- nmisclass1 + 1
  }
misclassratio1 <- nmisclass1 / nrep
print(misclassratio1)
#
nmisclass2 <- 0
set.seed(135)
e1 <- rpois(n, lambda = l1)
e2 <- rpois(n, lambda = l2)
for(index in (1:nrep))
  {x <- rpois(ne, lambda = l2)
   d1 <- ddchisqsym(x,e1)
   d2 <- ddchisqsym(x,e2)
   if (d1 < d2) nmisclass2 <- nmisclass2 + 1
  }
misclassratio2 <- nmisclass2 / nrep
print(misclassratio2)
#
## TABLE 11
n <- 30
ne <- 10
nrep <- 1000
l1 <- 1
l2 <- 2
distancesd <- c("ddchisqsym", "ddhellinger", "ddjensen", "ddlp")
for (distd in distancesd)
{
  cat("\n", distd, "\n")
  set.seed(135)
  nmisclass1 <- 0
  e1 <- rpois(n, lambda = l1)
  e2 <- rpois(n, lambda = l2)
  for(index in (1:nrep))
  {
    x <- rpois(ne, lambda = l1)
    d1 <- do.call(distd, list(x,e1))
    d2 <- do.call(distd, list(x,e2))
    if(d1 > d2) nmisclass1 <- nmisclass1 + 1
  }
  misclassratio1 <- nmisclass1 / nrep
  print(misclassratio1)
  #
  set.seed(135)
  nmisclass2 <- ninf2 <- 0
  e1 <- rpois(n, lambda = l1)
  e2 <- rpois(n, lambda = l2)
  for(index in (1:nrep))
  {
    x <- rpois(ne, lambda = l2)
    d1 <- do.call(distd, list(x,e1))
    d2 <- do.call(distd, list(x,e2))
    if (d1 < d2) nmisclass2 <- nmisclass2 + 1
  }
  misclassratio2 <- nmisclass2 / nrep
  print(misclassratio2)
}
# Jeffreys divergence: ddjef
# With Jeffreys, the divergence can be infinite
set.seed(135)
nmisclass1 <- ninf1 <- 0
e1 <- rpois(n, lambda = l1)
e2 <- rpois(n, lambda = l2)
for(index in (1:nrep))
{
  x <- rpois(ne, lambda = l1)
  d1 <- ddjeffreys(x,e1)
  d2 <- ddjeffreys(x,e2)
  if (is.infinite(d1) & is.infinite(d2)) ninf1 <- ninf1 + 1
  if(d1 > d2) nmisclass1 <- nmisclass1 + 1
}
misclassratio1 <- nmisclass1 / nrep
print(misclassratio1)
cat(ninf1, "infinite\n")
#
set.seed(135)
nmisclass2 <- ninf2 <- 0
e1 <- rpois(n, lambda = l1)
e2 <- rpois(n, lambda = l2)
for(index in (1:nrep))
{
  x <- rpois(ne, lambda = l2)
  d1 <- ddjeffreys(x,e1)
  d2 <- ddjeffreys(x,e2)
  if (is.infinite(d1) & is.infinite(d2)) ninf2 <- ninf2 + 1
  if (d1 < d2) nmisclass2 <- nmisclass2 + 1
}
misclassratio2 <- nmisclass2 / nrep
print(misclassratio2)
cat(ninf2, "infinite\n")
#
## TABLE 12
n <- 30
ne <- 10
nrep <- 1000
m1 <- 0; s1 <- 1
m2 <- 1; s2 <- 2
distancesc <- c("hellinger", "jeffreys", "distl2d", "distl2dnorm", "wasserstein")
for (distc in distancesc)
{
  cat("\n", distc, "\n")
  set.seed(123)
  nmisclass1 <- 0
  e1 <- rnorm(n, mean = m1, sd = s1)
  e2 <- rnorm(n, mean = m2, sd = s2)
  for(index in (1:nrep))
  {
    x <- rnorm(ne, mean = m1, sd = s1)
    d1 <- do.call(distc, list(x,e1))
    d2 <- do.call(distc, list(x,e2))
    if(d1 > d2) nmisclass1 <- nmisclass1 + 1
  }
  misclassratio1 <- nmisclass1 / nrep
  print(misclassratio1)
  #
  set.seed(123)
  nmisclass2 <- 0
  e1 <- rnorm(n, mean = m1, sd = s1)
  e2 <- rnorm(n, mean = m2, sd = s2)
  for(index in (1:nrep))
  {
    x <- rnorm(ne, mean = m2, sd = s2)
    d1 <- do.call(distc, list(x,e1))
    d2 <- do.call(distc, list(x,e2))
    if (d1 < d2) nmisclass2 <- nmisclass2 + 1
  }
  misclassratio2 <- nmisclass2 / nrep
  print(misclassratio2)
}


#### Appendix D: Import plant architectures encoded in mtg files
mtgfile <- system.file("extdata/plant2.mtg", package = "dad")
x2 <- read.mtg(mtgfile)
fh <- as.folderh(x2, classes = c("P", "A", "I"))
print(fh)


#### Appendix G: Comparison of using data frame or data folder for computing inter-group distances
# Data loading
library(dad)
data(castles.dated)
x.df <- castles.dated$stones
x.folder <- as.folder(x.df, groups = "castle")
## Example 1 
system.time(matdistl2d(x.folder, method = "gaussiand"))
#
system.time(matdistl2d(x.folder, method = "kern"))
## Example 2
x.fh <- folderh(castles.dated$periods, "castle", castles.dated$stones)
#
system.time(fdiscd.misclass(x.fh, class.var = "period", distance = "l2", gaussiand = TRUE))
#
system.time(fdiscd.misclass(x.fh, class.var = "period", distance = "l2", gaussiand = FALSE))


#### Appendix H: Applying MDS to compositional data
library(compositions)
data(SimulatedAmounts)
print(sa.lognormals)
#
acomp(sa.lognormals) -> x1
print(x1)
#
x <- as.data.frame(x1)
nomscol <- colnames(x)
x2 <- list()
for(i in 1:60)
 {
  x2[[i]] <- as.table(as.numeric(x[i,]))
  dimnames(x2[[i]]) <- list("dd" = nomscol)
 }
names(x2) <- rownames(x)
# Figure 6a
r1 <- princomp(x1)
biplot(r1)
#
r2 <- mdsdd(x2, distance = "hellinger")
names(r2)
# Figure 6b
plot(r2)
# Figure 7a
plot(r1$scores[, "Comp.1"], -r2$scores[, "PC.1"], type = "n", xlab  = "comp1", ylab = "-PC.1")
text(r1$scores[, "Comp.1"], -r2$scores[, "PC.1"], labels = rownames(x))
# Figure 7b
plot(r1$scores[, "Comp.2"], -r2$scores[, "PC.2"], type = "n", xlab  = "comp2", ylab = "-PC.2")
text(r1$scores[, "Comp.2"], -r2$scores[, "PC.2"], labels = rownames(x))
#
interpret(r2, nscore = 1)
#

