# R code to reproduce code in the R Journal paper:
# The vote Package: Single Transferable Vote and Other Electoral Systems in R
# Adrian E. Raftery, Hana Sevcikova, Bernard W. Silverman
#
## vote package version 2.3-0

# Section Electoral methods
#################
library (vote)
data (food_election)
food_election

# Plurality voting
#----------------
food_election_plurality <- 1 * (food_election == 1 & !is.na (food_election))
head(food_election_plurality)
plurality (food_election_plurality)

# Two-round runoff voting
#----------------
food_election3 <- food_election[-c(12:15),]
tworound.runoff (food_election3)

# Approval voting
#----------------
food_election_approval <- 1 * !is.na (food_election)
approval (food_election_approval, nseats = 2)

# Score voting
#----------------
score (food_election, larger.wins = FALSE, nseats = 2, max.score = 6)

# Condorcet voting
#----------------
condorcet(food_election)

# Section Single Transferable Vote (STV)
######################
# STV method
#----------------
stv (food_election, nseats = 2)

# Equal preference STV
#----------------
food_election2 <- food_election
food_election2[c(1:3), 4] <- 1
stv (food_election2, equal.ranking = TRUE)

# Section Examples
#####################
# Irish general election 2002: Dublin West constituency
#----------------
data (dublin_west)
head(dublin_west)

dublin_west1 <- 1*(dublin_west == 1) 
plurality (dublin_west1)

tworound.runoff (dublin_west)

dublin_west2 <- 1* (dublin_west == 1 | dublin_west == 2 | dublin_west == 3)
approval (dublin_west2)

condorcet (dublin_west)

stv.dwest <- stv (dublin_west, nseats = 3, eps = 1, digits = 0)

plot(stv.dwest) # Figure 1
image (stv.dwest, all.pref = TRUE)  # Figure 2
image (stv.dwest, proportion = FALSE) # Figure 3 (left panel)
image (stv.dwest, proportion = TRUE) # Figure 3 (right panel)

# IMS council election
#----------------
data (ims_election)
stv.ims <- stv (ims_election, nseats = 4, eps = 1, digits = 0)

# Figure 4
plot(stv.ims) # a
image (stv.ims, all.pref = TRUE)  # b
image (stv.ims, proportion = FALSE) # c
image (stv.ims, proportion = TRUE) # d

# Explore invalid/corrected/valid votes
invalid.votes(stv.ims)
stv.ims <- stv (ims_election, nseats = 4, eps = 1, digits = 0, invalid.partial = TRUE)
corrected.votes(stv.ims)
head(valid.votes(stv.ims))

# Trial faculty recruitment vote
#----------------
faculty <- data.frame(
    Cauchy =      c(3, 4, 4, 4, 4, 5, 4, 5, 5, 5),
    Gauss  =      c(4, 1, 2, 2, 2, 2, 2, 2, 2, 4),
    Laplace =     c(5, 2, 1, 3, 1, 3, 3, 4, 4, 1),
    Nightingale = c(1, 3, 5, 1, 3, 1, 5, 1, 1, 2),
    Poisson =     c(2, 5, 3, 5, 5, 4, 1, 3, 3, 3)
    )
stv.faculty <- stv (faculty, nseats = 2, digits = 2, complete.ranking = TRUE)

# Figure 5
plot(stv.faculty) # a
image (stv.faculty, all.pref = TRUE)  # b
image (stv.faculty, proportion = FALSE) # c
image (stv.faculty, proportion = TRUE) # d

condorcet (faculty)

# reserved seats
stv (faculty, nseats = 2, group.nseats = 1,
     group.members = c("Laplace", "Poisson", "Cauchy"), digits = 2)

# equal preferences
faculty2 <- faculty
faculty2[1,] <- c(2,2,3,1,1)
faculty2[4,] <- c(3,1,2,1,3)
faculty2[9,] <- c(4,1,3,1,2)
faculty2[10,] <- c(2,1,1,1,1)
faculty2
stv.faculty.equal <- stv (faculty2, equal.ranking = TRUE, digits = 2)
corrected.votes(stv.faculty.equal)$new

# Faculty job candidate trial with single winner (to illustrate tie-breaking)
stv.faculty.tie <- stv (faculty, nseats = 1)
ordered.tiebreak(stv.faculty.tie$data)


