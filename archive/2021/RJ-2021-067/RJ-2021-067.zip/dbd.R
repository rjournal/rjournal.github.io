#
# Script dbd.R
#

library(dbd)

# Figures.
HRDCPY <- TRUE
source("makeCIs.R")
source("MSE.R")
source("plotCIs.R")

# Probability mass functions of db distributions.
if(HRDCPY) pdf(file="Figs/dbpmf1.pdf",height=6)
OP <- par(mfrow=c(2,2),mar=c(5,5,4,1)+0.1,cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
plotDb(alpha=0.5,beta=0.5,ntop=10,zeta=TRUE,xlab="",ylab="Probability",
       col="red",main=expression(paste(alpha==0.5,", ",beta==0.5)))
plotDb(alpha=5,beta=1,ntop=10,zeta=TRUE,xlab="",ylab="",col="red",
        main=expression(paste(alpha==5,", ",beta==1)))
plotDb(alpha=2,beta=2,ntop=10,zeta=TRUE,col="red",ylab="Probaility",
        main=expression(paste(alpha==2,", ",beta==2)))
plotDb(alpha=2,beta=5,ntop=10,zeta=TRUE,ylab="",col="red",
        main=expression(paste(alpha==2,", ",beta==5)))
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

if(FALSE) {
# Probability mass functions, comparing alpha=2, beta=2, with
# alpha=-2, beta=-2.
if(HRDCPY) pdf(file="Figs/dbpmf2.pdf",height=6)
OP <- par(mfrow=c(2,1),mar=c(4,4,1,1)+0.1)
plotDb(2,2,5,FALSE,col="red",xlab="")
plotDb(-2,-2,5,FALSE,col="blue")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}
}


# Analytic vs. Monte Carlo variances.
if(file.exists("anal.vs.mc.rda")) {
    load("anal.vs.mc.rda")
} else {
    Ndat <- c(25*(1:10),50*(6:15))
    obj  <- makeDbdpars(alpha=3,beta=3,ntop=10,zeta=TRUE,ndata=NA)
    set.seed(867)
    seeds <- sample(1:1e5,30)
    mc    <- numeric(20)
    anal  <- numeric(20)
    nNdat <- length(Ndat)
    for(i in 1:nNdat) {
        obj[["ndata"]] <- Ndat[i]
        cm <- mcCovMat(obj,nsim=500,seed=seeds[i])
        ca <- solve(do.call(finfoDb,obj))
        mc[i]   <- cm[2,2]
        anal[i] <- ca[2,2]
        cat(i,"")
        if(i %% 10 == 0) cat("\n")
    }
    if(i %% 10 != 0) cat("\n")
    save(Ndat,anal,mc,file="anal.vs.mc.rda")
}

if(HRDCPY) pdf(file="Figs/varEst.pdf",height=6)
OP <- par(mar=c(5,6,4,1)+0.1,cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
plot(Ndat,mc,ylim=range(mc,anal),col="blue",pch=20,log="y",
     xlab="Sample size",ylab=expression(paste("Log variance of ",hat(beta))))
points(Ndat,anal,col="red",pch=20)
legend("topright",pch=20,col=c("blue","red"),
       legend=c("Monte Carlo","From Fisher Info"),bty="n")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Binomial example.
set.seed(495)
X   <- rbinom(100,10,0.25)
fit <- mleDb(X,ntop=10,zeta=TRUE)
if(HRDCPY) pdf(file="Figs/binEx.pdf",height=6)
OP <- par(mar=c(5,6,4,1)+0.1,cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
plot(fit,obsd=X,legPos=NULL,xlab="Count",ylab="Probability")
lines((0:10)+0.2,dbinom(0:10,10,0.25),type="h",col="green")
phat <- mean(X)/10
lines((0:10)+0.3,dbinom(0:10,10,phat),type="h",col="brown")
legend("topright",lty=1,col=c("red","blue","green","brown"),
       legend=c("fitted db","observed","true binom.","fitted binom."),
       bty="n")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Downloads.
X <- hmm.discnp::Downloads
fit <- mleDb(X,ntop=15,zeta=TRUE)
if(HRDCPY) pdf(file="Figs/dnLds.pdf",height=6)
OP <- par(mar=c(5,6,4,2)+0.1,cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
plot(fit,obsd=X,xlab="Count",ylab="Probability")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Sydney Coliform Counts
X    <- hmm.discnp::SydColDisc
X$y  <- as.numeric(X$y)
X    <- split(X,f=with(X,interaction(locn,depth)))
X    <- X[c("BondiE.0","BondiE.20","BondiE.40","BondiE.60")]
fitz <- lapply(X,function(x){mleDb(x$y,ntop=5)})
if(HRDCPY) pdf("Figs/sydCol.pdf",height=6)
OP <- par(mfrow=c(2,2),cex.axis=1.5,cex.lab=1.5,cex.main=1.5,oma=c(2,2,2,2))
par(mar=c(2,4,4,1)+0.1)
plot(fitz[[1]],xlab="",ylab="Probability",main="Depth = 0 meters",
     ylim=c(0,0.85),obsd=X[[1]]$y)
plot(fitz[[2]],xlab="",ylab="",main="Depth = 20 meters",legPos=NULL,
     ylim=c(0,0.85),
     obsd=X[[2]]$y)
par(mar=c(4,4,2,1)+0.1)
plot(fitz[[3]],xlab="Discretized counts",ylab="Probability",
     main="Depth = 40 meters",legPos=NULL,ylim=c(0,0.85),obsd=X[[3]]$y)
plot(fitz[[4]],xlab="Discretized counts",ylab="",
               main="Depth = 60 meters",legPos=NULL,ylim=c(0,0.85),
     obsd=X[[4]]$y)
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# 95% confidence ellipses for the parameters of the "BondiE" Sydney
# Coliform Counts data.
library(ellipse)
CMs <- lapply(fitz,vcov)
if(HRDCPY) pdf("Figs/sydColConfEll.pdf",height=6)
OP <- par(mfrow=c(2,2),cex.axis=1.5,cex.lab=1.5,cex.main=1.5,oma=c(2,2,2,2))
par(mar=c(4,5,4,1)+0.1)
for(i in 1:4) {
   xlab <- if(i %in% 3:4) expression(alpha) else ""
   ylab <- if(i %in% c(1,3)) expression(beta) else ""
   mane <- paste0("Depth = ",sub("BondiE.","",names(fitz)[i])," meters")
   plot(ellipse(CMs[[i]],centre=fitz[[i]],npoints=300),type="l",xlab=xlab,
        ylab=ylab,main=mane,xlim=c(-4,0.5),ylim=c(-3,5))
   points(fitz[[i]][1],fitz[[i]][2],pch=20,col="red")
}
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# 95% confidence ellipses for differences between the parameters
# at various depths for the "BondiE" Sydney Coliform Counts data.
if(HRDCPY) pdf("Figs/sydColConfEllDiffs.pdf",height=6)
OP <- par(mfrow=c(2,3),cex.axis=1.5,cex.lab=1.5,cex.main=1.5,oma=c(2,2,2,2))
mar=c(5,5,5,2)+0.1
k <- 0
for(i in 2:4) {
   Ci <- vcov(fitz[[i]])
   mane1 <- paste0("Depth ",sub("BondiE.","",names(fitz)[i])," minus\n ")
# Got here.
   for(j in 1:(i-1)) {
       k <- k+1
       xlab <- if(k %in% c(4:6)) expression(alpha) else ""
       ylab <- if(k %in% c(1,4)) expression(beta) else ""
       Cj <- vcov(fitz[[j]])
       mane2 <- paste0("depth ",sub("BondiE.","",names(fitz)[j]))
       mane  <- paste0(mane1,mane2)
       CM <- Ci + Cj
       cc <- fitz[[i]] - fitz[[j]]
       plot(ellipse(CM,centre=cc,npoints=300),type="l",
            xlim=c(-3,3),ylim=c(-5,4),xlab=xlab,ylab=ylab,main=mane)
       points(cc[1],cc[2],pch=20,col="red")
       points(0,0,pch=20,col="blue")
       legend("topleft",pch=20,col=c("red","blue"),legend=c("estimate","origin"),
              bty="n")
   }
}
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Comparison of "analytic" and Monte Carlo based 95% confidence
# ellipses for the parameters, and for differences between the parameters
# at different sites (location-depth combinations), of the db distribution
# fitted to the Sydney Coliform Count data.  These comparisons are made
# for the site and the combination of sites for which the difference
# between the two types of ellipse is greatest.

# Get fitz.
X    <- hmm.discnp::SydColDisc
X$y  <- as.numeric(X$y)
X    <- split(X,f=with(X,interaction(locn,depth)))
X    <- X[c("BondiE.0","BondiE.20","BondiE.40","BondiE.60")]
fitz <- lapply(X,function(x){mleDb(x$y,ntop=5)})
A3 <- vcov(fitz[[3]])
A4 <- vcov(fitz[[4]])
set.seed(969)
MC3 <- mcCovMat(fitz[[3]])
MC4 <- mcCovMat(fitz[[4]])

if(HRDCPY) pdf("Figs/biggestDiff.pdf",height=6)
OP <- par(mfrow=c(2,2),cex.axis=1.5,cex.lab=1.5,cex.main=1.5,oma=c(2,2,2,2))
par(mar=c(4,5,4,1)+0.1)
# 95% confidence ellipses for the parameters of the "BondiE" Sydney
# Coliform Counts data at depth 40 using "analytic" covariance matrix.
plot(ellipse(A3,centre=fitz[[3]],npoints=300),type="l",xlab="",
    ylab=expression(beta),main="Analytic CM",xlim=c(-4.5,0.5),ylim=c(-5,5))
points(fitz[[3]][1],fitz[[3]][2],pch=20,col="red")

# 95% confidence ellipses for the parameters of the "BondiE" Sydney
# Coliform Counts data at depth 40 using Monte Carlo covariance matrix.
plot(ellipse(MC3,centre=fitz[[3]],npoints=300),type="l",xlab="",
     ylab="",,main="Monte Carlo CM",xlim=c(-4.5,0.5),ylim=c(-5,5))
points(fitz[[3]][1],fitz[[3]][2],pch=20,col="red")

# 95% confidence ellipses for differences between the parameters
# at depth 60 and depth 40 for the "BondiE" Sydney Coliform Counts data.
# using "analytic" covariance matrices
CM <- A3 + A4
cc <- fitz[[4]] - fitz[[3]]
plot(ellipse(CM,centre=cc,npoints=300),type="l",xlab=expression(alpha),
     ylab=expression(beta),main="",xlim=c(-5,5),ylim=c(-11,11))
points(cc[1],cc[2],pch=20,col="red")
points(0,0,pch=20,col="blue")
legend("topleft",pch=20,col=c("red","blue"),legend=c("estimate","origin"),
       bty="n")

# 95% confidence ellipses for differences between the parameters
# at depth 60 and depth 40 for the "BondiE" Sydney Coliform Counts data.
# using Monte Carlo covariance matrices
CM <- MC3 + MC4
cc <- fitz[[4]] - fitz[[3]]
plot(ellipse(CM,centre=cc,npoints=300),type="l",xlab=expression(alpha),ylab="",
     xlim=c(-5,5),ylim=c(-11,11),main="")
points(cc[1],cc[2],pch=20,col="red")
points(0,0,pch=20,col="blue")
legend("topleft",pch=20,col=c("red","blue"),legend=c("estimate","origin"),
       bty="n")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Monocyte counts and psychosis ratings.
load("hmmFits.rda")

objs   <- list(ccfit.3.33,prfit.3.36)
xs     <- list(1:5,0:4)
ns     <- c(5,4)
zs     <- c(FALSE,TRUE)
xlabs  <- c("Discretized monocyte counts","Psychosis rating")
phials <- c("Figs/mono.pdf","Figs/psych.pdf")

for(i in 1:2) {
    obj <- objs[[i]]
    x   <- xs[[i]]
    p <- vector("list",3)
    for(k in 1:3) {
        phi    <- obj[["phi"]][[k]]
        p[[k]] <- ddb(x,phi[1],phi[2],ntop=ns[i],zeta=zs[i])
    }
    ylim <- c(0,max(unlist(p)))
    if(HRDCPY) pdf(file=phials[i],height=6)
    OP <- par(mfrow=c(2,2),cex.axis=1.5,cex.lab=1.5,cex.main=1.5,oma=c(2,2,2,2))
    par(mar=c(4,5,4,1)+0.1)
    for(k in 1:3) {
        plot(x,p[[k]],type="h",ylim=ylim,main=paste0("State ",k),
             col="red",xlab=xlabs[i],ylab="Probability")
    }
    if(HRDCPY) dev.off() else {
        readline("Go? ")
        par(OP)
    }
}

# MSE plots.
mseEsts <- MSE()

if(HRDCPY) pdf(file="Figs/eme.vs.mle.pdf",height=6)
OP <- par(cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
with(mseEsts,plot(MSEmaxLike,MSEmomExct,xlab="MSE for maximum likelihood",
    ylab="MSE for the exact moment method"))
abline(0,1,col="red")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

if(HRDCPY) pdf(file="Figs/ame.vs.mle.pdf",height=6)
OP <- par(cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
with(mseEsts,plot(MSEmaxLike,MSEmomAppr,xlab="MSE for maximum likelihood",
    ylab="MSE for the approximate moment method"))
abline(0,1,col="red")
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

if(HRDCPY) pdf(file="Figs/mle.vs.absParDiff.pdf",height=6)
OP <- par(cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
with(mseEsts,plot(abs(alpha-beta),MSEmaxLike,
                  xlab=expression(paste("|",alpha-beta,"|",sep="")),
                  ylab="MSE for maximum likelihood"))
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Confidence intervals for mean bias in estimates.
if(file.exists("cidf.rda")) {
    load("cidf.rda")
} else {
    cidf <- makeCIs()
    save(cidf,file="cidf.rda")
}
ciPlot <- plotCIs(cidf)
if(HRDCPY) pdf(file="Figs/biasCIs.pdf",height=6)
print(ciPlot)
if(HRDCPY) dev.off() else {
    readline("Go? ")
    par(OP)
}

# Example of some wild estimates of the overdispersion parameter`
# of the beta binomial distribution.
if(!requireNamespace("rmutil")) {
    cat("Package \"rmutil\" must be available to do this part.\n")
} else {
    xxx <- vector("list",100)
    yyy <- vector("list",100)
    ndata <- 30
    set.seed(911)
    for(i in 1:100) {
       repeat {
           xxx[[i]] <- rmutil::rbetabinom(n=ndata,size=10,m=0.75,s=10)
           yyy[[i]] <- try(mleBb(xxx[[i]],size=10,par0=c(m=0.75,s=10),covmat=TRUE))
           if(!inherits(yyy[[i]],"try-error")) break
       }
       cat(i,"")
       if(i %% 10 == 0) cat("\n")
    }
    fx <- sapply(yyy,function(u){u["s"]})
    if(HRDCPY) pdf(file="Figs/wilds.pdf",height=6)
    OP <- par(mar=c(5,6,4,1)+0.1,cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
    plot(fx,type="h",xlab="",ylab=expression(hat(s)))
    if(HRDCPY) dev.off() else par(OP)
    x.hi <- xxx[[which.max(fx)]]
    CM <- solve(finfo(distr="b",x=x.hi,m=0.75,s=10,size=10))
    cat("Analytic estimate of the variance of s.hat: ",CM[2,2],"\n")
}

#
# Tables.
#

# Table of estimates of alpha and beta.`
Nsim <- 100
Ndat <- 1000
Alpha <- Beta <- c(3,6,9)
set.seed(924)
seeds <- sample(1:1024,9)
abTbl  <- vector("list",9)
K <- 0
for(i in 1:3) {
    for(j in 1:3) {
        K <- K + 1
        obj  <- makeDbdpars(alpha=Alpha[i],beta=Beta[j],ntop=10,zeta=TRUE,ndata=Ndat)
        sam  <- simulate(obj,nsim=Nsim,seed=seeds[K])
        fitz <- lapply(sam,mleDb,ntop=10,zeta=TRUE)
        ests <- matrix(unlist(fitz),ncol=2,byrow=TRUE)
        mHat <- apply(ests,2,mean)
        sHat <- apply(ests,2,sd)/sqrt(Ndat)
        v    <- c(Alpha[i],Beta[j],mHat[1],mHat[1]-1.96*sHat[1],mHat[1]+1.96*sHat[1],
                                   mHat[2],mHat[2]-1.96*sHat[2],mHat[2]+1.96*sHat[2])
        abTbl[[K]] <- v
    }
}
abTbl <- matrix(unlist(abTbl),byrow=TRUE,nrow=9)
abTbl <- round(abTbl,3)

abTbl <- cbind(abTbl[,1:3],paste0("(",abTbl[,4],", ",abTbl[,5],")"),
               abTbl[,6],paste0("(",abTbl[,7],", ",abTbl[,8],")"))
library(xtable)
abTbl <- xtable(abTbl,align="l|cc|c|c|c|c|")
print(abTbl,file="abTbl.tex",include.rownames=FALSE)

# Table of mean squared error values.

mseEsts <- MSE()
mseTbl <- with(mseEsts,data.frame(alpha=alpha,beta=beta,apprxMom=MSEmomAppr,
                                  exactMom=MSEmomExct,maxLike=MSEmaxLike))
ok <- with(mseTbl,alpha%in%c(0,5,10) & beta%in%c(0,2,4,6,8,10))
mseTbl <- mseTbl[ok,]
rownames(mseTbl) <- 1:nrow(mseTbl)
library(xtable)
mseTbl <- xtable(mseTbl,align="l|r|r|rrr|")
print(mseTbl,file="mseTbl.tex",include.rownames=FALSE)
