##########################################################
#################### Replication code ####################
##########################################################



### install marqLevAlg package from CRAN and load it
install.packages("marqLevAlg")
library("marqLevAlg")




############### code of section 4 : example ###############

## This section uses the dataset dataEx and the functions loglikLMM and gradLMM included in the marqLevAlg package. 

## We first define the quantities to include as argument in loglikLMM function:
Y <- dataEx$Y
X <- as.matrix(cbind(1, dataEx[, c("t", "X1", "X3")], dataEx$t * dataEx$X1))
ni <- as.numeric(table(dataEx$i))
binit <- c(0, 0, 0, 0, 0, 1, 1)

## maximum likelihood estimation of the linear mixed model in sequential mode :
estim <- marqLevAlg(b = binit, fn = loglikLMM, minimize = FALSE, 
                    X = X, Y = Y, ni = ni)
estim

summary(estim, loglik = TRUE)

## exact same model estimated in parallel mode using FORK implementation of parallelism : 
estim2 <- marqLevAlg(b = binit, fn = loglikLMM, minimize = FALSE, 
                     nproc = 2, clustertype = "FORK", 
                     X = X, Y = Y, ni = ni)

## estimation by using analytical gradients :
estim3 <- marqLevAlg(b = binit, fn = loglikLMM, gr = gradLMM, 
                     minimize = FALSE, X = X, Y = Y, ni = ni)


## 2 functions to summarize the results :
res <- function(x, core, gradient){
  res <- data.frame(core = core, gradient = gradient, loglik = x$fn, 
                    iterations = x$ni,
                    criterion1 = x$ca,
                    criterion2 = x$cb,
                    criterion3 = x$rdm)
  rownames(res) <- paste("Object ", deparse(substitute(x)), sep = "")
  colnames(res) <- c("Number of cores", "Analytical gradient", "Objective Function", "Number of iterations", "Parameter Stability", "Likelihood stability", "RDM")
  return(t(res))
}

coef <- function(x){
  coef <- cbind(x$b, sqrt(x$v[c(1, 3, 6, 10, 15, 21, 28)]))
  colnames(coef) <- c(paste("Coef (", deparse(substitute(x)), ")", sep = ""),
                  paste("SE (", deparse(substitute(x)), ")", sep = ""))
  rownames(coef) <- paste("Parameter", 1:7)  
  return(round(coef, digits = 4))
}


## Table 1 in the manuscript
cbind(res(estim, 1, "no"), res(estim2, 2, "no"), res(estim3, 1, "yes"))

## Table 2 in the manuscript
cbind(coef(estim), coef(estim2), coef(estim3))



############### code of section 5 : benckmark ###############

## In this section, we propose a benchmark on 3 different examples from the mixed models area. They rely on packages that can be downloaded on the github page https://github.com/VivianePhilipps/marqLevAlgPaper/.
## We give the code to estimate all models once with a various number of cores.
## The results obtained on 100 replications are stored in the res_JM_hlme_CInLPN.RData file and we provide the code to replicate Table 3 and Figure 1 of the manuscript.

## install all packages after downloading them

install.packages("CInLPN_0.2.0.tar.gz")
install.packages("JM_1.5-0.tar.gz")
install.packages("lcmmMLA_1.0.tar.gz")


## loading simulated dataset

load("data_mla.RData")
data_mla[c(1:5, 22:26, 43:47), c("i", "class", "X1", "X2", "X3", "t", "Ycens", "tsurv", "event")]


## one replication for "JM" models (numerical and analytical derivatives)

library("JM")
load("data_mla_5000.RData")
load("lmeFit.RData")
load("coxFit.RData")

core <- c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30)


### JM with numerical derivatives

sortie <- NULL

for(k in core) {

 JM <- jointModel(lmeObject = lmeFit,
               survObject = coxFit,
               timeVar = "t",
               parameterization = "value",
               method = "spline-PH-aGH",
               control = list(optimizer="marq",GHk = 3, lng.in.kn = 1,
                iter.EM=0,iter.qN=50,nproc=k, numeriDeriv=TRUE),
               verbose = TRUE)

sortie <- rbind(sortie,c(k,JM$CPUtime,JM$logLik,JM$iters,JM$convergence))
colnames(sortie) <- c("core","CPUtime","logLik","iters","convergence")
}

### JM with anaytical derivatives

sortie <- NULL

for(k in core) {

 JM <- jointModel(lmeObject = lmeFit,
               survObject = coxFit,
               timeVar = "t",
               parameterization = "value",
               method = "spline-PH-aGH",
               control = list(optimizer="marq",GHk = 3, lng.in.kn = 1,
                iter.EM=0,iter.qN=50,nproc=k, numeriDeriv=FALSE),
               verbose = TRUE)

sortie <- rbind(sortie,c(k,JM$CPUtime,JM$logLik,JM$iters,JM$convergence))
colnames(sortie) <- c("core","CPUtime","logLik","iters","convergence")
}



## one replication for "hlme" models (1 to 4 latent classes)

library("lcmmMLA")

## one latent class

sortie <- NULL

for(k in core) {
    mG1 <- hlme(Y~1+I(t/10)+I((t/10)^2), random=~1+I(t/10)+I((t/10)^2),
                subject="i",ng=1,data=data_mla,verbose=FALSE,maxiter=30,nproc=k)

sortie <- rbind(sortie,c(k,mG1$time,mG1$loglik,mG1$ni,mG1$istop))
colnames(sortie) <- c("core","CPUtime","logLik","iters","convergence")
}


## 2 latent classes

b2 <- c(0, 0, 0, 0, 54.2713165484272, 51.9692401385805, 2.4708605906538, 
5.53807280570749, -8.82863376679862, -8.18035913550552, 329.06447101401, 
-108.035593294684, 153.357722977144, -11.2339964792991, -166.00077515535, 
244.634691319755, 1, 4.34225696290442)

sortie <- NULL

for(k in core) {
    mG2 <- hlme(Y~1+I(t/10)+I((t/10)^2), random=~1+I(t/10)+I((t/10)^2),
                mixture=~1+I(t/10)+I((t/10)^2),nwg=TRUE,classmb=~X1+X2+X3,
                subject="i",ng=2,data=data_mla,verbose=FALSE,maxiter=30,nproc=k,B=b2)

sortie <- rbind(sortie,c(k,mG2$time,mG2$loglik,mG2$ni,mG2$istop))
colnames(sortie) <- c("core","CPUtime","logLik","iters","convergence")
}


## 3 latent classes

b3 <- c(0, 0, 0, 0, 0, 0, 0, 0, 53.0945627380509, 53.2399420396394, 
54.4269074001362, 5.26465623011422, 3.79143012314735, 6.23839975066632, 
-9.44143356198573, -10.4950552552757, -10.1529978271412, 292.751768720462, 
-80.2567239174774, 132.206422427329, -9.92168321839977, -152.906018466692, 
220.23371919073, 1, 1, 4.40372813987142)

sortie <- NULL

for(k in core) {
    mG3 <- hlme(Y~1+I(t/10)+I((t/10)^2), random=~1+I(t/10)+I((t/10)^2),
                mixture=~1+I(t/10)+I((t/10)^2),nwg=TRUE,classmb=~X1+X2+X3,
                subject="i",ng=3,data=data_mla,verbose=FALSE,maxiter=30,nproc=k,B=b3)

sortie <- rbind(sortie,c(k,mG3$time,mG3$loglik,mG3$ni,mG3$istop))
colnames(sortie) <- c("core","CPUtime","logLik","iters","convergence")
}


## 4 latent classes

b4 <- c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 52.8490592741525, 55.6394754968402, 
54.1545598758033, 52.9982705556955, 3.35731963419959, 6.97751925567454, 
4.9458820485929, 5.14394239823614, -6.64671457489409, -10.4877076311514, 
-8.03560028321582, -9.41373051406899, 248.988298845135, -81.2369505771433, 
145.484846690813, -3.58765944283958, -172.145995642558, 252.738512339079, 
1, 1, 1, 4.5231699453073)

sortie <- NULL

for(k in core) {
    mG4 <- hlme(Y~1+I(t/10)+I((t/10)^2), random=~1+I(t/10)+I((t/10)^2),
                mixture=~1+I(t/10)+I((t/10)^2),nwg=TRUE,classmb=~X1+X2+X3,
                subject="i",ng=4,data=data_mla,verbose=FALSE,maxiter=30,nproc=k,B=b4)

sortie <- rbind(sortie,c(k,mG4$time,mG4$loglik,mG4$ni,mG4$istop))
colnames(sortie) <- c("core","CPUtime","loglik","iters","convergence")
}



## one replication for "CInLPN" models

library("CInLPN")

epsa <- 0.0001
epsb <- 0.0001
epsd <- 0.0001
paras.ini <- NULL
paras.ini <- c(0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,0,1,rep(0,9),rep(1,9))

indexparaFixeUser <- c(1,2,3,6+c(1, 2,3,5,6, 7, 8,9,11, 12, 13,14,17,18,20))
paraFixeUser <- c(0,0,0,1,rep(0,4),1,rep(0,3),1,rep(0,5))

DeltaT <- 1

sortie <- NULL

for(k in core) {
    mod <- CInLPN(structural.model = list(fixed.LP0 = ~1|1|1,fixed.DeltaLP = L1 | L2 | L3 ~ 1|1|1,random.DeltaLP = ~1|1|1,trans.matrix = ~1,delta.time = DeltaT),
                   measurement.model = list(link.functions = list(links = c(NULL, NULL, NULL),knots = list(NULL, NULL, NULL))),
                   parameters = list(paras.ini = paras.ini, Fixed.para.index = indexparaFixeUser, Fixed.para.values = paraFixeUser),
                   option = list(parallel = TRUE, nproc = k, print.info = FALSE, epsa = epsa, epsb = epsb, epsd = epsd,maxiter=50,univarmaxiter = 7, makepred = FALSE),
                  Time = "time", subject = "id", data = data)

sortie <- rbind(sortie,c(k,mod$MLAtime,mod$loglik,mod$niter,mod$conv))
colnames(sortie) <- c("core","CPUtime","logLik","iters","convergence")
}



## Load results obtained by running the preceding code 100 times on a cluster 
load("res_JM_hlme_CInLPN.RData")

## Table 3
table3 <- cbind(c(40, 16, 40, round(temps_JM_analyDeriv[1, 1]), round(res_JM_analyDeriv[-1, 1], 2)),
  c(40, 16, 860, round(temps_JM_numeriDeriv[1, 1]), round(res_JM_numeriDeriv[-1, 1], 2)),
  c(10, 30, 65, round(temps_hlme_G1[1, 1]), round(res_hlme_G1[-1, 1], 2)),
  c(18, 30, 189, round(temps_hlme_G2[1, 1]), round(res_hlme_G2[-1, 1], 2)),
  c(26, 30, 377, round(temps_hlme_G3[1, 1]), round(res_hlme_G3[-1, 1], 2)),
  c(34, 30, 629, round(temps_hlme_G4[1, 1]), round(res_hlme_G4[-1, 1], 2)),
  c(27, 13, 405, round(temps_CInLPN[1, 1]), round(res_CInLPN[-1, 1], 2)))
rownames(table3) <- c("Number of parameters", "Number of iterations", "Number of elements in foreach loop", "Sequential time (seconds)",  "Speed up with 2 cores", "Speed up with 3 cores", "Speed up with 4 cores", "Speed up with 6 cores", "Speed up with 8 cores", "Speed up with 10 cores", "Speed up with 15 cores", "Speed up with 20 cores", "Speed up with 25 cores", "Speed up with 30 cores")
table3


## Figure 1
library("ggplot2")
library("viridis")
library("patchwork")
pJM <- ggplot(data = cbind.data.frame("ncores" = rep(c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30), 2),
                               "speedup" = c(res_JM_numeriDeriv[, 1],
                                             res_JM_analyDeriv[, 1]),
                               "method" = factor(rep(c("Numeric gradient", "Analytical gradient"), each = 11), 
                                                 levels = c("Numeric gradient", "Analytical gradient"), ordered = TRUE),
                               "lowbound" = c(res_JM_numeriDeriv[, 1] - 1.96 * res_JM_numeriDeriv[, 2],
                                              res_JM_analyDeriv[, 1] - 1.96 * res_JM_analyDeriv[, 2]),
                               "upbound" = c(res_JM_numeriDeriv[, 1] + 1.96 * res_JM_numeriDeriv[, 2], 
                                             res_JM_analyDeriv[, 1] + 1.96 * res_JM_analyDeriv[, 2])
                               ),  
       aes(x = ncores)) +
  geom_ribbon(aes(ymin = lowbound, ymax = upbound, fill = method), alpha = 0.4) +
  geom_point(aes(y = speedup, colour = method)) +
  geom_line(aes(y = speedup, colour = method)) +
  theme_classic() +
  scale_x_continuous(minor_breaks = c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30), breaks = c(1, 5, 10, 15, 20, 25, 30)) +
  theme(panel.grid.major.y = element_line(), 
        panel.grid.minor.y = element_blank(),
        axis.title = element_text(size = 16),
        axis.text  = element_text(size = 14),
        title = element_text(size = 17, face = "bold"),
        legend.margin = margin(-30, 10, 10, 10),
        legend.position = "bottom", legend.direction = "vertical",
        legend.text = element_text(size = 14)) +
  xlab("Number of cores") +
  ylab("Speed-up") +
  scale_color_manual("", values = rev(viridis::inferno(5)[3:4])) +
  scale_fill_manual("", values = rev(viridis::inferno(5)[3:4])) +
  ggtitle("JM") +
  guides(fill="none") +
  NULL

phlme <- ggplot(data = cbind.data.frame("ncores" = rep(c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30), 4),
                               "speedup" = c(res_hlme_G1[, 1], res_hlme_G2[, 1],
                                             res_hlme_G3[, 1], res_hlme_G4[, 1]),
                               "nbclass" = factor(rep(c("1 class", "2 classes", "3 classes", "4 classes"), each = 11), 
                                                 levels = c("1 class", "2 classes", "3 classes", "4 classes"), ordered = TRUE),
                               "lowbound" = c(res_hlme_G1[, 1] - 1.96 * res_hlme_G1[, 2], res_hlme_G2[, 1] - 1.96 * res_hlme_G2[, 2],
                                              res_hlme_G3[, 1] - 1.96 * res_hlme_G3[, 2], res_hlme_G4[, 1] - 1.96 * res_hlme_G4[, 2]),
                               "upbound" = c(res_hlme_G1[, 1] + 1.96 * res_hlme_G1[, 2], res_hlme_G2[, 1] + 1.96 * res_hlme_G2[, 2],
                                              res_hlme_G3[, 1] + 1.96 * res_hlme_G3[, 2], res_hlme_G4[, 1] + 1.96 * res_hlme_G4[, 2])
                               ),  
       aes(x = ncores)) +
  geom_ribbon(aes(ymin = lowbound, ymax = upbound, fill = nbclass), alpha = 0.4) +
  geom_point(aes(y = speedup, colour = nbclass)) +
  geom_line(aes(y = speedup, colour = nbclass)) +
  theme_classic() +
  scale_x_continuous(minor_breaks = c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30), breaks = c(1, 5, 10, 15, 20, 25, 30)) +
  theme(panel.grid.major.y = element_line(), 
        panel.grid.minor.y = element_blank(),
        axis.title = element_text(size = 16),
        axis.text  = element_text(size = 14),
        title = element_text(size = 17, face = "bold"),
        legend.margin = margin(-30, 10, 10, 10),
        legend.position = "bottom", legend.direction = "vertical",
        legend.text = element_text(size = 14)) +
  xlab("Number of cores") +
  ylab("Speed-up") +
  scale_color_manual("", values = rev(viridis::viridis(5)[1:4])) +
  scale_fill_manual("", values = rev(viridis::viridis(5)[1:4])) +
  ggtitle("hlme") +
  guides(fill = "none", color = guide_legend(ncol = 2)) +
  NULL
  

pCInLPN <- ggplot(data = cbind.data.frame("ncores" = rep(c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30), 1),
                               "speedup" = res_CInLPN[, 1],
                               "lowbound" = res_CInLPN[, 1] - 1.96 * res_CInLPN[, 2],
                               "upbound" = res_CInLPN[, 1] + 1.96 * res_CInLPN[, 2]
                               ),  
       aes(x = ncores)) +
  geom_ribbon(aes(ymin = lowbound, ymax = upbound, fill = "95% Conf. Int."), alpha = 0.4) +
  geom_point(aes(y = speedup, color = "95% Conf. Int.")) +
  geom_line(aes(y = speedup, color = "95% Conf. Int.")) +
  theme_classic() +
  scale_x_continuous(minor_breaks = c(1, 2, 3, 4, 6, 8, 10, 15, 20, 25, 30), breaks = c(1, 5, 10, 15, 20, 25, 30)) +
  theme(panel.grid.major.y = element_line(), 
        panel.grid.minor.y = element_blank(),
        axis.title = element_text(size = 16),
        axis.text  = element_text(size = 14),
        title = element_text(size = 17, face = "bold"),
        legend.margin = margin(-10, 10, 10, 10),
        legend.position = "bottom",
        legend.text = element_text(size = 14)) +
  scale_color_manual("", values = "black") +
  scale_fill_manual("", values = "black") +
  xlab("Number of cores") +
  ylab("Speed-up") +
  ggtitle("CInLPN") +
  NULL

(pJM + ylim(0, 18)) + (phlme + ylim(0, 18)) + (pCInLPN + ylim(0, 18))



############### code of section 6 : comparison with other optimization algorithms ###############

## prothro data from JM package
prothro$t0 <- as.numeric(prothro$time == 0)

## initial models
lmeFit <- nlme::lme(pro ~ treat * (time + t0), random = ~ time | id, data = prothro)
survFit <- survival::coxph(Surv(Time, death) ~ treat, data = prothros, x = TRUE)

##derivForm
dFpro <- list(fixed = ~ 1 + treat, indFixed = c(3, 5), random = ~ 1, indRandom = 2)


## 0.1 scaling
prothro$pro01 <- prothro$pro / 10
lmeFit01 <- lme(pro01 ~ treat * (time + t0), random = ~ time | id, data = prothro)

## 10 scaling
prothro$pro10 <- prothro$pro * 10
lmeFit10 <- lme(pro10 ~ treat * (time + t0), random = ~ time | id, data = prothro)


## dependency : current value

## estimation by BFGS algorithm from optim function, scaling 1, 0.1 and 10 :

jm_pro_val_GH15_BFGS <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_val_GH15_BFGS <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_val_GH15_BFGS <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)


## estimation by L-BFGS-B algorithm from optimParallel, scaling 1, 0.1 and 10 :

jm_pro_val_GH15_LBFGSB <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_val_GH15_LBFGSB <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_val_GH15_LBFGSB <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)
if(!exists("jm_pro10_val_GH15_LBFGSB"))
{
    jm_pro10_val_GH15_LBFGSB <- vector("list",length(jm_pro_val_GH15_LBFGSB))
    names(jm_pro10_val_GH15_LBFGSB) <- names(jm_pro_val_GH15_LBFGSB)
    jm_pro10_val_GH15_LBFGSB$convergence <- 1
    jm_pro10_val_GH15_LBFGSB$iters <- 0
    jm_pro10_val_GH15_LBFGSB$logLik <- NA
    jm_pro10_val_GH15_LBFGSB$coefficients <- list(Dalpha=NA, alpha=NA)
    jm_pro10_val_GH15_LBFGSB$qNtime <- NA
}


## estimation by EM, scaling 1, 0.1 and 10 :

jm_pro_val_GH15_EM <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)

jm_pro01_val_GH15_EM <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)

jm_pro10_val_GH15_EM <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)


## estimation by marqLevAlg, scaling 1, 0.1 and 10 :

jm_pro_val_GH15_marq <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_val_GH15_marq <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_val_GH15_marq <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)



## dependency : current slope

## estimation by BFGS algorithm from optim function, scaling 1, 0.1 and 10 :

jm_pro_slo_GH15_BFGS <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_slo_GH15_BFGS <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_slo_GH15_BFGS <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)


## estimation by L-BFGS-B algorithm from optimParallel, scaling 1, 0.1 and 10 :

jm_pro_slo_GH15_LBFGSB <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_slo_GH15_LBFGSB <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_slo_GH15_LBFGSB <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)


## estimation by EM, scaling 1, 0.1 and 10 :

jm_pro_slo_GH15_EM <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)

jm_pro01_slo_GH15_EM <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)

jm_pro10_slo_GH15_EM <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)


## estimation by marqLevAlg, scaling 1, 0.1 and 10 :

jm_pro_slo_GH15_marq <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_slo_GH15_marq <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_slo_GH15_marq <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="slope",derivForm=dFpro,control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)



## dependency : current value and current slope

## estimation by BFGS algorithm from optim function, scaling 1, 0.1 and 10 :

jm_pro_both_GH15_BFGS <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_both_GH15_BFGS <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_both_GH15_BFGS <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="optim",GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)


## estimation by L-BFGS-B alogorithm from optimParallel, scaling 1, 0.1 and 10 :

jm_pro_both_GH15_LBFGSB <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_both_GH15_LBFGSB <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_both_GH15_LBFGSB <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="optim",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)


## estimation by EM, scaling 1, 0.1 and 10 :

jm_pro_both_GH15_EM <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)

jm_pro01_both_GH15_EM <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)

jm_pro10_both_GH15_EM <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(GHk = 15,lng.in.kn = 1,iter.EM=1000,iter.qN=0),verbose = TRUE)


## estimation by marqLevAlg, scaling 1, 0.1 and 10 :

jm_pro_both_GH15_marq <- jointModel(lmeFit, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro01_both_GH15_marq <- jointModel(lmeFit01, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)

jm_pro10_both_GH15_marq <- jointModel(lmeFit10, survFit, timeVar = "time",method = "spline-PH-aGH",parameterization="both",derivForm=dFpro,control=list(optimizer="marq",nproc=3,GHk = 15,lng.in.kn = 1,iter.EM=0,iter.qN=1000),verbose = TRUE)


## Table 4
a <- expand.grid(c("", "01", "10"), c("val", "slo", "both"), "GH15", c("BFGS", "LBFGSB", "EM", "marq"), stringsAsFactors=FALSE)
a <- a[order(a[,2], decreasing=TRUE),]
mod <- apply(a, 1, function(x) paste("jm_pro", paste(x, collapse = "_"), sep = ""))


res <- matrix(NA, 27+9, 7)
table4 <- data.frame(dep=rep(c("value","slope","both"), each=12),
                   algorithm = a[,4], scaling = "1", loglik=0, value = 0, slope = 0,
                   iterations=0, time=0)

k <- 0
for(m in mod)
{
  k <- k + 1
  jm <- get(m)
  
  sc <- 1
  if(length(grep("pro10", m))) sc <- 10
  if(length(grep("pro01", m))) sc <- 0.1

  res[k, 1] <- jm$convergence
  res[k, 2] <- jm$iters
  res[k, 3] <- jm$logLik
  res[k, 4] <- jm$logLik + nrow(prothro) * log(sc)
  if(!length(jm$coefficients$Dalpha)) res[k, 7] <- NA else res[k, 7] <- as.numeric(jm$coefficients$Dalpha)
  if(!length(jm$coefficients$alpha)) res[k, 6] <- NA else  res[k, 6] <- as.numeric(jm$coefficients$alpha)
  if(!is.null(jm$qNtime)) res[k, 5] <- jm$qNtime[3]
  if(length(grep("EM", m))) res[k, 5] <- jm$EMtime

  table4$scaling[k] <- sc
  table4$loglik[k] <- res[k,4]
  table4$value[k] <- res[k,6]*sc
  table4$slope[k] <- res[k,7]*sc
  table4$iterations[k] <- res[k,2]
  table4$time[k] <- res[k,5]
}

colnames(res) <- c("convergence", "iterations", "LogLik", "scaledLogLik", "time", "alpha", "Dalpha")

table4$value[1:12] <- 100 * (table4$value[1:12] - table4$value[10]) / table4$value[10]
table4$slope[13:24] <- 100 * (table4$slope[13:24] - table4$slope[22]) / table4$slope[22]

table4$value[25:36] <- 100 * (table4$value[25:36] - table4$value[34]) / table4$value[34]
table4$slope[25:36] <- 100 * (table4$slope[25:36] - table4$slope[34]) / table4$slope[34]

table4



#######################################################
############### supplementary materials ###############
#######################################################

library("marqLevAlg")
library("funconstrain")
library("parallel")
library("optimParallel")
library("minpack.lm")
library("nlmrt")
library("microbenchmark")
library("rgenoud")
library("DEoptim")
library("hydroPSO")
library("GA")


############### code of section 1 : examples from the litterature ###############


## 35 problems implemented in funconstrain package
pb <- list(rosen(), freud_roth(), powell_bs(), brown_bs(), beale(), jenn_samp(m=10), helical(), bard(), gauss(), meyer(), gulf(m=99), box_3d(m=20), powell_s(), wood(), kow_osb(), brown_den(m=20), osborne_1(), biggs_exp6(m=13), osborne_2(), watson(), ex_rosen(), ex_powell(), penalty_1(), penalty_2(), var_dim(), trigon(), brown_al(), disc_bv(), disc_ie(), broyden_tri(),broyden_band(), linfun_fr(m=100), linfun_r1(m=100), linfun_r1z(m=100), chebyquad())

## initial values
init <- lapply(pb,"[[", name="x0")

vi <- lapply(init, function(x) {if(class(x)=="function") do.call(x,list()) else x})
vi[[20]] <- rep(0, 6) # watson n=6
vi[[23]] <- 1:4 #penalty_1 n=4
vi[[24]] <- rep(0.5, 4) #penalty_2 n=4
n <- 35
vi[[28]] <- (1:n * (1/(n+1))) * ( (1:n * (1/(n+1))) -1)
vi[[29]] <- (1:n * (1/(n+1))) * ( (1:n * (1/(n+1))) -1)
vi[[35]] <- 1:7/8

## objective function's value at optimum
solutionf <- c(0, 48.9842, 0, 0, 0, 124.362, 0, 8.21487e-3, 1.12793e-8, 87.9458, 0, 0, 0, 0, 3.07505e-4, 85822.2, 5.46489e-5, 5.65565e-3, 4.01377e-2, 2.28767e-3,0, 0, 2.24997e-5, 9.37629e-6, 0, 0, 0, 0,0,0,0, 55, (100*99)/(2*(200+1)),(100^2+300-6)/(2*(200-3)), 0)

## set default cluster (needed for optimParallel)
cl <- parallel::makeCluster(1)
setDefaultCluster(cl)

## initialize the matrix of results
res35 <- matrix(NA, nrow=35, ncol=8)
rownames(res35) <- c("rosen", "freud_roth", "powell_bs", "brown_bs","beale", "jenn_samp", "helical", "bard", "gauss", "meyer", "gulf", "box_3d", "powell_s", "wood","kow_osb", "brown_den", "osborne_1", "biggs_exp6","osborne_2", "watson", "ex_rosen", "ex_powell", "penalty_1","penalty_2", "var_dim", "trigon", "brown_al", "disc_bv","disc_ie", "broyden_tri", "broyden_band", "linfun_fr", "linfun_r1", "linfun_r1z", "chebyquad")
colnames(res35) <- c("solution", "marqLevAlg", "Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "optimParallel", "nlminb")
res35[,1] <- solutionf

## run the optimizations
for(k in 1:35)
{
    resmla <- mla(b=vi[[k]], fn=pb[[k]]$fn, gr=pb[[k]]$gr, maxiter=500)
    if(resmla$istop!=1) res35[k,2] <- NA else res35[k,2] <- resmla$fn.value

    resoptim <- optim(par=vi[[k]], fn=pb[[k]]$fn, gr=pb[[k]]$gr, method="Nelder-Mead",control=list(maxit=500), hessian=TRUE)
    if(resoptim$convergence!=0) res35[k,3] <- NA else res35[k,3] <- resoptim$value
    rm(resoptim)
    
    resoptim <- optim(par=vi[[k]], fn=pb[[k]]$fn, gr=pb[[k]]$gr, method="BFGS",control=list(maxit=500), hessian=TRUE)
    if(resoptim$convergence!=0) res35[k,4] <- NA else res35[k,4] <- resoptim$value
    rm(resoptim)
    
    resoptim <- optim(par=vi[[k]], fn=pb[[k]]$fn, gr=pb[[k]]$gr, method="CG",control=list(maxit=500), hessian=TRUE)
    if(resoptim$convergence!=0) res35[k,5] <- NA else res35[k,5] <- resoptim$value
    rm(resoptim)
    
    try(resoptim <- optim(par=vi[[k]], fn=pb[[k]]$fn, gr=pb[[k]]$gr, method="L-BFGS-B",control=list(maxit=500), hessian=TRUE), silent=TRUE)
    res35[k,6] <- NaN
    if(exists("resoptim"))
    {
        if(resoptim$convergence!=0) res35[k,6] <- NA else res35[k,6] <- resoptim$value
        rm(resoptim)
    }
    
    try(resoptp <- optimParallel(par=vi[[k]], fn=pb[[k]]$fn, gr=pb[[k]]$gr, control=list(maxit=500), hessian=TRUE, parallel=cl), silent=TRUE)
    res35[k,7] <- NaN
    if(exists("resoptp"))
    {
        if(resoptp$convergence!=0) res35[k,7] <- NA else res35[k,7] <- resoptp$value
        rm(resoptp)
    }
        
    resnlm <- nlminb(vi[[k]], pb[[k]]$fn, pb[[k]]$gr, control=list(iter.max=500))
    if(resnlm$convergence!=0) res35[k,8] <- NA else res35[k,8] <- resnlm$objective
    rm(resnlm)
}


## results : absolute biases
round(sweep(res35[,-c(1)], 1, res35[,1]),5) # in table (Table 1)
boxplot(log(1+round(sweep(res35[,-c(1)], 1, res35[,1]),5)), ylab="log(1 + bias)") # in boxplot (Figure 1)



############### code of section 2 : nonlinear least squares ###############

## examples from nlmrt package ##

traceval <- FALSE

## Problem in 1 parameter to ensure methods work in trivial case
set.seed(1)
nobs <- 8
tt <- seq(1,nobs)
dd <- 1.23*tt + 4*runif(nobs)
df <- data.frame(tt, dd)

runtime1 <- microbenchmark(
    n1 <- nlxb(dd ~ a*tt, start=c(a=1), data=df),
    m1 <- mla(b=1, fn=function(b,dd,tt){sum((b[1]*tt-dd)^2)}, dd=df$dd, tt=df$tt))


## Hobbs problem
ydat  <-  c(5.308, 7.24, 9.638, 12.866, 17.069, 23.192, 31.443, 
           38.558, 50.156, 62.948, 75.995, 91.972) # for testing
y  <-  ydat  # for testing
tdat  <-  seq_along(ydat) # for testing
weeddata1  <-  data.frame(y=ydat, tt=tdat)

eunsc  <-   y ~ b1/(1+b2*exp(-b3*tt))
escal  <-   y ~ 100*b1/(1+10*b2*exp(-0.1*b3*tt))

suneasy  <-  c(b1=200, b2=50, b3=0.3)
ssceasy  <-  c(b1=2, b2=5, b3=3)
st1scal  <-  c(b1=100, b2=10, b3=0.1)
start1  <-  c(b1=1, b2=1, b3=1)

shobbs.res  <-  function(x){ # scaled Hobbs weeds problem -- residual
                        # This variant uses looping
     if(length(x) != 3) stop("hobbs.res -- parameter vector n!=3")
     y  <-  c(5.308, 7.24, 9.638, 12.866, 17.069, 23.192, 31.443, 
              38.558, 50.156, 62.948, 75.995, 91.972)
     tt  <-  1:12
     res  <-  100.0*x[1]/(1+x[2]*10.*exp(-0.1*x[3]*tt)) - y
}
      
shobbs.jac  <-  function(x) { # scaled Hobbs weeds problem -- Jacobian
     jj  <-  matrix(0.0, 12, 3)
     tt  <-  1:12
     yy  <-  exp(-0.1*x[3]*tt)
     zz  <-  100.0/(1+10.*x[2]*yy)
     jj[tt,1]   <-   zz
     jj[tt,2]   <-   -0.1*x[1]*zz*zz*yy
     jj[tt,3]   <-   0.01*x[1]*zz*zz*yy*x[2]*tt
     return(jj)
}

grhobbs <- function(b,y,tt) {
    .expr8 <- 1 + 10 * b[2] * exp(-0.1 * b[3] * tt)
    g1 <- 100/.expr8

    .expr1 <- 100 * b[1]
    .expr6 <- exp(-0.1 * b[3] * tt)
    .expr8 <- 1 + 10 * b[2] * .expr6
    g2 <- -(.expr1 * (10 * .expr6)/.expr8^2)

    .expr1 <- 100 * b[1]
    .expr2 <- 10 * b[2]
    .expr6 <- exp(-0.1 * b[3] * tt)
    .expr8 <- 1 + .expr2 * .expr6
    g3 <- .expr1 * (.expr2 * (.expr6 * (0.1 * tt)))/.expr8^2

    c(sum(-2 * g1 * (y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))),
      sum(-2 * g2 * (y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))),
      sum(-2 * g3 * (y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))))
}


runtime2 <- microbenchmark(
    n2 <- nlxb(eunsc, start=start1, trace=traceval, data=weeddata1),
    m2 <- mla(b=start1, fn=function(b,y,tt){sum((y - b[1]/(1+b[2]*exp(-b[3]*tt)))^2)}, y=weeddata1$y, tt=weeddata1$tt),
    n3 <- nlxb(eunsc, start=suneasy, trace=traceval, data=weeddata1),
    m3 <- mla(b=suneasy, fn=function(b,y,tt){sum((y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))^2)}, y=weeddata1$y, tt=weeddata1$tt),
    n4 <- nlxb(escal, start=start1, trace=traceval, data=weeddata1),
    m4 <- mla(b=start1, fn=function(b,y,tt){sum((y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))^2)}, y=weeddata1$y, tt=weeddata1$tt),
    n5 <- nlxb(escal, start=ssceasy, trace=traceval, data=weeddata1),
    m5 <- mla(b=ssceasy, fn=function(b,y,tt){sum((y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))^2)}, y=weeddata1$y, tt=weeddata1$tt),
    n6 <- nlxb(escal, start=st1scal, trace=traceval, data=weeddata1),
    m6 <- mla(b=st1scal, fn=function(b,y,tt){sum((y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))^2)}, y=weeddata1$y, tt=weeddata1$tt),
    n7 <- nlfb(start1, shobbs.res, shobbs.jac, trace=traceval),
    m7 <- mla(b=start1, fn=function(b,y,tt){sum((y - 100*b[1]/(1+10*b[2]*exp(-0.1*b[3]*tt)))^2)}, gr=grhobbs, y=weeddata1$y, tt=weeddata1$tt))


## Gabor Grothendieck problem
DF <- data.frame(x = c(5, 4, 3, 2, 1), y = c(1, 2, 3, 4, 5))

runtime3 <- microbenchmark(
    n8 <- nlxb(y ~ A * x + B, data = DF, start = c(A = 1, B = 6), trace=traceval),
    m8 <- mla(b=c(1,6), fn=function(b, x, y){sum((y - b[1]*x - b[2])^2)}, x=DF$x, y=DF$y))

meantime1 <- summary(runtime1, unit="us")[,4]
meantime2 <- summary(runtime2, unit="us")[,4]
meantime3 <- summary(runtime3, unit="us")[,4]

rssn <- sapply(paste("n", 1:8, sep=""), function(x){get(x)$ssquares})

rssm <- sapply(paste("m", 1:8, sep=""), function(x){
    m <- get(x)
    ifelse(m$istop==1, m$fn.value, NA)})

res <- matrix(cbind(rssn, c(meantime1[1], meantime2[seq(1,12,2)], meantime3[1]), rssm, c(meantime1[2], meantime2[seq(2,12,2)], meantime3[2])), 8, 4)
colnames(res) <- rep(c("objective function", "runtime"), 2)
rownames(res) <- c("One parameter problem", paste("Hobbs problem", c("unscaled - start1", "unscaled - easy", "scaled - start1", "scaled - easy", "scaled - hard", "scaled - start1 - gradient")), "Gabor Grothendieck problem")

res # Table 2



## examples from minpack.lm package ##

## exemple 1

set.seed(1)     
## values over which to simulate data 
x <- seq(0,5,length=100)
     
## model based on a list of parameters 
getPred <- function(parS, xx) parS$a * exp(xx * parS$b) + parS$c 
     
## parameter values used to simulate data
pp <- list(a=9,b=-1, c=6) 
     
## simulated data, with noise  
simDNoisy <- getPred(pp,x) + rnorm(length(x),sd=.1)
      
## residual function 
residFun <- function(p, observed, xx) observed - getPred(p,xx)
     
## starting values for parameters  
parStart <- list(a=3,b=-.001, c=1)
     
## for mla
residFunSum2 <- function(p, observed, xx) sum( (observed - getPredVec(p,xx) )^2)
getPredVec <- function(parS, xx) parS[1] * exp(xx * parS[2]) + parS[3] 
parStartVec <- c(3, -0.001, 1)


runtime1 <- microbenchmark(
 nls1 <- nls.lm(par=parStart, fn = residFun, observed = simDNoisy,
                xx = x, control = nls.lm.control(maxiter=500)),
 mla1 <- marqLevAlg(b = parStartVec, fn = residFunSum2,
                observed = simDNoisy, xx = x, maxiter=500))


## exemple 2

## function to simulate data 
f <- function(TT, tau, N0, a, f0) {
         expr <- expression(N0*exp(-TT/tau)*(1 + a*cos(f0*TT)))
         eval(expr)
}
     
## helper function for an analytical gradient 
j <- function(TT, tau, N0, a, f0) {
expr <- expression(N0*exp(-TT/tau)*(1 + a*cos(f0*TT)))
c(eval(D(expr, "tau")), eval(D(expr, "N0" )),
  eval(D(expr, "a"  )), eval(D(expr, "f0" )))
}
     
## values over which to simulate data 
TT <- seq(0, 8, length=501)
     
## parameter values underlying simulated data  
p <- c(tau = 2.2, N0 = 1000, a = 0.25, f0 = 8)
     
## get data 
Ndet <- do.call("f", c(list(TT = TT), as.list(p)))
## with noise
set.seed(1)
N <- Ndet +  rnorm(length(Ndet), mean=Ndet, sd=.01*max(Ndet))

## define a residual function 
fcn <- function(p, TT, N, fcall, jcall){
         (N - do.call("fcall", c(list(TT = TT), as.list(p))))
}     
 
## define analytical expression for the gradient 
fcn.jac <- function(p, TT, N, fcall, jcall){
         -do.call("jcall", c(list(TT = TT), as.list(p)))
}     

## starting values 
guess <- c(tau = 2.2, N0 = 1500, a = 0.25, f0 = 10)
     
gr <- function(b, TT, N){
    .expr3 <- exp(-TT/b[1])
    .expr8 <- 1 + b[3] * cos(b[4] * TT)
    g1 <- b[2] * (.expr3 * (TT/b[1]^2)) * .expr8

    .expr3 <- exp(-TT/b[1])
    .expr8 <- 1 + b[3] * cos(b[4] * TT)
    g2 <- .expr3 * .expr8

    .expr4 <- b[2] * exp(-TT/b[1])
    .expr6 <- cos(b[4] * TT)
    g3 <- .expr4 * .expr6
    
    .expr4 <- b[2] * exp(-TT/b[1])
    .expr5 <- b[4] * TT
    g4 <- -(.expr4 * (b[3] * (sin(.expr5) * TT)))

    c(sum(-2 * g1 * (N - b[2]*exp(-TT/b[1])*(1 + b[3]*cos(b[4]*TT)))),
      sum(-2 * g2 * (N - b[2]*exp(-TT/b[1])*(1 + b[3]*cos(b[4]*TT)))),
      sum(-2 * g3 * (N - b[2]*exp(-TT/b[1])*(1 + b[3]*cos(b[4]*TT)))),
      sum(-2 * g4 * (N - b[2]*exp(-TT/b[1])*(1 + b[3]*cos(b[4]*TT)))))    
}


runtime2 <- microbenchmark(
    nls2 <- nls.lm(par = guess, fn = fcn, jac = fcn.jac,fcall = f, jcall = j,TT = TT, N = N),
    mla2 <- mla(b=guess, fn=function(b, TT, N){sum((N - b[2]*exp(-TT/b[1])*(1 + b[3]*cos(b[4]*TT)))^2)}, N=N, TT=TT, gr=gr),
    nls2gr <- nls.lm(par = guess, fn = fcn,fcall = f,TT = TT, N = N),
    mla2gr <- mla(b=guess, fn=function(b, TT, N){sum((N - b[2]*exp(-TT/b[1])*(1 + b[3]*cos(b[4]*TT)))^2)}, N=N, TT=TT))


meantime1 <- summary(runtime1, unit="us")[,4]
meantime2 <- summary(runtime2, unit="us")[,4]


res <- cbind(c(nls1$deviance, nls2$deviance, nls2gr$deviance), 
             c(meantime1[1], meantime2[c(1,3)]), 
             c(mla1$fn.value, mla2$fn.value, mla2gr$fn.value),
             c(meantime1[2], meantime2[c(2,4)]))
colnames(res) <- rep(c("objective function", "runtime"), 2)
rownames(res) <- c("Example1", "Example2", "Example2 - gradient")

res # Table 3


############### code of section 3 : other parallelized algorithms ###############

## sequential estimations
cl1 <- parallel::makeCluster(1)
clusterExport(cl1, list("fLMM","loglikLMM","X", "Y", "ni"))
setDefaultCluster(cl1)
set.seed(123)

time1proc <- microbenchmark(
    mla1 <- marqLevAlg(b = binit, fn = loglikLMM, minimize = FALSE, X = X, Y = Y, ni = ni),
    genoud1   <- genoud(loglikLMM, nvars=length(binit), max=TRUE, X = X, Y = Y, ni = ni),
    DEoptim1 <- DEoptim(fn=fLMM, lower=low, upper=up, Z=X, Y=Y, ni=ni),
    pso1 <- hydroPSO(binit, fn=fLMM, Y=Y, Z=X, ni=ni, lower=low, upper=up),
    ga1 <- ga(type="real-valued", fitness=loglikLMM, lower=low, upper=up, Y=Y, X=X, ni=ni),
    opt1 <- optimParallel(par=binit, fn=fLMM, control=list(maxit=500), hessian=TRUE, parallel=cl1, Y=Y, Z=X, ni=ni),
    times=10)


## in parallel mode
cl <- parallel::makeCluster(2)
clusterExport(cl, list("fLMM","loglikLMM","X", "Y", "ni"))
setDefaultCluster(cl)
set.seed(123)

time2proc <- microbenchmark(
    mla2 <- marqLevAlg(b = binit, fn = loglikLMM, minimize = FALSE, nproc = 2, X = X, Y = Y, ni = ni),
    genoud2   <- genoud(loglikLMM, nvars=length(binit), max=TRUE, X = X, Y = Y, ni = ni, cluster=cl),
    DEoptim2 <- DEoptim(fn=fLMM, lower=low, upper=up, Z=X, Y=Y, ni=ni, control=DEoptim.control(cluster=cl)),
    pso2 <- hydroPSO(binit, fn=fLMM, Y=Y, Z=X, ni=ni, lower=low, upper=up, control=list(parallel="parallel", par.nnodes=2)),
    ga2 <- ga(type="real-valued", fitness=loglikLMM, lower=low, upper=up, Y=Y, X=X, ni=ni, parallel=2),
    opt2 <- optimParallel(par=binit, fn=fLMM, control=list(maxit=500), hessian=TRUE, parallel=cl, Y=Y, Z=X, ni=ni),
    times=10)


## results
t1 <- summary(time1proc)
t2 <- summary(time2proc)
round(cbind(t1[,4], t2[,4], t1[,4] / t2[,4]), 2) # Table 4



############### code of section 4 : sensitivity to initial values ###############


## comparison with minpack.lm ##


## example 1 in the help of nls.lm function
set.seed(123)

## values over which to simulate data 
x <- seq(0,5,length=100)

## model based on a list of parameters 
getPred <- function(parS, xx) parS$a * exp(xx * parS$b) + parS$c 

## parameter values used to simulate data
pp <- list(a=9,b=-1, c=6) 
     
   
## residual function 
residFun <- function(p, observed, xx) observed - getPred(p,xx)

## sum squares residuals function
residFunSum2 <- function(p, observed, xx) sum( (observed - getPredVec(p,xx) )^2)

## model based on a list of parameters 
getPredVec <- function(parS, xx) parS[1] * exp(xx * parS[2]) + parS[3] 


## doone : data simulation and estimation with nls.lm and marqLevAlg with 100 different starting points
doone <- function(seed)
{
    set.seed(seed)
    
    ## simulated data, plus noise  
    simD <- getPred(pp,x) + rnorm(length(x),sd=.05)

    res <- matrix(NA,4,100)
    for(i in 1:100) {
        
        ## set starting values at random in interval -10 -- 10 
        param <- c(runif(1, -10, 10), runif(1, -10, 10), runif(1, -10, 10))
        
        ## starting values for parameters  
        parStart <- list(a=param[1],b=param[2], c=param[3])
        parStartVec <- c(a=param[1],b=param[2], c=param[3])
        
        ## perform fit 
        nls.out <- nls.lm(par = parStart, fn = residFun, observed = simD,
                          xx = x, control = nls.lm.control(nprint=0, maxiter=500))
        ml.out <- marqLevAlg(b = parStartVec, fn = residFunSum2,
                             observed = simD, xx = x, maxiter=500)
        
        res[1,i] <- nls.out$info
        res[2,i] <- nls.out$deviance
        res[3,i] <- ml.out$istop
        res[4,i] <- ml.out$fn.value
    }

    return(res)
}

## 100 different seeds
set.seed(123)
seeds <- round(runif(100, 0, 1000))

## run 100 replicates
res100 <- sapply(seeds, doone)


## results
convnls <- res100[seq(1,397,4),]
convmla <- res100[seq(3,399,4),]

table(convnls, convmla) # Table 5

fnls <- res100[seq(2,398,4),]
fmla <- res100[seq(4,400,4),]

ok1 <- length(which(fnls[which(convnls==1)]<1)) / length(which(convnls==1))
ok2 <- length(which(fnls[which(convnls==2)]<1)) / length(which(convnls==2))
ok3 <- length(which(fnls[which(convnls==3)]<1)) / length(which(convnls==3))
okm <- length(which(fmla[which(convmla==1)]<1)) / length(which(convmla==1))

par(mfrow=c(2,2), mgp=c(2,0.5,0), mar=c(5,4,2,2), tcl=-0.5, xpd=NA)
hist(log(1+fmla[which(convmla==1)]), ylim=c(0,1), freq=FALSE, breaks=seq(0,45,1), xlab="log(1+f)", main="marqLevAlg - istop=1 (N=5155)")
text(0.7, okm+0.05, paste(round(okm*100),"%", sep=""))
hist(log(1+fnls[which(convnls==1)]), ylim=c(0,1), breaks=seq(0,45,1), freq=FALSE, xlab="log(1+f)", main="nls.lm - info=1 (N=4730)")
text(0.7, ok1+0.05, paste(round(ok1*100,1),"%", sep=""))
text(6.6, 1-ok1+0.05, paste(round((1-ok1)*100,1),"%", sep=""))
hist(log(1+fnls[which(convnls==2)]), ylim=c(0,1), freq=FALSE, breaks=seq(0,45,1), xlab="log(1+f)", main="nls.lm - info=2 (N=1274)")
text(0.7, ok2+0.05, paste(round(ok2*100,1),"%", sep=""))
hist(log(1+fnls[which(convnls==3)]), ylim=c(0, 1), freq=FALSE, breaks=seq(0,45,1), xlab="log(1+f)", main="nls.lm - info=3 (N=594)")
text(0.7, ok3+0.05, paste(round(ok3*100,1),"%", sep=""))
text(6.5, 1-ok3+0.05, paste(round((1-ok3)*100,1),"%", sep="")) # Figure 2



## global optimization ##

## the Wild function
fw <- function (x){ 10*sin(0.3*x)*sin(1.3*x^2) + 0.00001*x^4 + 0.2*x+80}
plot(fw, -50, 50, n = 1000, ylab="fw")
points(-15.81515, fw(-15.81515), col=2, lwd=3, pch=3) # Figure 4

## optimization using SANN
resSANN <- optim(50, fw, method = "SANN",
                 control = list(maxit = 20000, temp = 20, parscale = 20))

## optimization using marqLevAlg with grid search
res200 <- sapply(seq(-50,50, length.out=200), function(x){
    z <- mla(b=x, fn=fw)
    res <- c(NA, NA)
    if(z$istop==1) res <- c(z$fn.value, z$b)
    return(res)}) 

## results
res <- cbind(c(resSANN$value, resSANN$par), res200[,which.min(res200[1,])] )
colnames(res) <- c("SANN", "grid search MLA")
rownames(res) <- c("minimum", "param")

res # Table 6

