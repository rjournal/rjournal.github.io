# Code for replication for paper submission: "BayesSenMC:
# an R package for Bayesian Sensitivity Analysis of Misclassification"
#
# Jinhui Yang, University of Minnesota Twin Cities (yang7004@umn.edu)
# Lifeng Lin, Florida State University (linl@stat.fsu.edu)
# Haitao Chu, University of Minnesota Twin Cities (chux0051@umn.edu)


# Load and install packages
# Note that for MacOSX Mojave or higher, the package may fail to install due to issues with nlopt.
# In that case, make sure the command lines tools package is installed, and nlopt is installed with brew
# then, installing and loading nloptr in R will resolve the issue. If the issue persists, please contact
# Jinhui Yang (yang7004@umn.edu).

install.packages("BayesSenMC")
library("BayesSenMC")

library("ggplot2")
library("rstan")
library("gridExtra")

# Load meta-analysis data from BayesSenMC
data(bd_meta)

# Fit data using GLMM
my.mod <- nlmeNDiff(bd_meta, lower = 0)
params <- paramEst(my.mod)

# Run models to get posterior estimates for corrected odds ratio
# Model with no misclassification
m.1 <- crudeOR(a = 66, N1 = 11782, c = 243, N0 = 57973, chains = 3, iter = 10000)

# Model with constant misclassification
m.2 <- correctedOR(a = 66, N1 = 11782, c = 243, N0 = 57973, prior_list = params,
                  chains = 3, iter = 10000)

# Model with logit bivariate transformed misclassification
m.3 <- logitOR(a = 66, N1 = 11782, c = 243, N0 = 57973, prior_list = params,
               chains = 3, iter = 10000)

# Model with logit transformed misclassification w/ fixed correlation
m.4 <- fixedCorrOR(a = 66, N1 = 11782, c = 243, N0 = 57973, prior_list = params,
                   chains = 3, iter = 10000)

# Model with logit bivariate transformed misclassification 
# plus Fisher Z transformed correlation
m.5 <- randCorrOR(a = 66, N1 = 11782, c = 243, N0 = 57973, prior_list = params,
                  chains = 3, iter = 10000)
 
# Model with logit four-variate transformed differential misclassification
m.6 <- diffOR(a = 66, N1 = 11782, c = 243, N0 = 57973, mu = c(1.069, 1.069, 1.126, 1.126),
              s.lg.se0 = 0.712, s.lg.se1 = 0.712, s.lg.sp0 = 0.893, s.lg.sp1 = 0.893,
              corr.sesp0 = -0.377, corr.sesp1 = -0.377, corr.group = 0, chains = 3,
              iter = 10000, traceplot = TRUE)

# Extract summary statistics for adjusted odds ratio of the above models
# One can also directly call the model object (i.e., m.1) for more summary statistics
s.1 <- rstan::summary(m.1, pars = c("ORadj"))$summary
s.2 <- rstan::summary(m.2, pars = c("ORadj"))$summary
s.3 <- rstan::summary(m.3, pars = c("ORadj"))$summary
s.4 <- rstan::summary(m.4, pars = c("ORadj"))$summary
s.5 <- rstan::summary(m.5, pars = c("ORadj"))$summary
s.6 <- rstan::summary(m.6, pars = c("ORadj"))$summary

# Visualize posterior distributions of computed models
g1 <- plotOR(m.1, a = 66, N1 = 11782, c = 243, N0 = 57973, se = 0.744,
             sp = 0.755, x.max = 3, y.max = 5, binwidth = 0.1) + ggtitle("(i)")

g2 <- plotOR(m.2, a = 66, N1 = 11782, c = 243, N0 = 57973, se = 0.744,
             sp = 0.755, x.max = 3, y.max = 5, binwidth = 0.1) + ggtitle("(ii)")

g3 <- plotOR(m.3, a = 66, N1 = 11782, c = 243, N0 = 57973, se = 0.744,
             sp = 0.755, x.max = 3, y.max = 5, binwidth = 0.1) + ggtitle("(iii)")

g4 <- plotOR(m.4, a = 66, N1 = 11782, c = 243, N0 = 57973, se = 0.744,
             sp = 0.755, x.max = 3, y.max = 5, binwidth = 0.1) + ggtitle("(iv)")

g5 <- plotOR(m.5, a = 66, N1 = 11782, c = 243, N0 = 57973, se = 0.744,
             sp = 0.755, x.max = 3, y.max = 5, binwidth = 0.1) + ggtitle("(v)")

g6 <- plotOR(m.6, a = 66, N1 = 11782, c = 243, N0 = 57973, se = 0.744,
             sp = 0.755, x.max = 3, y.max = 5, binwidth = 0.1) + ggtitle("(vi)")

# call grid.arrange to format individual distribution plots
# to replicate the plots in the paper, user should disable the legends of the plots of the first two columns
# by adding `theme(legend.position="none")` to the returned ggplot2 object
grid.arrange(g1, g2, g3, g4, g5, g6, nrow = 2)
