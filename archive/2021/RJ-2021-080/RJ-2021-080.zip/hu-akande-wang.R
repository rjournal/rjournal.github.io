library(NPBayesImputeCat)

###########################################
###########################################
######## Missing data applications ########
###########################################
###########################################

###########################################
######### without zeros ###################
###########################################

data("ss16pusa_sample_nozeros_miss")
X <- ss16pusa_sample_nozeros_miss
p <- ncol(X)
for (j in 1:p){
  X[,j] <- as.factor(X[,j])
}

model <- CreateModel(X = X,
                     MCZ = NULL,
                     K = 30,
                     Nmax = 0,
                     aalpha = 0.25,
                     balpha = 0.25,
                     seed = 456)

model$Run(burnin = 2, 
          iter = 5, 
          thinning = 1, 
          silent = FALSE)

model <- CreateModel(X = X,
                     MCZ = NULL,
                     K = 80,
                     Nmax = 0,
                     aalpha = 0.25,
                     balpha = 0.25,
                     seed = 456)

model$Run(burnin = 2, 
          iter = 5, 
          thinning = 1, 
          silent = FALSE)


#First, enable the tracer for the model object
model$EnableTracer = TRUE

#Next, check the list of traceable parameters
model$traceable

#Then, specify the parameters to be traced or tracked
#Note that this will reset tracer everying time it is called.
#Below, we ask the model to track alpha and kstar values, up to 1000 iterations.
model$SetTrace(paralist = c("alpha","k_star"),
               num_of_iterations = 1000)

#Now run the model
model$Run(burnin = 50, 
          iter = 1000, 
          thinning = 1, 
          silent = TRUE)

#Return the list of tracked values
traced <- model$GetTrace()

m <- 10
Imp_DPMPM <- DPMPM_nozeros_imp(X = X,
                               nrun = 10000,
                               burn = 5000,
                               thin = 50,
                               K = 80,
                               aalpha = 0.25,
                               balpha = 0.25,
                               m = m,
                               seed = 211,
                               silent = TRUE)

library(bayesplot)
kstar_MCMCdiag(kstar = Imp_DPMPM$kstar,
                 nrun = 10000,
                 burn = 5000,
                 thin = 50)

impdata1 <- Imp_DPMPM$impdata[[1]] #for the first imputed dataset


library(mice)
#Set the number of imputations
m <- 10

#Run mice algorithm
Imp_MICE <- mice(data = X, 
                 m = m,
                 defaultMethod = c("norm", "logreg", "polyreg", "polr"),
                 print = F, 
                 seed = 342)

#Reshape the list of imputed datasets
Imp_MICE_reshape <- NULL
Imp_MICE_reshape$impdata <- lapply(1:m,function(x) x <- X)
col_names <- names(Imp_MICE$imp)
for (l in 1:m){
  for(j in col_names){
    na_index_j <- which(is.na((Imp_MICE_reshape$impdata[[l]])[,j])==TRUE)
    Imp_MICE_reshape$impdata[[l]][na_index_j,j] <- Imp_MICE$imp[[j]][[l]]
  }
}

library(tidyverse)
###Variable: WKL
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_DPMPM$impdata,
                         vars = "WKL") 
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_MICE_reshape$impdata,
                         vars = "WKL") 


###Variable: MAR
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_DPMPM$impdata,
                         vars = "MAR")
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_MICE_reshape$impdata,
                         vars = "MAR")
###Variable: SEX
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_DPMPM$impdata,
                         vars = "SEX")
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_MICE_reshape$impdata,
                         vars = "SEX")

varlist <- list(c("MAR"),c("SEX"),c("MAR","WKL")) #probabilities to evaluate
## First DPMPM
prob_ex1_DPMPM <- compute_probs(InputData = Imp_DPMPM$impdata,
                                varlist = varlist)
pooledprob_ex1_DPMPM <- pool_estimated_probs(ComputeProbsResults = prob_ex1_DPMPM,
                                             method = "imputation")
## Now MICE
prob_ex1_MICE <- compute_probs(InputData = Imp_MICE_reshape$impdata,
                               varlist = varlist)
pooledprob_ex1_MICE <- pool_estimated_probs(ComputeProbsResults = prob_ex1_MICE,
                                            method = "imputation")

pooledprob_ex1_DPMPM[[1]]
pooledprob_ex1_DPMPM[[2]]

pooledprob_ex1_MICE[[1]]
pooledprob_ex1_MICE[[2]]

library(nnet)
####### Fit multinomial model to WKL given MAR and SEX
## DPMPM
model_ex1_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = multinom(formula = MAR~SEX))
pool_fitted_GLMs(GLMResults = model_ex1_DPMPM,
                 method = "imputation")
## MICE
model_ex1_MICE <- with(data = Imp_MICE,
                       exp = multinom(formula = MAR~SEX))
summary(pool(model_ex1_MICE))

####### Fit muultinomial model to WKL given MAR and SEX
model_ex2_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = multinom(formula = WKL~MAR+SEX))
pool_fitted_GLMs(GLMResults = model_ex2_DPMPM,
                 method = "imputation")

model_ex2_MICE <- with(data = Imp_MICE,
                       exp = multinom(formula = WKL~MAR+SEX))
summary(pool(model_ex2_MICE))


####### Fit logistic model to SEX given the other two variables
## DPMPM
model_ex3_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = multinom(formula = MAR~1))
pool_fitted_GLMs(GLMResults = model_ex3_DPMPM,
                 method = "imputation")
## MICE
model_ex3_MICE <- with(data = Imp_MICE,
                       exp = multinom(formula = MAR~1))
summary(pool(model_ex3_MICE))

###########################################
######### with zeros ######################
###########################################

AGEP <- c(16, 16, 16, 16, 17, 17, 17, 17)
SCHL <- c("Bachelor's degree", "Doctorate degree", "Master's degree", 
          "Professional degree", "Bachelor's degree", "Doctorate degree", 
          "Master's degree", "Professional degree")
MAR <- rep(NA, 8)
SEX <- rep(NA, 8)
WKL <- rep(NA, 8)

MCZ <- as.data.frame(cbind(AGEP, MAR, SCHL, SEX, WKL))

data("ss16pusa_sample_zeros_miss")
X <- ss16pusa_sample_zeros_miss
p <- ncol(X)
for (j in 1:p){
  X[,j] <- as.factor(X[,j])
  MCZ[,j] <- factor(MCZ[,j], levels = levels(X[,j]))
}

model <- CreateModel(X = X,
                     MCZ = MCZ,
                     K = 30,
                     Nmax = 20000,
                     aalpha = 0.25,
                     balpha = 0.25,
                     seed = 521)

model$EnableTracer = TRUE
model$SetTrace(paralist = c("k_star","Nmis"),
               num_of_iterations = 1000)
model$Run(burnin = 50, 
          iter = 1000, 
          thinning = 1, 
          silent = TRUE)
traced <- model$GetTrace()

m <- 10
Imp_DPMPM <- DPMPM_zeros_imp(X = X,
                             MCZ = MCZ,
                             Nmax = 200000,
                             nrun = 10000,
                             burn = 5000,
                             thin = 50,
                             K = 80,
                             aalpha = 0.25,
                             balpha = 0.25,
                             m = m,
                             seed = 653,
                             silent = TRUE)

####### Compare estimates for marginal probabilities to observed data
###AGEP
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_DPMPM$impdata,
                         vars = "AGEP")
###MAR
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_DPMPM$impdata,
                         vars = "MAR")
###SCHL
marginal_compare_all_imp(obsdata = X,
                         impdata = Imp_DPMPM$impdata,
                         vars = "SCHL")


####### Compare estimates for marginal and joint probabilities
varlist <- list(c("AGEP"), c("MAR"), c("SCHL"), c("AGEP","MAR")) #probabilities to evaluate 
prob_ex1_DPMPM <- compute_probs(InputData = Imp_DPMPM$impdata,
                                varlist = varlist)
pooledprob_ex1_DPMPM <- pool_estimated_probs(ComputeProbsResults = prob_ex1_DPMPM,
                                             method = "imputation")
pooledprob_ex1_DPMPM

####### Fit multinomial model to MAR given SEX
model_ex1_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = multinom(formula = MAR~SEX))
pool_fitted_GLMs(GLMResults = model_ex1_DPMPM,
                 method = "imputation")
## Now the observed data
summary(multinom(formula = MAR~SEX, 
                 data = X))

####### Fit multinomial model to MAR given AGEP
model_ex2_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = multinom(formula = MAR~AGEP))
pool_fitted_GLMs(GLMResults = model_ex2_DPMPM,
                 method = "imputation")
## Now the observed data
summary(multinom(formula = MAR~AGEP, 
                 data = X))

####### Fit multinomial model to MAR only
model_ex3_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = multinom(formula = MAR~1))
pool_fitted_GLMs(GLMResults = model_ex3_DPMPM,
                 method = "imputation")
## Now the observed data
summary(multinom(formula = MAR~1, 
                 data = X))

####### Fit logistic model to SEX given SCHL
model_ex4_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = glm(formula = SEX~SCHL, 
                                      family = binomial))
pool_fitted_GLMs(GLMResults = model_ex4_DPMPM,
                 method = "imputation")
## Now the observed data
summary(glm(formula = SEX~SCHL,
            family = binomial, 
            data = X))

####### Fit logistic model to SEX given AGEP
model_ex5_DPMPM <- fit_GLMs(InputData = Imp_DPMPM$impdata,
                            exp = glm(formula = SEX~AGEP,
                                      family=binomial))
pool_fitted_GLMs(GLMResults = model_ex5_DPMPM,
                 method = "imputation")
## Now the observed data
summary(glm(formula = SEX~AGEP,
            family = binomial, 
            data = X))

###########################################
###########################################
######## Synthetic data applications ######
###########################################
###########################################

data(ss16pusa_sample_nozeros)
X <- ss16pusa_sample_nozeros
p <- ncol(X)
for (j in 1:p){
  X[,j] <- as.factor(X[,j])
}

model <- CreateModel(X = X,
                     MCZ = NULL,
                     K = 80,
                     Nmax = 0,
                     aalpha = 0.25,
                     balpha = 0.25,
                     seed = 973)

dj <- c(5, 2, 3)
m <- 5
Syn_DPMPM <- DPMPM_nozeros_syn(X = X,
                               dj = dj,
                               nrun = 10000,
                               burn = 5000,
                               thin = 50,
                               K = 80,
                               aalpha = 0.25,
                               balpha = 0.25,
                               m = 5,
                               vars = c("MAR", "WKL"),
                               seed = 837,
                               silent = TRUE)

syndata3 <- Syn_DPMPM$syndata[[3]] #for the third synthetic dataset

library(synthpop)
m <- 5 
Syn_CART <- syn(data = X,
                m = 5,
                seed = 123,
                visit.sequence = c("MAR", "WKL")) 

library(tidyverse)
###Variable: MAR
## DPMPM
marginal_compare_all_syn(obsdata = X,
                         syndata = Syn_DPMPM$syndata,
                         vars = "MAR")
## CART
marginal_compare_all_syn(obsdata = X,
                         syndata = Syn_CART$syn,
                         vars = "MAR")


###Variable: WKL
## DPMPM
marginal_compare_all_syn(obsdata = X,
                         syndata = Syn_DPMPM$syndata,
                         vars = "WKL")
## CART
marginal_compare_all_syn(obsdata = X,
                         syndata = Syn_CART$syn,
                         vars = "WKL")


varlist <- list(c("MAR"), c("SEX"), c("WKL"), c("MAR","WKL")) #probabilities to evaluate
## DPMPM
prob_ex1_DPMPM <- compute_probs(InputData = Syn_DPMPM$syndata,
                                varlist = varlist)
pooledprob_ex1_DPMPM <- pool_estimated_probs(ComputeProbsResults = prob_ex1_DPMPM,
                                             method = "synthesis_partial")
## CART
prob_ex1_CART <- compute_probs(InputData = Syn_CART$syn,
                               varlist = varlist)
pooledprob_ex1_CART <- pool_estimated_probs(ComputeProbsResults = prob_ex1_CART,
                                            method = "synthesis_partial")

pooledprob_ex1_DPMPM[[1]]
pooledprob_ex1_DPMPM[[3]]

pooledprob_ex1_CART[[1]]
pooledprob_ex1_CART[[3]]

model_ex1_DPMPM <- fit_GLMs(InputData = Syn_DPMPM$syndata,
                            exp = glm(formula = SEX~WKL+MAR,
                                      family = binomial))
pool_fitted_GLMs(GLMResults = model_ex1_DPMPM,
                 method = "synthesis_partial")

model_ex1_CART <- fit_GLMs(InputData = Syn_CART$syn,
                           exp = glm(formula = as.factor(SEX)~WKL+MAR,
                                     family = binomial))
pool_fitted_GLMs(GLMResults = model_ex1_CART,
                 method = "synthesis_partial")

summary(glm(formula = as.factor(SEX)~WKL+MAR,
            family = binomial,
            data = X))

####### Fit multinomial model to WKL given MAR and SEX
## First DPMPM
model_ex2_DPMPM <- fit_GLMs(InputData = Syn_DPMPM$syndata,
                            exp = multinom(formula = WKL~MAR+SEX))
pool_fitted_GLMs(GLMResults = model_ex2_DPMPM,
                 method = "synthesis_partial")
## Next CART
model_ex2_CART <- fit_GLMs(InputData = Syn_CART$syn,
                           exp = multinom(formula = WKL~MAR+SEX))
pool_fitted_GLMs(GLMResults = model_ex2_CART,
                 method = "synthesis_partial")
## Now the confidential data
summary(multinom(formula = WKL~MAR+SEX,
                 data = X))

####### Fit multinomial model to MAR given only SEX
## First DPMPM
model_ex3_DPMPM <- fit_GLMs(InputData = Syn_DPMPM$syndata,
                            exp = multinom(formula = MAR~SEX))
pool_fitted_GLMs(GLMResults = model_ex3_DPMPM,
                 method = "synthesis_partial")
## Next CART
model_ex3_CART <- fit_GLMs(InputData = Syn_CART$syn,
                           exp = multinom(formula = MAR~SEX))
pool_fitted_GLMs(GLMResults = model_ex3_CART,
                 method = "synthesis_partial")
## Now the confidential data
summary(multinom(formula = MAR~SEX,
                 data = X))
