library(MAINT.Data)

FlightsIdt <- AgrMcDt(FlightsDF,FlightsUnits,agrcrt=c(0.05,0.95)) 
head(FlightsIdt)
tail(FlightsIdt)

plot(FlightsIdt[,"distance"],FlightsIdt[,"arr_delay"])
plot(FlightsIdt[,"distance"],FlightsIdt[,"arr_delay"],type="rectangles")

plot(MidPoints(FlightsIdt)[,"arr_delay.MidP"],
     LogRanges(FlightsIdt)[,"arr_delay.LogR"],
     xlab="Mid Points",ylab="Log Ranges",
     main="Mid Points vs. Log Ranges for Arrival delays")


Flightsmle <-mle(FlightsIdt,Model="NrmandSKN") 
summary(Flightsmle)
mean(Flightsmle)
sd(Flightsmle)
var(Flightsmle)
cor(Flightsmle)
coef(Flightsmle)$gamma1

Flightstle <-fasttle(FlightsIdt) 
summary(Flightstle) 
mean(Flightstle)
sd(Flightstle)
Flights_Otl <- getIdtOutl(FlightsIdt,Flightstle) 
print(Flights_Otl) 
plot(Flights_Otl,cex.axis=0.3)

out1<-Flights_Otl@outliers
carr <- substring(rownames(FlightsIdt[-out1,]),5,6) 
carr_class <- factor(ifelse(carr=="9E"|carr=="EV"|carr=="MQ"| carr=="OO"|carr=="YV","REG","MAIN"))
MANOVAres <- MANOVA(FlightsIdt[-out1,],carr_class,Model="NrmandSKN")
summary(MANOVAres) 

MANOVA_Dep_delay_res <- MANOVA(FlightsIdt[-out1,"dep_delay"],carr_class,Model="NrmandSKN")
summary(MANOVA_Dep_delay_res)
MANOVA_Arr_delay_res <- MANOVA(FlightsIdt[-out1,"arr_delay"],carr_class,Model="NrmandSKN")
summary(MANOVA_Arr_delay_res) 

DACrossVal(FlightsIdt[-out1,],carr_class,TrainAlg=lda,loo=TRUE) 
DACrossVal(FlightsIdt[-out1,],carr_class,TrainAlg=qda,loo=TRUE)

ldares <- lda(FlightsIdt[-out1,],carr_class) 
ldapred <- predict(ldares,FlightsIdt[-out1,]) 
print(ldapred$class)

mclust_res <- Idtmclust(FlightsIdt[-out1,],1:16,Mxt="HomandHet")
plotInfCrt(mclust_res)
summary(mclust_res,classification=TRUE)

print(pro(mclust_res), digits=3)
print(mean(mclust_res),digits=3)

pcoordplot(mclust_res,Seq="MidPLogR_VarbyVar")
pcoordplot(mclust_res,Seq="MidPLogR_VarbyVar",model="HetG6C2")

## Diamond data set

library(tidyverse)

# Data pre-processsing 

# Removing observations with missing data and zeros, and creating log-transformed variables 

valid_diamonds  <- diamonds %>%   
  filter(carat !=0, x != 0, y != 0, z != 0) %>%
  drop_na() %>%
  mutate(
    logcarat = log(carat),
    logx     = log(x),
    logy     = log(y),
    logz     = log(z)
  )  
  
# Defining aggregation units : cut * color * clarity

DiamondsUnits <- factor( paste(valid_diamonds$cut,  valid_diamonds$color, valid_diamonds$clarity, sep="-") ) 

#########################################################


DiamondsIdt <- AgrMcDt(valid_diamonds[,c("logcarat","logx","logy","logz")], agrby=DiamondsUnits)

Diamd_mclust_res <- Idtmclust(DiamondsIdt,1:8,Mxt="HomandHet")
plotInfCrt(Diamd_mclust_res)

summary(Diamd_mclust_res)
print(pro(Diamd_mclust_res), digits=3)

plot(MidPoints(DiamondsIdt)[,"logz.MidP"],
     LogRanges(DiamondsIdt) [,"logz.LogR"],
     xlab="Mid Points",ylab="Log Ranges",
     main="Mid Points vs. Log Ranges for logdepth in mm",
     col = ifelse(Diamd_mclust_res@classification == 'CP1',1,
                  ifelse(Diamd_mclust_res@classification == 'CP2',2,7)),
     pch = 19, cex.lab=1.5)

