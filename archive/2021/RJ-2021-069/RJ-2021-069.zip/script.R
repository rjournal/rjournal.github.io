library(RSiena)
library(sna)
library(statnet)
library(latentnet)

#Read data - assuming data are in current working directory
s50s<-read.table("s50-smoke.dat",header=FALSE)
s50d<-read.table("s50-drugs.dat",header=FALSE)
s50sp<-read.table("s50-sport.dat",header=FALSE)
s50a<-read.table("s50-alcohol.dat", header=FALSE)

#latent space adjusted approach
g1<-network(s501,directed=TRUE)
g1%v%"a" <- s50a[,1]
g1%v%"s" <- s50s[,1]
g1%v%"sp" <- s50sp[,1]
g1%v%"d" <- s50d[,1]

g2<-network(s502,directed=TRUE)
g2%v%"a" <- s50a[,2]
g2%v%"s" <- s50s[,2]
g2%v%"sp" <- s50sp[,2]
g2%v%"d" <- s50d[,2]

g3<-network(s503,directed=TRUE)
g3%v%"a" <- s50a[,3]
g3%v%"s" <- s50s[,3]
g3%v%"sp" <- s50sp[,3]
g3%v%"d" <- s50d[,3]

m1<-ergmm(g1 ~ euclidean(d = 1)+absdiff("a")+absdiff("s")+absdiff("sp")+absdiff("d"),control=ergmm.control(sample.size=5000,burnin=20000,interval=10,Z.delta=5))
m2<-ergmm(g2 ~ euclidean(d = 1)+absdiff("a")+absdiff("s")+absdiff("sp")+absdiff("d"),control=ergmm.control(sample.size=5000,burnin=20000,interval=10,Z.delta=5))

E<-matrix(0,50,3)
for (i in 1:50)
{
if (sum(s501[i,])!=0)
E[i,1]<-(s501[i,]%*%s50a[,1])/sum(s501[i,])
if (sum(s502[i,])!=0)
E[i,2]<-(s502[i,]%*%s50a[,2])/sum(s502[i,])
if (sum(s503[i,])!=0)
E[i,3]<-(s503[i,]%*%s50a[,3])/sum(s503[i,])
}

cor(cbind(m1$mkl$Z,m2$mkl$Z))

alcohol<-c(s50a[,3],s50a[,2])
lag_alc<-c(s50a[,2],s50a[,1])
expo<-c(E[,2],E[,1])
drug<-c(s50d[,3],s50d[,2])
smoke<-c(s50s[,3],s50s[,2])
sport<-c(s50sp[,3],s50sp[,2])
latent_pos<-c(m2$mkl$Z,m1$mkl$Z)
latent_pos2<-rep(m2$mkl$Z,2)
latent_pos1<-rep(m1$mkl$Z,2)

infl<-data.frame(cbind(alcohol,lag_alc,expo,drug,smoke,sport,latent_pos1,latent_pos2,rep(c(1:50),2),rep(c(1:2),each=50)))
cor(infl[,1:8])
summary(lm(alcohol~lag_alc+expo,data=infl))
summary(lm(alcohol~lag_alc+expo+smoke+sport+drug,data=infl))
summary(lm(alcohol~lag_alc+expo+smoke+sport+drug+latent_pos1+latent_pos2,data=infl))


#SIENA
friend.data.w1 <- s501
friend.data.w2 <- s502
friend.data.w3 <- s503
drink <- s50a
smoke <- s50s
drug  <- s50d
sport <- s50sp
friendship <- sienaDependent( array( c( friend.data.w1, friend.data.w2,
                                        friend.data.w3 ),
                                     dim = c( 50, 50, 3 ) ) )# create dependent variable
drinkingbeh <- sienaDependent( drink, type = "behavior" )
smokingbeh <- varCovar( as.matrix(smoke))
drugbeh <- varCovar( as.matrix(drug))
sportbeh <- varCovar( as.matrix(sport))
lat1<-coCovar(as.vector(m1$mkl$Z))
lat2<-coCovar(as.vector(m2$mkl$Z))
myCoEvolutionData <- sienaDataCreate( friendship, drinkingbeh,smokingbeh,drugbeh,sportbeh,lat1,lat2 )

myCoEvolutionEff <- getEffects( myCoEvolutionData )


myCoEvolutionEff <- includeEffects( myCoEvolutionEff, transTrip,  cycle3,gwespFF,inPop,outPop)
myCoEvolutionEff <- includeEffects( myCoEvolutionEff, simX, interaction1 = "smokingbeh" )
myCoEvolutionEff <- includeEffects( myCoEvolutionEff, simX, interaction1 = "drugbeh" )
myCoEvolutionEff <- includeEffects( myCoEvolutionEff, simX, interaction1 = "sportbeh" )
myCoEvolutionEff <- includeEffects(myCoEvolutionEff,  simX,interaction1 = "drinkingbeh" )


myCoEvolutionEff <- includeEffects( myCoEvolutionEff,
                                    name = "drinkingbeh",
                                    avSim,
                                    interaction1 = "friendship" )

myCoEvolutionEff <- includeEffects( myCoEvolutionEff,
                                     name = "drinkingbeh", effFrom,
                                     interaction1 = "smokingbeh")

myCoEvolutionEff <- includeEffects( myCoEvolutionEff,
                                    name = "drinkingbeh", effFrom,
                                    interaction1 = "drugbeh")

myCoEvolutionEff <- includeEffects( myCoEvolutionEff,
                                    name = "drinkingbeh", effFrom,
                                    interaction1 = "sportbeh")


                                   
myCoEvolutionEff

myCoEvolutionEff2 <- getEffects( myCoEvolutionData )

effectsDocumentation(myCoEvolutionEff2)

myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2, transTrip,  cycle3,gwespFF,inPop,outPop)
myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2, simX, interaction1 = "smokingbeh" )
myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2, simX, interaction1 = "drugbeh" )
myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2, simX, interaction1 = "sportbeh" )
myCoEvolutionEff2 <- includeEffects(myCoEvolutionEff2,  simX,interaction1 = "drinkingbeh" )
myCoEvolutionEff2 <- includeEffects(myCoEvolutionEff2,  simX,interaction1 = "lat1" )
myCoEvolutionEff2 <- includeEffects(myCoEvolutionEff2,  simX,interaction1 = "lat2" )

myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2,
                                     name = "drinkingbeh",
                                     avSim,
                                     interaction1 = "friendship" )

myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2,
                                     name = "drinkingbeh", effFrom,
                                     interaction1 = "smokingbeh")

myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2,
                                     name = "drinkingbeh", effFrom,
                                     interaction1 = "drugbeh")

myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2,
                                     name = "drinkingbeh", effFrom,
                                     interaction1 = "sportbeh")

myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2,
                                     name = "drinkingbeh", effFrom,
                                     interaction1 = "lat1")
myCoEvolutionEff2 <- includeEffects( myCoEvolutionEff2,
                                     name = "drinkingbeh", effFrom,
                                     interaction1 = "lat2")

myCoEvolutionEff
myCoEvolutionEff2

betterCoEvAlgorithm <- sienaAlgorithmCreate( projname = 's50CoEv_3',
                                             diagonalize = 0.2, doubleAveraging = 0)

(ans1 <- siena07( betterCoEvAlgorithm, data = myCoEvolutionData,
                 effects = myCoEvolutionEff))

(ans2 <- siena07( betterCoEvAlgorithm, data = myCoEvolutionData,
                  effects = myCoEvolutionEff2))
