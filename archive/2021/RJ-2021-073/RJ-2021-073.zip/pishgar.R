# title: "MatchThem Example"
# author: "Noah Greifer"
# date: "3/1/2021"

# Example
library(MatchThem)
data('osteoarthritis')
summary(osteoarthritis)

# Imputing the Missing Data in the Dataset
library(mice)
imputed.datasets <- mice(osteoarthritis, m = 5, 
                         seed = 123456)

# Matching or Weighting the Imputed Datasets
## Matching the Imputed Datasets
matched.datasets <- matchthem(OSP ~ AGE + SEX + BMI + RAC + SMK,
                              datasets = imputed.datasets,
                              approach = 'within',
                              method = 'nearest',
                              caliper = 0.05,
                              ratio = 2)

## Weighting the Imputed Datasets
weighted.datasets <- weightthem(OSP ~ AGE + SEX + BMI + RAC + SMK,
                                datasets = imputed.datasets,
                                approach = 'across',
                                method = 'ps',
                                estimand = 'ATM')

# Assessing Balance on the Matched or Weighted Datasets
library(cobalt)
bal.tab(matched.datasets, stats = c('m', 'ks'),
        imp.fun = 'max')

bal.tab(weighted.datasets, stats = c('m', 'ks'),
        imp.fun = 'max')

# Analyzing the Matched and Weighted Datasets
library(survey)
matched.models <- with(matched.datasets, 
                       svyglm(KOA ~ OSP, family = quasibinomial()), 
                       cluster = TRUE)

weighted.models <- with(weighted.datasets, 
                        svyglm(KOA ~ OSP, family = quasibinomial()))

# Pooling the Causal Effect Estimates
matched.results <- MatchThem::pool(matched.models)
summary(matched.results, conf.int = TRUE)

weighted.results <- MatchThem::pool(weighted.models)
summary(weighted.results, conf.int = TRUE)

