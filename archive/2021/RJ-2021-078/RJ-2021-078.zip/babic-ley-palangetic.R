library(ellipticalsymmetry)

#import the dataset
filtered_returns = read.csv(file = "filtered_returns.csv", header = TRUE)
#save the name of the indices
indices = tail(colnames(filtered_returns), 3)

#date format
filtered_returns$Date = as.Date(filtered_returns$Date, format = '%d/%m/%Y')
months = as.numeric(format(filtered_returns$Date, "%m"))
years = as.numeric(format(filtered_returns$Date, "%Y"))
#create a new colomn "total_month"; this will be used later for the rolling window analysis
filtered_returns$total_month = months + 12*(years - min(years))
#rolling size
rollingSize = 12
#number of rolling windows
nRollingWindows = max(filtered_returns$total_month)-rollingSize



########################################################################################################################
############################################## rolling window data analysis ###########################################
#######################################################################################################################

#calculate the p-values using the skewoptimal test
p_vals_so = rep(0, nRollingWindows)
for (i in seq(nRollingWindows)){
  current_data = filtered_returns[filtered_returns[,'total_month'] >=i & filtered_returns[,'total_month'] < i + rollingSize,]
  output = SkewOptimal(current_data[indices])
  p_vals_so[i] = output$p.value
}

#plot the result
dates = seq(as.Date("2000-01-01"), by = "month", length.out = nRollingWindows)
par(bty="l")
plot(dates, p_vals_so, type = 'l', xaxt='n', xlab='', ylab='', main='')
axis.Date(1, at = seq(dates[1], dates[length(dates)], by = "year"),
          format = "%Y", las = 2)
abline(h=0.05)


########################################################################################################################



#calculate the p-values using the pseudoGaussian test
p_vals_pseudogaussian = rep(0, nRollingWindows)
for (i in seq(nRollingWindows)){
  current_data = filtered_returns[filtered_returns[,'total_month'] >=i & filtered_returns[,'total_month'] < i + rollingSize,]
  output = PseudoGaussian(current_data[indices])
  p_vals_pseudogaussian[i] = output$p.value
}

#plot the result
dates = seq(as.Date("2000-01-01"), by = "month", length.out = nRollingWindows)
par(bty="l")
plot(dates, p_vals_pseudogaussian, type = 'l', xaxt='n', ylim=c(0,1), xlab='', ylab='', main='')
axis.Date(1, at = seq(dates[1], dates[length(dates)], by = "year"),
          format = "%Y", las = 2)
abline(h=0.05)


########################################################################################################################


#calculate the p-values using the MPQ test
p_vals_mpq = rep(0, nRollingWindows)
for (i in seq(nRollingWindows)){
  current_data = filtered_returns[filtered_returns[,'total_month'] >=i & filtered_returns[,'total_month'] < i + rollingSize,]
  output = MPQ(current_data[indices])
  p_vals_mpq[i] = output$p.value
}

#plot the result
dates = seq(as.Date("2000-01-01"), by = "month", length.out = nRollingWindows)
par(bty="l")
plot(dates, p_vals_mpq, type = 'l', xaxt='n', ylim=c(0,1), xlab='', ylab='', main='')
axis.Date(1, at = seq(dates[1], dates[length(dates)], by = "year"),
          format = "%Y", las = 2)
abline(h=0.05)

########################################################################################################################


#calculate the p-values using Schott's test
p_vals_schott = rep(0, nRollingWindows)
for (i in seq(nRollingWindows)){
  current_data = filtered_returns[filtered_returns[,'total_month'] >=i & filtered_returns[,'total_month'] < i + rollingSize,]
  output = Schott(current_data[indices])
  p_vals_schott[i] = output$p.value
}

#plot the result
dates = seq(as.Date("2000-01-01"), by = "month", length.out = nRollingWindows)
par(bty="l")
plot(dates, p_vals_schott, type = 'l', xaxt='n', xlab='', ylab='', main='')
axis.Date(1, at = seq(dates[1], dates[length(dates)], by = "year"),
          format = "%Y", las = 2)
abline(h=0.05)

########################################################################################################################


#calculate the p-values using Huffer and Park's test
start_time <- Sys.time() #check the execution time of the HufferPark test given that it is a bootstrap test
set.seed(321) #set.seed is for the bootstrap tests to make sure that the results are reproducible
p_vals_hp = rep(0, nRollingWindows)
for (i in seq(nRollingWindows)){
  current_data = filtered_returns[filtered_returns[,'total_month'] >=i & filtered_returns[,'total_month'] < i + rollingSize,]
  output = HufferPark(current_data[indices], c= 3, R = 100)
  p_vals_hp[i] = output$p.value
}
end_time <- Sys.time()
end_time - start_time
#Time difference of 10.94442 mins (this is obtained using Intel Core i7 CPU with 7 logical cores)

#plot the result
dates = seq(as.Date("2000-01-01"), by = "month", length.out = nRollingWindows)
par(bty="l")
plot(dates, p_vals_hp, type = 'l', xaxt='n', xlab='', ylab='', main='')
axis.Date(1, at = seq(dates[1], dates[length(dates)], by = "year"),
          format = "%Y", las = 2)
abline(h=0.05)


########################################################################################################################


#calculate the p-values obtained using the test by Koltchinskii and Sakhanenko
start_time <- Sys.time() #check the execution time of the test by Koltchinskii and Sakhanenko given that it is a bootstrap test
set.seed(321) #set.seed is for the bootstrap tests to make sure that the results are reproducible
p_vals_ks = rep(0, nRollingWindows)
for (i in seq(nRollingWindows)){
  current_data = filtered_returns[filtered_returns[,'total_month'] >=i & filtered_returns[,'total_month'] < i + rollingSize,]
  output = KoltchinskiiSakhanenko(current_data[indices], R = 100)
  p_vals_ks[i] = output$p.value
}
end_time <- Sys.time()
end_time - start_time
#Time difference of 31.64272 mins (this is obtained using Intel Core i7 CPU with 7 logical cores)

#plot the result
dates = seq(as.Date("2000-01-01"), by = "month", length.out = nRollingWindows)
par(bty="l")
plot(dates, p_vals_ks, type = 'l', xaxt='n', ylim = c(0,1), xlab='', ylab='', main='')
axis.Date(1, at = seq(dates[1], dates[length(dates)], by = "year"),
          format = "%Y", las = 2)
abline(h=0.05)

########################################################################################################################
############################################### 2008 data analysis ####################################################
#######################################################################################################################

#data values between 1/1/2008 and 1/1/2009
data2008 = filtered_returns[filtered_returns[,'Date'] >= as.Date("2008-01-01") & filtered_returns[,'Date'] < as.Date("2009-01-01"), indices]


set.seed(321) #set.seed is for the bootstrap tests to make sure that the results are reproducible
KSoutput = KoltchinskiiSakhanenko(data2008, R = 100)
print(KSoutput)


MPQoutput = MPQ(data2008)
print(MPQoutput)


Schottoutput = Schott(data2008)
print(Schottoutput)


HPoutput = HufferPark(data2008, c=3)
print(HPoutput)


set.seed(321) #set.seed is for the bootstrap tests to make sure that the results are reproducible
HPoutput_boostrap1 = HufferPark(data2008, c=3, R = 100)
print(HPoutput_boostrap1)


set.seed(321) #set.seed is for the bootstrap tests to make sure that the results are reproducible
HPoutput_boostrap2 = HufferPark(data2008, c=3, R = 100, sector = 'permutations')
print(HPoutput_boostrap2)

PGoutput = PseudoGaussian(data2008)
print(PGoutput)

SkewOptimaloutput = SkewOptimal(data2008)
print(SkewOptimaloutput)


SkewOptimaloutput2 = SkewOptimal(data2008, f = 'logistic')
print(SkewOptimaloutput2)

SkewOptimaloutput3 = SkewOptimal(data2008, f = 'powerExp')
print(SkewOptimaloutput3)



