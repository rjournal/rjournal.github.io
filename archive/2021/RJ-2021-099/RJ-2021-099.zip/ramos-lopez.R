install.packages('rPACI', dependencies = T)
library('rPACI')

##### EXAMPLE 1: ANALYZE A PATIENT'S CORNEA BASED ON A SINGLE MEASUREMENT ######
  # Read an example file with the corneal topography of a normal eye, from a file exported by a CSO Placido disk topographer
  dataset_N = readFile(system.file("extdata","N01.txt", package="rPACI"))
  
  # Write a data.frame (in rPACI format) to disk
  writerPACI(dataset_N, filename = "newData.txt", sep = ",")
  
  
  # Now compute the Placido irregularity indices in Ramos-Lopez et al. (2013), <doi:10.1097/OPX.0b013e3182843f2a>
  results_N = computePlacidoIndices(dataset_N)
  
  # Show the diagnose for this dataset
  results_N$Diagnose
  
  # Or show the values of individual indices
  results_N$GLPI
  results_N$PI_1
  results_N$AR_1
  
  # Plot the results for the normal eye
  plotSingleCornea(dataset_N, results_N, filename = "N01.txt")
  
  # Alternatively, these three operations can be performed with the function analyzeFile:
  results_N = analyzeFile(system.file("extdata","N01.txt", package="rPACI"), drawplot=TRUE)
  


##### EXAMPLE 2: ANALYZE A PATIENT'S CORNEA BASED ON A REPEATED MEASUREMENTS ######
  # Specify a folder path to analyze a patient's evolution over time
  results_evolution = analyzeEvolution(data = system.file("extdata/evolution/", package="rPACI"), fileExtension = 'txt')




##### EXAMPLE 3: ANALYZE MULTIPLE FILES IN A FOLDER ######
  # Multiple files in a common folder can be analyzed at a time using the function 'analyzeFolder':
  results_all = analyzeFolder(system.file("extdata", package="rPACI"), individualPlots = FALSE, summaryPlot = T)
  
  # Show the diagnose for each analyzed file
  results_all[,c(13,1)]


#### EXAMPLE 4: SIMULATING DATA ######
  dataset = simulateData(rings = 15, pointsPerRing = 128, diameter = 8, ringRadiiPerturbation = 0.7)
  plot(dataset$x,dataset$y,pch=20,cex=0.5,asp=1)
  
  
  dataset = simulateData(maximumMireDisplacement = 2, mireDisplacementAngle = -30, 
                         mireDisplacementPerturbation = 1.2, ellipticAxesRatio= 1.2, 
                         ellipticRotation = 45)
  plot(dataset$x,dataset$y,pch=20,cex=0.5,asp=1)
