## Author: Andrew G. Allmon ##
## Purpose: Provide code for reproducible examples in the R Journal manuscript ##

# Use CRAN version
remotes::install_github("elbamos/clusteringdatasets")
library(diproperm)
library(clusteringdatasets)

#### Example 1 used in diproperm example subsection ####

cluster.data <- make_blobs(n_samples = 14, n_features = 50, centers = 2, cluster_std = 2)
X <- cluster.data[[1]]
y <- cluster.data[[2]]
y[y==2] <- -1

# solve the generalized DWD model
dpp <- DiProPerm(X,y,B=1000,classifier = "dwd",univ.stat = "md")

plotdpp(dpp)

loadings(dpp,loadnum = 5)
#########################

#### Example 2 used in the Application section ####
start_time <- Sys.time()

data("mushrooms")

dim(mushrooms$X)

table(mushrooms$y)

X <- Matrix::t(mushrooms$X)
X <- X[1:50,]
y <- mushrooms$y[1:50]

dpp <- DiProPerm(X=X,y=y,B=1000,classifier = "dwd")

end_time<-Sys.time()
end_time-start_time

#png("~/Figures/Paper3_Figures-1.png",res=300,width = par("din")[1],height = par("din")[2],units = "in")
plotdpp(dpp)
#dev.off()

loadings(dpp,loadnum = 5)

## Optional code mentioned in manuscript ##
#plotdpp(dpp,plots="obs")
#plotdpp(dpp,plots="min")
#plotdpp(dpp,plots="max")
#plotdpp(dpp,plots="permdist")

## Test error cases ##
#dpp <- DiProPerm(X=X,y=y,B=100)

#X<-as.data.frame(X)
#dpp <- DiProPerm(X=X,y=y,B=1000)

#y[y==1] <- 0
#dpp <- DiProPerm(X,y,B=1000,classifier = "dwd",univ.stat = "md")

#y[y==1] <- 1
#y[y==-1] <- 1
#dpp <- DiProPerm(X,y,B=1000,classifier = "dwd",univ.stat = "md")
