################################################################################
#NGSSEML in practice (VERSION 2.2)
# R code: Section of Examples 
################################################################################
## Select server
options(repos = "http://cran.r-project.org")  
# load packages
#if(!require("dlm")) {install.packages("dlm"); library("dlm")}
#if(!require("mvtnorm")) {install.packages("mvtnorm"); library("mvtnorm")}
#if(!require("fields")) {install.packages("fields"); library("fields")}
#if(!require("interp")) {install.packages("interp"); library("interp")}
#if(!require("car")) {install.packages("car");library("car")}
#if(!require("NGSSEML")) {install.packages("NGSSEML"); library("NGSSEML")}
#Note: Please, you must check if the packages above have installed correctly. 
#Otherwise, NGSSEML package may return some error messages. 

################################################################################
# Example 1: Polio Count data 
################################################################################
library("NGSSEML")

data(Polio_data)

# Xt as matrix always!
Xtm = Polio_data[,3:7]    

Xtm[,1] = (1:168-73)/168

Ytm = Polio_data$y

Ztm = NULL

model = "Poisson"

#CosAnnual, SinAnnual, CosSemiAnnual, SinSemiAnnual
#LabelParTheta = c("w", "Beta1", "Beta2", "Beta3", "Beta4", "Beta5")

StaPar=c(0.79, -0.11, -0.49, 0.18, -0.38)

a0 = 0.3

b0 = 0.1

ci = 0.95               

data1 = data.frame(Ytm, Xtm)

#Fit:
fit = ngssm.mle(Ytm ~ CosAnnual + SinAnnual + CosSemiAnnual + SinSemiAnnual,
data = data1, model = model, pz = NULL, StaPar = StaPar, a0 = a0, 
b0 = b0, ci = ci)

esttheta = as.numeric(fit[,1])

filt = FilteringF(Ytm ~ Trend + CosAnnual + SinAnnual + CosSemiAnnual 
+ SinSemiAnnual,
data = data1,StaPar = esttheta, model = "Poisson",a0 = a0, b0 = b0, 
distl = "FILTER", splot = TRUE)

filtest =(filt[1,]/filt[2,])

#Diagnostic analysis:
ID = var(Ytm)/mean(Ytm)

ID

n = length(Ytm)  

pred = FilteringF(Ytm ~ Trend + CosAnnual + SinAnnual + CosSemiAnnual 
+ SinSemiAnnual, data = data1, StaPar = esttheta, model = "Poisson", a0 = a0, 
b0 = b0, distl = "PRED")

predonestepahead = (pred[1,]/pred[2,])

residuals = (Ytm-predonestepahead)/sqrt(predonestepahead)

summary(residuals)

sd(residuals[1:n])

residuals = scale(residuals[1:n])

x = seq(as.Date("1970/01/01"), as.Date("1983/12/31"), "months") 

par(mfrow = c(1, 2))

plot(x[1:n], residuals, xlab = "Months", ylab = "Standardized Pearson residuals")

points(x[7], residuals[7], col = "red",lwd = c(2))

points(x[35], residuals[35], col = "red", lwd = c(2))

points(x[74], residuals[74], col = "red",lwd = c(2))

points(x[113], residuals[113], col = "red", lwd = c(2))

title("(a)")

acf(residuals, ci = 0.99, main = "(b)")

#Prediction in sample:
pred = FilteringF(Ytm ~ Trend + CosAnnual + SinAnnual + CosSemiAnnual 
+ SinSemiAnnual, data = data1, StaPar = esttheta, model = "Poisson", a0 = a0, 
b0 = b0, distl = "FILTER")

n = length(data1$Ytm)

predf = (pred[1,2:(n+1)]/pred[2,2:(n+1)])

MAEngssm = mean(abs(data1$Ytm-predf))

MAEngssm

#> MAEngssm
#[1] 0.8903139

SMSEngssm = sqrt(mean((data1$Ytm-predf)^2))

SMSEngssm

#> SMSEngssm
#[1] 1.279889
#> 

MAPEngssm = mean(abs(((data1$Ytm+1)-(predf+1))/(data1$Ytm+1)))

MAPEngssm

#> MAPEngssm
#[1]  0.4682849

#Bayesian estimation:

data(Polio_data)

Xtm = Polio_data[,3:7] 

Xtm[,1] = (1:168-73)/168  

Ytm = Polio_data$y

Ztm = NULL

model = "Poisson"

#CosAnnual, SinAnnual, CosSemiAnnual, SinSemiAnnual
#LabelParTheta = c("w", "Beta1", "Beta2", "Beta3", "Beta4", "Beta5")

StaPar=c(0.79, -0.11, -0.49, 0.18, -0.38)

a0 = 0.3

b0 = 0.1

pointss = 6     ### points

nsamplex = 2000  ##sample

ci = 0.95       ## Cred. level

data1 = data.frame(Ytm, Xtm)

#Fit:

set.seed(24666)

fitbayes = ngssm.bayes(Ytm ~ CosAnnual + SinAnnual + CosSemiAnnual + SinSemiAnnual,
data = data1, model = model, pz = NULL, StaPar = StaPar,
a0 = a0, b0 = b0, prw=  c(1, 1), prbetamu = rep(0, 4), prbetasigma = diag(10, 4, 4),
ci =ci, pointss = pointss, nsamplex = nsamplex, postplot = FALSE, 
contourplot = FALSE, verbose = TRUE)

# Smoothing: 
posts = fitbayes$samplepost

PlotF(Ytm ~ CosAnnual + SinAnnual + CosSemiAnnual + SinSemiAnnual,
data = data1, model = model, pz = NULL, axisxdate = x, Proc = "Smooth", 
Type = "Marg", a0 = 0.01, b0 = 0.01, ci = 0.95, posts = posts, 
startdate = "1970/01/01", enddate = "1983/12/31", Freq = "months", type = 'l', 
col=c("black", "blue", "lightgrey"), xlab = "Months", 
ylab = "The number of poliomyelitis cases", xlim = NULL, ylim = c(0, 15), 
Lty = c(1, 2, 1), lwd = c(2, 2, 2), cex = 0.68)

estthetabayes = as.numeric(fitbayes$coefficients[[2]])

predbayes = FilteringF(Ytm ~ Trend + CosAnnual + SinAnnual + CosSemiAnnual 
+ SinSemiAnnual, data = data1, StaPar = estthetabayes, model = "Poisson", 
a0 = a0, b0 = b0, distl = "FILTER")

n = length(data1$Ytm)

predfbayes = (predbayes[1,2:(n+1)]/predbayes[2,2:(n+1)])

MAEngssm = mean(abs(data1$Ytm-predfbayes))

MAEngssm
#> MAEngssm
#[1] 0.879536

SMSEngssm = sqrt(mean((data1$Ytm-predfbayes)^2))

SMSEngssm
#> SMSEngssm
#[1] 1.263607
#> 

MAPEngssm = mean(abs(((data1$Ytm+1)-(predfbayes+1))/(data1$Ytm+1)))

MAPEngssm
#> MAPEngssm
#[1]  0.4619782      

################################################################################
# Example 2: Petro return data 
################################################################################
library("NGSSEML")
# MLE estimation:
#GED:

data(Return_data)

plot( Return_data[,2], Return_data[,1], type = 'l', xlab = "Days", 
ylab = "Returns")

Ytm = Return_data$Rt

Xt = NULL

Zt = NULL 

model = "GED" 

#LabelParTheta = c("w", "nu")

StaPar = c(0.9, 1)

StaPar1 = c(exp(StaPar[1])/(1 + exp(StaPar[1])),log(StaPar[2]))

a0 = 0.01

b0 = 0.01

ci = 0.95

fit = ngssm.mle(Ytm ~ 1, data = data.frame(Ytm), model = model, StaPar = StaPar, 
method = "BFGS", pz = NULL, a0 = a0, b0 = b0, ci = ci, verbose = FALSE)

fit

#Bayesian estimation:

data(Return_data)

Ytm = Return_data$Rt

Date = Return_data$Date

Xtm = NULL

Ztm = NULL

model = "GED"

#LabelParTheta=c("W","nu")

StaPar = c(0.9,1)

p = length(StaPar)

nn = length(Ytm)

a0 = 0.01

b0 = 0.01

pointss = 15    ### points

nsamplex = 1000 #sample

ci = 0.95        # Cred. level 

#Bayesian fit:

fitbayes = ngssm.bayes(Ytm ~ 1,data = data.frame(Ytm), model = model, pz = NULL,
StaPar = StaPar, a0 = a0, b0 = b0, prw = c(1, 1), prnu = c(0.01, 0.01), ci = ci,
pointss = pointss, nsamplex = nsamplex, postplot = TRUE, contourplot = TRUE, 
verbose = TRUE)

# Smoothing: 
set.seed(1000)

posts = fitbayes$samplepost

PlotF(Ytm ~ 1, data = data.frame(Ytm), model = model, pz = NULL,
axisxdate = Return_data$Date, plotYt = FALSE, transf = -0.5, Proc = "Smooth",
Type="Marg", a0 = a0, b0 = b0, ci = ci, posts= posts, startdate = '2000-06-01', 
enddate = '2008-01-29', Freq = "days", typeline = 'l', 
col=c("black","blue","lightgrey"),xlab="Days", 
ylab = expression(paste(hat(sigma)[t])), xlim = NULL, ylim = c(0.02, 0.10), 
lty = c(1, 2, 1), lwd = c(2, 2, 2), cex = 0.68)

PlotF(Ytm ~ 1, data = data.frame(Ytm), model = model, pz = NULL, axisxdate = NULL,
plotYt = FALSE, transf = -0.5, Proc = "Smooth", Type = "Marg" ,distl = "PRED", 
a0 = a0, b0 = b0, ci = ci, posts = posts, startdate = NULL, enddate = NULL, 
Freq = NULL, typeline='l', col = c("black", "blue", "lightgrey"), 
xlab = "Days",ylab = expression(paste(hat(sigma)[t])),xlim=NULL, 
ylim = c(0.02, 0.10), lty = c(1, 2, 1), lwd = c(2, 2, 2), cex = 0.68)

################################################################################
# Example 3: GTE data, piecewise exponential model 
################################################################################
library("NGSSEML")
# MLE estimation:
data(gte_data)

Ytm = gte_data$V1

Xtm = NULL

Ztm = NULL

model = "PEM"

amp = FALSE

Event = gte_data$V2     
# Event: failure, 1.

Break = NGSSEML:::GridP(Ytm, Event, nT = NULL)

#LabelParTheta = c("w")
StaPar = c(0.73)

a0 = 0.01

b0 = 0.01

ci = 0.95

fit = ngssm.mle(Ytm ~ Event, data = data.frame(Ytm, Event), model = model, 
nBreaks = NULL, amp = amp, a0 = a0, b0 = b0, ci = ci, verbose = FALSE) 

#Bayesian estimation:

data(gte_data)

Ytm = gte_data$V1

Event = gte_data$V2   # Event: failure, 1.

Break = NGSSEML:::GridP(Ytm, Event, nT = NULL)

Xtm = NULL

Ztm = NULL

model = "PEM"

amp = FALSE

#LabelParTheta = c("w")
StaPar = c(0.5)

p = length(StaPar)

nn = length(Ytm)

a0 = 0.01

b0 = 0.01

pointss = 50    ### points

nsamplex = 1000 ## Sampling posterior

# Bayesian fit:
fitbayes = ngssm.bayes(Ytm ~ Event, data = data.frame(Ytm, Event), model = model, 
pz = NULL, StaPar = StaPar, amp = amp, a0 = a0, b0 = b0, prw = c(1, 1), 
prnu = NULL, prchi = NULL, prmu = NULL, prbetamu = NULL, prbetasigma = NULL, 
ci = ci, pointss = pointss, nsamplex = nsamplex, postplot = TRUE, 
contourplot = FALSE, verbose = TRUE)

# Smoothing: 

posts = fitbayes$samplepost

set.seed(1000)

PlotF(Ytm ~ Event, data = data.frame(Ytm, Event), pz = NULL, plotYt = FALSE,
axisxdate=Break[1:17], model = model, Proc="Smooth", Type="Marg", distl="PRED", 
a0 = a0, b0 = b0, ci = ci, posts = posts, typeline = 's', 
col=c("black","blue","lightgrey"), xlab = "Time to Failure (Days)", 
ylab = "Failure rate",xlim=c(0,139), ylim = c(0, 0.008), 
lty=c(1, 2, 1), lwd=c(2,2,2), cex=0.68)

################################################################################
## Example 4: Sys1 data, software reliability model 
################################################################################
library("NGSSEML")
# MLE estimation:
data(sys1_data)

Ytm = sys1_data[,1]+0.00001

# Xt as matrix always!
Xtm = sys1_data[,2]   

Zt = NULL

model = "SRWeibull"

#LabelParTheta = c("w", "alpha", "Beta1")
StaPar = c(0.9, 0.7, 0.01)

fit = ngssm.mle(Ytm ~ Xtm, data = data.frame(Ytm ,Xtm),
model = model, pz = NULL, StaPar = StaPar, a0 = 0.01, b0 = 0.01, ci = 0.95)

#Bayesian estimation:
data(sys1_data)

Ytm = sys1_data[,1]+0.00001

Xtm = sys1_data[,2]

model = "SRWeibull"  

#LabelParTheta = c("w","nu","Beta")
StaPar = c(0.98, 0.75, 0.02)

### points
pointss = 15   

# Bayesian fit:
fitbayes = ngssm.bayes(Ytm ~ Xtm, data = data.frame(Ytm,Xtm),
model = model, pz = NULL, StaPar = StaPar, prw = c(1,1), prnu = c(0.1, 0.1), 
prbetamu = rep(0, 1), prbetasigma = diag(100, 1, 1), pointss = pointss, 
nsamplex = 1000, postplot = TRUE, contourplot = TRUE, verbose = TRUE)

#Smoothing: 
posts = fitbayes$samplepost

set.seed(1000)
   
PlotF(Ytm ~ Xtm, data = data.frame(Ytm,Xtm), pz = NULL, plotYt = TRUE,
transf = 1/4, axisxdate = NULL, model = model,
Proc = "Smooth", Type = "Marg", distl = "PRED", a0 = 0.01, b0 = 0.01,
ci = 0.95, posts = posts, ypeline='l', col=c("black", "blue", "lightgrey"),
xlab = "Number of Failures", ylab = "Transformed Times", xlim = c(0,139),
ylim = c(-2,10), lty = c(1, 2, 1), lwd = c(1, 2, 1), cex = 0.68)
