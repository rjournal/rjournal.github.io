#Title of the Paper: RobustBF: An R Package for Robust Solution to the Behrens-Fisher Problem
#Authors: Gamze G�ven, ��kr� Ac�ta�, Hatice �amkar and Birdal �eno�lu

#In this R script file, we show the implementation of the proposed tests (RW and RF), provided in the 
# paper mentioned above,  using the data representing the values of
#10(y-2.0) (y is the pollution level (measurement of lead) in water samples from two lakes). It has
#been shown that long-tailed symmetric distribution provides plausible model for the mentioned data,
#see Tiku and Akkaya (2004) and also reference therein.


# Call the RobustBF package
install.packages("RobustBF")
library(RobustBF)

# observations of the pollution level data
y1 <- c(-1.48, 1.25, -0.51, 0.46, 0.60, -4.27, 0.63, -0.14, -0.38, 1.28,
        0.93, 0.51, 1.11, -0.17, -0.79, -1.02, -0.91, 0.10, 0.41, 1.11)
y2 <- c(1.32, 1.81, -0.54, 2.68, 2.27, 2.70, 0.78, -4.62, 1.88, 0.86,
        2.86, 0.47, -0.42, 0.16, 0.69, 0.78, 1.72, 1.57, 2.14, 1.62)

# The following code performs the Robust Welch (RW) Test on the pollution level data 
# to test the null hypothesis.
RW(y1,y2)

# Following code performs the Robust Fiducial (RF) Based Test.
RF(y1,y2,iter=5000)

# We also use 
t.test(y1,y2)
# function to perform the Welch's two sample t (W) test.



# Reference for the data set
# M. L. Tiku and A. D. Akkaya. Robust estimation and hypothesis testing. New Age International Limited
# Publishers, New Delhi, 2004.


