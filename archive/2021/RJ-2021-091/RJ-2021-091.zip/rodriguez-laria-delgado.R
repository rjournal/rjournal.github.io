## Installation
install.packages("cat.dt")
library(cat.dt)

## Example 1
example_cat <- CAT_DT(bank = itemBank, model = "GRM", crit = "MEPV", C = 0.3, 
                      stop = c(10,0), limit = 200, inters = 0.98, p = 0.9, 
                      dens = dnorm, 0, 1)

#View results (first node of the third level)
example_cat$nodes[[3]][[1]]

#Summarize results
summary(example_cat)

#Plot tree
plot_tree(example_cat, levels = 3, tree = 1)

## Example 2 (execute after Example 1)
#Seed
set.seed(0)

#Estimation of an individual and visualization
predict(example_cat, itemRes[1, ])

#Estimation of a group (it is recommended to store it in a variable)
predict(example_cat, itemRes)

