##########################
# R Journal
##########################

# clean environment and set working directory
rm(list=ls())

# set working directory
wd <- getwd()
setwd(wd)

# create empty folder for figures
ifelse(!dir.exists(file.path(paste0(wd,"/figs")))
       ,dir.create(file.path(paste0(wd,"/figs"))), FALSE)

# packages for the figures
library(RColorBrewer)
library(lattice)
library(gridExtra)
library(gridBase)

# install package from CRAN
install.packages("spfilteR")

# OR: install development version from GitHub
library(devtools)
devtools::install_github("sjuhl/spfilteR")

library(spfilteR)
data("fakedata")

y <- fakedataset$x1
X <- cbind(fakedataset$x2)

resid <- resid(lm(y ~ X))
MI.resid(resid, x = X, W = W, alternative = "greater")


EVs <- getEVs(W = W, covars = NULL)
E <- EVs$vectors

### FIGURE 1
col <- colorRampPalette(brewer.pal(n=9, "BuPu"))(400)
coord.x <- coord.y <- seq_len(sqrt(nrow(W)))
coord <- expand.grid(x=coord.x,y=coord.y)
# plot
png("./figs/eigenvector1.png",width=300, height=300)
levelplot(E[,1]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 1\n(MC = "
                                  ,round(EVs$moran[1],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector2.png",width=300, height=300)
levelplot(E[,10]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 10\n(MC = "
                                  ,round(EVs$moran[10],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector3.png",width=300, height=300)
levelplot(E[,20]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 20\n(MC = "
                                  ,round(EVs$moran[20],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector4.png",width=300, height=300)
levelplot(E[,30]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 30\n(MC = "
                                  ,round(EVs$moran[30],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector5.png",width=300, height=300)
levelplot(E[,70]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 70\n(MC = "
                                  ,round(EVs$moran[70],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector6.png",width=300, height=300)
levelplot(E[,80]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 80\n(MC = "
                                  ,round(EVs$moran[80],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector7.png",width=300, height=300)
levelplot(E[,90]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 90\n(MC = "
                                  ,round(EVs$moran[90],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/eigenvector8.png",width=300, height=300)
levelplot(E[,100]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Eigenvector 100\n(MC = "
                                  ,round(EVs$moran[100],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()


# identify candidate set
Ec <- EVs$moran / max(EVs$moran) >= .25
# obtain ESF residuals
esf.resid <- resid(lm(y ~ X + E[, Ec]))
# check for remaining spatial autocorrelation in model residuals
MI.resid(esf.resid, x = X, W = W, alternative = "greater")


round(partialR2(y = y, x = X, evecs = E[, Ec]), 6)

vif.ev(x = X, evecs = E[, Ec], na.rm = TRUE)


(esf <- lmFilter(y = y, x = X, W = W, objfn = "p", sig = .1, bonferroni = TRUE,
                positive = TRUE, ideal.setsize = TRUE))
esf$other$nev

summary(esf, EV = TRUE)


### FIGURE 2
png("./figs/output1.png",width=300, height=300)
plot(esf)
dev.off()
png("./figs/output2.png",width=300, height=300)
levelplot(esf$other$sf~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Spatial Filter\n(MC = "
                                  ,round(esf$other$sfMI,3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()
png("./figs/output3.png",width=300, height=300)
levelplot(esf$residuals[,"Filtered"]~coord[,1]*coord[,2],col.regions=col,colorkey=F
          ,contour=F, main=paste0("Residuals\n(MC = "
                                  ,round(esf$moran["Filtered","Observed"],3)
                                  ,")")
          ,xlab=NULL,ylab=NULL,scales=list(draw=F))
dev.off()


# define DVs
y.bin <- fakedataset$indicator
y.count <- fakedataset$count

# seed (because of 'boot.MI')
set.seed(123)

# logit model
(esf.logit <- glmFilter(y = y.bin, x = NULL, W = W, objfn = "p", model = "logit",
                        optim.method = "BFGS", sig = .05, bonferroni = FALSE,
                        resid.type = "pearson", boot.MI = 100))

# probit model
(esf.probit <- glmFilter(y = y.bin, x = NULL, W = W, objfn = "BIC",
                         model = "probit", optim.method = "BFGS",
                         min.reduction = 0, resid.type = "deviance",
                         boot.MI = 100))

# poisson model
(esf.poisson <- glmFilter(y = y.count, x = NULL, W = W, objfn = "pMI",
                          model = "poisson", optim.method = "BFGS", sig = .1,
                          resid.type = "pearson", boot.MI = 100))

