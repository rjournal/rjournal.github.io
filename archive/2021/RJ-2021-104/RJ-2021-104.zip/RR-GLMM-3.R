##
## Jean-Paul Fox, Konrad Klotzke, Duco Veen
## Generalized Linear Randomized Response Modeling using The Package \pkg{GLMMRR}
## MARCH 2021
## GLMMRR Version 0.5.0
##

### REAL DATA APPLICATION 1
### SECTION "AN RR VALIDATION STUDY" ###

require(GLMMRR)

data(MTURK) ## data object MTURK is created with ASQ-Mturk data.R (source Hoeglinger, Marc; Jann, Ben (2016))

### Define dummy variables ###

## dummy coded variable for cheater 
MTURK$cheaterdc <- rep(0,nrow(MTURK))
MTURK$cheaterdc[MTURK$cheater == 'cheater'] <- 1
MTURK$cheaterdh <- rep(0,nrow(MTURK))
MTURK$cheaterdh[MTURK$cheater == 'honest'] <- 1 

## True Prevalence Estimates per RR model
by(MTURK$cheaterdc[MTURK$dicegame==2],MTURK$RRmodel[MTURK$dicegame==2],mean,na.rm=TRUE) 

MTURK_cheating1 <- MTURK[which(MTURK$dicegame==2 & MTURK$Question=="cheating dice game"),]
rolla6 <- RRglm(RR_response ~ 1,
                item = Question, link = "RRlink.logit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,
                data = MTURK_cheating1)
summary(rolla6)

## how well know birthday?
## 33.6% don't know exactly  
## requires object data3 from "ASQ-MTurk data.R" 
#sum((table(data3$q21_1)+table(data3$q21_2)+table(data3$q21_3)+table(data3$q21_4)) / 
#      (table(data3$q21_1)+table(data3$q21_2)+table(data3$q21_3)+table(data3$q21_4))[1])-1

##RRmodel
MTURK$DQ <- rep(0,nrow(MTURK)) 
MTURK$DQ[MTURK$RRmodel=='DQ'] <- 1
MTURK$CW <- rep(0,nrow(MTURK)) 
MTURK$CW[MTURK$RRmodel=='Crosswise'] <- 1
MTURK$FR <- rep(0,nrow(MTURK)) 
MTURK$FR[MTURK$RRmodel=='Forced'] <- 1
MTURK$UQ <- rep(0,nrow(MTURK)) 
MTURK$UQ[MTURK$RRmodel=='UQM'] <- 1

## Question
MTURK$Questiond1 <- rep(0,nrow(MTURK)) 
MTURK$Questiond1[MTURK$Question=='cheating dice game'] <- 1
MTURK$Questiond2 <- rep(0,nrow(MTURK)) 
MTURK$Questiond2[MTURK$Question=='shoplifting'] <- 1
MTURK$Questiond3 <- rep(0,nrow(MTURK)) 
MTURK$Questiond3[MTURK$Question=='tax evasion'] <- 1
MTURK$Questiond4 <- rep(0,nrow(MTURK)) 
MTURK$Questiond4[MTURK$Question=='non voting'] <- 1

#### Prevalence estimates for roll-a-six game
#### MTURK$Question=="cheating dice game") :: Honest response = 0 and Dishonest response = 1
MTURK_cheating1 <- MTURK[which(MTURK$dicegame==2 & MTURK$Question=="cheating dice game"),]
rolla6A <- RRglm(RR_response ~ 1 + cheaterdc + CW + UQ + FR + cheaterdc*CW+cheaterdc*UQ,
                item = Question, link = "RRlink.logit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,
                data = MTURK_cheating1)
summary(rolla6A)

#DQ and honest reporters:
exp(rolla6A$coefficients[1])/(1+exp(rolla6A$coefficients[1]))
#ODDS DQ and honest reporters:
exp(rolla6A$coefficients[1])

#CW and honest reporters: 
exp(sum(rolla6A$coefficients[c(1,3)]))/(1+exp(sum(rolla6A$coefficients[c(1,3)])))
#UQ and honest reporters: 
exp(sum(rolla6A$coefficients[c(1,4)]))/(1+exp(sum(rolla6A$coefficients[c(1,4)])))
#FR and honest reporters: 
exp(sum(rolla6A$coefficients[c(1,5)]))/(1+exp(sum(rolla6A$coefficients[c(1,5)])))

#DQ and dishonest reporters: 
exp(sum(rolla6A$coefficients[1:2]))/(1+exp(sum(rolla6A$coefficients[1:2])))
#ODDS DQ and dishonest reporters: 
exp(sum(rolla6A$coefficients[1:2]))
#CW and dishonest reporters: 
exp(sum(rolla6A$coefficients[c(1,2,3,6)]))/(1+exp(sum(rolla6A$coefficients[c(1,2,3,6)])))
#UQ and dishonest reporters: 
exp(sum(rolla6A$coefficients[c(1,2,4,7)]))/(1+exp(sum(rolla6A$coefficients[c(1,2,4,7)])))
#FR and dishonest reporters: 
exp(sum(rolla6A$coefficients[c(1,2,5)]))/(1+exp(sum(rolla6A$coefficients[c(1,2,5)])))

## B examine other sensitive questions
MTURK_cheating2 <- MTURK[which(MTURK$dicegame==2 & MTURK$Question!="cheating dice game"),]
rolla6B <- RRglm(RR_response ~ 1 + RRmodel + Question + cheaterdc*RRmodel, item = Question, link = "RRlink.logit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,data = MTURK_cheating2)
summary(rolla6B)

#DQ and honest reporters:
exp(rolla6B$coefficients[1])/(1+exp(rolla6B$coefficients[1]))
#ODDS DQ and honest reporters:
exp(rolla6B$coefficients[1])

#DQ and dishonest reporters: 
exp(sum(rolla6B$coefficients[c(1,7)]))/(1+exp(sum(rolla6B$coefficients[c(1,7)])))
#ODDS DQ and dishonest reporters: 
exp(sum(rolla6B$coefficients[c(1,7)]))
#ODDS CW non-vote 
exp(sum(rolla6B$coefficients[c(1,2)]))
exp(sum(rolla6B$coefficients[c(1,2)]))/(1+exp(sum(rolla6B$coefficients[c(1,2)])))
#ODDS UQ non-vote
exp(sum(rolla6B$coefficients[c(1,3)]))
exp(sum(rolla6B$coefficients[c(1,3)]))/(1+exp(sum(rolla6B$coefficients[c(1,3)])))
#ODDS FR non-vote
exp(sum(rolla6B$coefficients[c(1,4)]))
exp(sum(rolla6B$coefficients[c(1,4)]))/(1+exp(sum(rolla6B$coefficients[c(1,4)])))

### examine contribution interaction effect 
rolla6C <- RRglm(RR_response ~ 1 + RRmodel+Question, item = Question, link = "RRlink.logit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,data = MTURK_cheating2)
anova(rolla6C, rolla6B,test="Chisq")

## AIC difference
rolla6B$aic-rolla6C$aic

RRglmGOF(RRglmOutput = rolla6C, doPearson = TRUE, doDeviance = TRUE,
         doHlemeshow = TRUE)

## fit other link functions
rolla6D <- RRglm(RR_response ~ 1 + RRmodel + Question, item = Question, link = "RRlink.cloglog", RRmodel = RRmodel,p1=RRp1,p2=RRp2,data = MTURK_cheating2)
rolla6E <- RRglm(RR_response ~ 1 + RRmodel + Question, item = Question, link = "RRlink.probit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,data = MTURK_cheating2)
rolla6F <- RRglm(RR_response ~ 1 + RRmodel + Question, item = Question, link = "RRlink.cauchit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,data = MTURK_cheating2)

## compare H-L statistic for model with different link functions  
RRglmGOF(RRglmOutput = rolla6D, doPearson = TRUE, doDeviance = TRUE,
         doHlemeshow = TRUE)
RRglmGOF(RRglmOutput = rolla6E, doPearson = TRUE, doDeviance = TRUE,
         doHlemeshow = TRUE) ## improved fit over logit link
RRglmGOF(RRglmOutput = rolla6F, doPearson = TRUE, doDeviance = TRUE,
         doHlemeshow = TRUE)

## AIC difference
rolla6C$aic-rolla6E$aic

## Residual plots 
plot(rolla6C)
#1 prevalence estimates with 95\% Confidence intervals
#2 fitted RR probabilities versus deviance residuals per RR design
#3 fitted RR probabilities versus grouped deviance residuals
#4 Q-Q plot of grouped deviance residuals (deviance goodness-of-fit statistic 
##    assumes normally distributed grouped-residuals)  
## with arguments: plot(rolla6C, which = 3, type = "pearson") 

#optional residual plots
#plot(rolla6C$fitted.values,residuals(rolla6C, type = "response"))
#plot(rolla6C$fitted.values,residuals(rolla6C, type = "pearson"))
#plot(rolla6C$fitted.values,residuals(rolla6C, type = "deviance"))
#plot(rolla6C$linear.predictors,residuals(rolla6C, type = "response"))
#plot(rolla6C$linear.predictors,exp(rolla6C$linear.predictors)/(1+exp(rolla6C$linear.predictors)))

## select cases 
set <- names(rolla6C$linear.predictors)
dataset <- MTURK_cheating2[set,]
plot(rolla6C$fitted.values,residuals(rolla6C, type = "pearson"),
      cex=.8,bty="l",xlim=c(.1,.8),ylim=c(-3,3),xlab="Fitted",ylab="Residual (Pearson)")
points(rolla6C$fitted.values[which(dataset$DQ==1)],
      residuals(rolla6C, type = "pearson")[which(dataset$DQ==1)],xlim=c(0,1),
      ylim=c(-1,1),pch=15,col="black")
points(rolla6C$fitted.values[which(dataset$CW==1)],
      residuals(rolla6C, type = "pearson")[which(dataset$CW==1)],pch=16,col="green")
points(rolla6C$fitted.values[which(dataset$UQ==1)],
       residuals(rolla6C, type = "pearson")[which(dataset$UQ==1)],pch=17,col="red")
points(rolla6C$fitted.values[which(dataset$FR==1)],
       residuals(rolla6C, type = "pearson")[which(dataset$FR==1)],pch=18,col="blue")
legend(.6,3,c("DQ","CW","FR","UQ"), 
       col=c("black","green","blue","red"),pch = c(15,16,18,17), bg = "gray95",cex=.7)

#################################################
## NOT IN REPORT
## Include more predictors to improve model fit
## and explain individual differences
#################################################
rolla6G <- RRglm(RR_response ~ 1 + RRmodel + Question + 
                gender+education+conscientiousness+
                openness+neuroticism+extraversion, 
                 item = Question, link = "RRlink.logit", RRmodel = RRmodel,p1=RRp1,p2=RRp2,data = MTURK_cheating2)
summary(rolla6G)

#   ----- end of analysis -------


##
## Jean-Paul Fox, Konrad Klotzke, Duco Veen
## Generalized Linear Randomized Response Modeling Using The Package \pkg{GLMMRR}
## MARCH 2021
## GLMMRR Version 0.5.0
##

### REAL DATA APPLICATION 2
### SECTION "Extended item response modeling: Prevalence of student misconduct" ###

require(GLMMRR)

data(ETHBE) ## data object ETHBE is created with ASQ-ETHBE data.R (source Hoeglinger, Marc; Jann, Ben; Diekmann, Andreas (2014).)

## Fit multiple group (multiple RRT conditions) IRT model with probit link
## Increased default number of iterations

out.re <- RRglmer(RR_response ~ 1 + Question + expcond + (1|id), item=Question,
                  link = "RRlink.probit", RRmodel = RRmodel,p1=p1,p2=p2,data = ETHBE,
                  control=glmerControl(optimizer="bobyqa", optCtrl = list(maxfun = 200000)))
summary(out.re)
plot(out.re)
#1 prevalence estimate with 95% confidence interval per item and design
#2 latent variable (random intercept) estimates 
#3 fitted RR probabilities versus conditional Pearson residuals 
#4 fitted RR probabilities versus unconditional Pearson residuals

##
## simultaneously test for differences between RRTs
## 
library(multcomp)

## (1) FRs not different
## (2) CWs not different
## (3) FRs different from CWs
## (4) FRs different from UQ

K <- matrix(c(c(0, 0, 0, 0, 0, 1, 0, -1, 0 , 0),
            c(0, 0, 0, 0, 0, 0, 1, 0, 0 ,-1),
            c(0, 0, 0, 0, 0, 1, -1, 1, 0 ,-1),
            c(0, 0, 0, 0, 0, 0, 0, 1, -1 ,0)), nrow=4,ncol=10,byrow=T)
t <- glht(out.re, linfct = K)
summary(t)

## Run GLM with factor variables Question and expcond using a Probit link
##
out.fe <- RRglm(RR_response ~ 1 + Question + expcond, item=Question,link = "RRlink.probit", 
                RRmodel = RRmodel,p1=p1,p2=p2,data = ETHBE)
summary(out.fe)

## Examine fit of GLM
##
RRglmGOF(RRglmOutput = out.fe, doPearson = TRUE, doDeviance = TRUE,
         doHlemeshow = TRUE)
plot(out.fe) 

# Examine model fit
# Random effect component needed
anova(out.re,out.fe)

## Plot fitted probabilities against Pearson residuals
## prediction on the scale of the linear predictor
eta <- predict(out.re, type = "link")
##pp <- pnorm(eta) #predicted probabilities without RR 
dum <- getRRparameters(ETHBE$RRmodel, ETHBE$p1, ETHBE$p2)
## predicted probabilities with RRT 
pp <- dum$c + dum$d*pnorm(eta) #probabilities with RR 
## note that pnorm(eta) are the individual prevalence estimates

##
resid <- residuals(out.re, type = c("pearson"))
plot(pp[ETHBE$expcond=="direct questioning"],
      resid[ETHBE$expcond=="direct questioning"],bty="l",
      xlim=c(0,1),ylim=c(-2,6),cex=.8,xlab="Fitted probability",ylab="Pearson residual")
points(pp[ETHBE$expcond=="CM pick-a-number"],
       resid[ETHBE$expcond=="CM pick-a-number"],cex=.8,pch=19,col="grey80")
points(pp[ETHBE$expcond=="FR pick-a-number"],
     resid[ETHBE$expcond=="FR pick-a-number"],cex=.8,pch=15,col="red")
points(pp[ETHBE$expcond=="FR random wheel"],
       resid[ETHBE$expcond=="FR random wheel"],cex=.8,pch=16,col="blue")
points(pp[ETHBE$expcond=="CM unrelated question"],
       resid[ETHBE$expcond=="CM unrelated question"],cex=.8,pch=17,col="green")
points(pp[ETHBE$expcond=="UQ Benford"],
       resid[ETHBE$expcond=="UQ Benford"],cex=.8,pch=18,col="purple")
abline(h=1,lty=2,col="grey")
abline(h=-1,lty=2,col="grey")
legend(.6,6,c("DQ","FR pick-a-number","FR random wheel",
              "CW unrelated", "UQ","CW pick-a-number"), 
       col=c("black","red","blue","green","purple","grey80"),
       pch = c(1,15,16,17,18,19),cex=.7,bty="n")

## -- end of analysis -- 


