# install.packages("mgee2")
library(mgee2)

# ====== simulated data example ======
# example code 1
data(obs1)
obs1$visit <- as.factor(obs1$visit)
obs1$treatment <- as.factor(obs1$treatment)
obs1$S <- as.factor(obs1$S)
obs1$W <- as.factor(obs1$W)
## set misclassification parameters to be known.
varphiMat <- gamMat <- log( cbind(0.04/0.95, 0.01/0.95,
                                  0.95/0.03, 0.02/0.03,
                                  0.04/0.01, 0.95/0.01) )
mgee2k.fit = mgee2k(formula = S~W+treatment+visit, id = "ID", data = obs1,
                    corstr = "exchangeable", misvariable = "W", gamMat = gamMat, 
                    varphiMat = varphiMat)
summary(mgee2k.fit)

# png(filename = "mgee2k.png",units="in", width=3.5, height=3.0,, res = 1200)
# plot_model(mgee2k.fit)
# dev.off()

# example code 2
data(obs1)
obs1$Y <- as.factor(obs1$Y)
obs1$X <- as.factor(obs1$X)
obs1$visit <- as.factor(obs1$visit)
obs1$treatment <- as.factor(obs1$treatment)
obs1$S <- as.factor(obs1$S)
obs1$W <- as.factor(obs1$W)
mgee2v.fit = mgee2v(formula = S~W+treatment+visit, id = "ID", data = obs1,
                    y.mcformula = "S~1", x.mcformula = "W~1", misvariable = "W",
                    valid.sample.ind = "delta",
                    corstr = "exchangeable")
summary(mgee2v.fit)
# png(filename = "mgee2v.png",units="in", width=3.5, height=3.0,, res = 1200)
# plot_model(mgee2v.fit)
# dev.off()

# example code 3
naigee.fit = ordGEE2(formula = S~W+treatment+visit, id = "ID",
                     data = obs1, corstr = "exchangeable")
summary(naigee.fit)
# png(filename = "naigee.png",units="in", width=3.5, height=3.0,, res = 1200)
# plot_model(naigee.fit)
# dev.off()

# ====== real data example ======
data(heart)
#Example 1:
heart$chol = as.factor(heart$chol)
heart$exam3 = as.factor(heart$exam3)
## set misclassification parameters to be known.
varphiMat <- gamMat <- log( cbind(0.04/0.95, 0.01/0.95,
                                  0.95/0.03, 0.02/0.03,
                                  0.04/0.01, 0.95/0.01) )
mgee2k.fit = mgee2k(formula = HBP~chol+AGE+CURSMOKE+exam3, id = "RANDID",
                    data = heart,
                    corstr = "exchangeable", misvariable = "chol", 
                    gamMat = gamMat,
                    varphiMat = varphiMat)
summary(mgee2k.fit)

#Example 2:
naigee.fit = ordGEE2(formula = HBP~chol+AGE+CURSMOKE+exam3, id = "RANDID",
                     data = heart, corstr = "exchangeable")
summary(naigee.fit)