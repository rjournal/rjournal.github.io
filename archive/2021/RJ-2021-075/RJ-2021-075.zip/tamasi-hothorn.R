## ----setup, echo=FALSE, message=FALSE, results="hide"-------------------------
knitr::opts_chunk$set(highlight=FALSE, background="white",
                      size = "small",
                      out.width = NULL, out.height = NULL,
                      fig.scap = NA)
knitr::opts_knit$set(global.par = TRUE)
knitr::render_sweave()  # use Sweave environments
knitr::set_header(highlight = '')  # do not \usepackage{Sweave}
options(prompt = "R> ", continue = "+  ", useFancyQuotes = FALSE)
options(width = 80, digits = 3)

## Dependencies
library("tramME")
library("ggplot2")
library("lme4")
library("survival")

## Functions
mycolors <- function(nr, type = "line") {
  cols <- list()
  cols[[1]] <- c(red = 0, green = 84, blue = 150)
  cols[[2]] <- c(red = 202, green = 108, blue = 24)
  out <- as.list(cols[[nr]])
  out$alpha <- switch(type, line = 255L, fill = 140L)
  out$maxColorValue <- 255
  do.call("rgb", out)
}

plot_cicomp <- function(est1, est2, labels, mnames, vline = 0, ylab = "",
                        col1 = mycolors(1), col2 = mycolors(2), xlas = 0,
                        legend_pos = "topleft") {
  stopifnot(all(dim(est1) == dim(est2)))
  nr <- nrow(est1)
  xs <- matrix(rep(c(-0.2, 0.2), nr) + rep(1:nr, each = 2), nrow = 2)
  plot(0, 0, type = "n", xlab = ylab, ylab = "",
       xlim = range(est1[, -1], est2[, -1]) + c(-0.2, 0.2),
       ylim = rev(range(xs) + c(-0.3, 0.3)), yaxt = "n", yaxs = "i")
  abline(h = seq(1.5, nr-0.5, by = 1), col = "grey", lty = 2)
  abline(v = vline)
  points(c(rbind(est1[, 1], est2[, 1])), c(xs),
         col = rep(c(col1, col2), nr), pch = 20)
  segments(x0 = est1[, 2], y0 = xs[1, ], x1 = est1[, 3], col = col1, lwd = 2)
  segments(x0 = est2[, 2], y0 = xs[2, ], x1 = est2[, 3], col = col2, lwd = 2)
  axis(2, at = 1:nr, labels = labels, tick = FALSE, las = xlas)
  if (!is.null(legend_pos)) {
    legend(legend_pos, mnames, col = c(col1, col2),
           pch = 20, lwd = 2, cex = 0.95, bg = "white")
  }
}

## ggplot theme
ggth <- theme(panel.grid.major = element_line(colour = "lightgrey", size = 0.3,
                                              linetype = "dotted"),
              panel.grid.minor = element_blank(),
              panel.background = element_blank(),
              strip.background = element_rect(colour = "black", fill = "white"),
              axis.line = element_line(colour = "black"),
              axis.title = element_text(size = rel(0.9)),
              legend.title = element_blank(),
              legend.key = element_rect(fill = "transparent", colour = "transparent"))


## ----sleeptudy-data, echo=FALSE, fig.width=7, fig.height=4, out.width="\\linewidth"----
data("sleepstudy", package = "lme4")
dat <- within(sleepstudy, Subject <- paste0("Subject = ", Subject))
ggplot(dat, aes(x = Days, y = Reaction)) +
  facet_wrap(~ Subject, nrow = 3) +
  geom_point(col = "black", size = 0.75) +
  geom_line(col = "black") +
  scale_x_continuous("Days of sleep deprivation",
                     breaks = c(0, 2, 4, 6, 8)) +
  ylab("Average reaction time (ms)") +
  ggth


## ----sleepstudy-lmme, message=FALSE-------------------------------------------
library("tramME")
sleep_lmME <- LmME(Reaction ~ Days + (Days | Subject), data = sleepstudy)
logLik(sleep_lmME)


## ----message=FALSE------------------------------------------------------------
library("lme4")
sleep_lmer <- lmer(Reaction ~ Days + (Days | Subject), data = sleepstudy,
                   REML = FALSE)
logLik(sleep_lmer)


## -----------------------------------------------------------------------------
cbind(coef = coef(sleep_lmME, as.lm = TRUE),
      se = sqrt(diag(vcov(sleep_lmME, as.lm = TRUE, pargroup = "fixef"))))


## -----------------------------------------------------------------------------
summary(sleep_lmer)$coefficients


## -----------------------------------------------------------------------------
VarCorr(sleep_lmME, as.lm = TRUE) ## random effects
sigma(sleep_lmME) ## residual SD
VarCorr(sleep_lmer)


## ----sleepstudy-lmme-upd------------------------------------------------------
## Update to specify the support
sleep_lmME1b <- update(sleep_lmME, support = c(150, 520))
## Set up grid to calculate conditional quantiles
nd <- expand.grid(Days = seq(min(sleepstudy$Days), max(sleepstudy$Days),
                             length.out = 200),
                  Subject = unique(sleepstudy$Subject))
## The quantiles we want to calculate
pr <- c(0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975)
## Specify the random effects values as predicted by the model
re <- ranef(sleep_lmME1b)
## Calculate conditional quantiles
pred <- predict(sleep_lmME1b, newdata = nd, prob = pr, ranef = re,
                type = "quantile")


## ----sleepstudy-quantiles1, echo=FALSE, fig.width=7, fig.height=5, out.width="\\linewidth"----
plot_cquant <- function(data, newdat, pred, quantiles) {
  pred <- c(pred)
  i <- 1:nrow(newdat)
  nd <- expand.grid(quantile = factor(quantiles), i = i)
  nd <- cbind(nd, newdat[nd$i,,drop = FALSE])
  nd$predict <- pred
  newdat <- nd
  newdat$Subject <- factor(paste("Subject =", newdat$Subject))
  data$Subject <- factor(paste("Subject =", data$Subject))
  ggplot(newdat, aes(x = Days, y = predict, color = quantile)) +
    geom_line() +
    geom_point(aes(x = Days, y = Reaction), data = data, color = "black", alpha = 0.3,
               size = 0.75) +
    geom_line(aes(x = Days, y = Reaction), data = data, color = "black", alpha = 0.3) +
    facet_wrap(~ Subject, nrow = 3) +
    scale_x_continuous("Days of sleep deprivation",
                     breaks = c(0, 2, 4, 6, 8)) +
    ylab("Average reaction time (ms)") +
    labs(colour = "Estimated conditional quantiles") +
    colorspace::scale_color_discrete_diverging("Blue-Red2") +
    theme(panel.grid.major = element_line(colour = "lightgrey", size = 0.3,
                                          linetype = "dotted"),
          panel.grid.minor = element_blank(),
          panel.background = element_blank(),
          strip.background = element_rect(colour = "black", fill = "white"),
          axis.line = element_line(colour = "black"),
          axis.title = element_text(size = rel(0.9)),
          legend.title = element_text(size = rel(0.9)),
          legend.position = "bottom",
          legend.key = element_rect(fill = "transparent", colour = "transparent")) +
    guides(colour = guide_legend(title.position = "top", title.hjust = 0.5, nrow = 1))
}

plot_cquant(sleepstudy, nd, pred, pr)


## -----------------------------------------------------------------------------
resid_lmME <- resid(sleep_lmME, as.lm = TRUE)
resid_lmer <- resid(sleep_lmer)
all.equal(resid_lmME, resid_lmer)


## -----------------------------------------------------------------------------
lp <- predict(sleep_lmME, type = "lp")


## ----resid-plot-lmME, echo=FALSE, fig.width=7, fig.height=3.5, out.width="\\linewidth"----
blk <- rgb(0, 0, 0, .3)
par(mfrow = c(1, 2), cex = 0.75, mar = c(4.1, 4.1, 1.5, 1.5))
scatter.smooth(lp, resid_lmME, pch = 19,
  lpars = list(col = "red"), xlab = "Linear predictor",
  ylab = "Residuals", col = blk)
grid()
qqnorm(resid_lmME, pch = 19, main = "", col = blk)
qqline(resid_lmME)
grid()


## ----sleepstudy-ic-data-------------------------------------------------------
library("survival")
ub <- ceiling(sleepstudy$Reaction / 50) * 50
lb <- floor(sleepstudy$Reaction / 50) * 50
lb[ub == 200] <- 0
sleepstudy$Reaction_ic <- Surv(lb, ub, type = "interval2")
head(sleepstudy$Reaction_ic)


## ----sleepstudy-ic------------------------------------------------------------
sleep_lmME2 <- LmME(Reaction_ic ~ Days + (Days | Subject), data = sleepstudy)
logLik(sleep_lmME2)


## ----sleepstudy-ic-results----------------------------------------------------
cbind(coef = coef(sleep_lmME2, as.lm = TRUE),
      se = sqrt(diag(vcov(sleep_lmME2, as.lm = TRUE, pargroup = "fixef"))))
sigma(sleep_lmME2)
VarCorr(sleep_lmME2, as.lm = TRUE)


## ----sleepstudy-ic2-----------------------------------------------------------
sleep_lmME3 <- LmME(Reaction_ic ~ Days + (Days || Subject), data = sleepstudy)
logLik(sleep_lmME3)


## ----sleepstudy-lrtest--------------------------------------------------------
anova(sleep_lmME2, sleep_lmME3)


## ----sleepstudy-boxcox-mod----------------------------------------------------
sleep_bc <- BoxCoxME(Reaction ~ Days + (Days | Subject), data = sleepstudy,
                     order = 10)
logLik(sleep_bc)


## ----sleepstudy-quantiles2, echo=FALSE, fig.width=7, fig.height=5, out.width="\\linewidth"----
sleep_bc1b <- update(sleep_bc, support = c(150, 520))
## Set up grid to calculate conditional quantiles
nd <- expand.grid(Days = seq(min(sleepstudy$Days), max(sleepstudy$Days),
                             length.out = 200),
                  Subject = unique(sleepstudy$Subject))
## The quantiles we want to calculate
pr <- c(0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975)
## Specify the random effects values as the fitted by the model
re <- ranef(sleep_bc1b)
## Calcualte conditional qunatiles
pred <- predict(sleep_bc1b, newdata = nd, prob = pr, ranef = re,
                type = "quantile")
plot_cquant(sleepstudy, nd, pred, pr)


## ----sleepstudy-dens, echo=FALSE, fig.width=8, fig.height=4, out.width="\\linewidth"----
## -- Compare two subjects
par(mfrow = c(1, 2), cex = 0.8, mar = c(4.1, 4.1, 1.5, 1.5))
nd <- subset(sleepstudy, subset = Subject %in% c(308, 309))
cols <- c(colorspace::sequential_hcl(13, palette = "Blues 3")[1:10],
          colorspace::sequential_hcl(13, palette = "Oranges")[1:10])
## NOTE: we don't set the vector of the random effects, the model predicts it
plot(sleep_bc1b, newdata = nd, type = "density", K = 200, col = cols, lwd = 2,
     xlab = "Average reaction time (ms)")
grid()
L <- legend("topright", legend = rep(NA, 20), col = cols, lty = 1, lwd = 2, ncol = 2,
            bty = "n", inset = c(0, 0.04), cex = 0.9)
legend(L$rect$left, y = L$rect$top, legend = 0:9, col = rep(NA, 10), lty = 1, x.intersp = -3.5,
       bg = NA, bty = "n", cex = 0.9)
legend(L$rect$left, y = L$rect$top, legend = c(308, 309), col = rep(NA, 2), lty = 1,
       y.intersp = -1, x.intersp = -0.9, bg = NA, bty = "n", ncol = 2, xjust = 0.1, cex = 0.9)

## -- The reference subject (at the mean of the random effect vector)
nd <- subset(sleepstudy, subset = Subject == 308) ## we only need one subject
cols <- colorspace::sequential_hcl(12, palette = "Grays")[1:10]
## NOTE: we explicitly set the random effects vector to 0
plot(sleep_bc1b, newdata = nd, ranef = "zero", type = "density", K = 200,
     col = cols, lwd = 2, xlab = "Average reaction time (ms)")
grid()
legend("topright", legend = 0:9, col = cols, lty = 1, lwd = 2, cex = 0.9, bty = "n")
## NOTE: The next code block contains the same steps without plot formatting.
## It is not executed in the paper.


## ----eval=FALSE---------------------------------------------------------------
## ## -- Compare two subjects (308 and 309)
## nd <- subset(sleepstudy, subset = Subject %in% c(308, 309))
## plot(sleep_bc1b, newdata = nd, type = "density", K = 200)
## ## -- The reference subject (at the mean of the random effect vector)
## ## (we only need an arbitrary subject)
## nd <- subset(sleepstudy, subset = Subject == 308)
## ## NOTE: we explicitly set the random effects vector to 0
## plot(sleep_bc1b, newdata = nd, ranef = "zero", type = "density", K = 200)


## ----warning=FALSE------------------------------------------------------------
sleep_bc2 <- BoxCoxME(Reaction | Days ~ 1 + (Days | Subject), data = sleepstudy,
                      order = 10, support = c(150, 520))
logLik(sleep_bc2)


## ----sleepstudy-quantiles3, echo=FALSE, fig.width=7, fig.height=5, out.width="\\linewidth", warning=FALSE----
## Set up grid to calculate conditional quantiles
nd <- expand.grid(Days = seq(min(sleepstudy$Days), max(sleepstudy$Days),
                             length.out = 200),
                  Subject = unique(sleepstudy$Subject))
## The quantiles we want to calculate
pr <- c(0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975)
## Specify the random effects values as the fitted by the model
re <- ranef(sleep_bc2)
## Calcualte conditional qunatiles
pred <- predict(sleep_bc2, newdata = nd, prob = pr, ranef = re,
                type = "quantile")
plot_cquant(sleepstudy, nd, pred, pr)


## ----margdist-bc, cache=TRUE--------------------------------------------------
ndraws <- 1000 ## number of MC draws
## Set up the grid on which we evaluate the marginal distribution
nd <- expand.grid(
  Reaction = seq(min(sleepstudy$Reaction), max(sleepstudy$Reaction),
                 length.out = 100),
  Days = 0:9,
  Subject = 1)
## Sample from the distribution of the random effects
re <- simulate(sleep_bc, newdata = nd, nsim = ndraws, what = "ranef", seed = 100)
## Evaluate the conditional distribution at each draw
## (done in parallel to speed up computations)
cp <- parallel::mclapply(re, function(x) {
  predict(sleep_bc, newdata = nd, ranef = x, type = "distribution")
}, mc.cores = 8)
cp <- array(unlist(cp), dim = c(100, 10, ndraws))
## Integral: take the average over these
mp_bc <- apply(cp, c(1, 2), mean)


## ----sleepstudy-margdist,dependson="margdist-bc",echo=FALSE,message=FALSE,fig.width=7,fig.height=4,cache=TRUE,out.width="\\linewidth"----
## --- LmME
## Repeat the same steps as in the case of BoxCoxME
re <- simulate(sleep_lmME, newdata = nd, nsim = ndraws, what = "ranef", seed = 100)
cp <- parallel::mclapply(re, function(x) {
  predict(sleep_lmME, newdata = nd, ranef = x, type = "distribution")
}, mc.cores = 8)
cp <- array(unlist(cp), dim = c(100, 10, ndraws))
mp_lmME <- apply(cp, c(1, 2), mean)

## Set up data for plotting
dat <- nd
dat$Days <- paste0("Days = ", dat$Days)
dat$mp_lm <- c(mp_lmME)
dat$mp_bc <- c(mp_bc)
dat2 <- sleepstudy
dat2$Days <- paste0("Days = ", dat2$Days)
## Plot
ggplot(dat, aes(x = Reaction)) +
  facet_wrap(~ Days, nrow = 2) +
  geom_line(aes(y = mp_bc, colour = "BoxCoxME")) +
  geom_line(aes(y = mp_lm, colour = "LmME")) +
  stat_ecdf(aes(x = Reaction, colour = "ECDF"), data = dat2, geom = "step") +
  xlab("Average reaction time (ms)") +
  ylab("Marginal distribution") +
  ggth +
  theme(legend.position = "bottom") +
  scale_color_manual(
    values = c(rgb(0, 84, 150, maxColorValue = 255),
               rgb(202, 108, 24, maxColorValue = 255),
               rgb(.5, .5, .5, .5)),
    breaks = c("BoxCoxME", "LmME", "ECDF"))


## ----neckpain-data, echo=FALSE, fig.width=7, fig.height=3.5, out.width="\\linewidth"----
## Plot
data("neck_pain", package = "ordinalCont")
dat <- within(neck_pain, {
  trt <- ifelse(laser == 1, "Active", "Placebo")
  t   <- ifelse(time == 1, "Baseline",
         ifelse(time == 2, "Week 7", "Week 12"))
})
ggplot(dat, aes(t, vas, group = id)) +
  facet_wrap(~ trt) +
  geom_line(col = "grey", alpha = 0.5) +
  geom_point(col = "grey", alpha = 0.5, size = 0.75) +
  scale_x_discrete(limits = c("Baseline", "Week 7", "Week 12")) +
  xlab("Follow-up times") +
  ylab("Pain level (VAS)") +
  ggth


## ----neckpain-colrme----------------------------------------------------------
neck_tr <- ColrME(vas ~ laser * time + (1 | id), data = neck_pain,
                  bounds = c(0, 1), support = c(0, 1))


## ----neckpain-ordinalCont, results="hide", message=FALSE, cache=TRUE----------
library("ordinalCont")
neck_ocm <- ocm(vas ~ laser * time + (1 | id), data = neck_pain, scale = c(0, 1))


## ----neckpain-compestim, echo=FALSE,fig.width=7, fig.height=3.5, out.width="\\linewidth"----
par(mfrow = c(1, 2), cex = 0.75, mar = c(4.1, 4.1, 1.5, 1.5))
## -- baseline transformation functions
h_tr <- trafo(neck_tr, type = "trafo", confidence = "interval", K = 100)
h_ocm <- ordinalCont:::get_gfun.ocm(neck_ocm)
plot(h_tr, col = mycolors(1), fill = mycolors(1, "fill"),
     xlab = "Pain level (VAS)", ylab = expression(h(y)), lwd = 2,
     panel.first = grid())
polygon(c(h_ocm[, 1], rev(h_ocm[, 1])), c(h_ocm[, 3], rev(h_ocm[, 4])), border = NA,
        col = mycolors(2, "fill"))
lines(h_ocm[, 1], h_ocm[, 2], col = mycolors(2), lwd = 2)
legend("topleft", c("tramME", "ordinalCont"),
       col = c(mycolors(1), mycolors(2)),
       lty = 1, lwd = 2, bty = "n")
rug(neck_pain$vas, col = rgb(.1, .1, .1, .1))
## --- lORs
idx_ocm <- 2:6
ci_ocm <- cbind(coef(neck_ocm)[idx_ocm], confint(neck_ocm)[idx_ocm, ])
ci_tr <- cbind(coef(neck_tr), confint(neck_tr, pargroup = "shift"))
labs <- c(expression(beta[Active]), expression(beta["7w"]), expression(beta["12w"]),
          expression(beta["7w, Active"]), expression(beta["12w, Active"]))
#par(cex = 0.8, mar = c(4, 10, 2, 2))
plot_cicomp(ci_tr, ci_ocm, labels = labs, xlas = 1,
            mnames = c("tramME", "ordinalCont"), ylab = "Log-odds ratios",
            legend_pos = NULL)


## ----neckpain-ORs-------------------------------------------------------------
exp(coef(neck_tr))


## ----margdist-colr, cache=TRUE------------------------------------------------
## A function to evaluate the joint cdf of the response and the random effects:
## Takes a vector of random effect and covariates values, evaluates the conditional
## distribution at these values and multiplies it with the pdf of the random effects
jointCDF <- function(re, nd, mod) {
  nd <- nd[rep(1, length(re)), ]
  nd$id <- seq(nrow(nd)) ## to take vector-valued REs
  pr <- predict(mod, newdata = nd, ranef = re, type = "distribution") *
    dnorm(re, 0, sd = sqrt(varcov(mod)[[1]][1, 1]))
  c(pr)
}
## Marginalize the joint cdf by integrating out the random effects
## using adaptive quadratures
marginalCDF <- function(nd, mod) {
  nd$cdf <- integrate(jointCDF, lower = -Inf, upper = Inf, nd = nd, mod = mod)$value
  nd
}
## Set up the grid on which we evaluate the marginal distribution
nd <- expand.grid(vas = seq(0, 1, length.out = 100),
                  time = unique(neck_pain$time),
                  laser = unique(neck_pain$laser))
## Calls marginalCDF on each row of nd
## (done in parallel to speed up computations)
mp_colr <- parallel::mclapply(split(nd, seq(nrow(nd))),
                              marginalCDF, mod = neck_tr, mc.cores = 8)
mp_colr <- do.call("rbind", mp_colr)


## ----neckpain-margdist,echo=FALSE,fig.width=7,fig.height=3,dependson="margdist-colr",out.width="\\linewidth"----
## Data for plotting
dat <- within(mp_colr, {
  trt <- factor(ifelse(laser == 1, "Active", "Placebo"), levels = c("Active", "Placebo"))
  t   <- factor(ifelse(time == 1, "Baseline",
            ifelse(time == 2, "Week 7", "Week 12")),
            levels = c("Baseline", "Week 7", "Week 12"))
})
dat2 <- within(neck_pain, {
  trt <- factor(ifelse(laser == 1, "Active", "Placebo"), levels = c("Active", "Placebo"))
  t   <- factor(ifelse(time == 1, "Baseline",
            ifelse(time == 2, "Week 7", "Week 12")),
            levels = c("Baseline", "Week 7", "Week 12"))
})
ggplot() +
  facet_wrap(~ t) +
  geom_line(data = dat, aes(vas, cdf, color = trt)) +
  stat_ecdf(aes(x = vas, color = laser, group = laser), data = dat2, geom = "step",
        size = 0.3, alpha = 0.5) +
  xlab("Pain level (VAS)") +
  ylab("Marginal distribution") +
  ggth +
  theme(legend.position = "bottom") +
  scale_color_manual(
values = c(rgb(0, 84, 150, maxColorValue = 255),
           rgb(202, 108, 24, maxColorValue = 255),
           rgb(0, 84, 150, maxColorValue = 255),
           rgb(202, 108, 24, maxColorValue = 255)),
breaks = c("Active", "Placebo"))


## ----eortc-cox, cache=TRUE----------------------------------------------------
data("eortc", package = "coxme")
eortc$trt <- factor(eortc$trt, levels = c(0, 1))
eortc_cp <- CoxphME(Surv(y, uncens) ~ trt + (1 | center/trt), data = eortc,
                    log_first = TRUE, order = 10)


## ----eortc-cox-ph-------------------------------------------------------------
exp(confint(eortc_cp, parm = "trt1", estimate = TRUE))


## ----eortc-cox-profile, cache=TRUE--------------------------------------------
exp(confint(eortc_cp, pargroup = "ranef", type = "profile", estimate = TRUE,
            ncpus = 2, parallel = "multicore"))


## ----eortc-trafo, cache=TRUE, warning=FALSE-----------------------------------
eortc_cp2 <- CoxphME(Surv(y, uncens) | 0 + trt ~ 0 + (1 | center/trt), data = eortc,
                     log_first = TRUE, order = 10)
tr <- trafo(eortc_cp2, confidence = "interval")


## ----eortc-trafo-plot, echo=FALSE, fig.width=4, fig.height=3, warning=FALSE----
x <- log(as.numeric(rownames(tr[[1]]))[-1])
par(mfrow = c(1, 1), cex = 0.75, mar = c(4.1, 4.1, 1.5, 1.5))
plot(0, type = "n", xlim = range(x), ylim = range(tr[[1]], tr[[2]], na.rm = TRUE),
     xlab = "log-time", ylab = expression(h(y)), cex.axis = 0.8, cex.lab = 0.8,
     panel.first = grid())
polygon(c(x, rev(x)), c(tr[[1]][-1, 2], rev(tr[[1]][-1, 3])), border = NA,
        col = mycolors(1, "fill"))
lines(x, tr[[1]][-1, 1], lwd = 2, col = mycolors(1))
polygon(c(x, rev(x)), c(tr[[2]][-1, 2], rev(tr[[2]][-1, 3])), border = NA,
        col = mycolors(2, "fill"))
lines(x, tr[[2]][-1, 1], lwd = 2, col = mycolors(2))
rug(log(eortc$y[eortc$uncens == 1]), col = rgb(.1, .1, .1, .1), quiet = TRUE)
legend("topleft", c("treatment", "control"),
       col = c(mycolors(1), mycolors(2)), lwd = 2, bty = "n", cex = 0.8)


## ----eortc-weibull------------------------------------------------------------
eortc_w <- SurvregME(Surv(y, uncens) ~ trt + (1 | center/trt), data = eortc,
                     dist = "weibull")


## ----eortc-cox-weibull-comp1, cache=TRUE--------------------------------------
## --- CoxphME
c(coef = coef(eortc_cp), se = sqrt(diag(vcov(eortc_cp, pargroup = "shift"))))
VarCorr(eortc_cp)
## --- SurvregME
c(coef = -coef(eortc_w), se = sqrt(diag(vcov(eortc_w, pargroup = "shift"))))
VarCorr(eortc_w)


## ----eortc-cox-weibull-comp2--------------------------------------------------
c(logLik(eortc_cp), logLik(eortc_w))


## ----eortc-coxme, message=FALSE, cache=TRUE-----------------------------------
library("coxme")
eortc_cm <- coxme(Surv(y, uncens) ~ trt + (1 | center/trt), data = eortc)
summary(eortc_cm)


## ----soup-data, echo=FALSE, fig.width = 7, fig.height=3.5, out.width="\\linewidth"----
data("soup", package = "ordinal")
dat <- within(soup, {
  prod <- factor(ifelse(PROD == "Ref", "Reference", "Test"), levels = c("Reference", "Test"))
})
ggplot(data = dat, aes(x = prod, fill = SURENESS)) +
  facet_wrap(~ SOUPFREQ) +
  geom_bar(position = "fill", width = 0.6) +
  scale_fill_grey() +
  xlab("Product") +
  ylab("Proportion") +
  ggth +
  theme(axis.ticks.x = element_blank(), legend.position = "bottom",
        legend.title = element_text()) +
  guides(fill = guide_legend(nrow = 1, title = "Sureness"))


## ----soup-polrme, cache=TRUE--------------------------------------------------
soup_pr <- PolrME(SURENESS ~ PROD + SOUPFREQ + (1 | RESP/PROD),
                  data = soup, method = "probit")
logLik(soup_pr)


## ----soup-ordinal, cache=TRUE, message=FALSE----------------------------------
library("ordinal")
soup_or <- clmm(SURENESS ~ PROD + SOUPFREQ + (1 | RESP/PROD), data = soup,
                link = "probit")
logLik(soup_or)


## ----soup-comp----------------------------------------------------------------
max(abs(coef(soup_or) - coef(soup_pr, with_baseline = TRUE)))


## ----soup-partial, cache=TRUE-------------------------------------------------
soup_pr2 <- PolrME(SURENESS | SOUPFREQ ~ PROD + (1 | RESP/PROD),
                   data = soup, method = "probit")
logLik(soup_pr2)


## ----soup-lrtest--------------------------------------------------------------
anova(soup_pr, soup_pr2)

