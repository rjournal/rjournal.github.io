# ------------- R Journal -----------------
# Title: An R package for Non-Normal Multivariate Distributions: Simulation and Probability Calculations from Multivariate Lomax (Pareto Type II) and Other Related Distributions
# 
# Authors: Zhixin Lun and Ravindra Khattree
#
# --------------- Reproducible examples --------------

# 3D bivariate density plot

library(plot3D)
dplot2 <- function(dfun, x1, x2, zlim) {
  zmat <- matrix(0, nrow = length(x1), ncol = length(x2))
  for (i in 1:length(x1)) {
    for (j in 1:length(x2)) {
      zmat[i, j] = dfun(x = c(x1[i], x2[j]))
    }
  }
  persp3D(z = zmat, x = x1, y = x2, theta = -60, phi = 10, ticktype = "detailed",
          zlim = zlim, contour = list(nlevels = 30, col = "red"),
          facets = FALSE, image = list(col = "white", side = "zmin"),
          xlab = "X1", ylab="X2", zlab = "Density", expand = 0.5, d = 2)
}

dplot2(dfun = function(x) dmvlomax(x, parm1 = 5, parm2 = c(0.5, 1)), x1 = seq(0, 4, 0.1), x2 = seq(0, 4, 0.1), zlim = c(-5, 13))

dplot2(dfun = function(x) dmvmpareto1(x, parm1 = 5, parm2 = c(0.5, 2)), x1 = seq(2, 5, 0.1), x2 = seq(0.5, 5, 0.1), zlim = c(-3, 28))

dplot2(dfun = function(x) dmvlogis(x, parm1 = c(0.5, 1), parm2 = c(1, 1.5)), x1 = seq(-4, 4, 0.1), x2 = seq(-4, 4, 0.1), zlim = c(-0.05, 0.05))

dplot2(dfun = function(x) dmvburr(x, parm1 = 3, parm2 = c(1, 3), parm3 = c(2, 5)), x1 = seq(0, 1, 0.05), x2 = seq(0, 1, 0.05), zlim = c(-2, 4))

dplot2(dfun = function(x) dmvunif(x, parm = 0.3), x1 = seq(0, 1, 1 / 30), x2 = seq(0, 1, 1 / 30), zlim = c(-5, 13))

dplot2(dfun = function(x) dmvglomax(x, parm1 = 5, parm2 = c(0.5, 1), parm3 = c(2, 4)), x1 = seq(0, 5, 0.1), x2 = seq(0, 5, 0.1), zlim = c(-1, 1))

dplot2(dfun = function(x) dmvf(x, df = c(4, 6, 9)), x1 = seq(0, 5, 0.1), x2 = seq(0, 5, 0.1), zlim = c(-0.4, 0.7))

dplot2(dfun = function(x) dmvinvbeta(x, parm1 = 4, parm2 = c(2, 6)), x1 = seq(0, 5, 0.1), x2 = seq(0, 5, 0.1), zlim = c(-0.4, 1))

# Random numbers generation
set.seed(2019)
rmvlomax(n = 2, parm1 = 5, parm2 = c(0.5, 1))

set.seed(2019)
rmvmpareto1(n = 2, parm1 = 5, parm2 = c(0.5, 2))

set.seed(2019)
rmvlogis(n = 2, parm1 = c(0.5, 1), parm2 = c(1, 1.5))

set.seed(2019)
rmvburr(n = 2, parm1 = 3, parm2 = c(1, 3), parm3 = c(2, 5))

set.seed(2019)
rmvunif(n = 2, parm = 0.3, dim = 2)

set.seed(2019)
rmvglomax(n = 2, parm1 = 5, parm2 = c(0.5, 1), parm3 = c(2, 4))

set.seed(2019)
rmvf(n = 2, df = c(4, 6, 9))

set.seed(2019)
rmvinvbeta(n = 2, parm1 = 4, parm2 = c(2, 6))

# CDF, survival function and equicoordinate quantile
pmvlomax(q = c(1, 0.5), parm1 = 5, parm2 = c(0.5, 1))
smvlomax(q = c(1, 0.5), parm1 = 5, parm2 = c(0.5, 1))
qmvlomax(p = 0.5, parm1 = 5, parm2 = c(0.5, 1))

pmvmpareto1(q = c(3, 1), parm1 = 5, parm2 = c(0.5, 2))
smvmpareto1(q = c(3, 1), parm1 = 5, parm2 = c(0.5, 2))
qmvmpareto1(p = 0.5, parm1 = 5, parm2 = c(0.5, 2))

pmvlogis(q = c(1, 2), parm1 = c(0.5, 1), parm2 = c(1, 1.5))
smvlogis(q = c(1, 2), parm1 = c(0.5, 1), parm2 = c(1, 1.5))
qmvlogis(p = 0.5, parm1 = c(0.5, 1), parm2 = c(1, 1.5))

pmvburr(q = c(0.5, 1), parm1 = 3, parm2 = c(1, 3), parm3 = c(2, 5))
smvburr(q = c(0.5, 1), parm1 = 3, parm2 = c(1, 3), parm3 = c(2, 5))
qmvburr(p = 0.5, parm1 = 3, parm2 = c(1, 3), parm3 = c(2, 5))

pmvunif(q = c(0.5, 0.75), parm = 0.3)
smvunif(q = c(0.5, 0.75), parm = 0.3)
qmvunif(p = 0.5, parm = 0.3, dim = 2)

pmvglomax(q = c(0.5, 1), parm1 = 5, parm2 = c(0.5, 1), parm3 = c(2, 4))
smvglomax(q = c(0.5, 1), parm1 = 5, parm2 = c(0.5, 1), parm3 = c(2, 4))
qmvglomax(p = 0.5, parm1 = 5, parm2 = c(0.5, 1), parm3 = c(2, 4))

pmvf(q = c(1, 2), df = c(4, 6, 9))
smvf(q = c(1, 2), df = c(4, 6, 9))
qmvf(p = 0.5, df = c(4, 6, 9))

pmvinvbeta(q = c(1, 2), parm1 = 4, parm2 = c(2, 6))
smvinvbeta(q = c(1, 2), parm1 = 4, parm2 = c(2, 6))
qmvinvbeta(p = 0.5, parm1 = 4, parm2 = c(2, 6))

# Maximum likelihood estimation of parameters 
# ------------ Lomax ---------------
loglik.lomax <- function(data, par) {
  ll <- sum(dmvlomax(data, parm1 = par[1], parm2 = par[-1], log = TRUE))
}

set.seed(1)
bvtlomax <- rmvlomax(n = 300, parm1 = 5, parm2 = c(0.5, 1))

est = constrOptim(theta = rep(10, 3), f = loglik.lomax, grad = NULL,
                  data = bvtlomax, ui = diag(3), ci = rep(0, 3),
                  control = list(fnscale = -1))
est$par
est$convergence

# ------------ Mardia's Pareto Type I ---------------
loglik.mpareto1 <- function(data, par) {
  ll <- sum(dmvmpareto1(data, parm1 = par[1], parm2 = par[-1], log = TRUE))
}

set.seed(1)
bvtMP1 <- rmvmpareto1(n = 300, parm1 = 5, parm2 = c(0.5, 2))

minParm2 = 1 / apply(bvtMP1, 2, min)
est = constrOptim(theta = rep(10, 3), f = loglik.mpareto1, grad = NULL, data = bvtMP1, ui = diag(3), ci = c(0, minParm2), control = list(fnscale = -1))
est$convergence
est$par

# ------------ Logistic ---------------
loglik.logis <- function(data, par) {
  mu <- par[1:((length(par)) / 2)]
  sigma <- par[((length(par))/2 + 1):(length(par))]
  ll <- sum(dmvlogis(data, parm1 = mu, parm2 = sigma, log = TRUE))
}

set.seed(1)
bvtlogis <- rmvlogis(n = 300, parm1 = c(0.5, 1), parm2 = c(1, 1.5))

est = optim(par = rep(10, 4), fn = loglik.logis, data = bvtlogis,
            control = list(fnscale = -1))
est$convergence
est$par

# ------------ Burr ---------------
loglik.burr <- function(data, par) {
  a <- par[1]
  d <- par[2:((length(par) + 1) / 2)]
  c <- par[((length(par) + 1) /2 + 1):(length(par))]
  ll = sum(dmvburr(data, parm1 = a, parm2 = d, parm3 = c, log = TRUE))
}

set.seed(1)
bvtburr <- rmvburr(n = 300, parm1 = 3, parm2 = c(1, 3), parm3 = c(2, 5))

est = constrOptim(theta = rep(10, 5), f = loglik.burr, grad = NULL,
                  data = bvtburr, ui = diag(5), ci = rep(0, 5),
                  control = list(fnscale = -1))
est$convergence
est$par

# ------------ Uniform ---------------
loglik.uniform <- function(data, par) {
  ll = sum(dmvunif(data, parm = par, log = TRUE))
}

set.seed(1)
bvtuniform <- rmvunif(n = 300, parm = 0.3, dim = 2)

est = optimize(f = loglik.uniform, data = bvtuniform,
               interval = c(0, 100000), maximum = TRUE)
est$maximum

# ------------ Generalized Lomax ---------------
loglik.glomax <- function(data, par) {
  a = par[1]
  theta = par[2:((length(par) + 1) / 2)]
  L = par[((length(par) + 1) / 2 + 1):(length(par))]
  ll = sum(dmvglomax(data, parm1 = a, parm2 = theta, parm3 = L, log = TRUE))
}

set.seed(1)
bvtglomax <- rmvglomax(n = 300, parm1 = 5, parm2 = c(0.5, 1), parm3 = c(2, 4))

est = constrOptim(theta = rep(10, 5), f = loglik.glomax,
                  grad = NULL, data = bvtglomax, ui = diag(5),
                  ci = rep(0, 5), control = list(fnscale = -1))

est$convergence
est$par

# ------------ Inverted Beta ---------------
loglik.invbeta <- function(data, par) {
  a = par[1]
  l = par[-1]
  ll = sum(dmvinvbeta(data, parm1 = a, parm2 = l, log = TRUE))
}

set.seed(1)
bvtinvbeta <- rmvinvbeta(n = 300, parm1 = 4, parm2 = c(2, 6))

est = constrOptim(theta = rep(10, 3), f = loglik.invbeta, grad = NULL,
                  data = bvtinvbeta, ui = diag(3), ci = rep(0, 3),
                  control = list(fnscale = -1))

est$convergence
est$par

# Two Applications
# Generating data from the non-elliptical symmetric distributions with univariate normal marginals

set.seed(1)
biv.unif <- rmvunif(8000, parm = 2, dim = 2)
biv.norm <- as.data.frame(apply(biv.unif, 2, qnorm))
cor(biv.norm$V1, biv.norm$V2)

library(ggplot2)
ggplot(biv.norm, aes(x=V1, y=V2)) +
  xlim(c(-4, 4)) + ylim(c(-4, 4)) + xlab("X1") + ylab("X2") +
  geom_point()


set.seed(1)
biv.unif <- rmvunif(8000, parm = 1.0, dim = 2)
biv.norm <- as.data.frame(apply(biv.unif, 2, qnorm))
cor(biv.norm$V1, biv.norm$V2)
ggplot(biv.norm, aes(x=V1, y=V2)) +
  xlim(c(-4, 4)) + ylim(c(-4, 4)) + xlab("X1") + ylab("X2") +
  geom_point()

set.seed(1)
biv.unif <- rmvunif(8000, parm = 0.5, dim = 2)
biv.norm <- as.data.frame(apply(biv.unif, 2, qnorm))
cor(biv.norm$V1, biv.norm$V2)
ggplot(biv.norm, aes(x=V1, y=V2)) +
  xlim(c(-4, 4)) + ylim(c(-4, 4)) + xlab("X1") + ylab("X2") +
  geom_point()

set.seed(1)
biv.unif <- rmvunif(8000, parm = 0.1, dim = 2)
biv.norm <- as.data.frame(apply(biv.unif, 2, qnorm))
cor(biv.norm$V1, biv.norm$V2)
ggplot(biv.norm, aes(x=V1, y=V2)) +
  xlim(c(-4, 4)) + ylim(c(-4, 4)) + xlab("X1") + ylab("X2") +
  geom_point()


# Creating tables for simultaneous MANOVA
qmvf(0.95, df = c(5, 1, 1))
qmvf(0.95, df = c(5, 2, 2))
qmvf(0.95, df = c(5, 3, 3))
qmvf(0.95, df = c(5, 4, 4))
qmvf(0.95, df = c(5, 5, 5))
qmvf(0.95, df = c(10, 6, 6))
qmvf(0.95, df = c(10, 7, 7))
qmvf(0.95, df = c(10, 8, 8))
qmvf(0.95, df = c(10, 9, 9))
qmvf(0.95, df = c(10, 10, 10))

qmvf(0.95, df = c(5, 1, 1), algorithm = "MC")
qmvf(0.95, df = c(5, 2, 2), algorithm = "MC")
qmvf(0.95, df = c(5, 3, 3), algorithm = "MC")
qmvf(0.95, df = c(5, 4, 4), algorithm = "MC")
qmvf(0.95, df = c(5, 5, 5), algorithm = "MC")
qmvf(0.95, df = c(10, 6, 6), algorithm = "MC")
qmvf(0.95, df = c(10, 7, 7), algorithm = "MC")
qmvf(0.95, df = c(10, 8, 8), algorithm = "MC")
qmvf(0.95, df = c(10, 9, 9), algorithm = "MC")
qmvf(0.95, df = c(10, 10, 10), algorithm = "MC")