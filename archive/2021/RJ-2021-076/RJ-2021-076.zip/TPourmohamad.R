################################################### 
### Necessary packages to be loaded
library(CompModels)
library(laGP)

# Seed set for reproducibility
set.seed(4)

################################################### 
### Internals of the function
bbox1

################################################### 
### The tension spring problem

tension(x1 = 1, x2 = 1, x3 = 3)

bbox <- function(X){
  output = tension(X[1], X[2], X[3])
  return(list(obj = output$obj, c = output$con))
}

B <- matrix(c(.05, .25, 2, 2, 1.3, 15), nrow=3)

ans <- optim.efi(bbox, B, fhat = TRUE, start = 10, end = 300)
constraint <- ifelse(apply(ans$C, 1, max) > 0, "Not Met", "Met")

min(ans$obj[constraint == "Met"])
ans$X[ans$obj == min(ans$obj[constraint == "Met"])]

S <- 30 
results <- rep(NA, S)
for(i in 1:S){
  ans <- optim.efi(bbox, B, fhat = TRUE, start = 10, end = 300)
  constraint <- ifelse(apply(ans$C, 1, max) > 0, "Not Met", "Met")
  results[i] <- min(ans$obj[constraint == "Met"])
}

summary(results)


################################################### 
### The bbox1 problem

bbox <- function(X){
  output = bbox1(X[1], X[2])
  return(list(obj = output$obj, c = output$con))
}

B <- matrix(c(-1.5, -3, 2.5, 3), nrow = 2)

ans <- optim.efi(bbox, B, fhat = TRUE, start = 10, end = 100)
constraint <- ifelse(apply(ans$C, 1, max) > 0, "Not Met", "Met")

min(ans$obj[constraint == "Met"])
xbest <- ans$X[ans$obj == min(ans$obj[constraint == "Met"])]
xbest


n <- 200
x1 <- seq(-1.5, 2.5, len = n)
x2 <- seq(-3, 3, len = n)

x <- expand.grid(x1, x2)
obj <- rep(NA, nrow(x))
con <- matrix(NA, nrow = nrow(x), ncol = 2)

for(i in 1:nrow(x)){
  temp <- bbox1(x[i,1], x[i,2])
  obj[i] <- temp$obj
  con[i,] <- temp$con
}

y <- obj
y[con[,1] > 0 | con[,2] > 0] <- NA

z <- obj
z[!(con[,1] > 0 | con[,2] > 0)] <- NA

par(ps=15)
plot(0, 0, type = "n", xlim = c(-1.5, 2.5), ylim = c(-3, 3), 
     xlab = expression(x[1]), ylab = expression(x[2]), main = "Black-box Function")
c1 <- matrix(con[,1], ncol = n)
contour(x1, x2, c1, nlevels = 1, levels = 0, drawlabels = FALSE, add = TRUE, lwd = 2)
c2 <- matrix(con[,2], ncol = n)
contour(x1, x2, c2, nlevels = 1, levels = 0, drawlabels = FALSE, add = TRUE, lwd = 2, lty = 2)
contour(x1, x2, matrix(y, ncol = n), nlevels = 10, add = TRUE, col = "forestgreen")
contour(x1, x2, matrix(z, ncol = n), nlevels = 20, add = TRUE, col = 2, lty = 2)
points(xbest[1], xbest[2], pch = 21, bg = "deepskyblue")


S <- 30 
results <- rep(NA, S)
for(i in 1:S){
  ans <- optim.efi(bbox, B, fhat = TRUE, start = 10, end = 100)
  constraint <- ifelse(apply(ans$C, 1, max) > 0, "Not Met", "Met")
  results[i] <- min(ans$obj[constraint == "Met"])
}

summary(results)

