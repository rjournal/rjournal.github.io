### R code for PAsso paper

# 1. 
library(PAsso)
data(ANES2016)   # load the dataset
set.seed(2020)  # for reproducibility
phi <- PAsso(responses = c("PID", "selfLR", "TrumpLR", "ClinLR"),
             adjustments = c("age", "edu.year", "income.num"),
             data = ANES2016,
             method = "kendall")
print(phi, digits = 3)

# 2.
summary(phi, digits=4)

# 3.
library(doParallel)  # load packages for parallel computing
library(progress)  
numCores <- detectCores()  # Number of CPU cores. Do Not be too aggressive!
# Set up parallel backend (multicore for unix and snow for windows)
cl <- if (.Platform$OS.type == "unix") numCores else makeCluster(numCores) 
registerDoParallel(cl)

test(phi, bootstrap_rep = 1000, H0 = 0, parallel = TRUE)

# 4.
test(phi, bootstrap_rep = 1000, H0 = 0.05, parallel = TRUE)

# 5.
plot(phi, color = "red", alpha = 0.1)

# 6.
plot3D(phi, y1="PID", y2="TrumpLR")
plot3D(phi, y1="PID", y2="TrumpLR", type = "contour")

# 7.
library(MASS)
# convert numeric response to factor
Yname<- c("PID", "selfLR", "TrumpLR", "ClinLR")
ANES2016[Yname]<- lapply(ANES2016[Yname], factor)
# fit each model separately 
fit.PID<- polr(PID~age+edu.year+income.num, data=ANES2016, method="probit")
fit.selfLR<- polr(selfLR~age+edu.year+income.num, data=ANES2016, method="probit")
fit.TrumpLR<- polr(TrumpLR~age+edu.year+income.num, data=ANES2016, method="probit")
fit.ClinLR<- polr(ClinLR~age+edu.year+income.num, data=ANES2016, method="probit")
# assess partial association
set.seed(2020)
phi1<- PAsso(fitted.models=list(fit.PID, fit.selfLR, fit.TrumpLR, fit.ClinLR), 
             method = "kendall")
print(phi1, digits = 3)

# 8.
# residual vs. fitted value (the linear predictor) for all models
diagnostic.plot(phi, output = "fitted") 

# 9.
# residual Q-Q plot for the second model (selfLR)
diagnostic.plot(phi, output = "qq", model_id = 2)

# 10.
ANES2016$PID<- as.numeric(ANES2016$PID)
phi2<- PAsso(responses = c("PreVote.num", "PID", "selfLR", "TrumpLR", "ClinLR"),
             adjustments = c("age", "edu.year", "income.num"),
             data = ANES2016,
             method = "kendall",
             model = c("logit", "acat", "acat", "acat", "acat"))
summary(phi2, digits = 3)






