setwd("C:/Users/asus/Desktop/PEN/_LA_5/_18_RJournal/Rjournal - Revision")

tools::texi2pdf(file = 'RJwrapper.tex')