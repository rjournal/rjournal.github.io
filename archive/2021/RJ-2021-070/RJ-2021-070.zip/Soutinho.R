####################################
#survidm in practice (VERSION 1.3.2)
####################################

library("survidm")
data(colonIDM)
colonIDM[c(1:2,16,21),1:7]

nevents(with(colonIDM, survIDM(time1, event1, Stime, event)),
        state.names = c("healthy", "recurrence", "death"))

#######################
#Multi-state regression
#######################

library(survival)
fit <- coxph(Surv(time1, Stime, event) ~ time1, data = colonIDM,
               subset=c(time1 < Stime))
fit

mk <- markov.test(survIDM(time1, event1, Stime, event) ~ 1, data = colonIDM)
mk

fit.cmm <- coxidm(survIDM(time1, event1, Stime, event) ~ rx + sex + age +
                    nodes + surg + adhere, data = colonIDM)
summary(fit.cmm)

summary(fit.cmm,type = 'anova')

library(ggplot2)
library(plotly)

fit2.cmm <- coxidm(survIDM(time1, event1, Stime, event) ~ rx + sex + age +
                     pspline(nodes) + surg + adhere, data = colonIDM)

d<-data.frame(x=fit2.cmm$term01$nodes$x, y=fit2.cmm$term01$nodes$y,
              y1=fit2.cmm$term01$nodes$y-1.96*fit2.cmm$term01$nodes$se,
              y2=fit2.cmm$term01$nodes$y+1.96*fit2.cmm$term01$nodes$se)
nonlinear<-ggplot(d, aes(x,y))+theme(axis.text=element_text(size=13))+
  theme_bw()+labs(x = "nodes") +
  labs(y = "Partial for pspline(nodes)")+
  geom_ribbon(aes(ymin=y1,ymax=y2),fill='gray92',alpha=0.9)+
  geom_line(aes(x,y))+
  geom_line(color=1,size=1)

ggplotly(nonlinear)

summary(fit2.cmm, type = 'ph')

######################################################
#Occupation probabilities and transition probabilities
######################################################

tpAJ <- tprob(survIDM(time1, event1, Stime, event) ~ 1, s = 365,
              method = "AJ", conf = TRUE, data = colonIDM)

summary(tpAJ, times=365*2:6)

autoplot(tpAJ)

tpLM <- tprob(survIDM(time1, event1, Stime, event) ~ 1, s = 365,
              method = "LM", conf = TRUE, data = colonIDM)

summary(tpLM, times=365*2:6)

autoplot(tpLM)

mk <- markov.test(survIDM(time1, event1, Stime, event) ~ 1, s = 365, data = colonIDM)
autoplot(mk)

tpIPCW.age <- tprob(survIDM(time1, event1, Stime, event) ~ age, s = 365,
                    method = "IPCW", z.value = 48, conf = FALSE, data = colonIDM,
                    bw = "dpik", window = "gaussian", method.weights = "NW")

summary(tpIPCW.age, time=365*2:6)

autoplot(tpIPCW.age)

tp.breslow.age <- tprob(survIDM(time1, event1, Stime, event) ~ age, s = 365,
                        method = "breslow", z.value = 48, conf = FALSE, data = colonIDM)


summary(tp.breslow.age, time=365*2:6)


tp.breslow <- tprob(survIDM(time1, event1, Stime, event) ~ rx + age + nodes, s = 365,
                    method = "breslow", z.value = c('Obs', 50, 10), conf = FALSE,
                    data = colonIDM)

summary(tp.breslow, time=365*2:6)

##############################
#Cumulative Incidence Function
##############################

cif <- CIF(survIDM(time1, event1, Stime, event) ~ 1, data = colonIDM, conf = TRUE)
summary(cif, time=365*1:6)

autoplot(cif, ylim=c(0, 0.6), confcol = 2)


cif.1.nodes <- CIF(survIDM(time1, event1, Stime, event) ~ nodes, data = colonIDM,
                   conf = FALSE, z.value = 1)
cif.9.nodes <- CIF(survIDM(time1, event1, Stime, event) ~ nodes, data = colonIDM,
                     conf = FALSE, z.value = 9)

d<-as.data.frame(cbind(rep(cif.1.nodes$est[,1],2),c(cif.1.nodes$est[,2],
                                                      cif.9.nodes$est[,2]), c(rep("1 nodes", length(cif.1.nodes$est[,1])),
                                                                              rep("9 nodes", length(cif.1.nodes$est[,2])))))
names(d)<-c('time','cif','type')

cif<-ggplot(d, aes(x=as.numeric(time), y=as.numeric(cif),group=factor(type),
                     color=factor(type)))+theme_bw()+labs(x = 'Time (days)',
                                                          y = 'CIF(t|nodes)')
cif+geom_step(size=1)+ theme(legend.title=element_blank())

#####################
#Sojourn distribution
#####################


soj <- sojourn(survIDM(time1, event1, Stime, event) ~ 1,
               data = colonIDM, method = "Satten-Datta", conf = FALSE)
summary(soj, time=365*1:6)


