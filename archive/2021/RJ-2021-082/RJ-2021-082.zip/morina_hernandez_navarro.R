options(scipen=999)
library(survsim)
library(miRecSurv)
library(doParallel)

d.ev       <- c('llogistic','weibull','weibull','weibull') 
b0.ev     <- c(5.843, 5.944, 5.782, 5.469) 
a.ev       <- c(0.700, 0.797, 0.822, 0.858)
d.cens   <- c('weibull','weibull','weibull','weibull') 
b0.cens <- c(7.398, 7.061, 6.947, 6.657)
a.cens   <- c(1.178, 1.246, 1.207, 1.422)

nsim <- 100
resultsMatrix <- matrix(nrow=nsim, ncol=72)
genResults <- function(k)
{
  print(paste0("Simulation step: ", k))
  ### Sample 1: 10% of subjects at risk before the beginning of the follow-up
  set.seed(k)
  sample1 <- rec.ev.sim(n=1500, foltime=1095, 
                        dist.ev=d.ev, anc.ev=a.ev, beta0.ev=b0.ev, 
                        dist.cens=d.cens, anc.cens=a.cens, beta0.cens=b0.cens, 
                        beta=list(c(-.25,-.25,-.25,-.25), c(-.5,-.5,-.5,-.5), c(-.75,-.75,-.75,-.75)), 
                        x=list(c("bern", .5), c("bern", .5), c("bern", .5)),
                        priskb=.1, max.old=5475)
  
  ### Shared frailty
  sample1$old2 <- -sample1$old
  sample1$old2[is.na(sample1$old)] <- 0
  
  ag_s1 <- try(coxph(Surv(start2,stop2,status)~as.factor(x)+as.factor(x.1)+as.factor(x.2)+old2+
                       strata(as.factor(risk.bef))+frailty(nid), data=sample1), silent=TRUE)
  if (class(ag_s1)!="try-error")
  {
    resultsMatrix[k, 1:3] <- coef(ag_s1)[1:3]
    resultsMatrix[k, 4:6] <- sqrt(diag(vcov(ag_s1)))[1:3]
  }else{
    resultsMatrix[k, 1:3] <- rep(NA, 3)
    resultsMatrix[k, 4:6] <- rep(NA, 3)
  }
  ### Counting process
  shfmi.cp_s1 <- try(recEvFit(Surv(start2, stop2, status)~x+x.1+x.2, data=sample1,
                              id="nid", prevEp = "obs.episode",
                              riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k), silent=TRUE)
  if (class(shfmi.cp_s1)!="try-error")
  {
    resultsMatrix[k, 7:9]   <- shfmi.cp_s1[[2]][1:3, 1]
    resultsMatrix[k, 10:12] <- shfmi.cp_s1[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 7:9] <- rep(NA, 3)
    resultsMatrix[k, 10:12] <- rep(NA, 3)
  }
  ### Gap time
  shfmi.gt_s1 <- try(recEvFit(Surv(stop2-start2, status)~x+x.1+x.2, data=sample1,
                              id="nid", prevEp = "obs.episode",
                              riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k), silent=TRUE)
  if (class(shfmi.gt_s1)!="try-error")
  {	  
    resultsMatrix[k, 13:15] <- shfmi.gt_s1[[2]][1:3, 1]
    resultsMatrix[k, 16:18] <- shfmi.gt_s1[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 13:15] <- rep(NA, 3)
    resultsMatrix[k, 16:18] <- rep(NA, 3)
  }
  ### Sample 2: 25% of subjects at risk before the beginning of the follow-up
  set.seed(k)
  sample2 <- rec.ev.sim(n=1500, foltime=1095, 
                        dist.ev=d.ev, anc.ev=a.ev, beta0.ev=b0.ev, 
                        dist.cens=d.cens, anc.cens=a.cens, beta0.cens=b0.cens, 
                        beta=list(c(-.25,-.25,-.25,-.25), c(-.5,-.5,-.5,-.5), c(-.75,-.75,-.75,-.75)), 
                        x=list(c("bern", .5), c("bern", .5), c("bern", .5)),
                        priskb=.25, max.old=5475)
  
  ### Shared frailty
  sample2$old2 <- -sample2$old
  sample2$old2[is.na(sample2$old)] <- 0
  
  ag_s2 <- try(coxph(Surv(start2,stop2,status)~as.factor(x)+as.factor(x.1)+as.factor(x.2)+old2+
                       strata(as.factor(risk.bef))+frailty(nid), data=sample2), silent=TRUE)
  if (class(ag_s2)!="try-error")
  {
    resultsMatrix[k, 19:21] <- coef(ag_s2)[1:3]
    resultsMatrix[k, 22:24] <- sqrt(diag(vcov(ag_s2)))[1:3]
  }else{
    resultsMatrix[k, 19:21] <- rep(NA, 3)
    resultsMatrix[k, 22:24] <- rep(NA, 3)
  }
  ### Counting process
  shfmi.cp_s2 <- try(recEvFit(Surv(start2, stop2, status)~x+x.1+x.2, data=sample2,
                              id="nid", prevEp = "obs.episode",
                              riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k), silent=TRUE)
  if (class(shfmi.cp_s2)!="try-error")
  {
    resultsMatrix[k, 25:27]   <- shfmi.cp_s2[[2]][1:3, 1]
    resultsMatrix[k, 28:30] <- shfmi.cp_s2[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 25:27] <- rep(NA, 3)
    resultsMatrix[k, 28:30] <- rep(NA, 3)
  }
  ### Gap time
  shfmi.gt_s2 <- recEvFit(Surv(stop2-start2, status)~x+x.1+x.2, data=sample2,
                          id="nid", prevEp = "obs.episode",
                          riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k)
  if (class(shfmi.gt_s2)!="try-error")
  {	  
    resultsMatrix[k, 31:33] <- shfmi.gt_s2[[2]][1:3, 1]
    resultsMatrix[k, 34:36] <- shfmi.gt_s2[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 31:33] <- rep(NA, 3)
    resultsMatrix[k, 34:36] <- rep(NA, 3)
  }	  
  ### Sample 3: 50% of subjects at risk before the beginning of the follow-up
  set.seed(k)
  sample3 <- rec.ev.sim(n=1500, foltime=1095, 
                        dist.ev=d.ev, anc.ev=a.ev, beta0.ev=b0.ev, 
                        dist.cens=d.cens, anc.cens=a.cens, beta0.cens=b0.cens, 
                        beta=list(c(-.25,-.25,-.25,-.25), c(-.5,-.5,-.5,-.5), c(-.75,-.75,-.75,-.75)), 
                        x=list(c("bern", .5), c("bern", .5), c("bern", .5)),
                        priskb=.5, max.old=5475)
  ### Shared frailty
  sample3$old2 <- -sample3$old
  sample3$old2[is.na(sample3$old)] <- 0
  
  ag_s3 <- try(coxph(Surv(start2,stop2,status)~as.factor(x)+as.factor(x.1)+as.factor(x.2)+old2+
                       strata(as.factor(risk.bef))+frailty(nid), data=sample3), silent=TRUE)
  if (class(ag_s3)!="try-error")
  {
    resultsMatrix[k, 37:39] <- coef(ag_s3)[1:3]
    resultsMatrix[k, 40:42] <- sqrt(diag(vcov(ag_s3)))[1:3]
  }else{
    resultsMatrix[k, 37:39] <- rep(NA, 3)
    resultsMatrix[k, 40:42] <- rep(NA, 3)
  }
  ### Counting process
  shfmi.cp_s3 <- try(recEvFit(Surv(start2, stop2, status)~x+x.1+x.2, data=sample3,
                              id="nid", prevEp = "obs.episode",
                              riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k), silent=TRUE)
  if (class(shfmi.cp_s3)!="try-error")
  {
    resultsMatrix[k, 43:45]   <- shfmi.cp_s3[[2]][1:3, 1]
    resultsMatrix[k, 46:48] <- shfmi.cp_s3[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 43:45] <- rep(NA, 3)
    resultsMatrix[k, 46:48] <- rep(NA, 3)
  }
  ### Gap time
  shfmi.gt_s3 <- recEvFit(Surv(stop2-start2, status)~x+x.1+x.2, data=sample3,
                          id="nid", prevEp = "obs.episode",
                          riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k)
  if (class(shfmi.gt_s3)!="try-error")
  {  	  
    resultsMatrix[k, 49:51] <- shfmi.gt_s3[[2]][1:3, 1]
    resultsMatrix[k, 52:54] <- shfmi.gt_s3[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 49:51] <- rep(NA, 3)
    resultsMatrix[k, 52:54] <- rep(NA, 3)
  }  	  
  
  ### Sample 4: 100% of subjects at risk before the beginning of the follow-up
  set.seed(k)
  sample4 <- rec.ev.sim(n=1500, foltime=1095, 
                        dist.ev=d.ev, anc.ev=a.ev, beta0.ev=b0.ev, 
                        dist.cens=d.cens, anc.cens=a.cens, beta0.cens=b0.cens, 
                        beta=list(c(-.25,-.25,-.25,-.25), c(-.5,-.5,-.5,-.5), c(-.75,-.75,-.75,-.75)), 
                        x=list(c("bern", .5), c("bern", .5), c("bern", .5)),
                        priskb=1, max.old=5475)
  
  ### Shared frailty
  sample4$old2 <- -sample4$old
  sample4$old2[is.na(sample4$old)] <- 0
  
  ag_s4 <- try(coxph(Surv(start2,stop2,status)~as.factor(x)+as.factor(x.1)+as.factor(x.2)+old2+
                       strata(as.factor(risk.bef))+frailty(nid), data=sample4), silent=TRUE)
  if (class(ag_s4)!="try-error")
  {
    resultsMatrix[k, 55:57] <- coef(ag_s4)[1:3]
    resultsMatrix[k, 58:60] <- sqrt(diag(vcov(ag_s4)))[1:3]
  }else{
    resultsMatrix[k, 55:57] <- rep(NA, 3)
    resultsMatrix[k, 58:60] <- rep(NA, 3)
  }
  ### Counting process
  shfmi.cp_s4 <- try(recEvFit(Surv(start2, stop2, status)~x+x.1+x.2, data=sample4,
                              id="nid", prevEp = "obs.episode",
                              riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k), silent=TRUE)
  if (class(shfmi.cp_s4)!="try-error")
  {
    resultsMatrix[k, 61:63]   <- shfmi.cp_s4[[2]][1:3, 1]
    resultsMatrix[k, 64:66] <- shfmi.cp_s4[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 61:63] <- rep(NA, 3)
    resultsMatrix[k, 64:66] <- rep(NA, 3)
  }
  ### Gap time
  shfmi.gt_s4 <- recEvFit(Surv(stop2-start2, status)~x+x.1+x.2, data=sample4,
                          id="nid", prevEp = "obs.episode",
                          riskBef = "risk.bef", oldInd = "old", frailty=TRUE, m=5, seed=k)
  if (class(shfmi.gt_s4)!="try-error")
  {  	  
    resultsMatrix[k, 67:69] <- shfmi.gt_s4[[2]][1:3, 1]
    resultsMatrix[k, 70:72] <- shfmi.gt_s4[[2]][1:3, 3]
  }else{
    resultsMatrix[k, 67:69] <- rep(NA, 3)
    resultsMatrix[k, 70:72] <- rep(NA, 3)
  }  	 				    
  return(resultsMatrix)
}

nCores <- detectCores()
registerDoParallel(nCores)
results <- foreach(k=1:nsim, .combine=rbind) %dopar% 
  genResults(k)
results <- as.data.frame(results)
results <- results[!is.na(results[, 1]), ]
colnames(results) <- c("ag_s1.x", "ag_s1.x1", "ag_s1.x2", "ag_s1.x_sd", "ag_s1.x1_sd", "ag_s1.x2_sd",
                       "cp_s1.x", "cp_s1.x1", "cp_s1.x2", "cp_s1.x_sd", "cp_s1.x1_sd", "cp_s1.x2_sd",
                       "gt_s1.x", "gt_s1.x1", "gt_s1.x2", "gt_s1.x_sd", "gt_s1.x1_sd", "gt_s1.x2_sd",
                       "ag_s2.x", "ag_s2.x1", "ag_s2.x2", "ag_s2.x_sd", "ag_s2.x1_sd", "ag_s2.x2_sd",
                       "cp_s2.x", "cp_s2.x1", "cp_s2.x2", "cp_s2.x_sd", "cp_s2.x1_sd", "cp_s2.x2_sd",
                       "gt_s2.x", "gt_s2.x1", "gt_s2.x2", "gt_s2.x_sd", "gt_s2.x1_sd", "gt_s2.x2_sd",
                       "ag_s3.x", "ag_s3.x1", "ag_s3.x2", "ag_s3.x_sd", "ag_s3.x1_sd", "ag_s3.x2_sd",
                       "cp_s3.x", "cp_s3.x1", "cp_s3.x2", "cp_s3.x_sd", "cp_s3.x1_sd", "cp_s3.x2_sd",
                       "gt_s3.x", "gt_s3.x1", "gt_s3.x2", "gt_s3.x_sd", "gt_s3.x1_sd", "gt_s3.x2_sd",
                       "ag_s4.x", "ag_s4.x1", "ag_s4.x2", "ag_s4.x_sd", "ag_s4.x1_sd", "ag_s4.x2_sd",
                       "cp_s4.x", "cp_s4.x1", "cp_s4.x2", "cp_s4.x_sd", "cp_s4.x1_sd", "cp_s4.x2_sd",
                       "gt_s4.x", "gt_s4.x1", "gt_s4.x2", "gt_s4.x_sd", "gt_s4.x1_sd", "gt_s4.x2_sd")
write.table(results, "results_allcauses.csv", row.names=F, col.names=T)

### Figure 1
library(ggplot2)
results <- read.table("Paper/Rev/results_allcauses.csv", header=T)

results_est <- results[, !grepl("sd", colnames(results))]

### Tables
avgs1 <- colMeans(results)
round(avgs1, 3)

### Figure 1
avgs <- colMeans(results_est)
est.x  <- avgs[grepl(".x", names(avgs)) & !grepl(".x1", names(avgs)) & !grepl(".x2", names(avgs))]
est.x1 <- avgs[grepl(".x1", names(avgs))]
est.x2 <- avgs[grepl(".x2", names(avgs))]

bias.x  <- (est.x-0.25)/0.25*100
bias.x1 <- (est.x1-0.5)/0.5*100
bias.x2 <- (est.x2-0.75)/0.75*100

results.graph <- data.frame(bias.x, bias.x1, bias.x2, Population=c(rep("Sample 1", 3), 
                                                                   rep("Sample 2", 3),
                                                                   rep("Sample 3", 3),
                                                                   rep("Sample 4", 3)),
                            Method=rep(c("Shared Frailty", "SHFMI.CP", "SHFMI.GT"), 4))

results.graph$MeanBias <- rowMeans(as.matrix(cbind(results.graph$bias.x, results.graph$bias.x1,
                                                   results.graph$bias.x2)))
p1 <- ggplot(results.graph, aes(Method, MeanBias)) + geom_point(size=3)
p1+facet_grid(cols = vars(Population))+ylab("Mean relative bias")+theme(text = element_text(size = 20))

### Real data example
library(foreign)
library(miRecSurv)
library(dplyr)
library(forcats)
library(ggplot2)

example <- read.spss("Data/David.sav", to.data.frame=T)
example$prev2[example$prev=="No"] <- FALSE
example$prev2[example$prev=="Yes"] <- TRUE
example$Male[example$sex=="Female"] <- 0
example$Male[example$sex=="Male"] <- 1
example$Non.civil.servant[example$contract=="Civil servant"] <- 0
example$Non.civil.servant[example$contract=="Non civil servant"] <- 1
example$Non.healthcare[example$type_work=="Healthcare professionals"] <- 0
example$Non.healthcare[example$type_work=="Non healtchare"] <- 1

mod1 <- recEvFit(Surv(start, stop, status)~Male+Non.civil.servant+
                   Non.healthcare, data=example, 
                 id="nid", prevEp="num", riskBef="prev2", oldInd="days_prev",
                 frailty=TRUE, m=5, seed=1234)
summary(mod1)

### Figure 2
set.seed(1234)
example$time <- ifelse(is.na(example$days_prev), example$stop, example$stop-example$days_prev)
keep <- example %>%
  count(nid, sort = TRUE) %>%
  filter(n > 2)
keep <- sample_n(keep, 30)
example.plot <- example %>%
  mutate(nid = factor(nid)) %>%
  filter(nid %in% keep$nid)
ggplot(example.plot, aes(x=time, y=fct_reorder(nid, stop, min))) + 
  geom_line(aes(group = nid)) + geom_vline(xintercept=0) +
  ylab("") + scale_colour_brewer("status", palette = "Dark2") +
  geom_point(data = filter(example.plot, time>=0),
             mapping = aes(x=time, y=fct_reorder(nid, stop, min), color=factor(status)))