## ----linear-Gaussian model for nhtemp data------------------------------------
library("bssm")
data("nhtemp", package = "datasets")
prior <- halfnormal(1, 10)
bsm_model <- bsm_lg(y = nhtemp, sd_y = prior, sd_level = prior, sd_slope = prior)


## ----non-Gaussian model-------------------------------------------------------
# Generate observations
set.seed(1)
x <- cumsum(rnorm(50, sd = 0.2)) 
y <- cbind(                                       
  rpois(50, exp(x)), 
  rpois(50, exp(x)))

# Log prior density function
prior_fn <- function(theta) {
  dgamma(theta, 2, 0.01, log = TRUE)               
}

# Model parameters from hyperparameters
update_fn <- function(theta) {                    
  list(R = array(theta, c(1, 1, 1)))
}

# define the model
mng_model <- ssm_mng(y = y, Z = matrix(1,2,1), T = 1, 
  R = 0.1, P1 = 1, distribution = "poisson",
  init_theta = 0.1, 
  prior_fn = prior_fn, update_fn = update_fn)


## ----mcmc for the bsm model defined above-------------------------------------
mcmc_bsm <- run_mcmc(bsm_model, iter = 1e5, burnin = 1e4)


## ----bsm-plot, for theta------------------------------------------------------
library("ggplot2")
d <- as.data.frame(mcmc_bsm, variable = "theta")
ggplot(d, aes(x = value)) + 
  geom_density(bw = 0.1, fill = "#9ebcda") + 
  facet_wrap(~ variable, scales = "free") + 
  theme_bw()


## ----bsm-plot-states, for states----------------------------------------------
library("dplyr")
d <- as.data.frame(mcmc_bsm, variable = "states")
summary_y <- d %>% 
  filter(variable == "level") %>%
  group_by(time) %>%
  summarise(mean = mean(value), 
    lwr = quantile(value, 0.025), 
    upr = quantile(value, 0.975))

ggplot(summary_y, aes(x = time, y = mean)) + 
  geom_ribbon(aes(ymin = lwr, ymax = upr), alpha = 0.25) +
  geom_line() +
  geom_point(data = data.frame(mean = nhtemp, 
    time = time(nhtemp))) +
  theme_bw() + xlab("Year") + 
  ylab("Mean annual temperature in New Haven")

## ----postcorrection for mng_model---------------------------------------------
out_approx <- run_mcmc(mng_model, mcmc_type = "approx", iter = 50000)
est_N <- suggest_N(mng_model, out_approx)
out_exact <- post_correct(mng_model, out_approx, particles = est_N$N)

## ---- comparison with rstan---------------------------------------------------
library("bssm")

# Simulate the data
set.seed(123)
n <- 200
sd_level <- 0.1
drift <- 0.01
beta <- -0.9
phi <- 5

level <- cumsum(c(5, drift + rnorm(n - 1, sd = sd_level)))
x <- 3 + (1:n) * drift + sin(1:n + runif(n, -1, 1))
y <- rnbinom(n, size = phi, mu = exp(beta * x + level))

# Construct model for bssm
bssm_model <- bsm_ng(y, 
  xreg = x,
  beta = normal(0, 0, 10),
  phi = halfnormal(1, 10),
  sd_level = halfnormal(0.1, 1), 
  sd_slope = halfnormal(0.01, 0.1),
  a1 = c(0, 0), P1 = diag(c(10, 0.1)^2), 
  distribution = "negative binomial")

# run the MCMC
fit_bssm <- run_mcmc(bssm_model, iter = 60000, burnin = 10000,
  particles = 10, seed = 1)

# create the Stan model

library("rstan")

stan_model <- "
data {
  int<lower=0> n;             // number of data points
  int<lower=0> y[n];          // time series
  vector[n] x;                // covariate
}

parameters {
  real<lower=0> sd_slope;
  real<lower=0> sd_level;
  real beta;
  real<lower=0> phi;
  // instead of working directly with true state variables
  // it is often suggested use standard normal variables in sampling
  // and reconstruct the true parameters in transformed parameters block
  // this should make sampling more efficient although coding the model 
  // is less intuitive.
  vector[n] level_std;        // N(0, 1) level noise
  vector[n] slope_std;        // N(0, 1) slope noise
}
transformed parameters {
  vector[n] level;
  vector[n] slope;
  // construct the actual states
  level[1] = 10 * level_std[1];
  slope[1] = 0.1 * slope_std[1];
  slope[2:n] = slope[1] + cumulative_sum(sd_slope * slope_std[2:n]);
  level[2:n] = level[1] + cumulative_sum(slope[1:(n-1)]) + 
               cumulative_sum(sd_level * level_std[2:n]);
}
model {
  beta ~ normal(0, 10);
  phi ~ normal(0, 10);
  sd_slope ~ normal(0, 0.1);
  sd_level ~ std_normal();
  // standardised noise terms
  level_std ~ std_normal();
  slope_std ~ std_normal();
  
  y ~ neg_binomial_2_log(level + beta * x, phi);
}

"

stan_data <- list(n = n, y = y, x = x)

stan_inits <- list(list(sd_level = 0.1, sd_slope = 0.01, phi = 1, beta = 0))

# need to increase adapt_delta and max_treedepth in order to avoid divergences
fit_stan <- stan(model_code = stan_model,
  data = stan_data, iter = 15000, warmup = 5000,
  control = list(adapt_delta = 0.99, max_treedepth = 12),
  init = stan_inits, chains = 1, refresh = 0, seed = 1)

d_stan <- summary(fit_stan, pars = 
    c("sd_level", 
      "sd_slope", 
      "phi", 
      "beta",
      "level[200]",
      "slope[200]"
    ))$summary[,c("mean", "sd", "se_mean")]

d_bssm <- summary(fit_bssm, variable = "both", return_se = TRUE)

# Parameter estimates:
d_stan
d_bssm$theta
d_bssm$states[d_bssm$states$time == 200,]

# Timings:
sum(get_elapsed_time(fit_stan))
fit_bssm$time[3]
