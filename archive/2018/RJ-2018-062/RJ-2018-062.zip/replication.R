# Title    : Consistency Cubes. 
#            A Fast, Efficient Method for exact Boolean Minimization.
# Author   : Adrian Dusa (dusa.adrian@unibuc.ro)
# Date     : 16 November 2017
#
# Package versions
# QCA      : 3.0
# venn     : 1.5
# LogicOpt : 1.0.0



# -----
# R code in section: "Context"
# -----

library(QCA)
createMatrix(rep(2, 4))


# -----
# R code in section: "Previous attempts"
# -----

set.seed(1234)
tt <- data.frame(createMatrix(rep(2, 4)), stringsAsFactors = FALSE,
            OUT = sample(c(1, 0, "?"), 16, replace = TRUE, prob = c(.19, .18, .63)))
tt
colnames(tt)[1:4] = LETTERS[1:4]
tt <- tt[tt$OUT != "?", ]
(tt <- tt[order(tt$OUT, decreasing = TRUE), ])


# -----
# R code in section: "Search space"
# -----

tt[, c("A", "D", "OUT")]
data.frame(AD = as.matrix(tt[, c("A", "D")]) %*% c(2^1, 2^0), OUT  = tt$OUT)

IM <- createMatrix(rep(3, 4)) # base 3 for 4 causal conditions
rownames(IM) <- seq(nrow(IM))
colnames(IM) <- LETTERS[1:4]
IM[apply(IM, 1, function(x) sum(x > 0) == 1), ]


# -----
# R code in section: "Solving the prime implicants chart"
# -----

PIs <- translate("~B + ~A*D + A*~D + C*~D")
PIs
pic <- makeChart(rownames(PIs), c("~A*B*~C*D", "A*~B*~C*~D", "A*~B*C*~D"))
pic
minimize(tt, outcome = "OUT", include = "?", use.tilde = TRUE)
findmin(pic)

library(venn)
venn("~A*D + ~B", snames = "A, B, C, D", zcolor = "red, #008833")


# -----
# R code in section: "Performance benchmark"
# -----

gendat <- function(ncols, nrows, seed = 12345) {
    set.seed(seed)
    dat <- unique(matrix(sample(0:1, ncols*nrows, replace = TRUE), ncol = ncols))
    colnames(dat) <- LETTERS[seq(ncols)]
    return(as.data.frame(dat[order(dat[, ncols], decreasing = TRUE), ]))
}

dat <- gendat(ncols = 11, nrows = 10)
minimize(dat, outcome = "K", include = "?", method = "QMC")

all.equal(
      capture.output(minimize(dat, outcome = "K", include = "?", method = "QMC")),
      capture.output(minimize(dat, outcome = "K", include = "?", method = "eQMC"))
)

all.equal(
      capture.output(minimize(dat, outcome = "K", include = "?", method = "eQMC")),
      capture.output(minimize(dat, outcome = "K", include = "?", method = "CCubes"))
)

test <- function(dat, method = "", min.pin = FALSE) {
    dat <- as.matrix(dat)
    nconds <- ncol(dat) - 1
    noflevels <- rep(2, nconds)
    output <- dat[, nconds + 1]
    switch(method,
    "QMC" = {
        mbase <- rev(c(1, cumprod(rev(noflevels))))[-1]
        neg <- drop(dat[output == 0, seq(nconds)] %*% mbase) + 1
        .Call("QMC", createMatrix(noflevels)[-neg, ] + 1, noflevels, PACKAGE = "QCA")
    },
    "eQMC" = {
        mbase <- rev(c(1, cumprod(rev(noflevels + 1))))[-1]
        pos <- dat[output == 1, seq(nconds)]
        neg <- dat[output == 0, seq(nconds)]
        rows <- sort.int(setdiff(findSupersets(input = pos + 1, noflevels + 1),
                                 findSupersets(input = neg + 1, noflevels + 1)))
        .Call("removeRedundants", rows, noflevels, mbase, PACKAGE = "QCA")
    },
    "CCubes" = {
        .Call("ccubes", list(dat, min.pin), PACKAGE = "QCA")
    })
}

system.time(test(dat, method = "QMC"))
system.time(test(dat, method = "eQMC"))
system.time(test(dat, method = "CCubes"))

dat <- gendat(ncols = 17, nrows = 10)
system.time(test(dat, method = "eQMC"))
system.time(test(dat, method = "CCubes"))

dat <- gendat(ncols = 26, nrows = 10)
system.time(test(dat, method = "CCubes"))

dat <- gendat(ncols = 21, nrows = 20)
system.time(cc <- test(dat, method = "CCubes"))

library(LogicOpt)
system.time(lo <- logicopt(dat, 20, 1, find_dc = TRUE, mode = "primes"))

nrow(cc)
lo[[2]][2]

system.time(cc <- test(dat, method = "CCubes", min.pin = TRUE))
nrow(cc)


# -----
# The code to record timings for 1000 randomly generated samples
# (can take several hours to run)
set.seed(12345)
seeds <- sample(1000000000, 1000)
result <- matrix(NA, nrow = length(seeds), ncol = 3)
for (i in seq(length(seeds))) {
    dat <- gendat(21, 20, seeds[i])
    result[i, ] <- c(system.time(test(dat, method = "CCubes"))[[3]],
        system.time(logicopt(dat, 20, 1, find_dc = TRUE, mode = "primes"))[[3]],
        system.time(test(dat, method = "CCubes", min.pin = TRUE))[[3]])
}


# -----
# The result object from the above code is saved in the file "timings.RData"
load("timings.RData")
apply(result, 2, mean)
apply(result, 2, sd)



