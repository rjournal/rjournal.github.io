# Usage

# Data generation process
set.seed(19394)
n <- 500
mu <- rep(0, 4)
Sigma <- diag(4)
Sigma[1,2] <- 0.15; Sigma[1,3] <- 0.1; Sigma[1,4] <- -0.1
Sigma[2,3] <- 0.25; Sigma[2,4] <- 0.05
Sigma[lower.tri(Sigma)] = t(Sigma)[lower.tri(Sigma)]
require("MASS")
rawvars <- mvrnorm(n, mu = mu, Sigma = Sigma)
pvars <- pnorm(rawvars)
X.1 <- rawvars[,1]
X.2 <- qchisq(pvars, 3)[,3]
X.3 <- qpois(pvars, 2.5)[,2]
X.4 <- qbinom(pvars, 1, .4)[,4]
data <- cbind(X.1, X.2, X.3, X.4)
beta <- c(1.8, 1.3, 1, -1)
sigma <- 4.2
y <- data %*% beta + rnorm(n, 0, sigma)
data <- data.frame(y, data)
mod <- lm(y ~ X.1 + X.2 + X.3 + X.4, data = data)
summary(mod)

# Missing mechanism
r.s <- cbind(y, X.1) %*% c(2,1)
r.s <- scale(r.s)
pos <- cut(r.s, quantile(r.s, c(0, .5, 1)), include.lowest=TRUE)
p.r <- as.numeric(c(.9, .2))
p.r <- as.vector(p.r[pos])
R2 <- as.logical(rbinom(length(p.r),1,p.r))
r.s <- cbind(y[!R2], X.1[!R2]) %*% c(2,1)
r.s <- scale(r.s)
pos <- cut(r.s, quantile(r.s, c(0, .4, 1)), include.lowest=TRUE)
p.r <- as.numeric(c(.32, .27))
p.r <- as.vector(p.r[pos])
R3 <- as.logical(rbinom(length(p.r),1,p.r))
R4 <- runif(nrow(data[!R2,][!R3,]), 0, 1) >= .25
data$X.2[!R2] <- NA
data$X.3[!R2][!R3] <- NA
data$X.4[!R2][!R3][!R4] <- NA

# Example 1
library(ImputeRobust)
md.pattern(data)
predictorMatrix <- matrix(c(rep(c(0,0,1,1,1),2), rep(0,5), c(0,0,1,0,0), c(0,0,1,1,0)),
                          nrow = 5)
imps <- mice(data, method = "gamlss", predictorMatrix = predictorMatrix,
             visitSequence = "monotone", maxit = 1, seed = 8913)
print(imps)
library(lattice)
stripplot(imps)
fit <- with(imps, lm(y ~ X.1 + X.2 + X.3 + X.4))
print(pool(fit))
round(summary(pool(fit)), 2)

# Example 2

imps <- mice(data, method = c("", "", "gamlssGA", "gamlssPO", "gamlssBI"), seed = 8913)
stripplot(imps)
fit <- with(imps, lm(y ~ X.1 + X.2 + X.3 + X.4))
round(summary(pool(fit)), 2)

# Example 3
library(RWeka)
data <- read.arff("data/chronic_kidney_disease_full.arff")
data <- data[,c("age", "bp", "bgr", "bu", "sc", "sod", "pot", "hemo",
                "class")]
data$class <- ifelse(data$class == "ckd", 1, 0)             

meth <- c("gamlssJSU", "gamlssJSU", "gamlssJSU", "gamlssJSU",
          "gamlssJSU", "gamlssJSU", "gamlssJSU", "gamlssJSU",
          "gamlss")
imps <- mice(data, method = meth, n.cyc = 3, bf.cyc = 2, cyc = 2,
             maxit = 5, m = 5, seed = 8901,
             gam.mod = list(type = "linear"))

stripplot(imps)

fit <- with(imps, glm(class ~ age + bp + bgr + sc + sod + pot + hemo,
                      family=binomial(link='logit')))
round(summary(pool(fit)), 2)
