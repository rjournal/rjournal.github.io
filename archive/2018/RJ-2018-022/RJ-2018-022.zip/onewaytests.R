# install onewaytests package
install.packages("onewaytests")

# load onewaytests package
library("onewaytests")

# obtain some basic descriptive statistics
describe(Sepal.Length ~ Species, data = iris)


#### One-way tests in independent groups designs

# ANOVA
aov.test(Sepal.Length ~ Species, data = iris, alpha = 0.05, na.rm = TRUE, verbose = TRUE)

###### how to pull the statistics from the output
result <- aov.test(Sepal.Length ~ Species, data = iris, alpha = 0.05, na.rm = TRUE, verbose = FALSE)

# the ANOVA test statistic
result$statistic

# the degrees of freedom for numerator and denominator
result$parameter

# the p-value of the test
result$p.value
######



# Welch�s heteroscedastic F test
welch.test(Sepal.Length ~ Species, data = iris)

# Welch�s heteroscedastic F test with trimmed means andWinsorized variances
welch.test(Sepal.Length ~ Species, data = iris, rate = 0.1)

# Brown-Forsythe test
bf.test(Sepal.Length ~ Species, data = iris)

# Alexander-Govern test
ag.test(Sepal.Length ~ Species, data = iris)

# James second order test
james.test(Sepal.Length ~ Species, data = iris, alpha = 0.05)

# Kruskal-Wallis test
kw.test(Sepal.Length ~ Species, data = iris)

####



#### Pairwise comparisons

# Alexander-Govern test
out <- ag.test(Sepal.Length ~ Species, data = iris, verbose = FALSE)
paircomp(out, adjust.method = "bonferroni")

# James second order test
out <- james.test(Sepal.Length ~ Species, data = iris, verbose = FALSE)
paircomp(out, adjust.method = "bonferroni")

####



#### Checking assumptions via tests and plots

# Bartlett's homogeneity test
homog.test(Sepal.Length ~ Species, data = iris, method = "Bartlett")

# Shapiro-Wilk normality test
nor.test(Sepal.Length ~ Species, data = iris, method = "SW", plot = "qqplot-histogram")

####



#### Graphical Approaches

# Box-and-whisker plot with violin line
gplot(Sepal.Length ~ Species, data = iris, type = "boxplot")

# Box-and-whisker plot
gplot(Sepal.Length ~ Species, data = iris, type = "boxplot", violin = FALSE)

# Mean +- standard deviation graph
gplot(Sepal.Length ~ Species, data = iris, type = "errorbar", option = "sd")

# Mean +- standard error graph
gplot(Sepal.Length ~ Species, data = iris, type = "errorbar", option = "se")

####



# install mfp package
install.packages("mfp")

# load mfp package
library("mfp")

# load GBSG data 
data("GBSG")

# select the patients of whom an event for recurrence-free survival occurs
GBSG_subset <- GBSG[GBSG$cens == 1,]

# obtain the descriptive statistics of the tumor grades in terms of recurrence-free survival times
describe(rfst ~ tumgrad, data = GBSG_subset)

# Bartlett's homogeneity test 
homog.test(rfst ~ tumgrad, data = GBSG_subset, method = "Bartlett")

# Shapiro-Wilk normality test
nor.test(rfst ~ tumgrad, data = GBSG_subset, method = "SW")

# ANOVA
aov.test(rfst ~ tumgrad,data = GBSG_subset)

# Kruskal-Wallis test
kw.test(rfst ~ tumgrad, data = GBSG_subset)




#### Pairwise comparisons

# ANOVA
out <- aov.test(rfst ~ tumgrad, data = GBSG_subset, verbose = FALSE)
paircomp(out, adjust.method = "bonferroni")

# Kruskal-Wallis test
out<- kw.test(rfst ~ tumgrad, data = GBSG_subset, verbose = FALSE)
paircomp(out, adjust.method = "bonferroni")

####
