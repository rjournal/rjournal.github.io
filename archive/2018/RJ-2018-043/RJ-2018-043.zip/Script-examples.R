
## Examples ##


# Breast cancer dataset

library(data.table)
data <- fread('https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/wdbc.data')
names(data) <- c("id", "diagnosis", "radius_mean", "texture_mean", "perimeter_mean", "area_mean", "smoothness_mean", "compactness_mean", "concavity_mean", "concave.points_mean", "symmetry_mean", "fractal_dimension_mean", "radius_se", "texture_se", "perimeter_se", "area_se", "smoothness_se", "compactness_se", "concavity_se", "concave.points_se", "symmetry_se", "fractal_dimension_se", "radius_worst", "texture_worst", "perimeter_worst", "area_worst", "smoothness_worst", "compactness_worst", "concavity_worst", "concave.points_worst", "symmetry_worst", "fractal_dimension_worst")
attach(data)

library(nsROC)

roc <- gROC(fractal_dimension_mean, diagnosis, plot.density=TRUE)
generalroc <- gROC(fractal_dimension_mean, diagnosis, side="both")

print(roc)
print(generalroc)

plot(roc, main="ROC curve (left-sided)")
plot(generalroc, main="General ROC curve")

roc <- gROC(texture_mean, diagnosis) 	# "auto" side -> right-sided in this case

rocbands_psn <- ROCbands(roc, method="PSN")
rocbands_psn_mod <- ROCbands(roc, method="PSN", alpha1=0.025)
rocbands_jms <- ROCbands(roc, method="JMS")
rocbands_dek <- ROCbands(roc, method="DEK")

print(rocbands_psn)
print(rocbands_psn_mod)
print(rocbands_jms)
print(rocbands_dek)

plot(rocbands_psn)
plot(rocbands_psn_mod)
plot(rocbands_jms)
plot(rocbands_dek)

depmarker <- cbind(smoothness_mean,smoothness_worst)

out.KS <- compareROCdep(depmarker, diagnosis)
out.L1 <- compareROCdep(depmarker, diagnosis, statistic="L1")
out.L2 <- compareROCdep(depmarker, diagnosis, statistic="L2")
out.CR <- compareROCdep(depmarker, diagnosis, statistic="CR")
out.new <- compareROCdep(depmarker, diagnosis, statistic="other", FUN.dist=function(g){mean(g^4)})

out.perm.KS <- compareROCdep(depmarker, diagnosis, method="perm")
out.perm.L1 <- compareROCdep(depmarker, diagnosis, statistic="L1", method="perm")
out.perm.L2 <- compareROCdep(depmarker, diagnosis, statistic="L2", method="perm")
out.perm.CR <- compareROCdep(depmarker, diagnosis, statistic="CR", method="perm")
out.VK <- compareROCdep(depmarker, diagnosis, statistic="VK")
out.perm.new <- compareROCdep(depmarker, diagnosis, statistic="other", method="perm", FUN.dist=function(g){mean(g^4)})

type <- as.numeric(symmetry_mean > 0.18) + as.numeric(symmetry_worst > 0.29) + 1
table(type,diagnosis)

output.L1 <- compareROCindep(radius_mean, type, diagnosis, statistic="L1")
output.L2 <- compareROCindep(radius_mean, type, diagnosis, statistic="L2")
output.CR <- compareROCindep(radius_mean, type, diagnosis, statistic="CR")
output.VK <- compareROCindep(radius_mean, type, diagnosis, statistic="VK")
output.AUC <- compareROCindep(radius_mean, type, diagnosis, statistic="AUC")


# Primarily Biliary Cirrhosis Data

library(survival)
data <- subset(pbc, status!=1)
attach(data)
status <- status/2

out1 <- cdROC(time,status,bili,4000)
out2 <- cdROC(time,status,bili,4000, method="KM")
out3 <- cdROC(time,status,bili,4000, method="wKM")
out4 <- cdROC(time,status,bili,4000, method="wKM", kernel="other", kernel.fun=function(x,xi,h){u <- (x-xi)/h; 1/(2*h)*(abs(u) <= 1)}, h=0.5)

plot(out1, main="ROC curve at time 4000 (Cox method)")
text(0.8,0.1,paste("AUC =",round(out1$auc,3)))
plot(out2, main="ROC curve at time 4000 (KM method)")
text(0.8,0.1,paste("AUC =",round(out2$auc,3)))
plot(out3, main="ROC curve at time 4000 \n (Weighted KM method with normal kernel)")
text(0.8,0.1,paste("AUC =",round(out3$auc,3)))
plot(out4, main="ROC curve at time 4000 \n (Weighted KM method with uniform kernel)")
text(0.8,0.1,paste("AUC =",round(out4$auc,3)))


# Interleukin 6 Data

data(interleukin6)

output1 <- metaROC(interleukin6, plot.Author=TRUE)
points(1-output1$youden.index[1], output1$youden.index[2], pch=16, col='blue')

output2 <- metaROC(interleukin6, model="random-effects", plot.Author=TRUE, plot.inter.var=TRUE)
points(1-output2$youden.index[1], output2$youden.index[2], pch=16, col='blue')