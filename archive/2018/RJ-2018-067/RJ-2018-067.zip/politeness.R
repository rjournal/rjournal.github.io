# politeness: Detecting Politeness Features in Text
# by Michael Yeomans, Alejandro Kantor, Dustin Tingley

#-----------------------------------------------------------------------
# Politeness features
#-----------------------------------------------------------------------

library(politeness)

data("feature_table")

feature_table

#-----------------------------------------------------------------------
# Part of speech tagging
#-----------------------------------------------------------------------

# install.packages("spacyr")
PYTHON_PATH <- "/anaconda/bin/python" # substitute with your path name 
spacyr::spacy_initialize(python_executable = PYTHON_PATH)

library(politeness)

#-----------------------------------------------------------------------
# Detecting politeness features
#-----------------------------------------------------------------------

library(politeness)

texts <- c("Hello, you", "You")


df_politeness <- politeness(texts, parser="none",drop_blank = TRUE)
df_politeness


df_politeness <- politeness(texts, parser="spacy",drop_blank = TRUE)
df_politeness


data("phone_offers")
texts <- phone_offers$message[c(21,25)]
texts


features <- c("Positive.Emotion", "Impersonal.Pronoun","First.Person","Second.Person",
              "Negative.Emotion")

df_politeness <- politeness(texts,drop_blank = TRUE)
df_politeness[ , features]


df_politeness <- politeness(texts, metric="binary",drop_blank = TRUE)
df_politeness[ , features]


#-----------------------------------------------------------------------
# Plotting politeness features
#-----------------------------------------------------------------------

df_politeness_count <- politeness(phone_offers$message, 
                                  parser="none", 
                                  drop_blank=FALSE)

politenessPlot(df_politeness_count,
               split=phone_offers$condition,
               split_levels = c("Tough","Warm"),
               split_name = "Condition")


df_politeness_binary <- politeness(phone_offers$message, 
                                   parser="none", 
                                   metric="binary", 
                                   drop_blank=FALSE)

politenessPlot(df_politeness_binary,
               split=phone_offers$condition,
               split_levels = c("Tough","Warm"),
               split_name = "Condition")

#-----------------------------------------------------------------------
# Projecting politeness features
#-----------------------------------------------------------------------

df_polite_train <- politeness(phone_offers$message, drop_blank=FALSE)

df_polite_holdout <- politeness(bowl_offers$message, drop_blank=FALSE)

project <- politenessProjection(df_polite_train,
                                phone_offers$condition,
                                df_polite_holdout)

mean(project$test_proj[bowl_offers$condition==1])

mean(project$test_proj[bowl_offers$condition==0])

set.seed(111)

fpt_most <- findPoliteTexts(phone_offers$message,
                            df_polite_train,
                            phone_offers$condition,
                            type="most",
                            num_docs=2)
fpt_least <- findPoliteTexts(phone_offers$message,
                             df_polite_train,
                             phone_offers$condition,
                             type="least",
                             num_docs=2)

fpt_most$text

fpt_least$text


#-----------------------------------------------------------------------
# New Example - SpeedDating
#-----------------------------------------------------------------------

#devtools::install_github("myeomans/politeness")

library(politeness)

# Replace with your own path to this repository to run the example
#FOLDER_PATH<-"/Users/mikeyeomans/Desktop/PolitenessRJournal/"
#load(paste0(FOLDER_PATH,"speedDateDates.rdata"))
#load(paste0(FOLDER_PATH,"speedDateTurns.rdata"))

#-----------------------------------------------------------------------
# Plotting and dichotimizing the ground truth politeness label

par(family="Times",mar=c(5,5,1,0))
barplot(table(as.numeric(speedDateDates$courtesy)),yaxt="n",
        col=c(rep("navyblue",5),rep("gray",3),rep("firebrick",2)),
        cex.names=2,ylim=c(0,400))
mtext("Partner Courtesy",side=1,line=3,font=2,cex=2)
mtext("Number of Dates",side=2,line=3.5,font=2,cex=2)
axis(side=2,at=seq(0,1000,100),cex.axis=1.5,las=1)
legend(x=.5,y=400,legend=c("Rude","Courteous"),
       pch=15,pt.cex=3,cex=1.6,col=c("navyblue","firebrick"))

speedDateDates$politeness <- ""
speedDateDates$politeness[speedDateDates$courtesy>8] <-  "Courteous"
speedDateDates$politeness[speedDateDates$courtesy<6] <-  "Rude"
speedDateDates<-speedDateDates[speedDateDates$politeness != "",]
#-----------------------------------------------------------------------

# Counting feature totals across entire transcripts from turn-by-turn data.

polite.cols<-names(speedDateTurns)[!names(speedDateTurns)%in%c("selfid","otherid","turn","span","group")]
speedDateDates[,polite.cols]<-NA
for (o in 1:nrow(speedDateDates)){
  matched.rows<-(speedDateTurns$selfid==speedDateDates[o,"otherid"])&(speedDateTurns$otherid==speedDateDates[o,"selfid"])
  speedDateDates[o,polite.cols]<-colSums(speedDateTurns[matched.rows,polite.cols],na.rm=T)
}

#-----------------------------------------------------------------------

extra_names<-c(paste0(c("Followup","Switch","Intro","Mirror","Repair"),".Qs"),"Laughter")

extras<-rbind(round(colMeans(speedDateDates[(speedDateDates$sex==1),extra_names]),2),
              round(colMeans(speedDateDates[(speedDateDates$sex==0),extra_names]),2))
row.names(extras)<-c("Spoken by Women (to Men)","Spoken by Men (to Women)")
extras

politeness::politenessPlot(speedDateDates[(speedDateDates$sex==1),c(polite.cols,extra_names)],
                           split=speedDateDates$politeness[(speedDateDates$sex==1)],
                           split_name="Ratings of Women (by Men)",
                           top_title="",
                           middle_out=.1)


politeness::politenessPlot(speedDateDates[(speedDateDates$sex==0),c(polite.cols,extra_names)],
                           split=speedDateDates$politeness[(speedDateDates$sex==0)],
                           split_name="Ratings of Men (by Women)",
                           top_title="",
                           middle_out=.1)
##########################################################################################
