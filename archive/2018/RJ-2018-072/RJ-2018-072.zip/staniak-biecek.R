# Examples from the _Explanations of model predictions with live and breakDown packages_ paper.

# Load necessary packages:

if(!require(shapleyR)) {
  devtools::install_github("redichh/shapleyr")
}
library(e1071)
library(lime)
library(breakDown)
library(live)
library(mlr)
library(shapleyR)
library(tidyverse)
library(xtable)
library(iml)

# Setup the archivist repository

library(archivist)
## createLocalRepo("arepo")
# setLocalRepo("arepo")

# Wine data (from `live` package):

data('wine', package = "live")
nc <- which(colnames(wine) == "quality")

# saveToLocalRepo(wine)
# 3722f537a2cb2d78daba392d1c7e8bd7
# archivist::aread("pbiecek/live_simulations/arepo/3722f537a2cb2d78daba392d1c7e8bd7")

# Fit SVM (no hyperparameter tuning)

wine_svm <- svm(quality ~., data = wine)

# saveToLocalRepo(wine_svm)
# 1025d57a48c5a037e5a56d8b1b06c1df
# archivist::aread("pbiecek/live_simulations/arepo/1025d57a48c5a037e5a56d8b1b06c1df")

# LIME explanation (set.seed because instances are sampled)

set.seed(17)
wine_expl <- lime(wine, wine_svm)
model_type.svm <- function(x, ...) "regression"
svm_explained <- lime::explain(wine[5, ], wine_expl, n_features = 11)
plot_features(svm_explained)

# saveToLocalRepo(svm_explained)
# 66e9851f52186a38d5773dd5b7f1a669
# archivist::aread("pbiecek/live_simulations/arepo/66e9851f52186a38d5773dd5b7f1a669")

# Break Down explanation

explain_bd <- broken(wine_svm, new_observation = wine[5, -nc],
                     data = wine[, -nc],
                     baseline = "Intercept",
                     keep_distributions = TRUE)
plot(explain_bd)

# saveToLocalRepo(explain_bd)
# 1f3204991d06e083f7608cd3f2acce5b
# archivist::aread("pbiecek/live_simulations/arepo/1f3204991d06e083f7608cd3f2acce5b")

# Break Down with direction = "down"

explain_bd2 <- broken(wine_svm, new_observation = wine[5, -nc],
                      data = wine[, -nc],
                      baseline = "Intercept",
                      direction = "down")
plot(explain_bd2)

# Example plot showing how Break Down works.

plot(explain_bd, plot_distributions = T)

# LIVE explanation.

wine_sim <- sample_locally(data = wine,
                           explained_instance = wine[5, ],
                           explained_var = "quality",
                           size = 2000,
                           seed = 17)
wine_sim_svm <- add_predictions(wine_sim, wine_svm)
wine_expl_live <- fit_explanation(wine_sim_svm)
plot(wine_expl_live, "waterfall")
plot(wine_expl_live, "forest")

# saveToLocalRepo(wine_expl_live)
# 878d51516eec906e9b5aed526836f57b
# archivist::aread("pbiecek/live_simulations/arepo/878d51516eec906e9b5aed526836f57b")

# LIVE explanation using decision tree.

wine_expl_tree <- fit_explanation(wine_sim_svm, "regr.ctree", kernel = identity_kernel,
                                  hyperpars = list(maxdepth = 2))
plot(wine_expl_tree)

# saveToLocalRepo(wine_expl_tree)
# 32f06fe892f0b02a756d28280b985cbd
# archivist::aread("pbiecek/live_simulations/arepo/32f06fe892f0b02a756d28280b985cbd")

# Shapley values (requires the use of mlr, so model is fitted again)

tsk <- makeRegrTask("wine", wine, "quality")
set.seed(17)
shp <- shapley(5, model = train("regr.svm", tsk), task = tsk)
class(shp) <- c("shapley.singleValue", "list")
plot(shp)

# saveToLocalRepo(shp)
# e1ae768c305f1df6d89bd564ebe84003
# archivist::aread("pbiecek/live_simulations/arepo/e1ae768c305f1df6d89bd564ebe84003")

# Shapley values calculated with the `iml` package.

model_svm = Predictor$new(model = wine_svm, data = wine[, -nc], y = wine$quality)
set.seed(17)
shapley_iml = Shapley$new(model_svm, x.interest = wine[5, -nc])
shapley_iml
plot(shapley_iml)

# saveToLocalRepo(shapley_iml)
# 50f5f3bcf2b6ac60435bbd92c637254f
# archivist::aread("pbiecek/live_simulations/arepo/50f5f3bcf2b6ac60435bbd92c637254f")

# Shapley values table
brk <- data.frame(var = explain_bd$variable_name, explain_bd$contribution)
shapley_iml$results %>%
  select(feature, phi) %>%
  inner_join(brk, by = c("feature" = "var")) %>%
  arrange(desc(abs(phi))) %>%
  rename(`breakDown score` = `explain_bd.contribution`,
         `Shapley value` = phi) %>%
  mutate_if(is.numeric, function(x) round(x, 2)) %>%
  xtable()

