## ----setup, cache = F, echo = F, warning = F, message = F----------------
library(knitr)
library(tidyverse)
library(gridExtra)

# set global chunk options
opts_chunk$set(fig.align = 'center', message = F, dev = 'pdf', dev.args = list(family = 'serif'), fig.pos = '!h', warning = F, background = 'white', highlight = FALSE, prompt = FALSE, size = 'small', out.width = '\\textwidth', 
  fig.process = function(x) {
  x2 = sub('-\\d+([.][a-z]+)$', '\\1', x)
  if (file.rename(x, x2)) x2 else x
  })
options(replace.assign=TRUE,width=40,digits=2)
knit_hooks$set(document = function(x) {sub('\\usepackage[]{color}', '\\usepackage{xcolor}', x, fixed = TRUE)})
source('SupportiveCodes/funcs.R')

## ----eval = F------------------------------------------------------------
## impute_errors(dataIn, smps = "mcar",
##   methods = c("na.approx","na.interp",
##   "na.interpolation", "na.locf", "na.mean"),
##   methodPath = NULL, errorParameter = "rmse",
##   errorPath = NULL, blck = 50, blckper = TRUE,
##   missPercentFrom = 10, missPercentTo = 90,
##   interval = 10, repetition = 10, addl_arg =
##   NULL)

## ------------------------------------------------------------------------
library(imputeTestbench)
set.seed(123)
a <- impute_errors(dataIn = nottem)
a

## ----Fig2, fig.height = 5, fig.width = 9, out.width = '\\textwidth', fig.cap = 'Distribution of error values from the \\code{errprof} object for each imputation method and interval of missing observations.  The plot is created with \\code{plot\\_errors()} using the boxplot option.', fig.env = 'figure*'----
plot_errors(a)

## ----Fig3, fig.height = 5, fig.width = 9, out.width = '\\textwidth', fig.cap = 'Average error values for each imputation method and interval of missing observations.  The \\code{line} option is used for \\code{plot\\_errors()}.', fig.env = 'figure*'----
plot_errors(a, plotType = 'line')

## ----eval = F------------------------------------------------------------
## sample_dat(datin, smps = "mcar", repetition = 10, b = 50, blck = 50, blckper = TRUE,
##   plot = FALSE)

## ----echo = F------------------------------------------------------------
set.seed(123)

## ----Fig4, out.width = '\\textwidth', fig.cap = 'Examples of sampling schemes for missing data provided by \\code{sample\\_dat()}, plotted using the argument \\code{plot = T}.  Values to be removed and imputed are shown as open circles and the data to be kept are in blue. From top to bottom, sampling is MCAR with 10\\% missing, MCAR with 50\\% missing, MAR with 10\\% missing and block size 10\\% of total missing, MAR with 50\\% missing and block size 50\\% of total missing, MAR with 10\\% missing and block size of ten observations, and MAR with 50\\% missing and block size of fifty observations.', fig.height = 9, fig.width = 7, echo = F, fig.pos='h!', fig.env='figure*'----
library(gridExtra)
library(ggplot2)
mytheme <- theme(legend.position = 'none', axis.title.x = element_blank(), axis.title.y = element_blank(),
  plot.title = element_text(size = 10))
a <- rnorm(500)
p1 <- sample_dat(a, smps = 'mcar', b = 10, plot = TRUE)
pleg <- g_legend(p1)
p1 <- p1 + mytheme
p2 <- sample_dat(a, smps = 'mcar', b = 50, plot = TRUE) + mytheme
p3 <- sample_dat(a, smps = 'mar', b = 10, blck = 10, blckper = TRUE, plot = TRUE) + mytheme
p4 <- sample_dat(a, smps = 'mar', b = 50, blck = 50, blckper = TRUE, plot = TRUE) + mytheme
p5 <- sample_dat(a, smps = 'mar', b = 10, blck = 10, blckper = FALSE, plot = TRUE) + mytheme
p6 <- sample_dat(a, smps = 'mar', b = 50, blck = 50, blckper = FALSE, plot = TRUE) + mytheme
grid.arrange(pleg, p1, p2, p3, p4, p5, p6, ncol = 1, heights = c(0.1, 1, 1, 1, 1, 1, 1), left = 'Value', bottom = 'Time')

## ----Fig5, fig.height = 6, fig.width = 7, out.width = '\\textwidth', fig.cap = 'Output from the \\code{plot\\_impute()} function that shows the data that were retained (blue), removed (open circles), and imputed (red).', fig.pos='h!', fig.env='figure*'----
plot_impute(dataIn = nottem, showmiss = T)

## ----eval = F------------------------------------------------------------
## # changing the option argument for na.mean
## impute_errors(dataIn = nottem,
##   addl_arg = list(na.mean = list(option = 'mode'))
##   )

## ----eval = F------------------------------------------------------------
## # function to include with impute_errors
## new_imp <- function(In){
##   out <- imputeTS::na.random(In)
##   out <- as.numeric(out)
##   return(out)
## }

## ----eval = F------------------------------------------------------------
## # error metric to include with impute_errors
## pcv <- function(dataIn, imputed)
## {
##   d <- (var(imputed) - var(dataIn)) *
##     100/ var(imputed)
##   d <- as.numeric(d)
##   return(d)
## }

## ----Fig6, fig.cap = "Three datasets used to demonstrate application of \\pkg{imputeTestbench}.  The top dataset, \\code{nrm}, was created with random samples from a normal distribution.  The bottom two datasets are \\code{austres} and \\code{nottem} from the \\pkg{datasets} package. Each dataset has different temporal correlation structures shown at different lags (right column).  The light red shading indicates a threshold beyond which correlations are significant ($\\alpha = 0.05$).", eval = T, message = F, warning = F, fig.height = 6, fig.width = 8, out.width = '\\textwidth', fig.env = 'figure*', echo = F----
set.seed(123)
data(austres)
data(nottem)

n <- 100
smp <- rnorm(n)
nrm <- smp %>% 
  data.frame(
    dts = 1:n, 
    val = .,
    lab = 'Value'
  )

aust <- data.frame(
  dts = as.numeric(time(austres)),
  val = as.numeric(austres)/ 1000,
  lab = 'Pop. (1e3)'
  )

nott <- data.frame(
  dts = as.numeric(time(nottem)),
  val = as.numeric(nottem),
  lab = 'Temp (F)'
  )

dats <- list(
  nrm = nrm, 
  austres = aust, 
  nottem = nott
  ) %>% 
  enframe

tmps <- pmap(dats, function(name, value){
  
  ests <- acf(value$val, plot = FALSE)
  out <- data.frame(
    val = ests$acf[, , 1], 
    lag = ests$lag[, , 1],
    cis = qnorm(0.975) / sqrt(ests$n.used)
    )
    
  cival <- unique(out$cis)
  
  ggplot(out, aes(x = lag, y = val)) +
    geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -cival, ymax = cival), alpha = 0.6, 
      fill = 'lightpink'
    ) +
    geom_bar(stat = 'identity', width = 0.2) + 
    scale_y_continuous(limits = c(-1, 1)) +
    scale_x_continuous(expand = c(0, 0)) + 
    geom_hline(yintercept = 0) + 
    theme_bw() +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    ) + 
    ggtitle(name)

  })

tsplo <- pmap(dats, function(name, value){
  
  lab <- unique(value$lab)
  ggplot(value, aes(x = dts, y = val)) +
    geom_line() + 
    geom_point(size = 0.8) + 
    scale_y_continuous(lab) +
    theme_bw() +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.title.x = element_blank()
    ) + 
    ggtitle(name)
  
  })

grid.arrange(
  arrangeGrob(tsplo[[1]], tsplo[[2]], tsplo[[3]], ncol = 1, bottom = 'Time'),
  arrangeGrob(tmps[[1]], tmps[[2]], tmps[[3]], ncol = 1, left = 'Correlation', bottom = 'Lag'), 
  ncol = 2
)


## ----eval = F------------------------------------------------------------
## # load packages, set seed
## library(tidyverse)
## library(imputeTestbench)
## set.seed(123)
## 
## # create nested list of datasets
## dats <- list(
##   nrm = rnorm(100),
##   aust = austres,
##   nott = nottem
##   ) %>%
##   enframe('nms', 'dataIn')
## 
## # create parameters to vary with imputeTestbench
## prms <- crossing(
##   smps = c('mcar', 'mar'),
##   blck = c(20, 100),
##   nms = dats$nms
##   ) %>%
##   mutate( # blck does not matter for mcar
##     blck = ifelse(smps %in% 'mcar', NA, blck)
##   ) %>%
##   unique
## 
## # join parameters with data
## # map parameter and data to impute_errors
## ests <- prms %>%
##   left_join(dats, by = 'nms') %>%
##   mutate(
##     est = pmap(
##       list(smps = smps, blck = blck, dataIn = dataIn),
##       .f = impute_errors,
##       errorParameter = 'mape'
##       )
##     )

## ----Fig7, fig.cap = "Comparisons of prediction errors for three datasets with different temporal correlation structures (see Figure \\ref{fig:Fig6}).  Missing observations were simulated from the complete datasets as MCAR and MAR with missing chunks of different sizes from 20\\% and 100\\% of the total. The total percentage of missing observations from the complete datasets varied from 10\\% to 90\\%.", eval = T, message = F, warning = F, echo = FALSE, fig.height = 5, fig.width = 7, out.width = '\\textwidth', fig.env = 'figure*'----
# set.seed(123)
# data(austres)
# data(nottem)
# 
# n <- 100
# nrm <- rnorm(n)
# dats <- list(
#   nrm = nrm,
#   aust = austres,
#   nott = nottem
#   ) %>%
#   enframe('nms', 'dataIn')
# 
# smps <- c('mcar', 'mar')
# blck <- c(20, 100)
# nms <- c(dats$nms)
# ests <- crossing(smps, blck, nms) %>%
#   left_join(dats, by = 'nms') %>%
#   mutate(
#     est = pmap(
#       list(smps = smps, blck = blck, dataIn = dataIn),
#       .f = impute_errors,
#       errorParameter = 'mape'
#       )
#     )
# save(ests, file = 'SupportiveCodes/ests.RData', compress = 'xz')

load(file = 'SupportiveCodes/ests.RData')

toplo <- mutate(ests,
  summ = map(ests$est, function(x){

    data.frame(x[-1])
  
    })
  ) %>% 
  select(-est, -dataIn) %>% 
  unnest %>% 
  gather('Methods', 'Mean Absolute Percent Error', na.approx:na.mean) %>% 
  unite('sim', smps, blck, sep = ', ') %>%
  mutate(
    sim = gsub('^mcar, NA$', 'mcar', sim),
    sim = factor(sim, 
      levels = c("mcar", "mar, 20", "mar, 100"), 
      labels = c("'mcar'", "'mar', 20", "'mar', 100")
      ),
    nms = factor(nms, 
      levels = c('nrm', 'aust', 'nott'),
      labels = c('nrm', 'austres', 'nottem'))
  )

ggplot(toplo, aes(x = MissingPercent, y = `Mean Absolute Percent Error`, group = Methods)) + 
  geom_line() +
  facet_grid(nms ~ sim, scales = 'free_y') +
  geom_point(aes(fill = Methods), shape = 21, size = 2.5, alpha = 0.75) +
  scale_x_continuous('Percent of missing observations') + 
  theme_bw() + 
  theme(legend.position = 'top')

## ----Fig8, fig.height = 5, fig.width = 6, out.width = '\\textwidth', fig.cap  = "An example from \\code{plot\\_impute()} of imputed values for the austres dataset using \\code{na.approx}, \\code{na.locf}, and \\code{na.mean}.  Seventy percent of observations were removed for each dataset.  The left column shows the observations removed using MCAR and the right shows the observations removed using MAR.", echo = F, fig.env = 'figure*'----
set.seed(12266)
mytheme <- theme(legend.position = 'none', axis.title.x = element_blank(), axis.title.y = element_blank(), plot.title = element_text(size = 10))
aust <- austres / 1000
p1 <- plot_impute(dataIn = aust, methods = c('na.mean', 'na.locf', 'na.approx'), missPercent = 70, showmiss = T, smps = 'mcar') +
  ggtitle("Removed as 'mcar'")
pleg <- g_legend(p1)
p1 <- p1 + mytheme
p2 <- plot_impute(dataIn = aust, methods = c('na.mean', 'na.locf', 'na.approx'), missPercent = 70, showmiss = T, blck = 100, smps = 'mar') +
  mytheme +
  ggtitle("Removed as 'mar', one chunk")
grid.arrange(
  pleg, ncol = 1, heights = c(0.1, 1), left = 'Pop. (1e3)', bottom = 'Time',
  arrangeGrob(p1, p2, ncol = 2)
)

