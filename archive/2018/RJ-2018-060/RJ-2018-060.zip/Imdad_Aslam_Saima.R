###############################################
#        Multicollinearity Testing            #
###############################################

# mctest package
library(mctest)

x <- Hald[, -1] # regressors
y <- Hald[, 1]  # response variable

######## Section 2.1 ########
## Overal Collinearity Diagnostics measures
mctest(x, y)

## Individual Collinearity Diagnostics measures
mctest(x, y, type = "i")

## only VIF measure
imcdiag(x, y, method = "VIF")

## Individual collinearity diagnostics in 0 or 1 format
imcdiag(x, y, all=TRUE)


###############################################
# Ridge Regression Analysis                   #
###############################################

library(lmridge)

# fit linear ridge regression model
# biasing parameter k varies from 0 to 0.1 with increament of 0.01
# scaling of regressors

# 1) for scaling suggested by belsely and draper & smith 
### Three models are fitted for each scaling method
### In paper results are only for "sc" scaling that is mod1
mod <- lmridge(y~X1+X2+X3+X4, data=as.data.frame(Hald), scaling="sc", 
               K=seq(0, 0.15, 0.001))

# 2) for standardized scaling of regressors
#mod2<-lmridge(y~X1+X2+X3+X4, data=as.data.frame(Hald), K=seq(0, 0.1, 0.01), scaling="scaled")

# 3) for centered scaling of regressors
#mod3<-lmridge(y~X1+X2+X3+X4, data=as.data.frame(Hald), K=seq(0, 0.1, 0.01), scaling="centered")

## Scaled Coefficients for each scaling of regressors
mod$coef # sc scaling of regressors
#mod2$coef # scaled scaling of regressors
#mod3$coef # centered scaling of regressors

## Re-Scaled Coefficients
#coef(mod) # sc scaling of regressors
#coef(mod2) # scaled scaling of regressors
#coef(mod2) # centered scaling of regressors

# ridge coefficients for selected Ks
mod<-lmridge(y~.,as.data.frame(Hald), K=c(0.01, 0.05, 0.5, 0.9, 1))
mod
mod$coef

## Testing of Ridge Coefficients
summary(mod) # sc scaling of regressors
#summary(mod2) # scaled scaling of regressors
#summary(mod3) # centered scaling of regressors

# summary(mod) for K=0.012
summary(lmridge(y~., as.data.frame(Hald), K=0.012))

# Ridge statistics for selected Ks
mod<- lmridge(y~., as.data.frame(Hald), K=c(0, 0.012, 0.1, 0.2))
rstats1(mod)
## Ridge biasing parameter by researchers
kest(mod) # sc scaling of regressors
#kest(mod2) # scaled scaling of regressors
#kest(mod3) # centered scaling of regressors

## Ridge statistics 1
rstats1(mod) # sc scaling of regressors
#rstats1(mod2) # scaled scaling of regressors
#rstats1(mod3) # centered scaling of regressors

## Ridge statistics 2
rstats2(mod) # sc scaling of regressors
#rstats2(mod2) # scaled scaling of regressors
#rstats2(mod3) # centered scaling of regressors

## hat matrix
hatr(mod) # sc scaling of regressors
#hatr(mod2) # scaled scaling of regressors
#hatr(mod3) # centered scaling of regressors

hatr(mod)[[1]] # hat matrix of first given K
diag(hatr(mod)[[1]]) # diagonal element of first given K
#diag(hatr(mod2)[[1]]) # diagonal element of first given K
#diag(hatr(mod3)[[1]]) # diagonal element of first given K

## Ridge predicted values for each biasing parameter
predict(mod)  # sc scaling of regressors
predict(mod, newdata = as.data.frame(Hald[1 : 5 , -1]))
#predict(mod2) # scaled scaling of regressors
#predict(mod3) # centered scaling of regressors

## Ridge fited values
mod$rfit # Ridge fitted values for sc scaling of regressors
#mod2$rfit # Ridge fitted values for scaled scaling of regressors
#mod3$rfit # Ridge fitted values for centered scaling of regressors

## Ridge residuals values for each biasing parameter
resid(mod) # sc scaling of regressors
#residuals(mod2) # scaled scaling of regressors
#residuals(mod3) # centered scaling of regressors

## Model Selection Criteria
infocr(mod) # sc scaling of regressors
#infocr(mod2) # scaled scaling of regressors
#infocr(mod3) # centered scaling of regressors
infocr( lmridge(y~., as.data.frame(Hald), K=c(0, 0.012, 0.1, 0.2) ) )

## Ridge VIF values
vif(mod) # sc scaling of regressors
#vif(mod2) # scaled scaling of regressors
#vif(mod3) # centered scaling of regressors

## Ridge Var-Cov matrix
vcov(mod) # sc scaling of regressors
#vcov(mod2) # scaled scaling of regressors
#vcov(mod3) # centered scaling of regressors

## predicted values for first five rows of X
predict(mod, newdata = as.data.frame(Hald[1:5, -1]))

## Ridge fitted values
#fitted(mod) # sc scaling of regressors
#fitted(mod2) # scaled scaling of regressors
#fitted(mod3) # centered scaling of regressors

## list of objects from lmridgeEst function
#lmridgeEst(y~X1+X2+X3+X4, data=as.data.frame(Hald), K=seq(0, 0.1, 0.01), scaling="sc")


###############################################
# Plotting different ridge related statistics # 
###############################################
######## Ridge coefficients and VIF Plots ########
## Ridge trace
# larger Ks are used
mod <- lmridge(y ~ ., data = as.data.frame(Hald), K = seq(0, 0.5, 0.001))
plot(mod)

## VIF trace
plot(mod, type="vif", abline = TRUE)

## Ridge trace without abline
plot(mod, type="ridge", abline=FALSE)

######## Bias, Variance and MSE plot ########
## for indication vertical line (biasing parameter k) and
## horizontal line (minimum minimum Ridge MSE values corresponding to vertical line)
bias.plot(mod, abline = TRUE)

######## Model Selection Criteria (AIC and BIC) Plot ########
## for indication vertical line (df ridge)
## with vertical line set \code{abline=FALSE}
info.plot(mod, abline = TRUE)

######## Cross-Validation Plot ########
## for indication vertical line (biasing parameter k) and
## horizontal line (minimum respective CV and GCV values corresponding to vertical line)
cv.plot(mod, abline=TRUE)

######## Vinod's measure (ISRM and m-scale) Plots ########
isrm.plot(mod)

######## Miscellaneous Ridge Plots ########
rplots.plot(mod)
